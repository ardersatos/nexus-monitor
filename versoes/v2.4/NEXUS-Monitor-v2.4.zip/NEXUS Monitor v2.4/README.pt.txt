NEXUS // MONITOR  v2.4
========================

Monitor do sistema em tempo real para Windows 10/11, com interface futurista
no browser: CPU, nucleos, RAM, temperaturas, GPU, discos, rede, ventoinhas,
consumo, processos e FPS / latencia dos jogos. Da para abrir no telemovel.
Inclui o Deep Scan (o que ocupa espaco nos discos, limpeza rapida e
desinstalador de programas sem restos), a pagina Performance (otimizacoes
do Windows para jogos, debloat e overlay em jogo) e um teste de velocidade.
Em portugues, ingles, espanhol, frances e alemao.

Ficheiros: README.pt.txt (este) e CHANGELOG.pt.txt (o que mudou em cada
versao). Em ingles: README.txt e CHANGELOG.txt.


INSTALAR (release normal)
-------------------------
1. Extrai o zip (botao direito > "Extrair tudo...").
   IMPORTANTE: nao corras o instalador de dentro do zip.
2. Abre a pasta extraida e faz duplo clique em "INSTALL NEXUS.bat".
3. Responde as perguntas (extras opcionais), ve o resumo, carrega S e
   aceita o aviso de administrador do Windows. O resto e automatico.

O que o instalador faz:
   - Pergunta onde instalar: por defeito em
     AppData\Local\Programs\NEXUS Monitor (ou onde o NEXUS ja estiver), ou
     escolhes outra pasta numa janela (E) ou escreves o caminho (C); e
     criada uma pasta "NEXUS Monitor" la dentro.
   - Pergunta se queres atalho no menu Iniciar e no ambiente de trabalho.
     Fica sempre em Definicoes > Aplicacoes (de onde tambem da para
     desinstalar).
   - Instala o driver PawnIO (assinado, open-source) e descarrega o
     LibreHardwareMonitor do GitHub - le todas as temperaturas, ventoinhas
     e consumos sozinho. Precisa de internet na primeira vez.
   - Cria o NEXUS Monitor.exe no proprio PC.
   - Extras opcionais:
       . Intel PresentMon - FPS e latencia dos jogos
       . gdu - motor do Deep Scan (analisador de disco, open-source)
       . Plugin da Stream Deck - so aparece se a app estiver instalada
   - Fica so uma copia do NEXUS no PC: se houver outras (versoes antigas
     ou instalacoes noutras pastas), mostra-as, passa o que ja tinham
     descarregado para a pasta escolhida e apaga-as no fim. As definicoes
     ficam (estao nos Documentos).
   - No fim apaga-se a si proprio e aos ficheiros extraidos do zip (ja nao
     fazem falta). So apaga o que veio no zip.
   - O antivirus ou alguns anti-cheats de jogos podem avisar por causa do
     driver.


ATUALIZAR (update)
------------------
Cada versao nova sai em dois zips:
   - "NEXUS Monitor vX.Y" - release normal, para instalar de raiz;
   - "NEXUS Monitor vX.Y (update)" - so para quem ja tem o NEXUS.

Para atualizar: extrai o zip do update e corre "UPDATE NEXUS.bat".
   - Procura sozinho onde o NEXUS esta instalado e atualiza la. Nao faz
     perguntas: so tens de carregar em Sim no aviso do Windows.
   - Fecha o NEXUS, copia so o que mudou, apaga o que ja nao faz parte da
     versao nova, atualiza o plugin da Stream Deck se mudou e volta a abrir
     o NEXUS sozinho.
   - No fim apaga-se a si proprio e aos ficheiros do update.
   - Definicoes, tema e chave do telemovel ficam como estavam.

Atualizar sem descarregar nada a mao (a partir da 2.1):
   - O NEXUS procura versoes novas em github.com/ardersatos/nexus-monitor
     ao abrir e de hora a hora, e avisa. Em Opcoes > Geral > Atualizacoes carrega em
     INSTALAR ATUALIZACAO: descarrega o zip certo, confere-o (SHA-256) e
     corre o atualizador sozinho, sem o aviso do Windows.
   - So le um ficheiro publico do GitHub. Nao envia nada sobre ti nem sobre
     o PC. Desliga "Procurar versoes novas no GitHub" e o NEXUS nunca se liga
     ao GitHub.
   - Copia de seguranca (Opcoes > Geral): EXPORTAR guarda num ficheiro as
     opcoes, o tema, os perfis, as medicoes e as sessoes; IMPORTAR repoe-os
     (por exemplo noutro PC). O codigo do telemovel nunca vai no ficheiro.


DEFINICOES
----------
Ficam em Documentos\NEXUS Monitor (settings.ini): opcoes, tema, lingua e a
chave do telemovel. Por isso nao se perdem ao reinstalar ou atualizar, e o
telemovel continua ligado. A chave so muda se carregares em "Nova chave".
O desinstalador pergunta se tambem as queres apagar.
Em OPCOES > GERAL > PASTAS ha botoes para abrir a pasta das definicoes e a pasta
onde o NEXUS esta instalado.


PERFORMANCE (pagina propria - botao PERFORMANCE no topo)
-----------
Otimizacoes do Windows para jogos, feitas pelo proprio NEXUS (registo,
servicos e plano de energia), sem descarregar nada. Vem tudo desligado.
- No topo aparece o hardware deste PC (processador, placa grafica, RAM,
  disco, portatil ou desktop) e as otimizacoes adaptam-se a ele: por
  exemplo, num Ryzen X3D com dois CCDs escondem-se as que estragam a
  escolha dos nucleos com cache 3D, num portatil so mudam o que acontece
  ligado a corrente, e com grafica integrada recomenda-se outras.
- Cada otimizacao diz o que faz, o risco (SEGURO, MODERADO, AVANCADO), se
  precisa de reiniciar e o ganho estimado neste PC (FPS, menos quebras,
  menos latencia...). O ganho e uma estimativa conservadora: varia muito
  de jogo para jogo.
- OTIMIZAR O WINDOWS: mostra tudo o que pode mudar; as recomendadas ja vem
  escolhidas e tiras ou juntas o que quiseres.
- Antes de mudar uma definicao o NEXUS guarda o valor original
  (Documentos\NEXUS Monitor\performance_backup.txt). REPOR volta
  exatamente ao que estava. Ha tambem CRIAR PONTO DE RESTAURO do Windows.
- Debloat do Windows: privacidade e anuncios (telemetria, sugestoes, Bing
  no Iniciar, Copilot, Recall, Widgets...) e as apps que vem com o Windows
  (so aparecem as instaladas; a Loja, Xbox, Fotos, Calculadora, Bloco de
  Notas e Terminal nunca sao tocados; uma app removida volta a instalar-se
  pela Microsoft Store).
- No telemovel a pagina so deixa ver.
- As otimizacoes ficam no Windows mesmo se desinstalares o NEXUS: se
  quiseres o Windows como estava, carrega em REPOR antes de desinstalar.

Mais na pagina Performance:
- Sessoes de jogo: ao fechar um jogo (mais de 1 minuto) fica um resumo com
  o tempo, FPS medio, pior 1%, temperaturas maximas e uso medio.
- Driver da placa grafica: versao, data e idade, com a pagina oficial.
- Modo poupanca (Boost de jogo): PC parado e sem jogo -> plano Equilibrado;
  volta ao teu plano quando mexes no rato ou no teclado.
- RELATORIO DO PC: abre uma pagina com hardware, drivers, discos,
  otimizacoes, medicoes e sessoes, para imprimir ou guardar.
- Caixa de pesquisa no topo para encontrar uma otimizacao ou opcao.
- PLACA GRAFICA (so NVIDIA): consumo, relogio e limite de energia.
- ARRANQUE DO WINDOWS: liga/desliga os programas que abrem com o PC.
- TESTE DE ESTABILIDADE: processador (e RAM) a 100% durante 1 a 10 min.
- Nos perfis por jogo ha LIMITE DE FPS (precisa do RivaTuner Statistics
  Server instalado).
- No overlay: item "Gargalo" (CPU ou GPU) e avisos de temperatura, RAM e
  quedas de FPS.
- VENTOINHAS (modo Completo): curvas ou valor fixo para as ventoinhas da
  placa-mae.
- REDE EM JOGO: ping e o DNS mais rapido. DRIVERS E BIOS. LIGAR A
  DISTANCIA (Wake-on-LAN). O TEU PC VS OUTROS.
- Modo streaming: Alt+Shift+P em qualquer altura.
- Limpeza automatica: no Deep Scan, por baixo da Limpeza rapida.
- Notificacoes no telemovel: Opcoes > Telemovel (app gratis ntfy).

Telemovel e Discord (Opcoes > Telemovel):
- Depois de abrir o link no telemovel: menu do browser > "Adicionar ao ecra
  principal" (fica como uma app).
- "Controlar o PC a partir do telemovel": botoes de musica, volume, overlay,
  RAM, bloquear, suspender, reiniciar e desligar. Da primeira vez aparece
  uma pergunta no PC para aceitar o telemovel.
- Discord: mostra o jogo e os FPS no teu estado. Cria uma aplicacao em
  discord.com/developers/applications e cola o Application ID.
- Stream Deck: na lista de sensores ha "Botoes do NEXUS" (overlay, medir
  FPS, limpar RAM, boost, abrir a Performance).

Na pagina principal ha o cartao HISTORICO (temperaturas e uso das ultimas
1 h, 6 h, 24 h ou 7 dias, guardado 8 dias em Documentos\NEXUS Monitor\
historico). No Deep Scan ha a SAUDE DOS DISCOS (SMART pelo Windows).

Medir FPS:
- Abre o jogo, carrega em MEDIR (com uns segundos para voltares ao jogo) ou
  usa Alt+Shift+M dentro do jogo. O NEXUS grava cada frame e calcula os FPS
  medios, o 1% low, o 0.1% low, o frametime e as quebras.
- Marca uma medicao como BASE e as outras do mesmo jogo mostram a diferenca.
  Para comparar bem, joga sempre a mesma parte do jogo.

Perfis por jogo:
- Um perfil por jogo (pelo nome do .exe): o overlay, a prioridade alta, o
  desempenho maximo e a limpeza da RAM podem seguir o perfil em vez das
  opcoes gerais, e as otimizacoes escolhidas so ficam ligadas enquanto esse
  jogo esta aberto. Ao fechar o jogo tudo volta como estava.
- Cria-se escolhendo um jogo que o NEXUS ja detetou, ou escrevendo o nome do
  .exe. Otimizacoes que precisam de reiniciar nao aparecem nos perfis.

Boost de jogo (precisa da detecao de jogo ligada):
- Prioridade alta para o jogo, plano Desempenho Maximo enquanto jogas e
  limpar a RAM ao abrir um jogo. Ao sair do jogo tudo volta.

Detecao de jogo
  Deteta sozinho quando abres e fechas um jogo (ecra inteiro, janela sem
  bordas a ocupar o ecra, jogos da Steam/Epic/GOG/Xbox/EA/Ubisoft/Riot/
  Battle.net, ou o RivaTuner). Enquanto jogas, poe em PAUSA processos em
  segundo plano que nao fazem falta: atualizadores (Google, Edge, Adobe, Java),
  sincronizacao (OneDrive, Dropbox, iCloud, Google Drive), Ligacao ao
  Telemovel, Widgets, telemetria...
  Nunca toca nas apps que abriste (Steam, Stream Deck, Spotify, Discord,
  browser, OBS, software de RGB...), em nada com janela aberta nem no
  Windows. Nao fecha nada: ao sair do jogo tudo continua onde estava.
  Em "Processos em segundo plano" podes tirar ou juntar outros.

Limpar a RAM automaticamente
  Quando a RAM passa do LIMITE % (30 a 98%), pede as apps para devolverem
  a memoria que nao estao a usar. Nunca com um jogo aberto. Depois de
  limpar espera o tempo que escolheres em ESPERAR antes de poder limpar
  outra vez. O botao "Limpar ja" limpa na hora.


OVERLAY EM JOGO (pagina PERFORMANCE)
---------------
Uma caixa por cima do jogo com FPS, frametime, latencia, CPU, GPU,
temperaturas, RAM, nome do jogo e hora: escolhes o que aparece, o estilo
(lista ou linha), o tamanho e a opacidade. Os cliques passam para o jogo.
- Posicao: arrasta a caixa na miniatura do ecra, usa os botoes dos cantos,
  ou carrega em MOVER NO ECRA e arrasta-a no proprio ecra (duplo clique ou
  Enter para acabar).
- Atalho para mostrar/esconder em qualquer altura: Alt+Shift+O (da para
  mudar ou tirar). Tambem esta no menu do icone.
- "So enquanto jogas" mostra-o sozinho quando um jogo abre.
- Funciona por cima de jogos em janela ou sem bordas. Em ecra inteiro
  exclusivo o Windows nao deixa nenhuma janela por cima: escolhe "Sem
  bordas" nas opcoes de imagem do jogo.


MODO SIMPLES (OPCOES > GERAL)
------------
Na primeira vez que o NEXUS abre pergunta se o queres SIMPLES ou COMPLETO.
O simples mostra so o essencial: processador, memoria, temperaturas, placa
grafica, processos e, na rede, so o download, o upload e o teste de
velocidade. Esconde os IPs, os nucleos, as ventoinhas e os detalhes
tecnicos.


FPS E LATENCIA DOS JOGOS (PresentMon)
-------------------------------------
O PresentMon e uma ferramenta gratuita e open-source da Intel (~1 MB) que
mede os frames de qualquer jogo (DirectX, Vulkan, OpenGL) sem overlay e sem
injetar nada no jogo. Ja nao precisas do RivaTuner.

- So corre enquanto ha um jogo aberto (ecra inteiro, janela sem bordas a
  ocupar o ecra, jogo da Steam/Epic/GOG/Xbox/EA/Ubisoft/Riot/Battle.net, ou
  visto pelo RivaTuner) e desliga 30 s depois de o fechares. Jogos em
  janela pequena fora dessas lojas nao sao detetados.
- O instalador descarrega-o do GitHub da Intel para a pasta do NEXUS
  (pasta "presentmon"). Se ja la estiver, nao volta a descarregar.
- Ao abrires um jogo aparece no site o cartao JOGO com FPS, frametime,
  latencia, media, minimo e maximo. Tambem da para por na Stream Deck.
- Funciona logo, sem configurar nada.
- Se o PresentMon nao estiver disponivel e tiveres o RivaTuner aberto, o
  NEXUS usa o RivaTuner como alternativa (so FPS, sem latencia).
- A "latencia" e o tempo desde que o jogo comeca o frame ate aparecer no
  ecra (depende da placa grafica e do jogo; alguns nao a reportam).


ALERTAS (OPCOES > ALERTAS)
-------------------------
Escolhes os limites de temperatura do CPU e da GPU e de uso da RAM, e quanto
tempo o alerta fica no ecra: FORA DE JOGO (20 s por defeito) e EM JOGO
(12 s por defeito), de 3 a 300 s, e o quao transparente fica em cada caso
(ao mexer no slider, o alerta aparece no canto do ecra para veres como
fica). Quando um passa do limite:
   - aparece uma notificacao do NEXUS no canto do ecra, por cima de tudo
     (tambem de jogos em janela sem bordas). Durante um jogo fica meio
     transparente (55% por defeito) e os cliques passam para o jogo. Fora dos jogos, clicar
     nela abre o monitor;
   - na pagina aparece uma faixa vermelha a pulsar no topo, o cartao em
     causa pisca e o titulo do separador tambem avisa;
   - na Stream Deck, a tecla do sensor em alerta fica com o contorno a
     pulsar devagar e as outras teclas do NEXUS mostram um pequeno sinal.
Jogos em ecra inteiro exclusivo nao deixam nada aparecer por cima - ai so
a Stream Deck e o telemovel mostram o alerta.


ROTA PARA JOGOS (opcional - PERFORMANCE > REDE)
---------------
Parecido com o ExitLag, mas gratis: o trafego de um jogo pode passar pela
rede da Cloudflare (Cloudflare WARP) quando isso baixa o ping.
- Esta desligada ate carregares no botao. Antes de ligar, o NEXUS explica o
  que muda e pede autorizacao. E a unica funcao que liga o PC a um servico
  de fora para alem do normal, e so enquanto a usas.
- O NEXUS instala o WARP sozinho (ficheiro assinado pela Cloudflare),
  descobre o servidor de cada jogo e compara as duas rotas.
- So o trafego do jogo passa pela Cloudflare; o resto fica na ligacao normal.
- A rota nunca muda a meio de uma partida (isso desligava-te do servidor).
  Quando a Cloudflare ganha, liga-se logo que abres o jogo da proxima vez,
  antes de entrares num servidor, e desliga-se quando o fechas.
- Por jogo: Automatico (so se for melhor), Sempre ou Nunca.
- ONDE ESTA O LAG? diz se o atraso esta em casa, na operadora ou longe.
- O WARP nao arranca com o Windows nem abre janelas. Ha botoes para retirar a
  autorizacao e desinstalar o WARP.

TEMAS E ESTILOS (OPCOES > APARENCIA)
---------------
- 25 esquemas de cores (e "cores do meu papel de parede").
- 7 estilos que mudam o aspeto de todas as paginas: Neon, Simples, Terminal
  antigo, Classico (anos 90), Vidro, Blocos e Elegante.
- Combinacoes prontas com um clique (Terminal verde, Windows 98, Simples
  claro, Vidro oceano, Arcade, Papel...).
- Ajustes: letra, cantos, fundo, tamanho, linhas de ecra, brilho e animacoes.
- OS MEUS TEMAS: guarda ate 8 aspetos com nome. EXPORTAR cria um ficheiro
  .json para partilhar; IMPORTAR TEMA aplica o de outra pessoa. Nada vai para
  a internet.

TELEMOVEL
---------
1. O PC e o telemovel tem de estar na mesma rede Wi-Fi / router.
2. No PC abre o NEXUS > OPCOES > TELEMOVEL e liga "Acesso pelo telemovel".
   O Windows pode pedir administrador para abrir a porta 8765 na firewall.
3. Aponta a camara do telemovel ao codigo QR (ou escreve o endereco).
   O link tem uma chave secreta - so quem a tem consegue entrar.
4. "Nova chave" invalida todos os telemoveis que ja tinham acesso.
5. O telemovel fica guardado: mesmo ao fechar o browser ou passarem dias,
   volta a entrar sozinho (ate carregares em "Nova chave").

Notas:
- A rede do Windows tem de estar como "Privada" (Definicoes > Rede e
  Internet > a tua ligacao > Tipo de perfil de rede > Privada).
- O tema, as cores personalizadas, o modo privado, a velocidade de
  atualizacao e as opcoes ficam SINCRONIZADOS: mudas no telemovel e o PC
  muda sozinho (e ao contrario).
- O acesso pelo telemovel (ligar/desligar, nova chave) so se muda no PC.
- Desligar o acesso fecha logo a porta.


STREAM DECK (opcional)
----------------------
Depois de instalar, na app Stream Deck procura a categoria "NEXUS Monitor"
e arrasta "Estatistica do PC" para uma tecla. Em cada tecla escolhes:

  SENSOR - todos os que o NEXUS le no teu PC, por grupos:
    Processador (uso, temperatura, nucleo mais quente, frequencia, consumo)
    Placa grafica (uso, temperatura, VRAM, consumo, CPU+GPU)
    Memoria (RAM %, RAM em GB, memoria virtual)
    Jogo (FPS, frametime, latencia)
    Rede (download, upload) e Discos (leitura, escrita, espaco de cada disco)
    Sistema (processos, tempo ligado, relogio, bateria)
    Temperaturas (todos os sensores: placa, discos, cada nucleo...)
    Ventoinhas (cada uma) e uso de cada thread do CPU
  ESTILO - Grafico (valor + historico de ~50 s), Anel (mostrador) ou
           Numero (grande). Visual futurista, com as cores do tema.

O nome do sensor aparece sempre no topo da tecla. As cores seguem o tema.
Carregar na tecla abre o monitor (ou arranca o NEXUS, se estiver fechado).
Abre o NEXUS antes de configurar as teclas para veres todos os sensores.

Ja tens o NEXUS instalado e so queres o plugin? Corre
"INSTALL STREAM DECK ADDON.bat" (esta tambem na pasta do NEXUS).
Se o PC nao tiver a Stream Deck, o instalador e o atualizador nao deixam
os ficheiros dela na pasta do NEXUS: se a instalares depois, corre o
instalador da release normal outra vez.


SIGNALRGB (opcional - so aparece se tiveres o SignalRGB)
---------------------------------------------------------
OPCOES > SIGNALRGB > "Cores do SignalRGB": as cores principal e secundaria
do NEXUS seguem o efeito que esta a dar no SignalRGB, em tempo real (nas
paginas, no menu e icone da bandeja e na Stream Deck).
- Ao ligar, o NEXUS poe o plugin dele em Documentos\WhirlwindFX\Plugins.
  Se for preciso, fecha e abre o SignalRGB uma vez: o "NEXUS Monitor" tem
  de aparecer em Dispositivos e no Layout.
- Atraso das cores: 0 ms segue o efeito ao instante; mais alto e mais suave.
- So trabalha enquanto ha alguma coisa do NEXUS a vista (pagina, menu do
  icone ou teclas na Stream Deck).
- Funciona com o SignalRGB gratuito. O plugin fica so neste PC: envia as
  cores so para 127.0.0.1 e nao usa a internet.


DEEP SCAN (analisador de disco)
------------------------------
Botao DEEP SCAN no topo (ou menu do icone). Usa o gdu (open-source, MIT),
que so corre quando carregas em ANALISAR e fecha-se sozinho no fim.

Tudo o que e discos e espaco esta aqui, em 4 separadores:
- ANALISAR: escolher um disco ou pasta -> mapa, tipos de ficheiro,
  conteudo das pastas e maiores ficheiros (o gestor de ficheiros).
- LIMPAR: limpeza rapida (e automatica), ficheiros duplicados, espaco da
  Steam e espaco escondido (hibernacao, pontos de restauro, paginacao).
- SAUDE: saude dos discos (SMART, com o motivo dos avisos), vida dos SSD,
  otimizar discos (TRIM/desfragmentar), velocidade e poupar o SSD.
- PROGRAMAS: desinstalar programas (com restos) e programas esquecidos.

- Escolhe um disco ou escreve uma pasta: mapa do disco, tipos de ficheiro,
  conteudo de cada pasta e os maiores ficheiros.
- Navegar: VOLTAR, PASTA ACIMA, INICIO (tambem Backspace e o botao de
  voltar do rato). Clicar numa pasta entra nela.
- Botao direito num ficheiro/pasta: abrir no Explorador, enviar para a
  Reciclagem ou eliminar permanentemente (com aviso de que e irrecuperavel).
- Pastas importantes: o NEXUS diz os possiveis efeitos antes de eliminar.
  Pastas que partiam o Windows (Windows, raiz do disco, Programas, AppData,
  perfil do utilizador, ficheiros de arranque) ficam bloqueadas; as outras
  pedem "Percebo os riscos".
- Ficheiros ocultos: so o que TU escondeste aparece censurado (sem nome e
  sem dar para abrir/eliminar). O que o Windows e os programas escondem
  aparece normal. Para mostrar tudo: OPCOES > PRIVACIDADE > Mostrar
  ficheiros ocultos (so no PC).
- LIMPEZA RAPIDA: mostra logo quanto liberta neste PC e limpa com 1 clique:
  ficheiros temporarios, Reciclagem, cache do Windows Update, cache de
  shaders da placa grafica, miniaturas, relatorios de erros e registos
  antigos. Ficheiros em uso ficam.
- DESINSTALAR PROGRAMAS: lista o que esta instalado (e as apps da Loja, se
  quiseres), com pesquisa e ordenar por nome, tamanho ou data.
    1. Escolhe um ou varios e carrega em DESINSTALAR (modo silencioso =
       sem janelas, quando o programa deixa).
    2. Corre o desinstalador do proprio programa. Jogos da Steam e outros
       launchers: confirma na janela deles, o NEXUS espera que acabe.
    3. Depois procura os restos: pastas, atalhos, registo, arranque,
       servicos, tarefas agendadas e firewall. O que e de certeza do
       programa vem marcado; o resto aparece como VERIFICA (ve antes).
    4. Ficheiros vao para a Reciclagem e o registo e guardado em .reg em
       Documentos\NEXUS Monitor\Backups do desinstalador (com um
       registo.txt do que foi feito). Para repor uma chave, abre o .reg.
  REMOCAO FORCADA: para programas com o desinstalador estragado - nao corre
  o desinstalador, so procura e apaga os restos.
  Nunca toca no Windows, em pastas de outros programas nem no NEXUS.
- Eliminar, limpar e desinstalar so funcionam no PC (no telemovel nem
  aparecem).


SEPARADORES DA PERFORMANCE (organizacao da 2.3)
-----------------------------------------------
Cada cartao tem um botao (i) com a explicacao. O botao SIMPLES no topo
mostra explicacoes muito simples em cada cartao.
- INICIO: resumo das otimizacoes, cenarios, o teu PC vs outros, O MEU PC
  (imagem para partilhar, sem numeros de serie) e ANTES E DEPOIS DE MUDAR
  PECAS (marca o dia da mudanca e compara os FPS das sessoes).
- JOGOS: medir FPS, sessoes, ENGASGOS E CARREGAMENTOS (frames muito mais
  lentos que os outros, por sessao e com os minutos piores; tempo ate ao
  primeiro frame por disco), boost, FECHAR PROGRAMAS AO JOGAR (fecham ao
  abrir um jogo e reabrem no fim, sem administrador), OVERLAYS ATIVOS (so
  ve os programas abertos, nao mexe no jogo), RAM, perfis, overlay e ABRIR
  JOGOS PELO TELEMOVEL (Steam e jogos ja jogados; precisa do Controlo do PC).
- OTIMIZAR: otimizacoes, NVIDIA APP (desliga a app, o overlay, o arranque,
  o servico NvContainerLocalSystem e as tarefas dela; o driver e o Painel
  de Controlo ficam; "Manter desligada" volta a desligar ao abrir o NEXUS
  e de 30 em 30 min; REPOR volta tudo atras), arranque do Windows, MENU DO
  BOTAO DIREITO (esconde entradas de outros programas; menu classico no
  Windows 11), TAREFAS AGENDADAS ESCONDIDAS (as que nao sao do Windows,
  com aviso nas suspeitas) e debloat. Nova otimizacao: "Desligar mais
  servicos dispensaveis" (Registo remoto, Insider, Controlo parental,
  Pagamentos NFC, Rastreio de atalhos).
- HARDWARE (so as pecas): verificacoes, placa grafica, ventoinhas, FONTE
  DE ALIMENTACAO (escreves os watts da tua; diz se chega e avisa perto do
  limite), O QUE LIMITA O BOOST (plano de energia do Windows e razoes da
  placa NVIDIA), INVENTARIO E GARANTIAS (pecas, numeros de serie, data de
  compra e anos de garantia; exporta CSV), BATERIAS DOS PERIFERICOS
  (Bluetooth; aviso abaixo de 15%) e SIMULADOR DE UPGRADE.
- DISCOS: passou para o DEEP SCAN (separadores LIMPAR, SAUDE e PROGRAMAS).
- REDE: ping e DNS, PRIORIDADE DE REDE PARA O JOGO (QoS/DSCP 46; so ajuda
  se o router respeitar), TESTE DE LAG COM A REDE CHEIA (bufferbloat, nota
  de A+ a F; usa o teste de velocidade da Cloudflare), WI-FI (sinal, canal
  e redes vizinhas), QUEM ESTA A USAR A INTERNET (so le a tabela de
  ligacoes do Windows), transferencias, Wake-on-LAN, outros PCs e
  PARTILHAR COM OUTROS (link so de leitura e copiar definicoes de outro PC
  da casa com um codigo de 6 numeros, valido 5 minutos e uma vez).
- SISTEMA (o Windows): SEGURANCA DO WINDOWS (ativacao, antivirus,
  firewall, atualizacoes, UAC, Arranque Seguro, TPM, BitLocker), VERSAO DO
  WINDOWS (e ate quando tem atualizacoes), ULTIMAS ATUALIZACOES (desinstalar
  uma), BIOS E DRIVERS (desinstalar drivers antigos), DRIVERS GRAFICOS
  ANTIGOS (apagar versoes guardadas; a que esta em uso nunca), APPS PADRAO
  (aviso se mudarem sem pedires), AVISOS e programas como administrador.
- PROBLEMAS (novo): tudo o que serve quando algo corre mal - PRIMEIROS
  SOCORROS, crashes e erros, teste de estabilidade, teste da RAM, pasta
  termica da placa, reparar o Windows, arranque lento, o que nao deixa o PC
  dormir e ZIP DE SUPORTE.

Avisos novos (ligam/desligam em Sistema > AVISOS): ventoinha que parou,
PC quente parado (CPU 70 C / GPU 65 C durante 3 min sem fazer nada), fonte
no limite, bateria fraca de perifericos e apps padrao mudadas.

MAIS FERRAMENTAS DA 2.3:
- TEMPO DE ECRA (Inicio): minutos por programa em primeiro plano, so quando
  mexes no PC. Nao grava titulos de janelas nem o que fazes. 30 dias.
- ATRASO DO CLIQUE (Jogos): do clique do rato ate a imagem sair do PC
  (precisa do PresentMon). Abaixo de 20 ms e muito bom.
- GRAFICO DE SESSAO (Jogos > Sessoes, botao do grafico) e FPS POR EURO no
  simulador de upgrade (escreves o preco da peca).
- PASTA TERMICA DA PLACA (Hardware): compara o nucleo com o hotspot da
  placa em carga e avisa se a diferenca cresce com os meses.
- TESTE DA RAM (Hardware): usa o Diagnostico de Memoria do Windows (o PC
  reinicia, ~15 min); o resultado aparece no cartao.
- DRIVERS (Hardware > BIOS e drivers): botao DESINSTALAR nos drivers antigos
  de dispositivos (pnputil, sem forcar). Aviso semanal se o driver grafico
  tiver mais de 60 dias.
- ESPACO DA STEAM (Discos): cache de shaders e downloads a meio; so limpa
  com a Steam fechada. PROGRAMAS ESQUECIDOS tem botao DESINSTALAR (usa o
  desinstalador do Deep Scan).
- O QUE NAO DEIXA O PC DORMIR (Sistema): programas a impedir a suspensao,
  o que o acordou e que dispositivos o podem acordar (podes tirar).
- PRIMEIROS SOCORROS (Sistema): passo a passo para ecra azul, FPS baixos,
  temperaturas, lag, crashes, disco com aviso, etc.
- ZIP DE SUPORTE (Sistema): ficheiro para mandares a quem te ajuda, sem
  nome de utilizador, nomes de PC nem numeros de serie. Fica nas
  Transferencias; nada e enviado.
- PROCESSOS: clica no nome de um processo para saber o que e e se e
  seguro fechar. ESTADO NUMA FRASE no topo do painel.
- DEEP SCAN: o aviso de saude dos discos diz o motivo (falha prevista,
  setores trocados ou a espera, erros no cabo, arranque do motor).
- OTIMIZAR: cada categoria mostra o ganho estimado ja ativo e o que falta.

PAINEL NUMA JANELA: em OPCOES > GERAL abre o painel em ecra inteiro no 2.o
monitor (modo apresentacao) ou pequeno por cima do jogo. Atalho em jogo:
Alt+Shift+N (funciona em jogos em janela sem bordas). Usa o Edge, Chrome, Brave
ou Vivaldi num perfil proprio, sem administrador.
CORES DO PAPEL DE PAREDE: em OPCOES > APARENCIA, um botao tira as duas
cores principais do teu papel de parede.

STREAM DECK: teclas novas no grupo Musica - o que esta a tocar com a capa
(carrega para tocar/pausar), seguinte, anterior e volume (carrega para
silenciar). Funciona com Spotify, browsers e outras apps que usam os
controlos de multimedia do Windows.

TESTE DE VELOCIDADE (cartao REDE)
---------------------------------
Botao TESTAR VELOCIDADE: download, upload e latencia (em repouso e com
carga) com o servidor Cloudflare mais proximo. So corre quando carregas e
gasta algumas centenas de MB de dados. Fica guardado o ultimo resultado.


NOVIDADES E TUTORIAL
--------------------
- Botao NOVIDADES no topo: o que mudou em cada versao (ponto aceso quando
  ha coisas novas).
- O tutorial aparece na primeira vez que abres o NEXUS (PC ou telemovel).
  Para o rever: OPCOES > GERAL > "Ver o tutorial outra vez".


COMANDO (testar comando)
------------------------
Na pagina PERFORMANCE, cartao COMANDO (tambem em "Testar comando" no menu
do icone). So corre quando chegas a esse cartao e ha um comando ligado. Headsets e outros
aparelhos que o browser mostra como comando ficam escondidos (da para os
mostrar).
   - O desenho muda conforme o comando: Xbox, PlayStation ou Nintendo, com
     os nomes certos dos botoes.
   - Sticks com rasto e zona morta ajustavel, gatilhos em %, todos os
     botoes com contagem (os ja testados ficam a verde) e todos os eixos.
   - Testes: DRIFT (larga os sticks: mede quanto se mexem sozinhos) e
     CIRCULARIDADE (roda os sticks na borda: mostra o desenho e o erro).
   - Vibracao: motor fraco, forte e gatilhos, com forca e duracao. Se o
     browser nao conseguir, o NEXUS faz vibrar direto no PC: comandos Xbox
     e XInput (a maioria dos de PC) e DualShock 4 / DualSense (USB e
     Bluetooth).
   - Polling: quantas leituras por segundo chegam ao browser.
Funciona no PC (localhost). O browser so ve o comando depois de carregares
num botao.

LINGUAS
-------
OPCOES > APARENCIA > IDIOMA: Automatico (lingua do Windows / telemovel),
Portugues, English, Espanol, Francais, Deutsch. Muda a pagina, o Deep Scan,
o menu e o painel do icone, as notificacoes e as teclas da Stream Deck.


USAR
----
- O NEXUS fica junto ao relogio (icones ocultos ^). O icone muda de cor
  com o tema.
  Rato por cima: painel com CPU, RAM, GPU e jogo, atualizado a cada segundo.
  Clique esquerdo: abre o monitor (se ja estiver aberto, traz a janela
  para a frente em vez de abrir outra).
  Clique direito: CPU, RAM, GPU e jogo de relance, liga/desliga as opcoes
  (arranque, alertas, limpeza da RAM, detecao de jogo, telemovel), muda o
  tema, "Limpar a RAM agora" e Sair.
- No topo da pagina:
    DEEP SCAN -> analisador de disco, limpeza rapida e desinstalar programas
    PERFORMANCE -> otimizacoes para jogos, boost, RAM, overlay e debloat
    NOVIDADES -> o que mudou em cada versao
    OPCOES   -> em separadores: APARENCIA (tema, cores e lingua),
                GERAL (modo simples, iniciar com o Windows, iniciar minimizado,
                abrir como administrador sem aviso,
                desfocar dados pessoais (IP, MAC, nome do PC),
                esconder os dados de rede, mostrar ficheiros ocultos,
                velocidade de atualizacao (0,1 a 10 s; 0,1 e 0,25 s
                aparecem a vermelho porque gastam mais CPU),
                alertas de temperatura do CPU / GPU e uso de RAM,
                acesso pelo telemovel (QR code),
                SignalRGB (se tiveres), ver o tutorial outra vez, pastas)
    (botao)  -> desligar o NEXUS
- Processos: ordena por CPU ou por memoria.


DESINSTALAR
-----------
No proprio NEXUS: OPCOES > GERAL > DESINSTALAR, ou no menu do icone junto
ao relogio > "Desinstalar o NEXUS...". Tambem em Definicoes > Aplicacoes >
NEXUS Monitor > Desinstalar (ou o "UNINSTALL NEXUS.bat" na pasta do NEXUS). Mostra o que vai ser removido,
pergunta se queres remover tambem o driver PawnIO e as definicoes
(Documentos\NEXUS Monitor) e depois: fecha o NEXUS e o PresentMon
(retomando os processos em pausa), remove o arranque automatico, a regra
da firewall, o atalho, a entrada nas Aplicacoes, o plugin da Stream Deck
(e as definicoes, se escolheres) e apaga a pasta do NEXUS.


PROBLEMAS
---------
- Erro CS2001 ao instalar: nao extraiste o zip. Ve o passo 1.
- "O NEXUS nao esta instalado" ao atualizar: o update so serve para quem
  ja tem o NEXUS - usa a release normal.
- Aviso azul "O Windows protegeu o seu PC": Mais informacoes > Executar.
- Sem temperatura do CPU: volta a correr o instalador com internet (o
  LibreHardwareMonitor e descarregado na instalacao).
- O cartao JOGO mostra um programa que nao e jogo (ex.: wallpaper animado):
  aparece o programa com mais frames; ao abrires o jogo passa para ele.
- Telemovel nao abre: mesma rede? Rede do Windows como "Privada"? Acesso
  ligado nas OPCOES? Experimenta "Nova chave" e ler o QR outra vez.
- Tecla da Stream Deck mostra "OFF": o NEXUS esta fechado - carrega nela.
