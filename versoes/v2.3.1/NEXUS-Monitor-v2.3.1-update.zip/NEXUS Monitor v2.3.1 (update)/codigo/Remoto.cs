// NEXUS // MONITOR - app do telemóvel (ícone no ecrã principal), controlo do PC a partir do telemóvel e estado no Discord.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace Nexus
{
    // ------------------------------------------------------------ app do telemóvel: manifesto e ícones (sem nada a descarregar)
    static class AppTel
    {
        static readonly Dictionary<int, byte[]> icons = new Dictionary<int, byte[]>();
        public static string Manifest()
        {
            return "{\"name\":\"NEXUS Monitor\",\"short_name\":\"NEXUS\",\"start_url\":\"/\",\"scope\":\"/\",\"display\":\"standalone\",\"orientation\":\"any\"," +
                   "\"background_color\":\"#05070d\",\"theme_color\":\"#05070d\",\"description\":\"NEXUS Monitor\",\"icons\":[" +
                   "{\"src\":\"/nexus-icon-192.png\",\"sizes\":\"192x192\",\"type\":\"image/png\",\"purpose\":\"any maskable\"}," +
                   "{\"src\":\"/nexus-icon-512.png\",\"sizes\":\"512x512\",\"type\":\"image/png\",\"purpose\":\"any maskable\"}]," +
                   "\"shortcuts\":[{\"name\":\"Performance\",\"url\":\"/perf\"},{\"name\":\"Deep Scan\",\"url\":\"/disk\"}]}";
        }
        // o losango do NEXUS desenhado aqui, nas cores do tema
        public static byte[] Icon(int size)
        {
            lock (icons)
            {
                byte[] b;
                if (icons.TryGetValue(size, out b)) return b;
                Color bg = ColorTranslator.FromHtml("#05070d"), c1;
                try { c1 = AppSettings.ThemeColor("c1"); } catch { c1 = ColorTranslator.FromHtml("#3ee8ff"); }
                using (Bitmap bmp = new Bitmap(size, size))
                using (Graphics g = Graphics.FromImage(bmp))
                {
                    g.SmoothingMode = SmoothingMode.AntiAlias;
                    g.Clear(bg);
                    float c = size / 2f, r = size * 0.30f, r2 = size * 0.105f, w = size * 0.06f;
                    using (Pen p = new Pen(c1, w)) g.DrawPolygon(p, new[] { new PointF(c, c - r), new PointF(c + r, c), new PointF(c, c + r), new PointF(c - r, c) });
                    using (SolidBrush br = new SolidBrush(c1)) g.FillPolygon(br, new[] { new PointF(c, c - r2), new PointF(c + r2, c), new PointF(c, c + r2), new PointF(c - r2, c) });
                    using (MemoryStream ms = new MemoryStream()) { bmp.Save(ms, ImageFormat.Png); b = ms.ToArray(); }
                }
                icons[size] = b;
                return b;
            }
        }
    }

    // ------------------------------------------------------------ controlar o PC a partir do telemóvel
    // Desligado por defeito. Cada telemóvel (IP) tem de ser aceite uma vez no próprio PC.
    static class Controlo
    {
        [DllImport("user32.dll")] static extern bool LockWorkStation();
        [DllImport("user32.dll")] static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);
        static readonly object lk = new object();
        static readonly HashSet<string> asking = new HashSet<string>();
        static readonly HashSet<string> refused = new HashSet<string>();

        static bool Allowed(string ip) { return ("," + AppSettings.RemoteCtlIps + ",").Contains("," + ip + ","); }

        public static string Do(string action, bool remote, string ip)
        {
            if (remote)
            {
                if (!AppSettings.RemoteCtl) return "{\"ok\":false,\"error\":\"off\"}";
                if (!Allowed(ip))
                {
                    lock (lk)
                    {
                        if (refused.Contains(ip)) return "{\"ok\":false,\"error\":\"refused\"}";
                        if (!asking.Contains(ip)) { asking.Add(ip); Thread t = new Thread(() => Ask(ip)) { IsBackground = true }; t.SetApartmentState(ApartmentState.STA); t.Start(); }
                    }
                    return "{\"ok\":false,\"pending\":true}";
                }
            }
            if (action.StartsWith("game:")) return Ferr.GameLaunch(action.Substring(5));   // abrir um jogo a partir do telemóvel (2.3)
            string msg;
            switch (action)
            {
                case "shutdown": Run("shutdown", "/s /t 15 /c \"NEXUS: o PC desliga-se daqui a 15 s (shutdown /a cancela)\""); msg = "O PC desliga-se daqui a 15 segundos."; break;
                case "restart": Run("shutdown", "/r /t 15 /c \"NEXUS: o PC reinicia daqui a 15 s (shutdown /a cancela)\""); msg = "O PC reinicia daqui a 15 segundos."; break;
                case "cancel": Run("shutdown", "/a"); msg = "Cancelado."; break;
                case "sleep": ThreadPool.QueueUserWorkItem(delegate { Thread.Sleep(1500); try { Application.SetSuspendState(PowerState.Suspend, false, false); } catch { } }); msg = "O PC vai suspender."; break;
                case "lock": LockWorkStation(); msg = "PC bloqueado."; break;
                case "overlay":
                    AppSettings.OverlayOn = !AppSettings.OverlayOn; try { AppSettings.Save(); } catch { }
                    Program.Ui(GameOverlay.Apply); msg = AppSettings.OverlayOn ? "Overlay ligado." : "Overlay desligado."; break;
                case "ram": Optimizer.Clean(false); msg = "RAM limpa."; break;
                case "play": Key(0xB3); msg = "▶❚❚"; break;
                case "next": Key(0xB0); msg = "⏭"; break;
                case "prev": Key(0xB1); msg = "⏮"; break;
                case "volup": Key(0xAF); msg = "🔊"; break;
                case "voldown": Key(0xAE); msg = "🔉"; break;
                case "mute": Key(0xAD); msg = "🔇"; break;
                default: return "{\"ok\":false,\"error\":\"acao\"}";
            }
            return "{\"ok\":true,\"message\":" + Js.S(Lang.L(msg)) + ",\"overlay\":" + (AppSettings.OverlayOn ? "true" : "false") + "}";
        }
        static void Key(byte vk) { keybd_event(vk, 0, 0, UIntPtr.Zero); keybd_event(vk, 0, 2, UIntPtr.Zero); }
        static void Run(string exe, string args)
        {
            try { Process.Start(new ProcessStartInfo(exe, args) { UseShellExecute = false, CreateNoWindow = true }); } catch { }
        }
        // pergunta no PC (uma vez por telemóvel)
        static void Ask(string ip)
        {
            try
            {
                DialogResult r = MessageBox.Show(Lang.L("Um telemóvel na tua rede quer controlar este PC (desligar, suspender, música, overlay).") + "\n\nIP: " + ip + "\n\n" + Lang.L("Permitir?"),
                    "NEXUS Monitor", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2, MessageBoxOptions.DefaultDesktopOnly);
                lock (lk)
                {
                    if (r == DialogResult.Yes)
                    {
                        List<string> l = AppSettings.RemoteCtlIps.Split(',').Where(x => x != "").ToList();
                        if (!l.Contains(ip)) l.Add(ip);
                        AppSettings.RemoteCtlIps = string.Join(",", l.ToArray());
                        try { AppSettings.Save(); } catch { }
                    }
                    else refused.Add(ip);
                }
            }
            catch { }
            finally { lock (lk) asking.Remove(ip); }
        }
        public static string Forget()
        {
            lock (lk) { AppSettings.RemoteCtlIps = ""; refused.Clear(); }
            try { AppSettings.Save(); } catch { }
            return "{\"ok\":true}";
        }
    }

    // ------------------------------------------------------------ estado no Discord ("A jogar X · 144 FPS"), pelo Discord aberto neste PC
    // Precisa de um Application ID do Discord (Opções). Desligado por defeito.
    static class Discord
    {
        static NamedPipeClientStream pipe;
        static System.Threading.Timer timer;
        static string lastGame, status = "desligado";
        static long since;
        static readonly object lk = new object();
        public static string Status { get { return status; } }

        public static void Start() { timer = new System.Threading.Timer(delegate { try { Tick(); } catch { } }, null, 15000, 15000); }
        public static void Stop() { lock (lk) { Close(); status = "desligado"; } }

        static void Close() { try { if (pipe != null) pipe.Dispose(); } catch { } pipe = null; lastGame = null; }

        static void Write(int op, string json)
        {
            byte[] p = Encoding.UTF8.GetBytes(json), h = new byte[8];
            BitConverter.GetBytes(op).CopyTo(h, 0); BitConverter.GetBytes(p.Length).CopyTo(h, 4);
            pipe.Write(h, 0, 8); pipe.Write(p, 0, p.Length); pipe.Flush();
        }
        static string Read()
        {
            byte[] h = new byte[8]; int got = 0;
            while (got < 8) { int n = pipe.Read(h, got, 8 - got); if (n <= 0) throw new IOException("fechado"); got += n; }
            int len = BitConverter.ToInt32(h, 4);
            if (len < 0 || len > 65536) throw new IOException("tamanho");
            byte[] b = new byte[len]; got = 0;
            while (got < len) { int n = pipe.Read(b, got, len - got); if (n <= 0) throw new IOException("fechado"); got += n; }
            return Encoding.UTF8.GetString(b);
        }
        static bool Connect()
        {
            for (int i = 0; i < 10; i++)
            {
                try
                {
                    NamedPipeClientStream p = new NamedPipeClientStream(".", "discord-ipc-" + i, PipeDirection.InOut);
                    p.Connect(300);
                    pipe = p;
                    Write(0, "{\"v\":1,\"client_id\":" + Js.S(AppSettings.DiscordId) + "}");
                    string r = Read();
                    if (r.Contains("\"READY\"")) return true;
                    status = "o Discord recusou o Application ID"; Close(); return false;
                }
                catch { Close(); }
            }
            status = "o Discord não está aberto";
            return false;
        }

        static void Tick()
        {
            lock (lk)
            {
                if (!AppSettings.DiscordOn || string.IsNullOrEmpty(AppSettings.DiscordId)) { if (pipe != null) Close(); status = "desligado"; return; }
                string game = Optimizer.GameName;
                if (pipe == null && game == null) { status = "à espera de um jogo"; return; }
                try
                {
                    if (pipe == null && !Connect()) return;
                    if (game != lastGame) since = (long)(DateTime.UtcNow - new DateTime(1970, 1, 1)).TotalSeconds;
                    string act;
                    if (game == null) act = "null";
                    else
                    {
                        string fps = "";
                        string g = PresentMonReader.Json(); if (g == "null") g = Rtss.Json();
                        System.Text.RegularExpressions.Match m = System.Text.RegularExpressions.Regex.Match(g, "\"fps\":([0-9.]+)");
                        if (AppSettings.DiscordFps && m.Success) fps = Math.Round(double.Parse(m.Groups[1].Value, System.Globalization.CultureInfo.InvariantCulture)) + " FPS";
                        act = "{\"details\":" + Js.S(Nice(game)) + (fps != "" ? ",\"state\":" + Js.S(fps) : "") + ",\"timestamps\":{\"start\":" + since + "}}";
                    }
                    Write(1, "{\"cmd\":\"SET_ACTIVITY\",\"args\":{\"pid\":" + Process.GetCurrentProcess().Id + ",\"activity\":" + act + "},\"nonce\":\"" + Guid.NewGuid().ToString("N") + "\"}");
                    Read();
                    lastGame = game;
                    status = game == null ? "ligado (sem jogo)" : "a mostrar " + Nice(game);
                }
                catch (Exception e) { Close(); status = "erro: " + e.Message; }
            }
        }
        static string Nice(string exe)
        {
            if (string.IsNullOrEmpty(exe)) return "";
            string n = exe.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) ? exe.Substring(0, exe.Length - 4) : exe;
            n = n.Replace("-Win64-Shipping", "").Replace("-win64-shipping", "").Replace("_", " ");
            return n.Length > 0 ? char.ToUpper(n[0]) + n.Substring(1) : n;
        }
    }
}
