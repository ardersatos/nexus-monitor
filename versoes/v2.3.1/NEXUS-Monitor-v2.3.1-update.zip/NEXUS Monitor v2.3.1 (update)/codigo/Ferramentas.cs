// NEXUS // MONITOR 2.3 - base das ferramentas novas: definições próprias (nexus23.ini), PowerShell com cache,
// vigias em segundo plano (ventoinha parada, PC quente parado, picos de energia, periféricos com bateria fraca,
// apps padrão mudadas, engasgos e tempo de carregamento dos jogos, fechar programas ao jogar, prioridade de rede)
// e o encaminhamento dos pedidos /api/x/...
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

namespace Nexus
{
    // ------------------------------------------------------------ definições da 2.3 (ficheiro à parte para não mexer no settings.ini)
    static class Cfg23
    {
        static readonly object lk = new object();
        static Dictionary<string, string> d;
        static string F { get { return Path.Combine(AppSettings.Dir, "nexus23.ini"); } }
        static void Load()
        {
            if (d != null) return;
            d = new Dictionary<string, string>();
            try
            {
                if (File.Exists(F))
                    foreach (string l in File.ReadAllLines(F, Encoding.UTF8)) { int i = l.IndexOf('='); if (i > 0) d[l.Substring(0, i)] = l.Substring(i + 1); }
            }
            catch { }
        }
        public static string Get(string k, string def) { lock (lk) { Load(); string v; return d.TryGetValue(k, out v) ? v : def; } }
        public static bool On(string k, bool def) { return Get(k, def ? "1" : "0") == "1"; }
        public static int Int(string k, int def) { int v; return int.TryParse(Get(k, ""), out v) ? v : def; }
        public static void Set(string k, string v)
        {
            lock (lk)
            {
                Load();
                if (v == null) d.Remove(k); else d[k] = v.Replace("\r", " ").Replace("\n", " ");
                try { Directory.CreateDirectory(AppSettings.Dir); File.WriteAllLines(F, d.OrderBy(x => x.Key).Select(x => x.Key + "=" + x.Value).ToArray(), new UTF8Encoding(true)); } catch { }
            }
        }
        public static string[] Keys(string prefix) { lock (lk) { Load(); return d.Keys.Where(k => k.StartsWith(prefix)).ToArray(); } }
    }

    // ------------------------------------------------------------ PowerShell (ficheiros .ps1, nunca comandos codificados) com cache
    static class Ps23
    {
        static readonly Dictionary<string, KeyValuePair<DateTime, string>> cache = new Dictionary<string, KeyValuePair<DateTime, string>>();
        public static string Run(string name, string script, int ms, int cacheSecs)
        {
            KeyValuePair<DateTime, string> c;
            lock (cache) if (cacheSecs > 0 && cache.TryGetValue(name, out c) && (DateTime.UtcNow - c.Key).TotalSeconds < cacheSecs) return c.Value;
            string o = PsFile.Run(name, script, ms);
            int a = o.IndexOfAny(new[] { '{', '[' });
            o = a < 0 ? "null" : o.Substring(a);
            lock (cache) cache[name] = new KeyValuePair<DateTime, string>(DateTime.UtcNow, o);
            return o;
        }
        public static void Drop(string name) { lock (cache) cache.Remove(name); }
        // comando simples (sc, schtasks, pnputil, defrag…) - devolve a saída
        public static string Cmd(string exe, string args, int ms)
        {
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo(exe, args) { UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true, RedirectStandardError = true };
                using (Process p = Process.Start(psi))
                {
                    string o = p.StandardOutput.ReadToEnd() + p.StandardError.ReadToEnd();
                    if (!p.WaitForExit(ms)) try { p.Kill(); } catch { }
                    return o.Trim();
                }
            }
            catch (Exception ex) { return ex.Message; }
        }
        public static string Ok(bool ok, string msg) { return "{\"ok\":" + (ok ? "true" : "false") + (msg != null ? ",\"msg\":" + Js.S(msg) : "") + "}"; }
    }

    // ------------------------------------------------------------ vigias em segundo plano (chamadas pelo Historico a cada 2 s)
    static partial class Vigias23
    {
        static readonly object lk = new object();
        static int tick;
        static string lastGame;
        static DateTime gameStart, firstFrame;
        static int gamePid;
        static string gameExe;
        // engasgos: média móvel do tempo por frame; um engasgo é um frame 2,5x mais lento e acima de 25 ms
        static double ema;
        static int stutters;
        static readonly Dictionary<int, int> stutMin = new Dictionary<int, int>();
        static DateTime lastStut = DateTime.MinValue;

        public static void Frame(float ft)
        {
            if (ft <= 0 || ft > 5000) return;
            DateTime now = DateTime.UtcNow;
            lock (lk)
            {
                if (lastGame == null) return;
                if (firstFrame == DateTime.MinValue) firstFrame = now;
                if (ema <= 0) { ema = ft; return; }
                if (ft > ema * 2.5 && ft > 25 && (now - lastStut).TotalMilliseconds > 250)
                {
                    stutters++; lastStut = now;
                    int m = (int)(now - gameStart).TotalMinutes;
                    int c; stutMin.TryGetValue(m, out c); stutMin[m] = c + 1;
                }
                ema = ema * 0.97 + Math.Min(ft, ema * 4) * 0.03;
            }
        }

        public static void Tick(string game, double cpu, double? cpuT, double? gpu, double? gpuT, double fps)
        {
            tick++;
            // ---- início e fim de jogo
            if (game != lastGame)
            {
                string old = lastGame;
                if (old != null) try { GameEnd(old); } catch { }
                lock (lk) { lastGame = game; stutters = 0; stutMin.Clear(); ema = 0; firstFrame = DateTime.MinValue; gameStart = DateTime.UtcNow; gamePid = 0; gameExe = null; }
                if (game != null) try { GameStart(game); } catch { }
            }
            try { Fan(); } catch { }
            try { Tick2(game, gpu); } catch { }
            try { HotIdle(game, cpu, cpuT, gpu, gpuT); } catch { }
            try { Power(); } catch { }
            if (tick % 300 == 15) ThreadPool.QueueUserWorkItem(delegate { try { Ferr.PeriphCheck(); } catch { } try { Ferr.DefaultsCheck(); } catch { } });
            if (tick % 900 == 30 && Cfg23.On("nvkeep", false)) ThreadPool.QueueUserWorkItem(delegate { try { NvApp.Off(true); } catch { } });
        }

        public static void Alert(string title, string msg)
        {
            Program.Ui(delegate { try { AlertToast.Show(title, msg); } catch { } });
        }

        // ---- jogo: carregamento, prioridade de rede, fechar programas
        static void GameStart(string game)
        {
            Process gp = null;
            try
            {
                foreach (Process p in Process.GetProcessesByName(game)) { if (gp == null || p.StartTime > gp.StartTime) gp = p; }
            }
            catch { }
            DateTime started = DateTime.UtcNow;
            string exe = null;
            if (gp != null) { try { started = gp.StartTime.ToUniversalTime(); exe = gp.MainModule.FileName; } catch { } }
            lock (lk) { gameStart = started; gamePid = gp != null ? gp.Id : 0; gameExe = exe; }
            if (exe != null) Cfg23.Set("gexe_" + game.ToLowerInvariant(), exe);
            if (Cfg23.On("qos", false) && exe != null) ThreadPool.QueueUserWorkItem(delegate { try { Ferr.QosEnsure(Path.GetFileName(exe)); } catch { } });
            if (Cfg23.On("closeon", false)) ThreadPool.QueueUserWorkItem(delegate { try { Ferr.CloseApps(); } catch { } });
        }

        static void GameEnd(string game)
        {
            int st; string mins, load = "", drive = "";
            List<KeyValuePair<int, int>> worst;
            lock (lk)
            {
                st = stutters;
                worst = stutMin.OrderByDescending(x => x.Value).Take(5).OrderBy(x => x.Key).ToList();
                mins = ((DateTime.UtcNow - gameStart).TotalMinutes).ToString("0.#", CultureInfo.InvariantCulture);
                if (firstFrame != DateTime.MinValue && firstFrame > gameStart) { double s = (firstFrame - gameStart).TotalSeconds; if (s > 1 && s < 900) load = s.ToString("0.#", CultureInfo.InvariantCulture); }
                if (gameExe != null && gameExe.Length > 2) drive = gameExe.Substring(0, 2).ToUpperInvariant();
            }
            double dm; double.TryParse(mins, NumberStyles.Float, CultureInfo.InvariantCulture, out dm);
            if (dm >= 1)
            {
                string line = game.Replace("|", "/") + "|" + DateTime.Now.ToString("yyyy-MM-dd HH:mm") + "|" + mins + "|" + st + "|" +
                              string.Join(",", worst.Select(x => (x.Key + 1) + ":" + x.Value).ToArray()) + "|" + load + "|" + drive;
                try
                {
                    string f = Path.Combine(AppSettings.Dir, "sessoes23.txt");
                    List<string> all = File.Exists(f) ? File.ReadAllLines(f, Encoding.UTF8).ToList() : new List<string>();
                    all.Add(line);
                    if (all.Count > 400) all = all.Skip(all.Count - 400).ToList();
                    File.WriteAllLines(f, all.ToArray(), new UTF8Encoding(true));
                }
                catch { }
            }
            if (Cfg23.On("closeon", false)) ThreadPool.QueueUserWorkItem(delegate { try { Thread.Sleep(3000); Ferr.ReopenApps(); } catch { } });
        }

        public static string SessJson()
        {
            StringBuilder sb = new StringBuilder("{\"ok\":true,\"live\":");
            lock (lk)
            {
                if (lastGame == null) sb.Append("null");
                else sb.Append("{\"game\":").Append(Js.S(lastGame)).Append(",\"stutters\":").Append(stutters)
                       .Append(",\"mins\":").Append(Js.N((DateTime.UtcNow - gameStart).TotalMinutes))
                       .Append(",\"load\":").Append(firstFrame != DateTime.MinValue && firstFrame > gameStart ? Js.N((firstFrame - gameStart).TotalSeconds) : "null").Append('}');
            }
            sb.Append(",\"list\":[");
            try
            {
                string f = Path.Combine(AppSettings.Dir, "sessoes23.txt");
                if (File.Exists(f))
                {
                    bool first = true;
                    foreach (string l in File.ReadAllLines(f, Encoding.UTF8).Reverse().Take(120))
                    {
                        string[] c = l.Split('|'); if (c.Length < 7) continue;
                        if (!first) sb.Append(','); first = false;
                        sb.Append("{\"game\":").Append(Js.S(c[0])).Append(",\"when\":").Append(Js.S(c[1])).Append(",\"mins\":").Append(Js.S(c[2]))
                          .Append(",\"stutters\":").Append(Js.S(c[3])).Append(",\"worst\":").Append(Js.S(c[4])).Append(",\"load\":").Append(Js.S(c[5])).Append(",\"drive\":").Append(Js.S(c[6])).Append('}');
                    }
                }
            }
            catch { }
            return sb.Append("]}").ToString();
        }

        // ---- ventoinha que parou (só as que já se viram a rodar; as que estão sempre a 0 nem aparecem)
        static readonly Dictionary<string, int> fanSeen = new Dictionary<string, int>();
        static readonly HashSet<string> fanAlerted = new HashSet<string>();
        static void Fan()
        {
            if (tick % 3 != 0 || !Cfg23.On("al_fan", true)) return;
            List<object[]> rows = Embedded.LastRows;
            if (rows == null) return;
            foreach (object[] r in rows)
            {
                if (Convert.ToString(r[2]) != "Fan") continue;
                string id = r[1] + " · " + r[3];
                double v = Convert.ToDouble(r[4]);
                int seen; fanSeen.TryGetValue(id, out seen);
                if (v > 200) { fanSeen[id] = Math.Min(seen + 1, 100); fanAlerted.Remove(id); continue; }
                if (v <= 0 && seen >= 10 && !fanAlerted.Contains(id))
                {
                    fanAlerted.Add(id);
                    Alert(Lang.L("NEXUS · Ventoinha parada"), Lang.L("Esta ventoinha estava a rodar e parou:") + " " + r[3] + ". " + Lang.L("Se não a mandaste parar, vê se tem pó ou um cabo solto."));
                }
            }
        }

        // ---- PC quente sem estar a fazer nada (pó, ventoinhas fracas, algo escondido a trabalhar)
        static int idleTicks; static DateTime lastHot = DateTime.MinValue;
        static void HotIdle(string game, double cpu, double? cpuT, double? gpu, double? gpuT)
        {
            if (!Cfg23.On("al_hotidle", true)) return;
            bool idle = game == null && cpu < 10 && (!gpu.HasValue || gpu.Value < 10);
            idleTicks = idle ? idleTicks + 1 : 0;
            if (idleTicks < 90) return;   // 3 min parado
            bool hot = (cpuT.HasValue && cpuT.Value >= 70) || (gpuT.HasValue && gpuT.Value >= 65);
            if (hot && (DateTime.UtcNow - lastHot).TotalHours >= 2)
            {
                lastHot = DateTime.UtcNow;
                Alert(Lang.L("NEXUS · PC quente parado"), Lang.L("O PC está quente sem estar a fazer nada") + " (CPU " + (cpuT.HasValue ? Math.Round(cpuT.Value) + " °C" : "–") + ", GPU " + (gpuT.HasValue ? Math.Round(gpuT.Value) + " °C" : "–") + "). " +
                      Lang.L("Pode ser pó, ventoinhas devagar ou a pasta térmica gasta."));
            }
        }

        // ---- energia: pico da fonte
        public static double PeakW; public static DateTime PeakWhen;
        static DateTime lastPow = DateTime.MinValue;
        static void Power()
        {
            double? c = Stats.CpuPowerNow, g = Stats.GpuPowerNow;
            if (!c.HasValue && !g.HasValue) return;
            double tot = (c ?? 0) + (g ?? 0) + Ferr.RestW();
            if (tot > PeakW) { PeakW = tot; PeakWhen = DateTime.Now; }
            int psu = Cfg23.Int("psu_w", 0);
            if (psu > 0 && Cfg23.On("al_power", true) && tot > psu * 0.9 && (DateTime.UtcNow - lastPow).TotalMinutes >= 15)
            {
                lastPow = DateTime.UtcNow;
                Alert(Lang.L("NEXUS · Fonte no limite"), Lang.L("O PC chegou a cerca de") + " " + Math.Round(tot) + " W " + Lang.L("de uma fonte de") + " " + psu + " W. " +
                      Lang.L("Se o PC se desligar sozinho em jogo, a fonte pode ser a causa."));
            }
        }
    }
}
