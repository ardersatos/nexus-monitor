@echo off
chcp 65001 >NUL
setlocal EnableExtensions
call :nxlang
setlocal EnableExtensions EnableDelayedExpansion
title !T_1!
cd /d "%~dp0"
for /F %%a in ('echo prompt $E ^| cmd') do set "ESC=%%a"
set "C=%ESC%[96m" & set "M=%ESC%[95m" & set "G=%ESC%[92m" & set "Y=%ESC%[93m" & set "R=%ESC%[91m" & set "D=%ESC%[90m" & set "B=%ESC%[1m" & set "N=%ESC%[0m"
set "HR=%D%  ────────────────────────────────────────────────────────────%N%"
set "DIR=%~dp0"
if "%DIR:~-1%"=="\" set "DIR=%DIR:~0,-1%"
set "PLUG=%APPDATA%\Elgato\StreamDeck\Plugins\com.nexus.monitor.sdPlugin"
set "CFG=%USERPROFILE%\Documents\NEXUS Monitor"
for /f "usebackq delims=" %%d in (`powershell -NoProfile -Command "[Environment]::GetFolderPath('MyDocuments')"`) do set "CFG=%%d\NEXUS Monitor"

rem ---- precisa de administrador (tarefa agendada, firewall, driver)
net session >NUL 2>NUL
if errorlevel 1 (
  echo.
  echo   %Y%!T_4!%N% !T_3! %B%!T_2!%N%.
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b 0
)

rem ================================================================ CONFIRMAR
cls
echo.
echo   %R%◆%N% %B%NEXUS MONITOR%N%  %D%!T_5!%N%
echo %HR%
echo.
echo   !T_6!
echo.
echo     %D%·%N% !T_8! %D%!T_7!%N%
echo     %D%·%N% !T_9!
if exist "%PLUG%" echo     %D%·%N% !T_10!
echo     %D%·%N% !T_11! %D%%DIR%%N%
echo.
set "PAWN="
call :temPawn && set "PAWN=1"
if defined PAWN (
  echo   !T_13! %C%PawnIO%N% !T_12!
  echo   %D%!T_14!%N%
  choice /c !K_YN! /n /m "  %C%»%N% !T_15! "
)
set "RMPAWN="
if defined PAWN if not errorlevel 2 set "RMPAWN=1"
echo.
set "RMCFG="
if not exist "%CFG%" goto confirmar
echo   !T_16! %D%%CFG%%N%
echo   %D%!T_17!%N%
choice /c !K_YN! /n /m "  %C%»%N% !T_18! "
if not errorlevel 2 set "RMCFG=1"
echo.
:confirmar
echo %HR%
choice /c !K_YN! /n /m "  %R%»%N% !T_19! "
if errorlevel 2 goto cancelado

rem ================================================================ REMOVER
cls
echo.
echo   %R%◆%N% %B%NEXUS MONITOR%N%  %D%!T_20!%N%
echo %HR%
echo.
set /a TOTAL=4, I=0
if exist "%PLUG%" set /a TOTAL+=1
if defined RMPAWN set /a TOTAL+=1

call :passo "!T_21!"
call :fecharNexus
call :ok "!T_22!"

call :passo "!T_23!"
schtasks /delete /tn "NEXUS Monitor" /f >NUL 2>NUL
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "NEXUS Monitor" /f >NUL 2>NUL
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\NEXUS Monitor" /f >NUL 2>NUL
netsh advfirewall firewall delete rule name="NEXUS Monitor" >NUL 2>NUL
for /f "usebackq delims=" %%s in (`powershell -NoProfile -Command "[Environment]::GetFolderPath('Programs')"`) do del "%%s\NEXUS Monitor.lnk" >NUL 2>NUL
for /f "usebackq delims=" %%s in (`powershell -NoProfile -Command "[Environment]::GetFolderPath('Desktop')"`) do del "%%s\NEXUS Monitor.lnk" >NUL 2>NUL
rem plugin do SignalRGB (cores do tema)
for /f "usebackq delims=" %%s in (`powershell -NoProfile -Command "[Environment]::GetFolderPath('MyDocuments')"`) do del "%%s\WhirlwindFX\Plugins\NEXUS_Monitor.js" >NUL 2>NUL
rmdir /s /q "%LOCALAPPDATA%\NEXUS" >NUL 2>NUL
call :ok "!T_24!"

call :passo "!T_25!"
if defined RMCFG (
  rmdir /s /q "%CFG%" >NUL 2>NUL
  if exist "%CFG%" (call :falha "!T_27! %CFG%") else (call :ok "!T_26!")
) else (
  call :ok "!T_28!"
)

if not exist "%PLUG%" goto pawn
call :passo "!T_29!"
set "SDEXE="
if exist "streamdeck\procurar_streamdeck.ps1" for /f "usebackq delims=" %%p in (`powershell -NoProfile -ExecutionPolicy Bypass -File "streamdeck\procurar_streamdeck.ps1"`) do set "SDEXE=%%p"
taskkill /im "StreamDeck.exe" /f >NUL 2>NUL
taskkill /im "NexusDeck.exe" /f >NUL 2>NUL
timeout /t 2 /nobreak >NUL
rmdir /s /q "%PLUG%" >NUL 2>NUL
if defined SDEXE explorer.exe "%SDEXE%"
if exist "%PLUG%" (call :falha "!T_27!") else (call :ok "!T_30!")

:pawn
if not defined RMPAWN goto pasta
call :passo "!T_31!"
where winget >NUL 2>NUL && winget uninstall --id namazso.PawnIO -e --silent --accept-source-agreements >NUL 2>NUL
call :temPawn || (call :ok "!T_30!" & goto pasta)
rem o winget não resolveu: usa o desinstalador registado no Windows
powershell -NoProfile -Command "$e = Get-ItemProperty 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*','HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*' -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -like 'PawnIO*' } | Select-Object -First 1; $c = if ($e.QuietUninstallString) { $e.QuietUninstallString } else { $e.UninstallString }; if ($c) { Start-Process -FilePath 'cmd.exe' -ArgumentList '/c', $c -Wait }" >NUL 2>NUL
call :temPawn && (call :falha "!T_32!") || call :ok "!T_30!"

:pasta
call :passo "!T_33!"
call :ok "!T_34!"
echo.
echo %HR%
echo   %G%%B%!T_35!%N%
echo   %D%!T_36!%N%
echo %HR%
echo.
set "RM=%TEMP%\nexus_desinstalar.bat"
> "%RM%" echo @echo off
>>"%RM%" echo timeout /t 2 /nobreak ^>NUL
>>"%RM%" echo rmdir /s /q "%DIR%"
>>"%RM%" echo if exist "%DIR%" ( timeout /t 3 /nobreak ^>NUL ^& rmdir /s /q "%DIR%" )
rem a última linha apaga o próprio script sem o erro "The batch file cannot be found"
>>"%RM%" echo (goto) 2^>NUL ^& del "%%~f0"
timeout /t 5 >NUL
cd /d "%TEMP%"
rem cmd /c: a janela fecha sozinha quando acabar
start "" /min cmd /c ""%RM%""
exit

:cancelado
echo.
echo   %D%!T_37!%N%
timeout /t 3 >NUL
exit /b 0

rem ================================================================ FUNÇÕES
:passo
set /a I+=1
set "PNOME=%~1                         "
<NUL set /p "=%N%   %D%[%I%/%TOTAL%]%N%  %PNOME:~0,24%"
exit /b 0

:ok
echo %G%✓%N% %D%%~1%N%
exit /b 0

:falha
echo %R%✗%N% %~1
exit /b 0

rem fecha o NEXUS com calma (retoma apps em pausa pelo modo jogo) e só depois à força
:fecharNexus
curl -s -m 3 -X POST http://127.0.0.1:8765/api/shutdown >NUL 2>NUL
timeout /t 2 /nobreak >NUL
taskkill /im "NEXUS Monitor.exe" /f >NUL 2>NUL
taskkill /im "PresentMon.exe" /f >NUL 2>NUL
timeout /t 1 /nobreak >NUL
exit /b 0

:temPawn
powershell -NoProfile -Command "if (Get-ItemProperty 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*','HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*' -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -like 'PawnIO*' }) { exit 0 } else { exit 1 }" >NUL 2>NUL
exit /b %errorlevel%

rem ================================================================ LÍNGUA (gerado na build)
:nxlang
set "NXL=en"
for /f "usebackq delims=" %%l in (`powershell -NoProfile -Command "(Get-UICulture).TwoLetterISOLanguageName"`) do set "NXL=%%l"
if defined NEXUS_LANG set "NXL=%NEXUS_LANG%"
if /i not "%NXL%"=="pt" if /i not "%NXL%"=="es" if /i not "%NXL%"=="fr" if /i not "%NXL%"=="de" set "NXL=en"
goto nxl_%NXL%
:nxl_pt
set "K_YN=SN" & set "K_SEC=SEC" & set "K_S1=S" & set "K_S2=E" & set "K_S3=C"
set "T_1=NEXUS Monitor · Desinstalar"
set "T_2=Sim"
set "T_3=No aviso do Windows carrega em"
set "T_4=!"
set "T_5=· desinstalar"
set "T_6=Vai ser removido:"
set "T_7=(fecha-o, mesmo que esteja aberto)"
set "T_8=o NEXUS Monitor"
set "T_9=o arranque automático, a regra da firewall e os atalhos"
set "T_10=o plugin da Stream Deck"
set "T_11=esta pasta:"
set "T_12=também está instalado."
set "T_13=O driver"
set "T_14=Outros programas podem usá-lo - FanControl, OpenRGB, LibreHardwareMonitor..."
set "T_15=Remover também o PawnIO? (S/N):"
set "T_16=As definições estão em"
set "T_17=Tema, opções e a chave do telemóvel. Se ficarem, voltam ao reinstalar."
set "T_18=Apagar também as definições? (S/N):"
set "T_19=Desinstalar o NEXUS agora? (S/N):"
set "T_20=· a desinstalar"
set "T_21=Fechar o NEXUS"
set "T_22=fechado"
set "T_23=Arranque e atalhos"
set "T_24=arranque, firewall, menu Iniciar e Aplicações"
set "T_25=Definições"
set "T_26=apagadas"
set "T_27=não consegui apagar"
set "T_28=ficam em Documentos\NEXUS Monitor"
set "T_29=Plugin Stream Deck"
set "T_30=removido"
set "T_31=Driver PawnIO"
set "T_32=remove em Definições - Aplicações - PawnIO"
set "T_33=Pasta do NEXUS"
set "T_34=vai ser apagada ao fechar esta janela"
set "T_35=✓ NEXUS desinstalado."
set "T_36=Se o ícone ainda aparecer junto ao relógio, passa-lhe o rato por cima."
set "T_37=Cancelado - nada foi alterado."
exit /b 0
:nxl_en
set "K_YN=YN" & set "K_SEC=HBT" & set "K_S1=H" & set "K_S2=B" & set "K_S3=T"
set "T_1=NEXUS Monitor · Uninstall"
set "T_2=Yes"
set "T_3=In the Windows prompt, click"
set "T_4=!"
set "T_5=· uninstall"
set "T_6=This will be removed:"
set "T_7=(closes it, even if it is open)"
set "T_8=NEXUS Monitor"
set "T_9=autostart, the firewall rule and the shortcuts"
set "T_10=the Stream Deck plugin"
set "T_11=this folder:"
set "T_12=is also installed."
set "T_13=The driver"
set "T_14=Other programs may use it - FanControl, OpenRGB, LibreHardwareMonitor..."
set "T_15=Also remove PawnIO? (Y/N):"
set "T_16=Settings are in"
set "T_17=Theme, options and the phone key. If you keep them, they come back when you reinstall."
set "T_18=Also delete the settings? (Y/N):"
set "T_19=Uninstall NEXUS now? (Y/N):"
set "T_20=· uninstalling"
set "T_21=Close NEXUS"
set "T_22=closed"
set "T_23=Autostart and shortcuts"
set "T_24=autostart, firewall, Start menu and Apps"
set "T_25=Settings"
set "T_26=deleted"
set "T_27=couldn't delete"
set "T_28=kept in Documents\NEXUS Monitor"
set "T_29=Stream Deck plugin"
set "T_30=removed"
set "T_31=PawnIO driver"
set "T_32=remove it in Settings - Apps - PawnIO"
set "T_33=NEXUS folder"
set "T_34=will be deleted when this window closes"
set "T_35=✓ NEXUS uninstalled."
set "T_36=If the icon still shows next to the clock, hover the mouse over it."
set "T_37=Cancelled - nothing was changed."
exit /b 0
:nxl_es
set "K_YN=SN" & set "K_SEC=AEC" & set "K_S1=A" & set "K_S2=E" & set "K_S3=C"
set "T_1=NEXUS Monitor · Desinstalar"
set "T_2=Sí"
set "T_3=En el aviso de Windows pulsa"
set "T_4=!"
set "T_5=· desinstalar"
set "T_6=Se va a quitar:"
set "T_7=(lo cierra, aunque esté abierto)"
set "T_8=NEXUS Monitor"
set "T_9=el inicio automático, la regla del firewall y los accesos directos"
set "T_10=el plugin de Stream Deck"
set "T_11=esta carpeta:"
set "T_12=también está instalado."
set "T_13=El driver"
set "T_14=Otros programas pueden usarlo - FanControl, OpenRGB, LibreHardwareMonitor..."
set "T_15=¿Quitar también PawnIO? (S/N):"
set "T_16=Los ajustes están en"
set "T_17=Tema, opciones y la clave del móvil. Si se quedan, vuelven al reinstalar."
set "T_18=¿Borrar también los ajustes? (S/N):"
set "T_19=¿Desinstalar NEXUS ahora? (S/N):"
set "T_20=· desinstalando"
set "T_21=Cerrar NEXUS"
set "T_22=cerrado"
set "T_23=Inicio y accesos"
set "T_24=inicio, firewall, menú Inicio y Aplicaciones"
set "T_25=Ajustes"
set "T_26=borrados"
set "T_27=no pude borrar"
set "T_28=se quedan en Documentos\NEXUS Monitor"
set "T_29=Plugin de Stream Deck"
set "T_30=quitado"
set "T_31=Driver PawnIO"
set "T_32=quítalo en Configuración - Aplicaciones - PawnIO"
set "T_33=Carpeta de NEXUS"
set "T_34=se borrará al cerrar esta ventana"
set "T_35=✓ NEXUS desinstalado."
set "T_36=Si el icono sigue junto al reloj, pasa el ratón por encima."
set "T_37=Cancelado - no se ha cambiado nada."
exit /b 0
:nxl_fr
set "K_YN=ON" & set "K_SEC=ICS" & set "K_S1=I" & set "K_S2=C" & set "K_S3=S"
set "T_1=NEXUS Monitor · Désinstaller"
set "T_2=Oui"
set "T_3=Dans l'alerte de Windows, clique sur"
set "T_4=!"
set "T_5=· désinstaller"
set "T_6=Sera supprimé :"
set "T_7=(le ferme, même s'il est ouvert)"
set "T_8=NEXUS Monitor"
set "T_9=le démarrage automatique, la règle du pare-feu et les raccourcis"
set "T_10=le plugin Stream Deck"
set "T_11=ce dossier :"
set "T_12=est aussi installé."
set "T_13=Le pilote"
set "T_14=D'autres programmes peuvent l'utiliser - FanControl, OpenRGB, LibreHardwareMonitor..."
set "T_15=Supprimer aussi PawnIO ? (O/N) :"
set "T_16=Les réglages sont dans"
set "T_17=Thème, options et clé du téléphone. Si tu les gardes, elles reviennent à la réinstallation."
set "T_18=Supprimer aussi les réglages ? (O/N) :"
set "T_19=Désinstaller NEXUS maintenant ? (O/N) :"
set "T_20=· désinstallation"
set "T_21=Fermer NEXUS"
set "T_22=fermé"
set "T_23=Démarrage et raccourcis"
set "T_24=démarrage, pare-feu, menu Démarrer et Applications"
set "T_25=Réglages"
set "T_26=supprimés"
set "T_27=suppression impossible"
set "T_28=conservés dans Documents\NEXUS Monitor"
set "T_29=Plugin Stream Deck"
set "T_30=supprimé"
set "T_31=Pilote PawnIO"
set "T_32=supprime-le dans Paramètres - Applications - PawnIO"
set "T_33=Dossier NEXUS"
set "T_34=sera supprimé à la fermeture de cette fenêtre"
set "T_35=✓ NEXUS désinstallé."
set "T_36=Si l'icône apparaît encore près de l'horloge, passe la souris dessus."
set "T_37=Annulé - rien n'a été modifié."
exit /b 0
:nxl_de
set "K_YN=JN" & set "K_SEC=HWE" & set "K_S1=H" & set "K_S2=W" & set "K_S3=E"
set "T_1=NEXUS Monitor · Deinstallieren"
set "T_2=Ja"
set "T_3=Klicke in der Windows-Abfrage auf"
set "T_4=!"
set "T_5=· deinstallieren"
set "T_6=Wird entfernt:"
set "T_7=(schließt es, auch wenn es offen ist)"
set "T_8=NEXUS Monitor"
set "T_9=Autostart, Firewall-Regel und Verknüpfungen"
set "T_10=das Stream-Deck-Plugin"
set "T_11=dieser Ordner:"
set "T_12=ist auch installiert."
set "T_13=Der Treiber"
set "T_14=Andere Programme nutzen ihn evtl. - FanControl, OpenRGB, LibreHardwareMonitor..."
set "T_15=PawnIO auch entfernen? (J/N):"
set "T_16=Die Einstellungen liegen in"
set "T_17=Theme, Optionen und Handy-Schlüssel. Wenn sie bleiben, sind sie nach Neuinstallation wieder da."
set "T_18=Einstellungen auch löschen? (J/N):"
set "T_19=NEXUS jetzt deinstallieren? (J/N):"
set "T_20=· wird deinstalliert"
set "T_21=NEXUS schließen"
set "T_22=geschlossen"
set "T_23=Autostart und Verknüpfungen"
set "T_24=Autostart, Firewall, Startmenü und Apps"
set "T_25=Einstellungen"
set "T_26=gelöscht"
set "T_27=konnte nicht löschen"
set "T_28=bleiben in Dokumente\NEXUS Monitor"
set "T_29=Stream-Deck-Plugin"
set "T_30=entfernt"
set "T_31=PawnIO-Treiber"
set "T_32=entferne es unter Einstellungen - Apps - PawnIO"
set "T_33=NEXUS-Ordner"
set "T_34=wird beim Schließen dieses Fensters gelöscht"
set "T_35=✓ NEXUS deinstalliert."
set "T_36=Wenn das Symbol noch neben der Uhr ist, fahre mit der Maus darüber."
set "T_37=Abgebrochen - nichts wurde geändert."
exit /b 0
