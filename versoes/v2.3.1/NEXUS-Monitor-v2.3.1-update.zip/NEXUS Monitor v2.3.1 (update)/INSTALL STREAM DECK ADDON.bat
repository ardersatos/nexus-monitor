@echo off
chcp 65001 >NUL
setlocal EnableExtensions
call :nxlang
setlocal EnableExtensions EnableDelayedExpansion
title !T_1!
cd /d "%~dp0"
for /F %%a in ('echo prompt $E ^| cmd') do set "ESC=%%a"
set "C=%ESC%[96m" & set "M=%ESC%[95m" & set "G=%ESC%[92m" & set "Y=%ESC%[93m" & set "R=%ESC%[91m" & set "D=%ESC%[90m" & set "B=%ESC%[1m" & set "N=%ESC%[0m"
set "HR=%D%  ────────────────────────────────────────────────────────────%N%"

cls
echo.
echo   %M%◆%N% %B%NEXUS MONITOR%N%  %D%!T_2!%N%
echo %HR%
echo   %D%!T_3!%N%
echo.

if not exist "streamdeck\NexusDeck.cs" (
  echo   %R%✗%N% !T_4!
  goto erro
)
set "SDEXE="
if exist "streamdeck\procurar_streamdeck.ps1" for /f "usebackq delims=" %%p in (`powershell -NoProfile -ExecutionPolicy Bypass -File "streamdeck\procurar_streamdeck.ps1"`) do set "SDEXE=%%p"
if not defined SDEXE for /f "usebackq delims=" %%p in (`powershell -NoProfile -Command "(Get-Process StreamDeck -ErrorAction SilentlyContinue | Select-Object -First 1).Path"`) do set "SDEXE=%%p"
rem a pasta da Stream Deck existe: a app está instalada (mesmo que noutro sítio)
if not defined SDEXE if exist "%APPDATA%\Elgato\StreamDeck\Plugins" set "SDEXE=?"
if not defined SDEXE (
  echo   %R%✗%N% !T_5!
  goto erro
)
set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
set "PLUGSRC=%~dp0streamdeck\com.nexus.monitor.sdPlugin"
set "PLUGDST=%APPDATA%\Elgato\StreamDeck\Plugins\com.nexus.monitor.sdPlugin"

rem já está instalado e igual? então não mexe na Stream Deck
set "PLUGHASH="
for /f "usebackq delims=" %%h in (`powershell -NoProfile -Command "((Get-FileHash -Algorithm SHA256 -LiteralPath 'streamdeck\NexusDeck.cs','streamdeck\com.nexus.monitor.sdPlugin\pi.html','streamdeck\com.nexus.monitor.sdPlugin\manifest.json' | ForEach-Object Hash) -join '').Substring(0,40)"`) do set "PLUGHASH=%%h"
set "PLUGHASH=%PLUGHASH%@%~dp0"
set "OLDHASH="
if exist "%PLUGDST%\nexus_build.txt" set /p OLDHASH=<"%PLUGDST%\nexus_build.txt"
if exist "%PLUGDST%\NexusDeck.exe" if "%OLDHASH%"=="%PLUGHASH%" (
  echo   %G%✓%N% !T_6!
  echo.
  timeout /t 5 >NUL
  exit /b 0
)

<NUL set /p "=%N%   %D%[1/2]%N%  !T_7!           "
del "%PLUGSRC%\NexusDeck.exe" >NUL 2>NUL
"%CSC%" /nologo /codepage:65001 /target:winexe /optimize+ /out:"%PLUGSRC%\NexusDeck.exe" /r:System.Drawing.dll /r:System.Web.Extensions.dll /r:System.Core.dll "streamdeck\NexusDeck.cs" > erro_deck.txt 2>&1
if not exist "%PLUGSRC%\NexusDeck.exe" (
  echo %R%✗%N% !T_8!
  type erro_deck.txt
  goto erro
)
del erro_deck.txt >NUL 2>NUL
> "%PLUGSRC%\nexus_build.txt" echo %PLUGHASH%
if exist "%~dp0NEXUS Monitor.exe" (
  > "%PLUGSRC%\nexus_path.txt" echo %~dp0NEXUS Monitor.exe
) else if exist "%LOCALAPPDATA%\Programs\NEXUS Monitor\NEXUS Monitor.exe" (
  > "%PLUGSRC%\nexus_path.txt" echo %LOCALAPPDATA%\Programs\NEXUS Monitor\NEXUS Monitor.exe
) else (
  powershell -NoProfile -Command "$p = (Get-Process 'NEXUS Monitor' -ErrorAction SilentlyContinue | Select-Object -First 1).Path; if ($p) { Set-Content -LiteralPath '%PLUGSRC%\nexus_path.txt' -Value $p }" >NUL 2>NUL
)
echo %G%✓%N% %D%!T_9!%N%

<NUL set /p "=%N%   %D%[2/2]%N%  !T_10!  "
taskkill /im "StreamDeck.exe" /f >NUL 2>NUL
taskkill /im "NexusDeck.exe" /f >NUL 2>NUL
timeout /t 2 /nobreak >NUL
if exist "%PLUGDST%" rmdir /s /q "%PLUGDST%" >NUL 2>NUL
xcopy "%PLUGSRC%" "%PLUGDST%\" /e /i /y /q >NUL
if not "%SDEXE%"=="?" explorer.exe "%SDEXE%"
if not exist "%PLUGDST%\NexusDeck.exe" (
  echo %R%✗%N% !T_11!
  goto erro
)
echo %G%✓%N% %D%!T_12!%N%
echo.
echo %HR%
echo   %G%%B%!T_14!%N%  !T_13! %C%NEXUS Monitor%N%.
echo %HR%
echo.
timeout /t 6 >NUL
exit /b 0

:erro
echo.
pause
exit /b 1

rem ================================================================ LÍNGUA (gerado na build)
:nxlang
set "NXL=en"
for /f "usebackq delims=" %%l in (`powershell -NoProfile -Command "(Get-UICulture).TwoLetterISOLanguageName"`) do set "NXL=%%l"
if defined NEXUS_LANG set "NXL=%NEXUS_LANG%"
if /i not "%NXL%"=="pt" if /i not "%NXL%"=="es" if /i not "%NXL%"=="fr" if /i not "%NXL%"=="de" set "NXL=en"
goto nxl_%NXL%
:nxl_pt
set "K_YN=SN" & set "K_SEC=SEC" & set "K_S1=S" & set "K_S2=E" & set "K_S3=C"
set "T_1=NEXUS Monitor · Plugin Stream Deck"
set "T_2=· plugin Stream Deck"
set "T_3=Instala só o plugin. O NEXUS já tem de estar instalado."
set "T_4=Faltam ficheiros - extrai o zip primeiro e corre este ficheiro da pasta extraída."
set "T_5=Não encontrei a app Stream Deck neste PC."
set "T_6=O plugin já está instalado e atualizado - nada a fazer."
set "T_7=Criar o plugin"
set "T_8=erro:"
set "T_9=criado"
set "T_10=Instalar na Stream Deck"
set "T_11=não consegui copiar"
set "T_12=a Stream Deck vai reabrir"
set "T_13=Na app Stream Deck procura a categoria"
set "T_14=✓ Pronto!"
exit /b 0
:nxl_en
set "K_YN=YN" & set "K_SEC=HBT" & set "K_S1=H" & set "K_S2=B" & set "K_S3=T"
set "T_1=NEXUS Monitor · Stream Deck plugin"
set "T_2=· Stream Deck plugin"
set "T_3=Installs only the plugin. NEXUS must already be installed."
set "T_4=Files are missing - extract the zip first and run this file from the extracted folder."
set "T_5=Couldn't find the Stream Deck app on this PC."
set "T_6=The plugin is already installed and up to date - nothing to do."
set "T_7=Build the plugin"
set "T_8=error:"
set "T_9=created"
set "T_10=Install in Stream Deck"
set "T_11=couldn't copy"
set "T_12=Stream Deck will reopen"
set "T_13=In the Stream Deck app, look for the category"
set "T_14=✓ Done!"
exit /b 0
:nxl_es
set "K_YN=SN" & set "K_SEC=AEC" & set "K_S1=A" & set "K_S2=E" & set "K_S3=C"
set "T_1=NEXUS Monitor · Plugin de Stream Deck"
set "T_2=· plugin de Stream Deck"
set "T_3=Instala solo el plugin. NEXUS ya tiene que estar instalado."
set "T_4=Faltan archivos - extrae primero el zip y ejecuta este archivo desde la carpeta extraída."
set "T_5=No encontré la app Stream Deck en este PC."
set "T_6=El plugin ya está instalado y actualizado - nada que hacer."
set "T_7=Crear el plugin"
set "T_8=error:"
set "T_9=creado"
set "T_10=Instalar en Stream Deck"
set "T_11=no pude copiar"
set "T_12=Stream Deck se va a reabrir"
set "T_13=En la app Stream Deck busca la categoría"
set "T_14=✓ ¡Listo!"
exit /b 0
:nxl_fr
set "K_YN=ON" & set "K_SEC=ICS" & set "K_S1=I" & set "K_S2=C" & set "K_S3=S"
set "T_1=NEXUS Monitor · Plugin Stream Deck"
set "T_2=· plugin Stream Deck"
set "T_3=Installe seulement le plugin. NEXUS doit déjà être installé."
set "T_4=Il manque des fichiers - extrais d'abord le zip et lance ce fichier depuis le dossier extrait."
set "T_5=Application Stream Deck introuvable sur ce PC."
set "T_6=Le plugin est déjà installé et à jour - rien à faire."
set "T_7=Créer le plugin"
set "T_8=erreur :"
set "T_9=créé"
set "T_10=Installer dans Stream Deck"
set "T_11=copie impossible"
set "T_12=Stream Deck va se rouvrir"
set "T_13=Dans l'application Stream Deck, cherche la catégorie"
set "T_14=✓ Terminé !"
exit /b 0
:nxl_de
set "K_YN=JN" & set "K_SEC=HWE" & set "K_S1=H" & set "K_S2=W" & set "K_S3=E"
set "T_1=NEXUS Monitor · Stream-Deck-Plugin"
set "T_2=· Stream-Deck-Plugin"
set "T_3=Installiert nur das Plugin. NEXUS muss schon installiert sein."
set "T_4=Dateien fehlen - entpacke zuerst das Zip und starte diese Datei aus dem entpackten Ordner."
set "T_5=Die Stream-Deck-App wurde auf diesem PC nicht gefunden."
set "T_6=Das Plugin ist schon installiert und aktuell - nichts zu tun."
set "T_7=Plugin erstellen"
set "T_8=Fehler:"
set "T_9=erstellt"
set "T_10=In Stream Deck installieren"
set "T_11=konnte nicht kopieren"
set "T_12=Stream Deck startet neu"
set "T_13=Suche in der Stream-Deck-App die Kategorie"
set "T_14=✓ Fertig!"
exit /b 0
