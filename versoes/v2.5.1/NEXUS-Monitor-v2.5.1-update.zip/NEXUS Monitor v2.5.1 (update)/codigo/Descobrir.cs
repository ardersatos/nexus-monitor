// NEXUS Monitor - modo "descobrir": ensinar ao NEXUS um aparelho que ele não conhece
// 1) o NEXUS lê tudo o que o aparelho deixa ler (só LEITURA: relatórios "feature", de entrada e o que ele envia sozinho)
// 2) mudas uma coisa (ligas o cabo, mudas o DPI na app da marca...) e o NEXUS lê outra vez
// 3) mostra que bytes mudaram; escolhes o que é cada um e passa a aparecer na lista de aparelhos
// Nada é escrito no aparelho e nada sai do PC.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using Microsoft.Win32.SafeHandles;

namespace Nexus
{
    static class Descobrir
    {
        [DllImport("hid.dll")] static extern bool HidD_GetInputReport(SafeFileHandle h, byte[] b, int len);

        static readonly object lk = new object();
        static readonly Dictionary<string, Dictionary<string, byte[]>> snaps = new Dictionary<string, Dictionary<string, byte[]>>();
        static volatile bool busy;

        // identidade de uma coleção que não muda entre arranques: página, uso, tamanhos e a ordem entre iguais
        static string Sig(List<Hid.Dev> g, Hid.Dev d)
        {
            string b = d.UsagePage.ToString("x4") + "." + d.Usage.ToString("x4") + "." + d.InLen + "." + d.FeatLen;
            int n = g.Where(x => x.UsagePage == d.UsagePage && x.Usage == d.Usage && x.InLen == d.InLen && x.FeatLen == d.FeatLen).ToList().IndexOf(d);
            return b + "." + n;
        }
        static string GroupId(string parent) { return ((uint)parent.ToLowerInvariant().GetHashCode()).ToString("x8"); }
        static List<IGrouping<string, Hid.Dev>> Groups()
        {
            return Hid.Find().Where(d => d.UsagePage >= 0xFF00 || d.FeatLen > 0 || d.UsagePage == 0x0C || d.UsagePage == 0x06)
                .GroupBy(d => Hid.Parent(d.Path)).ToList();
        }
        static string Known(ushort vid, ushort pid)
        {
            if (vid == 0x1532 || vid == 0x046D) return "Razer/Logitech";
            if (HsTable.All.Any(s => s.Vid == vid && s.Pids.Contains(pid))) return "tabela";
            if (vid == 0x03F0 && pid == 0x05B7) return "HyperX";
            return Cfg23.Get("disc_" + vid.ToString("x4") + pid.ToString("x4"), "") != "" ? "ensinado" : "";
        }

        public static string List()
        {
            var b = new StringBuilder("{\"ok\":true,\"devs\":[");
            bool first = true;
            foreach (var g in Groups())
            {
                Hid.Dev d = g.First(); var l = g.ToList();
                string name = l.Select(x => x.Product).FirstOrDefault(x => !string.IsNullOrEmpty(x)) ?? "";
                if (!first) b.Append(','); first = false;
                b.Append("{\"id\":").Append(Js.S(GroupId(g.Key))).Append(",\"name\":").Append(Js.S(name == "" ? "?" : name))
                 .Append(",\"vid\":").Append(Js.S(d.Vid.ToString("X4"))).Append(",\"pid\":").Append(Js.S(d.Pid.ToString("X4")))
                 .Append(",\"cols\":").Append(l.Count).Append(",\"known\":").Append(Js.S(Known(d.Vid, d.Pid))).Append('}');
            }
            return b.Append("]}").ToString();
        }

        // lê tudo o que dá para ler deste aparelho
        static Dictionary<string, byte[]> Read(List<Hid.Dev> g, int listenMs)
        {
            var r = new Dictionary<string, byte[]>();
            var threads = new List<Thread>();
            foreach (Hid.Dev d in g)
            {
                string sig = Sig(g, d);
                SafeFileHandle h = HidIo.Open(d.Path);
                if (h.IsInvalid) { h.Dispose(); h = Hid.CreateFile(d.Path, 0, 3, IntPtr.Zero, 3, 0x40000000, IntPtr.Zero); }
                if (h.IsInvalid) { h.Dispose(); continue; }
                // relatórios "feature" e de entrada pedidos diretamente (números 0 a 63)
                if (d.FeatLen > 1)
                    for (int id = 0; id < 64; id++)
                    {
                        byte[] a = new byte[d.FeatLen]; a[0] = (byte)id;
                        if (Hid.HidD_GetFeature(h, a, a.Length)) lock (r) r[sig + "|F|" + id] = a;
                    }
                if (d.InLen > 1)
                    for (int id = 0; id < 16; id++)
                    {
                        byte[] a = new byte[d.InLen]; a[0] = (byte)id;
                        if (HidD_GetInputReport(h, a, a.Length)) lock (r) r[sig + "|I|" + id] = a;
                    }
                // e o que o aparelho envia sozinho (só nas coleções do fabricante; teclados e ratos normais o Windows não deixa)
                if (d.InLen > 1 && listenMs > 0 && h != null)
                {
                    SafeFileHandle hh = h; Hid.Dev dd = d;
                    Thread t = new Thread(() =>
                    {
                        DateTime end = DateTime.UtcNow.AddMilliseconds(listenMs);
                        while (DateTime.UtcNow < end)
                        {
                            byte[] a = HidIo.Read(hh, dd.InLen, (int)Math.Max(1, (end - DateTime.UtcNow).TotalMilliseconds));
                            if (a == null) break;
                            lock (r) r[sig + "|L|" + a[0]] = a;
                        }
                        hh.Dispose();
                    }) { IsBackground = true };
                    threads.Add(t); t.Start();
                }
                else h.Dispose();
            }
            foreach (Thread t in threads) t.Join(listenMs + 1500);
            return r;
        }

        public static string Snap(string id, string tag)
        {
            if (busy) return Ps23.Ok(false, Lang.L("Já está a ler. Espera um segundo."));
            var g = Groups().FirstOrDefault(x => GroupId(x.Key) == id);
            if (g == null) return Ps23.Ok(false, Lang.L("Aparelho não encontrado. Está ligado?"));
            busy = true;
            try
            {
                var r = Read(g.ToList(), 2000);
                lock (lk) snaps[id + "|" + (tag == "B" ? "B" : "A")] = r;
                return "{\"ok\":true,\"n\":" + r.Count + "}";
            }
            finally { busy = false; }
        }

        // o que mudou entre a 1.ª e a 2.ª leitura
        public static string Diff(string id)
        {
            Dictionary<string, byte[]> a, b;
            lock (lk) { snaps.TryGetValue(id + "|A", out a); snaps.TryGetValue(id + "|B", out b); }
            if (a == null || b == null) return Ps23.Ok(false, Lang.L("Faz primeiro as duas leituras."));
            var rows = new List<string>();
            foreach (var kv in a)
            {
                byte[] y; if (!b.TryGetValue(kv.Key, out y)) continue;
                byte[] x = kv.Value; int n = Math.Min(x.Length, y.Length);
                for (int i = 1; i < n && rows.Count < 80; i++)
                {
                    if (x[i] == y[i]) continue;
                    int le0 = i + 1 < n ? x[i] | (x[i + 1] << 8) : -1, le1 = i + 1 < n ? y[i] | (y[i + 1] << 8) : -1;
                    int be0 = i + 1 < n ? (x[i] << 8) | x[i + 1] : -1, be1 = i + 1 < n ? (y[i] << 8) | y[i + 1] : -1;
                    rows.Add("{\"k\":" + Js.S(kv.Key) + ",\"o\":" + i + ",\"a\":" + x[i] + ",\"b\":" + y[i] + ",\"le\":[" + le0 + "," + le1 + "],\"be\":[" + be0 + "," + be1 + "]}");
                }
            }
            int same = a.Keys.Count(k => b.ContainsKey(k));
            return "{\"ok\":true,\"reads\":" + same + ",\"rows\":[" + string.Join(",", rows.ToArray()) + "]}";
        }

        // receita: "chave|byte|o que é|formato|valor quando carrega|nome" (uma por linha, separadas por ;)
        // o que é: bat | chg | val    formato: pct (já é %) | 255 (0-255) | le | be (2 bytes) | raw
        public static string Save(string id, string key, string off, string what, string fmt, string chgVal, string name, string kind)
        {
            var g = Groups().FirstOrDefault(x => GroupId(x.Key) == id);
            if (g == null) return Ps23.Ok(false, Lang.L("Aparelho não encontrado. Está ligado?"));
            int o; if (!int.TryParse(off, out o) || o < 1 || o > 1024 || string.IsNullOrEmpty(key) || key.Length > 80) return Ps23.Ok(false, "?");
            if (what != "bat" && what != "chg" && what != "val") return Ps23.Ok(false, "?");
            if (fmt != "pct" && fmt != "255" && fmt != "le" && fmt != "be" && fmt != "raw") fmt = "raw";
            Hid.Dev d = g.First();
            string ck = "disc_" + d.Vid.ToString("x4") + d.Pid.ToString("x4");
            var lines = Cfg23.Get(ck, "").Split(';').Where(x => x != "" && !x.StartsWith("kind=")).ToList();
            lines.RemoveAll(x => { var p = x.Split('|'); return p.Length > 6 && (what != "val" ? p[3] == what : p[6] == Clean(name)); });
            int cv; int.TryParse(chgVal, out cv);
            lines.Add(Clean(key) + "|" + o + "|" + "x" + "|" + what + "|" + fmt + "|" + cv + "|" + Clean(name));
            lines.Insert(0, "kind=" + (kind == "mouse" || kind == "keyboard" || kind == "headset" ? kind : "other"));
            Cfg23.Set(ck, string.Join(";", lines.ToArray()));
            ThreadPool.QueueUserWorkItem(delegate { try { Aparelhos.Scan(); } catch { } });
            return Ps23.Ok(true, null);
        }
        public static string Del(string vidpid)
        {
            if (string.IsNullOrEmpty(vidpid) || vidpid.Length != 8) return Ps23.Ok(false, "?");
            Cfg23.Set("disc_" + vidpid.ToLowerInvariant(), null);
            ThreadPool.QueueUserWorkItem(delegate { try { Aparelhos.Scan(); } catch { } });
            return Ps23.Ok(true, null);
        }
        static string Clean(string s) { return (s ?? "").Replace("|", "").Replace(";", "").Trim(); }

        // aparelhos ensinados que estão ligados agora
        public static List<Aparelho> Devices()
        {
            var r = new List<Aparelho>();
            var all = Cfg23.Prefix("disc_").ToDictionary(kv => kv.Key, kv => kv.Value);
            if (all.Count == 0) return r;
            foreach (var g in Groups())
            {
                Hid.Dev d = g.First();
                string v; if (!all.TryGetValue(d.Vid.ToString("x4") + d.Pid.ToString("x4"), out v) || string.IsNullOrEmpty(v)) continue;
                DiscDev x = new DiscDev(g.ToList(), v, GroupId(g.Key));
                try { x.Refresh(); } catch { }
                r.Add(x);
            }
            return r;
        }

        class DiscDev : Aparelho
        {
            readonly List<Hid.Dev> g; readonly List<string[]> rec = new List<string[]>();
            public readonly List<KeyValuePair<string, string>> Values = new List<KeyValuePair<string, string>>();
            public DiscDev(List<Hid.Dev> grp, string cfg, string gid)
            {
                g = grp; Hid.Dev d = g[0]; Vid = d.Vid; Pid = d.Pid; Brand = "";
                Name = g.Select(x => x.Product).FirstOrDefault(x => !string.IsNullOrEmpty(x)) ?? ("USB " + d.Vid.ToString("X4") + ":" + d.Pid.ToString("X4"));
                Id = "disc:" + d.Vid.ToString("x4") + d.Pid.ToString("x4") + ":" + gid;
                foreach (string l in cfg.Split(';'))
                {
                    if (l.StartsWith("kind=")) { Kind = l.Substring(5); continue; }
                    string[] p = l.Split('|'); if (p.Length >= 7) rec.Add(p);
                }
                Taught = true;
            }
            public override void Refresh()
            {
                Err = "";
                // lê só as chaves de que as receitas precisam
                var need = new HashSet<string>(rec.Select(p => p[0]));
                var data = Read(g.Where(d => need.Any(k => k.StartsWith(Sig(g, d) + "|"))).ToList(), rec.Any(p => p[0].Contains("|L|")) ? 1200 : 0);
                Values.Clear(); int bat = -1; int chg = -1;
                foreach (string[] p in rec)
                {
                    byte[] a; int o = int.Parse(p[1]);
                    if (!data.TryGetValue(p[0], out a) || a.Length <= o) continue;
                    int raw = a[o];
                    if ((p[4] == "le" || p[4] == "be") && a.Length > o + 1) raw = p[4] == "le" ? a[o] | (a[o + 1] << 8) : (a[o] << 8) | a[o + 1];
                    int val = p[4] == "255" ? (int)Math.Round(raw * 100.0 / 255) : raw;
                    if (p[3] == "bat") bat = Math.Min(100, val);
                    else if (p[3] == "chg") { int cv; int.TryParse(p[5], out cv); chg = raw == cv ? 1 : 0; }
                    else Values.Add(new KeyValuePair<string, string>(p[6] == "" ? "?" : p[6], val.ToString(CultureInfo.InvariantCulture)));
                }
                Battery = bat; Charging = chg == 1; ChargeUnknown = chg < 0;
                Extra = Values.ToList();
            }
            public override bool SetDpi(int dpi) { return false; }
        }
    }
}
