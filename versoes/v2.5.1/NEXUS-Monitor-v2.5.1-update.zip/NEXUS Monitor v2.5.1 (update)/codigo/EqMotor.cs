// NEXUS Monitor - motor do equalizador
// O equalizador de todo o som do Windows precisa de um APO (componente do motor de áudio do Windows).
// O NEXUS usa o motor do Equalizer APO (GPL, código aberto), mas instala-o e liga-o aos aparelhos sozinho:
// sem janelas, sem atalhos no menu Iniciar, sem aparecer na lista de programas. Tira-se tudo com "Remover".
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Threading;
using Microsoft.Win32;

namespace Nexus
{
    static class EqMotor
    {
        const string URL = "https://downloads.sourceforge.net/project/equalizerapo/1.4.2/EqualizerAPO-x64-1.4.2.exe";
        const string SHA = "7403be7427bbe1936a40dded082829b6e217fc4f5990fee5cba501f0ae055afa";
        const string RENDER = @"SOFTWARE\Microsoft\Windows\CurrentVersion\MMDevices\Audio\Render";
        const string CHILD = @"SOFTWARE\EqualizerAPO\Child APOs";
        const string FX = "{d04e05a6-594b-4fb6-a80d-01af5eed7d1d},";
        static readonly string[] SLOT = { FX + "1", FX + "2", FX + "5", FX + "6", FX + "7" };   // LFX GFX SFX MFX EFX
        const string MODES = "{d3993a3f-99c2-4402-b5ec-a92a0367664b},";
        const string DEFMODE = "{C18E2F7E-933D-4965-B7D1-1EEF228D2AF3}";
        const string DISENH = "{1da5d803-d492-4edd-8c23-e0c0ffee7f0e},5";
        const string TITLE = "{b725f130-47ef-101a-a5f1-02608c9eebac},10";
        const string NOKEY = "!KEY", NOVALUE = "!VALUE";

        // estado para a página: "" | download | install | devices | restart | ok | err:<texto>
        public static volatile string State = "";
        static string ResFile { get { return Path.Combine(Path.GetTempPath(), "nexus_eq_res.txt"); } }
        static string Tmp { get { return Path.Combine(Path.GetTempPath(), "nexus_eqmotor.exe"); } }

        // ---------- chamado pela página (NEXUS normal) ----------
        public static string Start(bool remove)
        {
            if (State == "download" || State == "install" || State == "devices" || State == "restart") return Ps23.Ok(true, null);
            if (!Environment.Is64BitOperatingSystem) return Ps23.Ok(false, Lang.L("O equalizador precisa do Windows de 64 bits."));
            State = remove ? "restart" : "download";
            new Thread(() =>
            {
                try
                {
                    string inst = null;
                    if (!remove && !EngineOk())
                    {
                        inst = Tmp;
                        Download(inst);
                    }
                    State = remove ? "restart" : "install";
                    string arg = remove ? "--eq-remove" : "--eq-setup" + (inst != null ? " \"" + inst + "\"" : "");
                    string err;
                    if (Program.IsAdmin()) err = Elevated(remove, inst);
                    else
                    {
                        try { File.Delete(ResFile); } catch { }
                        Process p;
                        try { p = Process.Start(new ProcessStartInfo(System.Windows.Forms.Application.ExecutablePath, arg) { Verb = "runas", UseShellExecute = true }); }
                        catch { State = "err:" + Lang.L("Não deste permissão no aviso do Windows."); return; }
                        if (p == null || !p.WaitForExit(300000)) { State = "err:" + Lang.L("Demorou demasiado. Tenta outra vez."); return; }
                        string r = File.Exists(ResFile) ? File.ReadAllText(ResFile).Trim() : "?";
                        err = r == "ok" ? null : r;
                    }
                    try { if (inst != null) File.Delete(inst); } catch { }
                    State = err == null ? "ok" : "err:" + err;
                    if (err == null && !remove) Equalizador.Rewrite();
                }
                catch (Exception e) { State = "err:" + e.Message; }
            }) { IsBackground = true }.Start();
            return Ps23.Ok(true, null);
        }

        static void Download(string path)
        {
            ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
            HttpWebRequest rq = (HttpWebRequest)WebRequest.Create(URL);
            rq.UserAgent = "Mozilla/5.0"; rq.AllowAutoRedirect = true; rq.Timeout = 60000; rq.ReadWriteTimeout = 60000;
            using (WebResponse rs = rq.GetResponse())
            using (Stream s = rs.GetResponseStream())
            using (FileStream f = File.Create(path))
            {
                byte[] buf = new byte[65536]; int n; long tot = 0;
                while ((n = s.Read(buf, 0, buf.Length)) > 0) { f.Write(buf, 0, n); tot += n; if (tot > 60L << 20) throw new Exception("?"); }
            }
            if (Hash(path) != SHA) { try { File.Delete(path); } catch { } throw new Exception(Lang.L("O ficheiro descarregado não é o verdadeiro (assinatura errada). Não foi instalado nada.")); }
        }
        static string Hash(string path)
        {
            using (SHA256 h = SHA256.Create()) using (FileStream f = File.OpenRead(path))
                return BitConverter.ToString(h.ComputeHash(f)).Replace("-", "").ToLowerInvariant();
        }

        // ---------- chamado no arranque com --eq-setup / --eq-remove (já com administrador) ----------
        public static bool HandleArgs(string[] args)
        {
            int i = Array.IndexOf(args, "--eq-setup"); bool rem = args.Contains("--eq-remove");
            if (i < 0 && !rem) return false;
            string inst = i >= 0 && i + 1 < args.Length ? args[i + 1] : null;
            string err;
            try { err = Elevated(rem, inst); } catch (Exception e) { err = e.Message; }
            try { File.WriteAllText(ResFile, err ?? "ok"); } catch { }
            return true;
        }

        static string Elevated(bool remove, string inst)
        {
            using (RegistryKey lm = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64))
            {
                if (remove) return Remove(lm);
                if (!EngineOk())
                {
                    if (string.IsNullOrEmpty(inst) || !File.Exists(inst) || Hash(inst) != SHA) return Lang.L("O ficheiro descarregado não é o verdadeiro (assinatura errada). Não foi instalado nada.");
                    string e = RunInstaller(inst); if (e != null) return e;
                }
                Hide(lm);
                State = "devices";
                string[] g = ApoGuids(lm);
                if (g == null) return Lang.L("O motor foi instalado mas não ficou registado no Windows. Reinicia o PC e tenta outra vez.");
                int done = 0; var errs = new List<string>();
                using (RegistryKey r = lm.OpenSubKey(RENDER))
                    foreach (string dev in r.GetSubKeyNames())
                    {
                        object st; using (RegistryKey k = r.OpenSubKey(dev)) st = k == null ? null : k.GetValue("DeviceState");
                        if (!(st is int) || ((int)st & 1) == 0) continue;   // só os aparelhos ligados
                        try { if (InstallDev(lm, dev, g[0], g[1])) done++; }
                        catch (Exception e) { errs.Add(e.Message); }
                    }
                if (done == 0 && errs.Count > 0) return errs[0];
                // o motor é do NEXUS: o config principal fica só com o do NEXUS (sem os exemplos que vêm com ele)
                try { string c = Path.Combine(Equalizador.ApoDirPublic(), "config"); File.WriteAllText(Path.Combine(c, "nexus_owner.txt"), "1"); } catch { }
                Equalizador.Rewrite();
                State = "restart";
                RestartAudio();
                return null;
            }
        }

        public static bool EngineOk()
        {
            string d = Equalizador.ApoDirPublic();
            return d != null && File.Exists(Path.Combine(d, "EqualizerAPO.dll"));
        }

        static string RunInstaller(string inst)
        {
            Process p = Process.Start(new ProcessStartInfo(inst, "/S") { UseShellExecute = false, CreateNoWindow = true });
            DateTime end = DateTime.Now.AddMinutes(4);
            while (!p.HasExited && DateTime.Now < end)
            {
                // o instalador abre a janela de escolher aparelhos: o NEXUS fecha-a e faz isso ele próprio
                foreach (string n in new[] { "DeviceSelector", "Configurator" })
                    foreach (Process q in Process.GetProcessesByName(n)) try { q.Kill(); } catch { }
                Thread.Sleep(250);
            }
            if (!p.HasExited) { try { p.Kill(); } catch { } return Lang.L("A instalação do motor não terminou. Tenta outra vez."); }
            return EngineOk() ? null : Lang.L("A instalação do motor falhou.");
        }

        // tira os atalhos do menu Iniciar e esconde-o da lista de programas (o NEXUS é que o gere)
        static void Hide(RegistryKey lm)
        {
            try
            {
                string name = null;
                using (RegistryKey k = lm.OpenSubKey(@"SOFTWARE\EqualizerAPO")) if (k != null) name = k.GetValue("Start Menu Folder") as string;
                foreach (string n in new[] { name, "Equalizer APO", "Equalizer APO 1.4.2" })
                {
                    if (string.IsNullOrEmpty(n) || n.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0 || n.IndexOf("Equalizer", StringComparison.OrdinalIgnoreCase) < 0) continue;
                    string sm = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonPrograms), n);
                    if (Directory.Exists(sm)) Directory.Delete(sm, true);
                }
            }
            catch { }
            // nada sai do PC: o verificador de atualizações do motor não é preciso (o NEXUS trata disso)
            try { string d = Equalizador.ApoDirPublic(); if (d != null) { string u = Path.Combine(d, "UpdateChecker.exe"); if (File.Exists(u)) File.Delete(u); } } catch { }
            try { Process p = Process.Start(new ProcessStartInfo("schtasks.exe", "/delete /tn EqualizerAPOUpdateChecker /f") { UseShellExecute = false, CreateNoWindow = true }); p.WaitForExit(15000); } catch { }
            try { using (RegistryKey u = lm.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\EqualizerAPO", true)) if (u != null) u.SetValue("SystemComponent", 1, RegistryValueKind.DWord); } catch { }
        }

        // os dois componentes registados (antes e depois da mistura do som); ids fixos do Equalizer APO
        const string PRE = "{EACD2258-FCAC-4FF4-B36D-419E924A6D79}", POST = "{EC1CC9CE-FAED-4822-828A-82A81A6F018F}";
        static string[] ApoGuids(RegistryKey lm)
        {
            using (RegistryKey a = lm.OpenSubKey(@"SOFTWARE\Classes\AudioEngine\AudioProcessingObjects\" + PRE))
            using (RegistryKey b = lm.OpenSubKey(@"SOFTWARE\Classes\AudioEngine\AudioProcessingObjects\" + POST))
                return a != null && b != null ? new[] { PRE, POST } : null;
        }

        static bool IsOurs(string v, string pre, string post) { return v != null && (v.Equals(pre, StringComparison.OrdinalIgnoreCase) || v.Equals(post, StringComparison.OrdinalIgnoreCase)); }

        static bool InstallDev(RegistryKey lm, string dev, string pre, string post)
        {
            string dk = RENDER + "\\" + dev, fk = dk + "\\FxProperties";
            RegistryKey fx = lm.OpenSubKey(fk);
            bool had = fx != null;
            string[] orig = new string[5];
            for (int i = 0; i < 5; i++) orig[i] = had ? fx.GetValue(SLOT[i]) as string : null;
            if (fx != null) fx.Close();
            if (orig.Any(v => IsOurs(v, pre, post))) return false;   // já está

            // modo: como o Windows 10/11 (SFX/MFX), salvo se o aparelho só usar o antigo (LFX/GFX) ou só EFX
            int mode = (orig[0] != null || orig[1] != null) && orig[2] == null && orig[3] == null && orig[4] == null ? 0 : (orig[4] != null && orig[3] == null ? 2 : 1);
            int preI = mode == 0 ? 0 : 2, postI = mode == 0 ? 1 : mode == 1 ? 3 : 4;

            // guarda o que lá estava (para "Remover" deixar tudo como antes)
            using (RegistryKey c = lm.CreateSubKey(CHILD + "\\" + dev))
            {
                for (int i = 0; i < 5; i++) c.SetValue(SLOT[i], !had ? NOKEY : (orig[i] ?? NOVALUE));
                c.SetValue("PreMixChild", orig[preI] ?? "");
                c.SetValue("PostMixChild", orig[postI] ?? "");
                c.SetValue("AllowSilentBufferModification", "false");
                c.SetValue("Version", "2");
                c.SetValue("NEXUS", "1");
            }

            fx = OpenWritable(lm, dk, fk);
            try
            {
                if (!had) fx.SetValue(TITLE, "NEXUS Monitor");
                if (mode == 0) { Del(fx, SLOT[2]); Del(fx, SLOT[3]); Del(fx, SLOT[4]); fx.SetValue(SLOT[0], pre); fx.SetValue(SLOT[1], post); }
                else
                {
                    Del(fx, SLOT[0]); Del(fx, SLOT[1]);
                    fx.SetValue(SLOT[2], pre); fx.SetValue(SLOT[postI], post);
                    foreach (int s in new[] { 5, mode == 1 ? 6 : 7 })
                        if (fx.GetValue(MODES + s) == null) fx.SetValue(MODES + s, new[] { DEFMODE }, RegistryValueKind.MultiString);
                }
                Del(fx, DISENH);   // "desligar melhorias de áudio" desligaria também o equalizador
            }
            finally { fx.Close(); }
            return true;
        }
        static void Del(RegistryKey k, string n) { if (k.GetValue(n) != null) k.DeleteValue(n, false); }

        // as chaves dos aparelhos de som pertencem ao sistema: se não der para escrever, o administrador fica dono delas
        static RegistryKey OpenWritable(RegistryKey lm, string dk, string fk)
        {
            try { return lm.CreateSubKey(fk); }
            catch (UnauthorizedAccessException) { }
            catch (System.Security.SecurityException) { }
            Grant(lm, dk);
            try { using (RegistryKey t = lm.OpenSubKey(fk)) if (t != null) Grant(lm, fk); } catch { }
            return lm.CreateSubKey(fk);
        }
        static void Grant(RegistryKey lm, string path)
        {
            Priv("SeTakeOwnershipPrivilege"); Priv("SeRestorePrivilege");
            SecurityIdentifier adm = new SecurityIdentifier(WellKnownSidType.BuiltinAdministratorsSid, null);
            using (RegistryKey k = lm.OpenSubKey(path, RegistryKeyPermissionCheck.ReadWriteSubTree, RegistryRights.TakeOwnership))
            { RegistrySecurity s = k.GetAccessControl(AccessControlSections.None); s.SetOwner(adm); k.SetAccessControl(s); }
            using (RegistryKey k = lm.OpenSubKey(path, RegistryKeyPermissionCheck.ReadWriteSubTree, RegistryRights.ChangePermissions | RegistryRights.ReadKey))
            { RegistrySecurity s = k.GetAccessControl(AccessControlSections.Access); s.AddAccessRule(new RegistryAccessRule(adm, RegistryRights.FullControl, InheritanceFlags.ContainerInherit, PropagationFlags.None, AccessControlType.Allow)); k.SetAccessControl(s); }
        }

        static string Remove(RegistryKey lm)
        {
            using (RegistryKey c = lm.OpenSubKey(CHILD))
                if (c != null)
                    foreach (string dev in c.GetSubKeyNames())
                        try
                        {
                            string[] o = new string[5];
                            using (RegistryKey k = c.OpenSubKey(dev)) for (int i = 0; i < 5; i++) o[i] = k.GetValue(SLOT[i]) as string;
                            string dk = RENDER + "\\" + dev, fk = dk + "\\FxProperties";
                            if (o[0] == NOKEY) { try { lm.DeleteSubKeyTree(fk, false); } catch { Grant(lm, fk); lm.DeleteSubKeyTree(fk, false); } }
                            else
                                using (RegistryKey fx = OpenWritable(lm, dk, fk))
                                    for (int i = 0; i < 5; i++)
                                    {
                                        if (o[i] == NOVALUE) Del(fx, SLOT[i]);
                                        else if (!string.IsNullOrEmpty(o[i]) && o[i] != NOKEY) fx.SetValue(SLOT[i], o[i]);
                                    }
                            lm.DeleteSubKeyTree(CHILD + "\\" + dev, false);
                        }
                        catch { }
            // tira o motor do PC
            string d = Equalizador.ApoDirPublic();
            if (d != null && File.Exists(Path.Combine(d, "Uninstall.exe")))
            {
                Process p = Process.Start(new ProcessStartInfo(Path.Combine(d, "Uninstall.exe"), "/S _?=" + d) { UseShellExecute = false, CreateNoWindow = true });
                DateTime end = DateTime.Now.AddMinutes(3);
                while (!p.HasExited && DateTime.Now < end)
                {
                    foreach (Process q in Process.GetProcessesByName("DeviceSelector")) try { q.Kill(); } catch { }
                    Thread.Sleep(250);
                }
                try { File.Delete(Path.Combine(d, "Uninstall.exe")); } catch { }
            }
            RestartAudio();
            return null;
        }

        static void RestartAudio()
        {
            foreach (string a in new[] { "stop audiosrv /y", "start audiosrv" })
                try { Process p = Process.Start(new ProcessStartInfo("net.exe", a) { UseShellExecute = false, CreateNoWindow = true }); p.WaitForExit(30000); } catch { }
            // programas que leem o som (medidores de volume) perdem a ligação quando o som do Windows reinicia:
            // fecha-se o servidor do Volume Controller da Elgato (o "vigia" dele volta a abri-lo sozinho, já ligado ao som novo)
            Thread.Sleep(1500);
            foreach (string n in new[] { "ElgatoAudioControlServer" })
                foreach (Process q in Process.GetProcessesByName(n)) try { q.Kill(); } catch { }
        }

        // aparelhos onde o equalizador está ligado (para a página)
        public static List<string> Installed()
        {
            var l = new List<string>();
            try
            {
                using (RegistryKey lm = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64))
                {
                    string[] g = ApoGuids(lm); if (g == null) return l;
                    using (RegistryKey r = lm.OpenSubKey(RENDER))
                        foreach (string dev in r.GetSubKeyNames())
                            using (RegistryKey fx = r.OpenSubKey(dev + "\\FxProperties"))
                                if (fx != null && SLOT.Any(s => IsOurs(fx.GetValue(s) as string, g[0], g[1]))) l.Add(dev.ToLowerInvariant());
                }
            }
            catch { }
            return l;
        }

        [DllImport("advapi32.dll", SetLastError = true)] static extern bool OpenProcessToken(IntPtr h, uint acc, out IntPtr tok);
        [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)] static extern bool LookupPrivilegeValue(string sys, string name, out long luid);
        [DllImport("advapi32.dll", SetLastError = true)] static extern bool AdjustTokenPrivileges(IntPtr tok, bool all, ref TP st, int len, IntPtr prev, IntPtr ret);
        [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);
        [StructLayout(LayoutKind.Sequential, Pack = 4)] struct TP { public int Count; public long Luid; public int Attr; }
        static void Priv(string name)
        {
            IntPtr t;
            if (!OpenProcessToken(Process.GetCurrentProcess().Handle, 0x28, out t)) return;
            try { TP p = new TP { Count = 1, Attr = 2 }; if (LookupPrivilegeValue(null, name, out p.Luid)) AdjustTokenPrivileges(t, false, ref p, 0, IntPtr.Zero, IntPtr.Zero); }
            finally { CloseHandle(t); }
        }
    }
}
