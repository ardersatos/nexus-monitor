// NEXUS // MONITOR - macros e atalhos à escolha (opcional, tudo dentro do PC).
//  - Macros: grava teclas e cliques com os tempos entre eles e repete-os (uma vez, N vezes, enquanto seguras ou liga/desliga).
//  - Atalhos: uma tecla ou combinação (também botões laterais do rato) faz uma ação: macro, DPI seguinte/anterior,
//    modo precisão, painel do NEXUS, medir FPS, abrir um programa, música e volume...
//  - Um atalho pode valer só num jogo e/ou só num teclado/rato (pelo "raw input" do Windows).
//  - Nos jogos com anti-cheat as macros ficam desligadas (podiam dar ban), a não ser que digas o contrário.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace Nexus
{
    static class Macros
    {
        // ------------------------------------------------------------ dados
        public class Step { public char T; public int Code; public bool Down; public int Delay; }   // T: k (tecla), m (botão do rato: 1 esq, 2 dir, 3 meio, 4 x1, 5 x2), w (roda)
        public class Macro { public string Id = "", Name = ""; public string Mode = "once"; public int Times = 1; public bool AntiCheatOk; public List<Step> Steps = new List<Step>(); }
        public class Key { public string Id = "", Action = "", Arg = "", Game = "", Dev = ""; public int Mods, Vk; public bool Block = true; }

        static readonly object lk = new object();
        static List<Macro> macros; static List<Key> keys;
        static string FileM { get { return Path.Combine(AppSettings.Dir, "macros.txt"); } }
        static string FileK { get { return Path.Combine(AppSettings.Dir, "atalhos.txt"); } }
        public static bool Enabled { get { return Cfg23.On("ctl_on", false); } }

        static string Esc(string s) { return (s ?? "").Replace("|", "/").Replace("\r", " ").Replace("\n", " "); }
        static void Load()
        {
            if (macros != null) return;
            macros = new List<Macro>(); keys = new List<Key>();
            try
            {
                if (File.Exists(FileM))
                    foreach (string l in File.ReadAllLines(FileM, Encoding.UTF8))
                    {
                        string[] c = l.Split('|'); if (c.Length < 6) continue;
                        Macro m = new Macro { Id = c[0], Name = c[1], Mode = c[2], AntiCheatOk = c[4] == "1" };
                        int.TryParse(c[3], out m.Times);
                        foreach (string st in c[5].Split(';'))
                        {
                            string[] p = st.Split(','); int code, delay;
                            if (p.Length == 4 && p[0].Length == 1 && int.TryParse(p[1], out code) && int.TryParse(p[3], out delay))
                                m.Steps.Add(new Step { T = p[0][0], Code = code, Down = p[2] == "d", Delay = Math.Max(0, Math.Min(60000, delay)) });
                        }
                        macros.Add(m);
                    }
                if (File.Exists(FileK))
                    foreach (string l in File.ReadAllLines(FileK, Encoding.UTF8))
                    {
                        string[] c = l.Split('|'); if (c.Length < 8) continue;
                        Key k = new Key { Id = c[0], Action = c[3], Arg = c[4], Game = c[5], Dev = c[6], Block = c[7] != "0" };
                        int.TryParse(c[1], out k.Mods); int.TryParse(c[2], out k.Vk);
                        if (k.Vk > 0) keys.Add(k);
                    }
            }
            catch { }
        }
        static void Save()
        {
            try
            {
                Directory.CreateDirectory(AppSettings.Dir);
                File.WriteAllLines(FileM, macros.Select(m => m.Id + "|" + Esc(m.Name) + "|" + m.Mode + "|" + m.Times + "|" + (m.AntiCheatOk ? "1" : "0") + "|" +
                    string.Join(";", m.Steps.Select(s => s.T + "," + s.Code + "," + (s.Down ? "d" : "u") + "," + s.Delay).ToArray())).ToArray(), new UTF8Encoding(false));
                File.WriteAllLines(FileK, keys.Select(k => k.Id + "|" + k.Mods + "|" + k.Vk + "|" + k.Action + "|" + Esc(k.Arg) + "|" + Esc(k.Game) + "|" + Esc(k.Dev) + "|" + (k.Block ? "1" : "0")).ToArray(), new UTF8Encoding(false));
            }
            catch { }
        }

        // ------------------------------------------------------------ jogo atual (para atalhos de um jogo e o bloqueio anti-cheat)
        static string game;
        public static void GameStart(string g) { lock (lk) game = Perfis.Norm(g); }
        public static void GameEnd() { lock (lk) game = null; StopAll(); }
        static readonly string[] AC = { "valorant", "valorant-win64-shipping", "fortniteclient-win64-shipping", "r5apex", "r5apex_dx12", "cod", "cod24-cod", "modernwarfare", "blackops6", "bf2042", "bf6",
            "rainbowsix", "rainbowsix_be", "rainbowsix_vulkan", "tslgame", "escapefromtarkov", "overwatch", "league of legends", "destiny2", "discovery", "marvel-win64-shipping",
            "deltaforceclient-win64-shipping", "thefinals", "rustclient", "dayz_x64", "eldenring", "nightreign", "fallguys_client_game", "apexlegends" };
        public static bool AntiCheatGame()
        {
            string g; lock (lk) g = game;
            if (g != null && AC.Contains(g)) return true;
            try
            {
                if (Process.GetProcessesByName("FACEIT").Length > 0 || Process.GetProcessesByName("faceitclient").Length > 0) return true;
                if (g != null && Process.GetProcessesByName("vgc").Length > 0) return true;   // Vanguard (Riot) a correr com um jogo aberto
            }
            catch { }
            return false;
        }

        // ------------------------------------------------------------ API
        static string NewId() { return DateTime.UtcNow.Ticks.ToString("x").Substring(4); }
        public static string Json()
        {
            lock (lk)
            {
                Load();
                StringBuilder b = new StringBuilder("{\"ok\":true,\"on\":" + (Enabled ? "true" : "false"));
                b.Append(",\"rec\":").Append(recording ? "true" : "false").Append(",\"recN\":").Append(rec.Count);
                b.Append(",\"ac\":").Append(AntiCheatGame() ? "true" : "false").Append(",\"game\":").Append(Js.S(game ?? ""));
                b.Append(",\"macros\":[").Append(string.Join(",", macros.Select(m => "{\"id\":" + Js.S(m.Id) + ",\"name\":" + Js.S(m.Name) + ",\"mode\":" + Js.S(m.Mode) + ",\"times\":" + m.Times +
                    ",\"acok\":" + (m.AntiCheatOk ? "true" : "false") + ",\"n\":" + m.Steps.Count + ",\"ms\":" + m.Steps.Sum(s => s.Delay) +
                    ",\"steps\":[" + string.Join(",", m.Steps.Take(400).Select(s => "[\"" + s.T + "\"," + s.Code + "," + (s.Down ? 1 : 0) + "," + s.Delay + "]").ToArray()) + "]}").ToArray())).Append(']');
                b.Append(",\"keys\":[").Append(string.Join(",", keys.Select(k => "{\"id\":" + Js.S(k.Id) + ",\"mods\":" + k.Mods + ",\"vk\":" + k.Vk + ",\"action\":" + Js.S(k.Action) + ",\"arg\":" + Js.S(k.Arg) +
                    ",\"game\":" + Js.S(k.Game) + ",\"dev\":" + Js.S(k.Dev) + ",\"block\":" + (k.Block ? "true" : "false") + "}").ToArray())).Append(']');
                b.Append(",\"snap\":").Append(SnapOn ? "true" : "false").Append(",\"snapPairs\":").Append(Js.S(Cfg23.Get("snap_pairs", null) ?? SNAPDEF)).Append(",\"snapLive\":").Append(SnapLive() ? "true" : "false");
                b.Append(",\"gm\":").Append(GmMode).Append(",\"gmWin\":").Append(Cfg23.Get("gm_win", null) != "0" ? "true" : "false").Append(",\"gmTab\":").Append(Cfg23.Get("gm_tab", null) != "0" ? "true" : "false")
                 .Append(",\"gmF4\":").Append(Cfg23.Get("gm_f4", null) != "0" ? "true" : "false").Append(",\"gmLive\":").Append(GmLive() ? "true" : "false");
                b.Append(",\"devices\":[").Append(string.Join(",", RawDevices().Select(d => "{\"id\":" + Js.S(d.Key) + ",\"name\":" + Js.S(d.Value) + "}").ToArray())).Append(']');
                return b.Append('}').ToString();
            }
        }
        public static string SetOn(bool on) { Cfg23.Set("ctl_on", on ? "1" : "0"); Apply(); return Json(); }

        static string recName;
        public static string RecStart(bool mouse, string name)
        {
            if (!Enabled) return Ps23.Ok(false, Lang.L("Liga primeiro as macros e atalhos."));
            lock (lk) { rec.Clear(); recMouse = mouse; recLast = 0; recording = true; recName = name; }
            Apply();
            return Json();
        }
        // acaba a gravação; fromUi: o clique no botão PARAR também foi gravado e sai
        public static string RecStop(string name, bool fromUi)
        {
            Macro m;
            lock (lk)
            {
                Load();
                recording = false;
                List<Step> s = rec.ToList(); rec.Clear();
                if (fromUi) while (s.Count > 0 && s[s.Count - 1].T == 'm') s.RemoveAt(s.Count - 1);
                // teclas que ficaram em baixo no fim: soltam-se
                foreach (var g in s.Where(x => x.T == 'k').GroupBy(x => x.Code).ToList()) if (g.Last().Down) s.Add(new Step { T = 'k', Code = g.Key, Down = false, Delay = 10 });
                if (s.Count == 0) { Apply(); return Ps23.Ok(false, Lang.L("Não foi gravado nada.")); }
                if (string.IsNullOrEmpty(name)) name = recName;
                m = new Macro { Id = NewId(), Name = string.IsNullOrEmpty(name) ? Lang.L("Macro") + " " + (macros.Count + 1) : name.Trim(), Steps = s };
                if (m.Name.Length > 40) m.Name = m.Name.Substring(0, 40);
                macros.Add(m); Save();
            }
            Apply();
            return Json();
        }
        public static string SaveMacro(string id, string name, string mode, string times, string acok, string steps)
        {
            lock (lk)
            {
                Load();
                Macro m = macros.FirstOrDefault(x => x.Id == id);
                if (m == null) { m = new Macro { Id = NewId() }; macros.Add(m); }
                if (!string.IsNullOrEmpty(name)) m.Name = name.Trim().Length > 40 ? name.Trim().Substring(0, 40) : name.Trim();
                if (mode == "once" || mode == "times" || mode == "hold" || mode == "toggle") m.Mode = mode;
                int t; if (int.TryParse(times, out t)) m.Times = Math.Max(1, Math.Min(999, t));
                if (acok != null) m.AntiCheatOk = acok == "1";
                if (!string.IsNullOrEmpty(steps))
                {
                    List<Step> l = new List<Step>();
                    foreach (string st in steps.Split(';'))
                    {
                        string[] p = st.Split(','); int code, delay;
                        if (p.Length == 4 && p[0].Length == 1 && "kmw".IndexOf(p[0][0]) >= 0 && int.TryParse(p[1], out code) && int.TryParse(p[3], out delay))
                            l.Add(new Step { T = p[0][0], Code = code, Down = p[2] == "d" || p[2] == "1", Delay = Math.Max(0, Math.Min(60000, delay)) });
                    }
                    if (l.Count > 0) m.Steps = l;
                }
                Save();
            }
            return Json();
        }
        public static string DelMacro(string id)
        {
            lock (lk) { Load(); macros.RemoveAll(x => x.Id == id); keys.RemoveAll(k => k.Action == "macro" && k.Arg == id); Save(); }
            Apply(); return Json();
        }
        public static string SaveKey(string id, string mods, string vk, string action, string arg, string g, string dev, string block)
        {
            lock (lk)
            {
                Load();
                int mo, v; int.TryParse(mods, out mo); int.TryParse(vk, out v);
                if (v <= 0 || v > 255) return Ps23.Ok(false, Lang.L("Escolhe uma tecla."));
                if (mo == 0 && v != 0x04 && v != 0x05 && v != 0x06 && !(v >= 0x70 && v <= 0x87) && string.IsNullOrEmpty(dev) && action != "remap" && action != "disable" && action != "turbo" && block != "v")
                    return Ps23.Ok(false, Lang.L("Uma tecla sozinha ia deixar de escrever. Junta Ctrl, Alt ou Shift, ou usa uma tecla F, um botão lateral do rato ou um teclado só para atalhos."));
                Key k = keys.FirstOrDefault(x => x.Id == id);
                if (k == null) { k = new Key { Id = NewId() }; keys.Add(k); }
                k.Mods = mo & 15; k.Vk = v; k.Action = action ?? ""; k.Arg = arg ?? ""; k.Game = Perfis.Norm(g) ?? ""; k.Dev = dev ?? ""; k.Block = block != "0";
                if (action == "remap" || action == "disable") k.Block = true;   // trocar/desligar uma tecla esconde sempre a original
                Save();
            }
            Apply(); return Json();
        }
        public static string DelKey(string id) { lock (lk) { Load(); keys.RemoveAll(x => x.Id == id); Save(); } Apply(); return Json(); }
        public static string PlayNow(string id, bool now)
        {
            Macro m; lock (lk) { Load(); m = macros.FirstOrDefault(x => x.Id == id); }
            if (m == null) return Ps23.Ok(false, "?");
            if (now) { ThreadPool.QueueUserWorkItem(delegate { try { Play(m, null); } catch { } }); return Ps23.Ok(true, null); }   // Stream Deck: já
            ThreadPool.QueueUserWorkItem(delegate { Thread.Sleep(2500); try { Play(m, null); } catch { } });   // página: tempo para voltares à janela certa
            return Ps23.Ok(true, Lang.L("A macro corre daqui a 2 segundos."));
        }

        // ------------------------------------------------------------ reprodução
        [StructLayout(LayoutKind.Sequential)] struct KI { public ushort vk, scan; public uint flags, time; public IntPtr extra; }
        [StructLayout(LayoutKind.Sequential)] struct MI { public int dx, dy; public uint data, flags, time; public IntPtr extra; }
        [StructLayout(LayoutKind.Explicit)] struct INPUT { [FieldOffset(0)] public uint type; [FieldOffset(8)] public KI k; [FieldOffset(8)] public MI m; }
        [StructLayout(LayoutKind.Explicit)] struct INPUT32 { [FieldOffset(0)] public uint type; [FieldOffset(4)] public KI k; [FieldOffset(4)] public MI m; }
        [DllImport("user32.dll")] static extern uint SendInput(uint n, INPUT[] i, int size);
        [DllImport("user32.dll", EntryPoint = "SendInput")] static extern uint SendInput32(uint n, INPUT32[] i, int size);
        [DllImport("user32.dll")] static extern uint MapVirtualKey(uint code, uint type);
        static readonly IntPtr MARK = new IntPtr(0x4E58);   // marca os eventos do NEXUS (para não se apanharem a si próprios)

        static void SendKey(int vk, bool down)
        {
            uint sc = MapVirtualKey((uint)vk, 0);
            bool ext = vk == 0x21 || vk == 0x22 || vk == 0x23 || vk == 0x24 || vk == 0x25 || vk == 0x26 || vk == 0x27 || vk == 0x28 || vk == 0x2D || vk == 0x2E || vk == 0xA3 || vk == 0xA5 || vk == 0x5B || vk == 0x5C || vk == 0x6F || (vk >= 0xA6 && vk <= 0xB7);
            uint fl = (sc != 0 && !(vk >= 0xA6 && vk <= 0xB7) ? 0x0008u : 0u) | (down ? 0u : 0x0002u) | (ext ? 0x0001u : 0u);
            KI k = new KI { vk = (ushort)(sc != 0 && (fl & 8) != 0 ? 0 : vk), scan = (ushort)sc, flags = fl, extra = MARK };
            Send(k, null);
        }
        static void SendMouse(int btn, bool down, int wheel)
        {
            MI m = new MI { extra = MARK };
            if (btn == 0) { m.flags = 0x0800; m.data = (uint)wheel; }
            else if (btn == 1) m.flags = down ? 0x0002u : 0x0004u;
            else if (btn == 2) m.flags = down ? 0x0008u : 0x0010u;
            else if (btn == 3) m.flags = down ? 0x0020u : 0x0040u;
            else { m.flags = down ? 0x0080u : 0x0100u; m.data = (uint)(btn == 4 ? 1 : 2); }
            Send(null, m);
        }
        static void Send(KI? k, MI? m)
        {
            if (IntPtr.Size == 8)
            {
                INPUT i = new INPUT(); if (k.HasValue) { i.type = 1; i.k = k.Value; } else { i.type = 0; i.m = m.Value; }
                SendInput(1, new[] { i }, Marshal.SizeOf(typeof(INPUT)));
            }
            else
            {
                INPUT32 i = new INPUT32(); if (k.HasValue) { i.type = 1; i.k = k.Value; } else { i.type = 0; i.m = m.Value; }
                SendInput32(1, new[] { i }, Marshal.SizeOf(typeof(INPUT32)));
            }
        }
        public static void SendVk(int vk) { SendKey(vk, true); SendKey(vk, false); }

        static readonly Dictionary<string, ManualResetEvent> running = new Dictionary<string, ManualResetEvent>();
        static DateTime acWarned = DateTime.MinValue;
        static void Play(Macro m, Key trigger)
        {
            if (!m.AntiCheatOk && AntiCheatGame())
            {
                if ((DateTime.UtcNow - acWarned).TotalSeconds > 60) { acWarned = DateTime.UtcNow; Vigias23.Alert(Lang.L("⌨ Macro desligada neste jogo"), Lang.L("Este jogo tem anti-cheat: uma macro podia dar ban. Podes autorizar esta macro nas definições dela, por tua conta.")); }
                return;
            }
            ManualResetEvent stop;
            lock (running)
            {
                if (running.TryGetValue(m.Id, out stop)) { stop.Set(); running.Remove(m.Id); return; }   // carregar outra vez pára (modo liga/desliga ou para interromper)
                stop = new ManualResetEvent(false); running[m.Id] = stop;
            }
            try
            {
                int n = m.Mode == "times" ? Math.Max(1, m.Times) : m.Mode == "once" ? 1 : int.MaxValue;
                HashSet<int> downK = new HashSet<int>(); HashSet<int> downM = new HashSet<int>();
                for (int r = 0; r < n; r++)
                {
                    foreach (Step s in m.Steps)
                    {
                        if (s.Delay > 0 && stop.WaitOne(s.Delay)) goto end;
                        if (s.T == 'k') { SendKey(s.Code, s.Down); if (s.Down) downK.Add(s.Code); else downK.Remove(s.Code); }
                        else if (s.T == 'm') { SendMouse(s.Code, s.Down, 0); if (s.Down) downM.Add(s.Code); else downM.Remove(s.Code); }
                        else if (s.T == 'w') SendMouse(0, false, s.Code);
                    }
                    if (m.Mode == "hold" && trigger != null && !held.Contains(trigger.Id)) break;
                    if (m.Steps.Sum(x => x.Delay) < 10 && stop.WaitOne(10)) break;   // nunca um ciclo sem pausa nenhuma
                }
            end:
                foreach (int k in downK) SendKey(k, false);   // nada fica carregado
                foreach (int b in downM) SendMouse(b, false, 0);
            }
            finally { lock (running) { ManualResetEvent cur; if (running.TryGetValue(m.Id, out cur) && cur == stop) running.Remove(m.Id); } }
        }
        static bool StopTurbo(string id)
        {
            lock (running) { ManualResetEvent e; if (running.TryGetValue("turbo:" + id, out e)) { e.Set(); running.Remove("turbo:" + id); return true; } }
            return false;
        }
        static void StopAll() { lock (running) { foreach (var e in running.Values) e.Set(); running.Clear(); } }

        // ------------------------------------------------------------ ações dos atalhos
        static void Run(Key k, bool down)
        {
            switch (k.Action)
            {
                case "macro":
                    {
                        Macro m; lock (lk) m = macros.FirstOrDefault(x => x.Id == k.Arg);
                        if (m == null) return;
                        if (!down) { if (m.Mode == "hold") lock (running) { ManualResetEvent e; if (running.TryGetValue(m.Id, out e)) { e.Set(); running.Remove(m.Id); } } return; }
                        ThreadPool.QueueUserWorkItem(delegate { try { Play(m, k); } catch { } });
                        return;
                    }
                case "precision": ThreadPool.QueueUserWorkItem(delegate { try { Aparelhos.Precision(down); } catch { } }); return;
                case "disable": return;   // a tecla fica sem fazer nada
                case "remap":
                    {
                        // a tecla passa a ser outra (ou um botão do rato): "k<vk>" ou "m<botão>"
                        string a = k.Arg ?? ""; int code;
                        if (a.Length < 2 || !int.TryParse(a.Substring(1), out code) || code <= 0) return;
                        if (a[0] == 'm') SendMouse(code, down, 0); else SendKey(code, down);
                        return;
                    }
                case "turbo":
                    {
                        // enquanto seguras (ou liga/desliga): repete um clique ou uma tecla. Arg = "alvo,cps,modo" (alvo: m1 m2 m3 ou k<vk>)
                        string[] p = (k.Arg ?? "").Split(','); int cps; if (p.Length < 2 || !int.TryParse(p[1], out cps)) return;
                        cps = Math.Max(1, Math.Min(50, cps)); bool toggle = p.Length > 2 && p[2] == "toggle";
                        if (!down) { if (!toggle) StopTurbo(k.Id); return; }
                        if (toggle && StopTurbo(k.Id)) return;
                        if (AntiCheatGame()) { if ((DateTime.UtcNow - acWarned).TotalSeconds > 60) { acWarned = DateTime.UtcNow; Vigias23.Alert(Lang.L("⌨ Turbo desligado neste jogo"), Lang.L("Este jogo tem anti-cheat: o clique rápido podia dar ban.")); } return; }
                        ManualResetEvent stop = new ManualResetEvent(false);
                        lock (running) running["turbo:" + k.Id] = stop;
                        string target = p[0];
                        ThreadPool.QueueUserWorkItem(delegate
                        {
                            try
                            {
                                int gap = 1000 / cps, vk = 0, btn = 0;
                                if (target.StartsWith("k")) int.TryParse(target.Substring(1), out vk); else int.TryParse(target.Substring(1), out btn);
                                for (int i = 0; i < 100000; i++)
                                {
                                    if (btn > 0) SendMouse(btn, true, 0); else if (vk > 0) SendKey(vk, true);
                                    if (stop.WaitOne(Math.Max(5, gap / 3))) { if (btn > 0) SendMouse(btn, false, 0); else if (vk > 0) SendKey(vk, false); break; }
                                    if (btn > 0) SendMouse(btn, false, 0); else if (vk > 0) SendKey(vk, false);
                                    if (stop.WaitOne(Math.Max(5, gap - gap / 3))) break;
                                }
                            }
                            catch { }
                        });
                        return;
                    }
            }
            if (!down) return;
            ThreadPool.QueueUserWorkItem(delegate
            {
                try
                {
                    switch (k.Action)
                    {
                        case "dpi_next": case "dpi_prev": { string r = Aparelhos.CycleDpi(k.Action == "dpi_next" ? 1 : -1); if (r != null) Program.Notify("NEXUS", "🖱 " + r); break; }
                        case "panel": Painel.Toggle("mini"); break;
                        case "fps": Medicao.Toggle(); break;
                        case "overlay": Program.Ui(GameOverlay.Toggle); break;
                        case "media":
                            {
                                int vk = k.Arg == "next" ? 0xB0 : k.Arg == "prev" ? 0xB1 : k.Arg == "volup" ? 0xAF : k.Arg == "voldown" ? 0xAE : k.Arg == "mute" ? 0xAD : 0xB3;
                                SendVk(vk); break;
                            }
                        case "open":
                            if (!string.IsNullOrEmpty(k.Arg) && (File.Exists(k.Arg) || k.Arg.StartsWith("steam://", StringComparison.OrdinalIgnoreCase)))
                                Process.Start(new ProcessStartInfo(k.Arg) { UseShellExecute = true, WorkingDirectory = File.Exists(k.Arg) ? Path.GetDirectoryName(k.Arg) : "" });
                            break;
                        case "micmute": { Som.Set(1, "togglemute", null); Program.Notify("NEXUS", Som.MicMuted() ? Lang.L("🎙 Microfone silenciado") : Lang.L("🎙 Microfone ligado")); break; }
                        case "text":
                            foreach (char c in (k.Arg ?? "").Take(500)) { TypeChar(c); Thread.Sleep(4); }
                            break;
                    }
                }
                catch { }
            });
        }
        static void TypeChar(char c)
        {
            KI d = new KI { scan = c, flags = 0x0004, extra = MARK }, u = new KI { scan = c, flags = 0x0004 | 0x0002, extra = MARK };   // KEYEVENTF_UNICODE
            Send(d, null); Send(u, null);
        }

        // ------------------------------------------------------------ ganchos (só ligados quando há atalhos ou uma gravação)
        delegate IntPtr HookProc(int code, IntPtr w, IntPtr l);
        [DllImport("user32.dll", SetLastError = true)] static extern IntPtr SetWindowsHookEx(int id, HookProc p, IntPtr mod, uint thread);
        [DllImport("user32.dll")] static extern bool UnhookWindowsHookEx(IntPtr h);
        [DllImport("user32.dll")] static extern IntPtr CallNextHookEx(IntPtr h, int code, IntPtr w, IntPtr l);
        [DllImport("user32.dll")] static extern short GetAsyncKeyState(int vk);
        [DllImport("kernel32.dll")] static extern IntPtr GetModuleHandle(string n);
        [StructLayout(LayoutKind.Sequential)] struct KBD { public uint vk, scan, flags, time; public IntPtr extra; }
        [StructLayout(LayoutKind.Sequential)] struct MSL { public int x, y; public uint data, flags, time; public IntPtr extra; }

        static Thread th; static HookWin win;
        static IntPtr hk, hm; static HookProc kp, mp;
        static volatile bool recording, recMouse; static readonly List<Step> rec = new List<Step>(); static uint recLast;
        static readonly HashSet<string> held = new HashSet<string>();   // atalhos com a tecla em baixo
        static readonly HashSet<int> swallowUp = new HashSet<int>();     // teclas cujo "soltar" também se esconde

        // ------------------------------------------------------------ Snap Tap (a última tecla carregada ganha) e modo jogo
        // Snap Tap: com A e D em baixo ao mesmo tempo, conta só a última; ao largá-la volta a primeira. Funciona em qualquer teclado.
        // O CS2 expulsa dos servidores da Valve quem usa isto: lá desliga-se sempre, sozinho.
        const string SNAPDEF = "65,68;87,83";   // A/D e W/S
        public static bool SnapOn { get { return Cfg23.On("snap_on", false); } }
        public static int GmMode { get { int m; return int.TryParse(Cfg23.Get("gm_mode", null), out m) && m >= 0 && m <= 2 ? m : 0; } }   // 0 desligado, 1 com um jogo aberto, 2 sempre
        static readonly string[] SNAPBAN = { "cs2", "csgo" };
        static bool SnapLive() { string g; lock (lk) g = game; return SnapOn && (g == null || !SNAPBAN.Contains(g)); }
        static bool GmLive() { int m = GmMode; if (m == 2) return true; string g; lock (lk) g = game; return m == 1 && g != null; }
        static readonly Dictionary<int, int> snapPartner = new Dictionary<int, int>();
        static readonly HashSet<int> snapDown = new HashSet<int>();
        static void SnapLoad()
        {
            lock (snapPartner)
            {
                snapPartner.Clear(); snapDown.Clear();
                foreach (string p in (Cfg23.Get("snap_pairs", null) ?? SNAPDEF).Split(';'))
                {
                    string[] q = p.Split(','); int a, b;
                    if (q.Length == 2 && int.TryParse(q[0], out a) && int.TryParse(q[1], out b) && a > 7 && b > 7 && a < 256 && b < 256 && a != b && !snapPartner.ContainsKey(a) && !snapPartner.ContainsKey(b))
                    { snapPartner[a] = b; snapPartner[b] = a; }
                }
            }
        }
        static void Snap(int vk, bool down)
        {
            int p; bool other;
            lock (snapPartner)
            {
                if (!snapPartner.TryGetValue(vk, out p)) return;
                if (down) { if (!snapDown.Add(vk)) return; }   // repetição automática
                else snapDown.Remove(vk);
                other = snapDown.Contains(p);
            }
            if (other) SendKey(p, !down);   // carregou: larga a outra · largou: volta a carregar a outra
        }
        // modo jogo: esconde a tecla Windows, Alt+Tab e Alt+F4 (para não saíres do jogo sem querer)
        static bool GmBlock(int vk, uint flags)
        {
            bool alt = (flags & 0x20) != 0;
            if ((vk == 0x5B || vk == 0x5C) && Cfg23.Get("gm_win", null) != "0") return true;
            if (vk == 0x09 && alt && Cfg23.Get("gm_tab", null) != "0") return true;
            if (vk == 0x73 && alt && Cfg23.Get("gm_f4", null) != "0") return true;
            return false;
        }
        public static string SetSnap(string on, string pairs)
        {
            if (on != null) Cfg23.Set("snap_on", on == "1" ? "1" : "0");
            if (pairs != null && pairs.Length < 200) Cfg23.Set("snap_pairs", pairs);
            SnapLoad(); Apply(); return Json();
        }
        public static string SetGm(string mode, string win, string tab, string f4)
        {
            int m; if (int.TryParse(mode, out m) && m >= 0 && m <= 2) Cfg23.Set("gm_mode", m.ToString());
            if (win != null) Cfg23.Set("gm_win", win == "0" ? "0" : "1");
            if (tab != null) Cfg23.Set("gm_tab", tab == "0" ? "0" : "1");
            if (f4 != null) Cfg23.Set("gm_f4", f4 == "0" ? "0" : "1");
            if (mode != null) { if (GmMode == 2) Aparelhos.KbGameAll(true); else if (GmMode == 0) Aparelhos.KbGameAll(false); }
            Apply(); return Json();
        }
        static bool Need() { lock (lk) { Load(); return (Enabled && (recording || keys.Count > 0)) || SnapOn || GmMode > 0; } }

        // liga/desliga os ganchos conforme é preciso (chamado quando muda algo)
        public static void Apply()
        {
            SnapLoad();
            bool need = Need();
            if (need && th == null)
            {
                th = new Thread(Loop) { IsBackground = true, Name = "NEXUS atalhos" };
                th.SetApartmentState(ApartmentState.STA);
                th.Start();
            }
            else if (!need && th != null && win != null) win.Post(0x8002);
            else if (need && win != null) win.Post(0x8001);
        }
        public static void OnStart() { try { Apply(); } catch { } }
        public static void Quit() { StopAll(); if (win != null) win.Post(0x8002); }

        static void Loop()
        {
            try
            {
                kp = KbHook; mp = MouseHook;
                IntPtr mod = GetModuleHandle(null);
                hk = SetWindowsHookEx(13, kp, mod, 0);
                hm = SetWindowsHookEx(14, mp, mod, 0);
                win = new HookWin(); win.SetRaw();
                if (!Need()) win.Post(0x8002);   // desligaram entretanto
                Application.Run();   // até win.Close() parar o ciclo
            }
            catch { }
            finally
            {
                if (hk != IntPtr.Zero) UnhookWindowsHookEx(hk); if (hm != IntPtr.Zero) UnhookWindowsHookEx(hm);
                hk = hm = IntPtr.Zero; win = null; th = null;
            }
        }
        static int Mods()
        {
            return ((GetAsyncKeyState(0x11) & 0x8000) != 0 ? 1 : 0) | ((GetAsyncKeyState(0x12) & 0x8000) != 0 ? 2 : 0) | ((GetAsyncKeyState(0x10) & 0x8000) != 0 ? 4 : 0) |
                   ((GetAsyncKeyState(0x5B) & 0x8000) != 0 || (GetAsyncKeyState(0x5C) & 0x8000) != 0 ? 8 : 0);
        }
        static bool IsMod(int vk) { return vk == 0x10 || vk == 0x11 || vk == 0x12 || vk == 0xA0 || vk == 0xA1 || vk == 0xA2 || vk == 0xA3 || vk == 0xA4 || vk == 0xA5 || vk == 0x5B || vk == 0x5C; }

        static void Record(char t, int code, bool down, uint time)
        {
            lock (lk)
            {
                if (rec.Count >= 2000) return;
                int delay = recLast == 0 ? 0 : (int)Math.Min(60000, time - recLast);
                recLast = time;
                if (t == 'k' && down && rec.Count > 0) { Step p = rec[rec.Count - 1]; if (p.T == 'k' && p.Code == code && p.Down) { recLast = time - (uint)delay; return; } }   // repetição automática da tecla
                rec.Add(new Step { T = t, Code = code, Down = down, Delay = delay });
            }
        }

        // devolve true se o evento deve ser escondido
        static bool Trigger(int vk, bool down, string dev)
        {
            if (!Enabled) return false;
            string g; lock (lk) g = game;
            List<Key> l; lock (lk) l = keys.ToList();
            if (!down)
            {
                bool sw; lock (swallowUp) sw = swallowUp.Remove(vk);
                foreach (Key k in l.Where(x => x.Vk == vk)) { bool was; lock (held) was = held.Remove(k.Id); if (was) Run(k, false); }
                return sw;
            }
            int mods = Mods(); bool hide = false;
            foreach (Key k in l)
            {
                bool single = k.Mods == 0 && (k.Action == "remap" || k.Action == "disable" || k.Action == "turbo");
                if (k.Vk != vk || (k.Mods != mods && !single)) continue;   // tecla trocada/desligada conta mesmo com Shift/Ctrl em baixo
                if (k.Game != "" && k.Game != g) continue;
                if (k.Dev != "" && k.Dev != dev) continue;
                if (dev != null && k.Dev != dev) continue;   // pelo raw input só contam os atalhos desse aparelho
                bool again; lock (held) again = !held.Add(k.Id);
                if (again) { if (k.Block && dev == null) hide = true; continue; }   // repetição automática: não volta a disparar
                Run(k, true);
                if (k.Block && dev == null) { hide = true; lock (swallowUp) swallowUp.Add(vk); }
            }
            return hide;
        }
        static bool HasDevKeys() { lock (lk) return keys.Any(k => k.Dev != ""); }

        static IntPtr KbHook(int code, IntPtr w, IntPtr l)
        {
            try
            {
                if (code >= 0)
                {
                    KBD k = (KBD)Marshal.PtrToStructure(l, typeof(KBD));
                    bool injected = (k.flags & 0x10) != 0 || k.extra == MARK;
                    int msg = w.ToInt32(); bool down = msg == 0x100 || msg == 0x104, up = msg == 0x101 || msg == 0x105;
                    if (!injected && (down || up))
                    {
                        if (!recording && GmLive() && GmBlock((int)k.vk, k.flags)) return new IntPtr(1);
                        if (recording)
                        {
                            if ((int)k.vk == 0x1B) { if (down) ThreadPool.QueueUserWorkItem(delegate { RecStop(null, false); }); return new IntPtr(1); }   // Esc acaba a gravação
                            Record('k', (int)k.vk, down, k.time);
                        }
                        else if (!IsMod((int)k.vk) && Trigger((int)k.vk, down, null)) return new IntPtr(1);
                        else if (SnapLive()) Snap((int)k.vk, down);
                    }
                }
            }
            catch { }
            return CallNextHookEx(hk, code, w, l);
        }
        static IntPtr MouseHook(int code, IntPtr w, IntPtr l)
        {
            try
            {
                if (code >= 0)
                {
                    int msg = w.ToInt32();
                    if (msg != 0x200)   // movimento não interessa
                    {
                        MSL m = (MSL)Marshal.PtrToStructure(l, typeof(MSL));
                        bool injected = (m.flags & 0x01) != 0 || m.extra == MARK;
                        if (!injected)
                        {
                            int btn = 0; bool down = false;
                            switch (msg)
                            {
                                case 0x201: btn = 1; down = true; break; case 0x202: btn = 1; break;
                                case 0x204: btn = 2; down = true; break; case 0x205: btn = 2; break;
                                case 0x207: btn = 3; down = true; break; case 0x208: btn = 3; break;
                                case 0x20B: btn = ((m.data >> 16) & 0xFFFF) == 1 ? 4 : 5; down = true; break;
                                case 0x20C: btn = ((m.data >> 16) & 0xFFFF) == 1 ? 4 : 5; break;
                                case 0x20A: if (recording && recMouse) Record('w', (short)((m.data >> 16) & 0xFFFF), false, m.time); break;
                            }
                            if (btn > 0)
                            {
                                if (recording) { if (recMouse) Record('m', btn, down, m.time); }
                                else if (btn >= 3)
                                {
                                    int vk = btn == 3 ? 0x04 : btn == 4 ? 0x05 : 0x06;   // meio e botões laterais podem ser atalhos
                                    if (Trigger(vk, down, null)) return new IntPtr(1);
                                }
                            }
                        }
                    }
                }
            }
            catch { }
            return CallNextHookEx(hm, code, w, l);
        }

        // ------------------------------------------------------------ "raw input": saber de que teclado/rato veio a tecla
        [StructLayout(LayoutKind.Sequential)] struct RID { public ushort page, usage; public uint flags; public IntPtr target; }
        [StructLayout(LayoutKind.Sequential)] struct RIDL { public IntPtr h; public uint type; }
        [DllImport("user32.dll")] static extern bool RegisterRawInputDevices(RID[] d, uint n, uint size);
        [DllImport("user32.dll")] static extern uint GetRawInputData(IntPtr h, uint cmd, IntPtr data, ref uint size, uint hsize);
        [DllImport("user32.dll")] static extern uint GetRawInputDeviceList(IntPtr list, ref uint n, uint size);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern uint GetRawInputDeviceInfo(IntPtr h, uint cmd, StringBuilder data, ref uint size);

        static string DevName(IntPtr h)
        {
            uint n = 0; GetRawInputDeviceInfo(h, 0x20000007, null, ref n);
            if (n == 0 || n > 1024) return "";
            StringBuilder sb = new StringBuilder((int)n + 1); GetRawInputDeviceInfo(h, 0x20000007, sb, ref n);
            return Hid.Parent(sb.ToString());
        }
        // teclados e ratos ligados (para escolher num atalho): id = caminho do aparelho, nome = marca/modelo quando se sabe
        static List<KeyValuePair<string, string>> RawDevices()
        {
            List<KeyValuePair<string, string>> r = new List<KeyValuePair<string, string>>();
            try
            {
                uint n = 0, sz = (uint)Marshal.SizeOf(typeof(RIDL));
                GetRawInputDeviceList(IntPtr.Zero, ref n, sz);
                if (n == 0 || n > 256) return r;
                IntPtr buf = Marshal.AllocHGlobal((int)(n * sz));
                try
                {
                    GetRawInputDeviceList(buf, ref n, sz);
                    List<Aparelho> ap = Aparelhos.All;
                    for (int i = 0; i < n; i++)
                    {
                        RIDL d = (RIDL)Marshal.PtrToStructure(new IntPtr(buf.ToInt64() + i * sz), typeof(RIDL));
                        if (d.type > 1) continue;
                        string id = DevName(d.h); if (id == "" || id.Contains("root#") || r.Any(x => x.Key == id)) continue;
                        string vid = Between(id, "vid_", 4), pid = Between(id, "pid_", 4);
                        if (vid == "") continue;
                        Aparelho a = ap.FirstOrDefault(x => x.Vid.ToString("x4") == vid && x.Pid.ToString("x4") == pid);
                        string brand = vid == "1532" ? "Razer" : vid == "046d" ? "Logitech" : vid == "1038" ? "SteelSeries" : vid == "1b1c" ? "Corsair" : vid == "3434" ? "Keychron" : vid == "258a" || vid == "3554" ? "" : "";
                        string nm = a != null ? a.Name : ((brand != "" ? brand + " " : "") + (d.type == 0 ? Lang.L("rato") : Lang.L("teclado")) + " " + vid.ToUpperInvariant() + ":" + pid.ToUpperInvariant()).Trim();
                        r.Add(new KeyValuePair<string, string>(id, (d.type == 0 ? "🖱 " : "⌨ ") + nm));
                    }
                }
                finally { Marshal.FreeHGlobal(buf); }
            }
            catch { }
            return r;
        }
        static string Between(string s, string k, int len) { int i = s.IndexOf(k); return i >= 0 && i + k.Length + len <= s.Length ? s.Substring(i + k.Length, len) : ""; }

        class HookWin : NativeWindow
        {
            bool raw;
            [DllImport("user32.dll")] static extern bool PostMessage(IntPtr h, int msg, IntPtr w, IntPtr l);
            public HookWin() { CreateParams cp = new CreateParams(); cp.Parent = new IntPtr(-3); CreateHandle(cp); }   // janela só de mensagens
            // pedidos de outras threads: 0x8001 = rever o raw input, 0x8002 = fechar (desligar os ganchos)
            public void Post(int msg) { try { if (Handle != IntPtr.Zero) PostMessage(Handle, msg, IntPtr.Zero, IntPtr.Zero); } catch { } }
            public void SetRaw()
            {
                bool want = HasDevKeys();
                if (want == raw || Handle == IntPtr.Zero) return;
                RID[] d = { new RID { page = 1, usage = 6, flags = want ? 0x100u : 0x1u, target = want ? Handle : IntPtr.Zero }, new RID { page = 1, usage = 2, flags = want ? 0x100u : 0x1u, target = want ? Handle : IntPtr.Zero } };
                RegisterRawInputDevices(d, 2, (uint)Marshal.SizeOf(typeof(RID)));
                raw = want;
            }
            protected override void WndProc(ref Message m)
            {
                if (m.Msg == 0x8001) { SetRaw(); return; }
                if (m.Msg == 0x8002) { try { DestroyHandle(); } catch { } Application.ExitThread(); return; }
                if (m.Msg == 0x00FF)   // WM_INPUT
                {
                    try
                    {
                        uint size = 0, hs = (uint)(IntPtr.Size == 8 ? 24 : 16);
                        GetRawInputData(m.LParam, 0x10000003, IntPtr.Zero, ref size, hs);
                        if (size > 0 && size < 1024)
                        {
                            IntPtr b = Marshal.AllocHGlobal((int)size);
                            try
                            {
                                if (GetRawInputData(m.LParam, 0x10000003, b, ref size, hs) == size)
                                {
                                    uint type = (uint)Marshal.ReadInt32(b);
                                    IntPtr dev = Marshal.ReadIntPtr(b, 8);
                                    int o = (int)hs;
                                    string id = null;
                                    if (type == 1)   // teclado: MakeCode(2) Flags(2) Reserved(2) VKey(2) Message(4)
                                    {
                                        int vk = (ushort)Marshal.ReadInt16(b, o + 6), msg = Marshal.ReadInt32(b, o + 8);
                                        bool down = msg == 0x100 || msg == 0x104, up = msg == 0x101 || msg == 0x105;
                                        if ((down || up) && !IsMod(vk) && !recording) { id = DevName(dev); if (id != "") TriggerDev(vk, down, id); }
                                    }
                                    else if (type == 0)   // rato: flags(2) pad(2) buttonFlags(2) buttonData(2) ...
                                    {
                                        int bf = (ushort)Marshal.ReadInt16(b, o + 4);
                                        int[][] map = { new[] { 0x10, 0x04, 1 }, new[] { 0x20, 0x04, 0 }, new[] { 0x40, 0x05, 1 }, new[] { 0x80, 0x05, 0 }, new[] { 0x100, 0x06, 1 }, new[] { 0x200, 0x06, 0 } };
                                        foreach (int[] x in map) if ((bf & x[0]) != 0 && !recording) { if (id == null) id = DevName(dev); if (id != "") TriggerDev(x[1], x[2] == 1, id); }
                                    }
                                }
                            }
                            finally { Marshal.FreeHGlobal(b); }
                        }
                    }
                    catch { }
                }
                base.WndProc(ref m);
            }
            // só os atalhos presos a um aparelho passam por aqui (os outros vêm dos ganchos)
            static void TriggerDev(int vk, bool down, string id)
            {
                bool any; lock (lk) any = keys.Any(k => k.Dev == id && k.Vk == vk);
                if (any) Trigger(vk, down, id);
            }
        }
    }
}
