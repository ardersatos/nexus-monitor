// NEXUS Monitor - bateria de auscultadores de várias marcas (SteelSeries, Corsair, HyperX/Kingston)
// Os pedidos de cada modelo vêm do que o projeto HeadsetControl documentou (código escrito de raiz para o NEXUS).
// Só se fazem pedidos de LEITURA (bateria e se está a carregar). Nada sai do PC.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using Microsoft.Win32.SafeHandles;

namespace Nexus
{
    // escrever um relatório e esperar a resposta (com tempo limite; nunca fica preso)
    static class HidIo
    {
        [DllImport("kernel32.dll", SetLastError = true)] static extern bool ReadFile(SafeFileHandle h, byte[] b, int n, IntPtr read, ref NativeOverlapped o);
        [DllImport("kernel32.dll", SetLastError = true)] static extern bool WriteFile(SafeFileHandle h, byte[] b, int n, IntPtr wr, ref NativeOverlapped o);
        [DllImport("kernel32.dll", SetLastError = true)] static extern bool GetOverlappedResult(SafeFileHandle h, ref NativeOverlapped o, out int n, bool wait);
        [DllImport("kernel32.dll")] static extern bool CancelIoEx(SafeFileHandle h, IntPtr o);

        public static SafeFileHandle Open(string path) { return Hid.CreateFile(path, 0xC0000000, 3, IntPtr.Zero, 3, 0x40000000, IntPtr.Zero); }

        public static bool Write(SafeFileHandle h, byte[] req, int outLen)
        {
            if (outLen <= 0) return false;
            byte[] w = new byte[outLen]; Array.Copy(req, w, Math.Min(req.Length, outLen));
            using (ManualResetEvent ev = new ManualResetEvent(false))
            {
                NativeOverlapped o = new NativeOverlapped(); o.EventHandle = ev.SafeWaitHandle.DangerousGetHandle();
                if (!WriteFile(h, w, w.Length, IntPtr.Zero, ref o) && Marshal.GetLastWin32Error() != 997) return false;
                if (!ev.WaitOne(500)) { CancelIoEx(h, IntPtr.Zero); int x; GetOverlappedResult(h, ref o, out x, true); return false; }
                return true;
            }
        }
        // lê um relatório de entrada; null se não chegar nada a tempo
        public static byte[] Read(SafeFileHandle h, int inLen, int ms)
        {
            if (inLen <= 0) return null;
            byte[] a = new byte[inLen];
            using (ManualResetEvent ev = new ManualResetEvent(false))
            {
                NativeOverlapped o = new NativeOverlapped(); o.EventHandle = ev.SafeWaitHandle.DangerousGetHandle();
                if (!ReadFile(h, a, inLen, IntPtr.Zero, ref o) && Marshal.GetLastWin32Error() != 997) return null;
                if (!ev.WaitOne(Math.Max(1, ms))) { CancelIoEx(h, IntPtr.Zero); int x; GetOverlappedResult(h, ref o, out x, true); return null; }
                int n; GetOverlappedResult(h, ref o, out n, false);
                if (n <= 0) return null;
                if (n < a.Length) Array.Resize(ref a, n);
                return a;
            }
        }
        // pedido -> resposta. Como no hidapi: se o relatório não tem número (0), a resposta vem sem esse 0 à frente.
        public static byte[] Ask(SafeFileHandle h, int outLen, int inLen, byte[] req, Func<byte[], bool> ok, int ms = 700, int waitAfterWrite = 0)
        {
            while (Read(h, inLen, 5) != null) { }   // deita fora o que estava em espera
            if (!Write(h, req, outLen)) return null;
            if (waitAfterWrite > 0) Thread.Sleep(waitAfterWrite);
            DateTime end = DateTime.UtcNow.AddMilliseconds(ms);
            while (DateTime.UtcNow < end)
            {
                byte[] a = Read(h, inLen, (int)Math.Max(1, (end - DateTime.UtcNow).TotalMilliseconds));
                if (a == null) return null;
                if (req.Length > 0 && req[0] == 0 && a.Length > 1 && a[0] == 0) a = a.Skip(1).ToArray();
                if (ok == null || ok(a)) return a;
            }
            return null;
        }
    }

    // um modelo conhecido: como se encontra e como se lê a bateria
    class HsSpec
    {
        public ushort Vid; public ushort[] Pids; public string Name; public int UsagePage = -1, Iface = -1;
        public Func<HsDev, int[]> Bat;
        public Func<HsDev, int, bool> Off;   // desligar sozinho após N minutos sem som (null = este modelo não deixa)   // devolve { nível 0-100 ou -1, a carregar 1/0/-1 (não se sabe) } ou null; { -2 } = auscultadores desligados
    }

    class HsDev : Aparelho
    {
        public readonly string path; public readonly int inLen, outLen; readonly HsSpec spec;
        public HsDev(Hid.Dev d, HsSpec s)
        {
            IdleSettable = s.Off != null;
            path = d.Path; inLen = d.InLen; outLen = d.OutLen; spec = s; Vid = d.Vid; Pid = d.Pid; Kind = "headset"; Wireless = true;
            Brand = s.Name.Split(' ')[0];
            Name = !string.IsNullOrEmpty(d.Product) && d.Product.Length > 3 ? d.Product : s.Name;
            if (Name.IndexOf(Brand, StringComparison.OrdinalIgnoreCase) < 0) Name = Brand + " " + Name;
            Id = "hs:" + Vid.ToString("x4") + Pid.ToString("x4") + ":" + Hid.Parent(path).GetHashCode().ToString("x8");
        }
        SafeFileHandle h;
        public byte[] Ask(byte[] req, Func<byte[], bool> ok, int ms = 700, int wait = 0) { return HidIo.Ask(h, outLen, inLen, req, ok, ms, wait); }
        public override void Refresh()
        {
            Err = "";
            using (h = HidIo.Open(path))
            {
                if (h.IsInvalid) { Battery = -1; return; }
                int[] r = null;
                try { r = spec.Bat(this); } catch { }
                if (r == null) { Battery = -1; return; }
                if (r[0] == -2) { Battery = -1; Err = Lang.L("Os auscultadores estão desligados ou longe do recetor."); return; }
                if (r[0] >= 0) Battery = Math.Max(0, Math.Min(100, r[0]));
                Charging = r.Length > 1 && r[1] == 1; ChargeUnknown = r.Length < 2 || r[1] < 0;
            }
            if (IdleSettable) { int m = Cfg23.Int("hs_off_" + Vid.ToString("x4") + Pid.ToString("x4"), 0); Idle = m > 0 ? m * 60 : -1; }   // os auscultadores não dizem o valor: fica o último escolhido
        }
        public bool W(params byte[] req) { return HidIo.Write(h, req, outLen); }
        public override bool SetIdle(int secs)
        {
            if (spec.Off == null) return false;
            int min = Math.Max(1, Math.Min(90, (int)Math.Round(secs / 60.0)));
            bool ok;
            using (h = HidIo.Open(path)) ok = !h.IsInvalid && spec.Off(this, min);
            if (ok) { Idle = min * 60; Cfg23.Set("hs_off_" + Vid.ToString("x4") + Pid.ToString("x4"), min.ToString()); }
            return ok;
        }
        public override bool SetDpi(int dpi) { return false; }
    }

    static class HsTable
    {
        static int Map(int v, int a, int b) { return b == a ? v : (int)Math.Round((v - a) * 100.0 / (b - a)); }
        static Func<byte[], bool> Starts(params byte[] p) { return a => a.Length >= p.Length && !p.Where((x, i) => a[i] != x).Any(); }
        static Func<byte[], bool> Len(int n) { return a => a.Length > n; }

        public static readonly List<HsSpec> All = new List<HsSpec>
        {
            // ---------------- SteelSeries
            new HsSpec { Vid = 0x1038, Pids = new ushort[] { 0x12b3, 0x12b6, 0x12d7, 0x12d5 }, Name = "SteelSeries Arctis Wireless", UsagePage = 0xFF43, Iface = 3,
                Bat = d => { var a = d.Ask(new byte[] { 0x06, 0x12 }, Len(3)); if (a == null) return null; if (a[2] == 0x01) return new[] { -2 }; return new[] { a[3], -1 }; },
                Off = (d, m) => d.W(0x06, 0x53, (byte)m) && d.W(0x06, 0x09) },
            new HsSpec { Vid = 0x1038, Pids = new ushort[] { 0x1260, 0x12ad, 0x1252, 0x1280 }, Name = "SteelSeries Arctis 7", UsagePage = 0xFF43, Iface = 5,
                Bat = d => { var a = d.Ask(new byte[] { 0x06, 0x18 }, Len(2)); return a == null ? null : new[] { (int)a[2], -1 }; },
                Off = (d, m) => d.W(0x06, 0x51, (byte)m) && d.W(0x06, 0x09) },
            new HsSpec { Vid = 0x1038, Pids = new ushort[] { 0x12c2, 0x12c4 }, Name = "SteelSeries Arctis 9", Iface = 0,
                Bat = d => { var a = d.Ask(new byte[] { 0x00, 0x20 }, Len(4)); return a == null ? null : new[] { Map(a[3], 0x64, 0x9A), a[4] == 1 ? 1 : 0 }; },
                Off = (d, m) => { int t = m * 60; return d.W(0x04, 0x00, (byte)(t >> 8), (byte)t) && d.W(0x90, 0x00); } },
            new HsSpec { Vid = 0x1038, Pids = new ushort[] { 0x220e, 0x2212, 0x2216, 0x2236 }, Name = "SteelSeries Arctis 7+", UsagePage = 0xFFC0, Iface = 3,
                Bat = d => { var a = d.Ask(new byte[] { 0x00, 0xb0 }, Len(3)); if (a == null) return null; if (a[1] == 0x01) return new[] { -2 }; return new[] { Map(a[2], 0, 4), a[3] == 1 ? 1 : 0 }; } },
            new HsSpec { Vid = 0x1038, Pids = new ushort[] { 0x2232, 0x2253, 0x2269, 0x226d }, Name = "SteelSeries Arctis Nova", UsagePage = 0xFFC0, Iface = 3,
                Bat = d => { var a = d.Ask(new byte[] { 0x00, 0xb0 }, Len(4)); if (a == null) return null; if (a[1] == 0x02) return new[] { -2 }; return new[] { (int)a[3], a[4] == 1 ? 1 : 0 }; },
                Off = (d, m) => d.Pid == 0x2232 || d.Pid == 0x2253 ? d.W(0x00, 0xA3, (byte)m) : false },
            new HsSpec { Vid = 0x1038, Pids = new ushort[] { 0x2202, 0x22A1, 0x227e, 0x2206, 0x2258, 0x229e, 0x22ad, 0x223a, 0x22a9, 0x227a, 0x22a4, 0x22a5, 0x220a }, Name = "SteelSeries Arctis Nova 7", UsagePage = 0xFFC0, Iface = 3,
                Bat = d =>
                {
                    var a = d.Ask(new byte[] { 0x00, 0xb0 }, Len(3)); if (a == null) return null;
                    if (a[3] == 0x00) return new[] { -2 };
                    bool discrete = new ushort[] { 0x2202, 0x2206, 0x220a, 0x223a, 0x227a, 0x22a4 }.Contains(d.Pid);
                    return new[] { discrete ? Map(a[2], 0, 4) : a[2], a[3] == 1 || a[3] == 2 ? 1 : 0 };
                },
                Off = (d, m) => d.W(0x00, 0xa3, (byte)m) },
            new HsSpec { Vid = 0x1038, Pids = new ushort[] { 0x12e0, 0x12e5 }, Name = "SteelSeries Arctis Nova Pro Wireless", Iface = 4,
                Bat = d => { var a = d.Ask(new byte[] { 0x06, 0xb0 }, Len(15)); if (a == null) return null; if (a[15] == 0x01) return new[] { -2 }; return new[] { Map(a[6], 0, 8), a[15] == 0x02 ? 1 : 0 }; } },
            new HsSpec { Vid = 0x1038, Pids = new ushort[] { 0x2290 }, Name = "SteelSeries Arctis Nova Pro Omni", UsagePage = 0xFFC0, Iface = 3,
                Bat = d => { var a = d.Ask(new byte[] { 0x01, 0xb0 }, Starts(0x01, 0xb0), 900); if (a == null || a.Length < 16) return null; if (a[15] == 0x01) return new[] { -2 }; return a[6] > 100 ? null : new[] { (int)a[6], a[15] == 0x02 ? 1 : 0 }; } },

            // ---------------- Corsair (Void, HS70/HS75/HS80 sem fios e parecidos)
            new HsSpec { Vid = 0x1B1C, Pids = new ushort[] { 0x1b1c, 0x1b27, 0x0a14, 0x0a16, 0x0a17, 0x0a1d, 0x0a1a, 0x1b2a, 0x1b23, 0x1b29, 0x0a55, 0x0a51, 0x0a52, 0x0a38, 0x0a4f, 0x0a2b, 0x0a75, 0x0a56 }, Name = "Corsair", UsagePage = 0xFFC5, Iface = 3,
                Bat = d =>
                {
                    var a = d.Ask(new byte[] { 0xC9, 0x64 }, Len(4)); if (a == null) return null;
                    int st = a[4]; if (st == 0) return new[] { -2 };
                    if (st != 1 && st != 2 && st != 4 && st != 5) return null;
                    return new[] { a[2] & 0x7F, st == 4 || st == 5 ? 1 : 0 };
                } },

            // ---------------- HyperX / Kingston
            new HsSpec { Vid = 0x03F0, Pids = new ushort[] { 0x098d }, Name = "HyperX Cloud Alpha Wireless", Iface = 0,
                Bat = d =>
                {
                    var c = d.Ask(new byte[] { 0x21, 0xbb, 0x03 }, Starts(0x21, 0xbb, 0x03), 1500); if (c == null) return null; if (c[3] == 0x01) return new[] { -2 };
                    var g = d.Ask(new byte[] { 0x21, 0xbb, 0x0c }, Starts(0x21, 0xbb, 0x0c), 1500); bool chg = g != null && g[3] == 0x01;
                    var b = d.Ask(new byte[] { 0x21, 0xbb, 0x0b }, Starts(0x21, 0xbb, 0x0b), 1500);
                    return new[] { b != null && !chg ? b[3] : -1, chg ? 1 : 0 };
                },
                Off = (d, m) => d.W(0x21, 0xbb, 0x12, (byte)m) },
            new HsSpec { Vid = 0x03F0, Pids = new ushort[] { 0x0696, 0x018b }, Name = "HyperX Cloud II Wireless", UsagePage = 0xFF90, Iface = 0,
                Bat = d =>
                {
                    var b = d.Ask(new byte[] { 0x06, 0xff, 0xbb, 0x02 }, Starts(0x06, 0xff, 0xbb, 0x02), 1000, 100); if (b == null || b.Length < 8) return null;
                    var c = d.Ask(new byte[] { 0x06, 0xff, 0xbb, 0x03 }, Starts(0x06, 0xff, 0xbb, 0x03), 1000, 100);
                    return new[] { (int)b[7], c == null ? -1 : c[4] == 1 ? 1 : 0 };
                } },
            new HsSpec { Vid = 0x0951, Pids = new ushort[] { 0x1718 }, Name = "HyperX Cloud II Wireless", Iface = 0,
                Bat = d =>
                {
                    Func<byte, byte[]> req = cmd => new byte[] { 0x06, 0x00, 0x02, 0x00, 0x9A, 0x00, 0x00, 0x68, 0x4A, 0x8E, 0x0A, 0x00, 0x00, 0x00, 0xBB, cmd, 0x00 };
                    var b = d.Ask(req(0x02), a => a.Length > 7 && a[0] == 0x0B && a[2] == 0xBB && a[3] == 0x02, 1000, 100); if (b == null) return null;
                    var c = d.Ask(req(0x03), a => a.Length > 4 && a[0] == 0x0B && a[2] == 0xBB && a[3] == 0x03, 1000, 100);
                    return new[] { (int)b[7], c == null ? -1 : c[4] == 1 ? 1 : 0 };
                } },
            new HsSpec { Vid = 0x0951, Pids = new ushort[] { 0x16C4, 0x1723 }, Name = "HyperX Cloud Flight", Iface = 0,
                Bat = d =>
                {
                    var a = d.Ask(new byte[] { 0x21, 0xff, 0x05 }, a2 => a2.Length == 0x0f || a2.Length == 0x14, 1500); if (a == null) return null;
                    int v = (a[3] << 8) | a[4];
                    if (v > 0x100B) return new[] { -1, 1 };   // acima disto está a carregar (o nível não se sabe nesse momento)
                    double p = v <= 3648 ? 0.00125 * v : v > 3975 ? 100 : 0.00000002547505 * Math.Pow(v, 4) - 0.0003900299 * Math.Pow(v, 3) + 2.238321 * Math.Pow(v, 2) - 5706.256 * v + 5452299.0;
                    return new[] { (int)Math.Round(Math.Max(0, Math.Min(100, p))), 0 };
                } },
        };

        public static readonly ushort[] Vids = { 0x1038, 0x1B1C, 0x03F0, 0x0951 };

        // aparelhos ligados que estão na tabela (uma entrada por aparelho físico; experimenta as coleções certas)
        public static List<HsDev> Find(List<Hid.Dev> all)
        {
            var found = new List<HsDev>();
            foreach (HsSpec s in All)
                foreach (var g in all.Where(d => d.Vid == s.Vid && s.Pids.Contains(d.Pid)).GroupBy(d => Hid.Parent(d.Path)))
                {
                    var cand = g.Where(d => d.OutLen > 0 && d.InLen > 0 && (s.UsagePage < 0 || d.UsagePage == s.UsagePage) && (s.Iface < 0 || Iface(d.Path) == s.Iface)).ToList();
                    if (cand.Count == 0) cand = g.Where(d => d.OutLen > 0 && d.InLen > 0 && d.UsagePage >= 0xFF00).ToList();   // reserva: qualquer coleção do fabricante
                    foreach (Hid.Dev d in cand)
                    {
                        HsDev x = new HsDev(d, s);
                        try { x.Refresh(); } catch { }
                        if (x.Battery >= 0 || x.Charging || x.Err != "") { found.Add(x); break; }
                    }
                }
            return found;
        }
        static int Iface(string path)
        {
            int i = path.IndexOf("&mi_", StringComparison.OrdinalIgnoreCase);
            int v; return i >= 0 && path.Length > i + 6 && int.TryParse(path.Substring(i + 4, 2), System.Globalization.NumberStyles.HexNumber, null, out v) ? v : 0;
        }
    }
}
