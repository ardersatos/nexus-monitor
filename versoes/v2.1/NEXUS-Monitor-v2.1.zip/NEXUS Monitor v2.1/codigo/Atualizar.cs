// NEXUS // MONITOR - procurar e instalar versões novas a partir do GitHub (ardersatos/nexus-monitor).
// Só lê um ficheiro público (versao.json) e descarrega o zip; não envia nada sobre o PC. Pode ser desligado nas Opções.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace Nexus
{
    static class Atualizar
    {
        const string RAW = "https://raw.githubusercontent.com/ardersatos/nexus-monitor/main/";
        public const string REPO = "https://github.com/ardersatos/nexus-monitor";

        static readonly object lk = new object();
        static Timer timer;
        static string latest, date, full, fullSha, upd, updSha, bat, batSha;
        static string fullSize, updSize;
        static List<string> files = new List<string>();
        static List<string> from = new List<string>(), notesPt = new List<string>(), notesEn = new List<string>();
        static string state = "idle", error, checkedAt;      // idle, checking, downloading, installing, error
        static int progress;
        static string notified;

        public static string Current
        {
            get { Version v = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version; return v.Major + "." + v.Minor + (v.Build > 0 ? "." + v.Build : ""); }
        }
        static Version V(string s)
        {
            if (string.IsNullOrEmpty(s)) return new Version(0, 0);
            string[] p = s.Trim().Split('.');
            int a = 0, b = 0, c = 0;
            if (p.Length > 0) int.TryParse(p[0], out a);
            if (p.Length > 1) int.TryParse(p[1], out b);
            if (p.Length > 2) int.TryParse(p[2], out c);
            return new Version(a, b, c);
        }
        public static bool Newer { get { return latest != null && V(latest) > V(Current); } }

        public static void Start()
        {
            // primeira verificação 1 min depois de abrir, depois a cada 6 h
            timer = new Timer(delegate { try { if (AppSettings.UpCheck) Check(); } catch { } }, null, 60000, 6 * 3600 * 1000);
        }

        static string Get(string url, int ms)
        {
            ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;   // TLS 1.2
            HttpWebRequest rq = (HttpWebRequest)WebRequest.Create(url + (url.Contains("?") ? "&" : "?") + "t=" + DateTime.UtcNow.Ticks);
            rq.UserAgent = "NEXUS-Monitor/" + Current; rq.Timeout = ms; rq.ReadWriteTimeout = ms;
            rq.CachePolicy = new System.Net.Cache.RequestCachePolicy(System.Net.Cache.RequestCacheLevel.NoCacheNoStore);
            using (WebResponse r = rq.GetResponse())
            using (StreamReader sr = new StreamReader(r.GetResponseStream(), Encoding.UTF8)) return sr.ReadToEnd();
        }
        static string Str(string json, string key)
        {
            Match m = Regex.Match(json, "\"" + key + "\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"");
            return m.Success ? Regex.Unescape(m.Groups[1].Value) : null;
        }
        static List<string> Arr(string json, string key)
        {
            List<string> l = new List<string>();
            Match m = Regex.Match(json, "\"" + key + "\"\\s*:\\s*\\[(.*?)\\]", RegexOptions.Singleline);
            if (!m.Success) return l;
            foreach (Match x in Regex.Matches(m.Groups[1].Value, "\"((?:[^\"\\\\]|\\\\.)*)\"")) l.Add(Regex.Unescape(x.Groups[1].Value));
            return l;
        }

        static string Num(string json, string key)
        {
            Match m = Regex.Match(json, "\"" + key + "\"\\s*:\\s*([0-9]+)");
            return m.Success ? m.Groups[1].Value : "0";
        }

        public static string Check()
        {
            lock (lk)
            {
                if (state == "downloading" || state == "installing") return Json();
                if (!AppSettings.UpCheck) { state = "idle"; error = null; return Json(); }
                state = "checking";
            }
            try
            {
                string j = Get(RAW + "versao.json", 15000);
                lock (lk)
                {
                    latest = Str(j, "ver"); date = Str(j, "date");
                    full = Str(j, "full"); fullSha = Str(j, "full_sha256");
                    upd = Str(j, "update"); updSha = Str(j, "update_sha256");
                    bat = Str(j, "updater"); batSha = Str(j, "updater_sha256");
                    from = Arr(j, "update_from"); files = Arr(j, "update_files");
                    fullSize = Num(j, "full_size"); updSize = Num(j, "update_size"); notesPt = Arr(j, "notes_pt"); notesEn = Arr(j, "notes_en");
                    state = "idle"; error = null; checkedAt = DateTime.Now.ToString("dd/MM HH:mm");
                }
                if (Newer && notified != latest)
                {
                    notified = latest;
                    ThreadPool.QueueUserWorkItem(delegate { try { Program.Notify("NEXUS · " + Lang.L("Versão nova") + " " + latest, Lang.L("Abre as Opções do NEXUS para instalar.")); } catch { } });
                }
            }
            catch (Exception ex) { lock (lk) { state = "idle"; error = Lang.L("Sem ligação ao GitHub.") + " (" + ex.GetType().Name + ")"; checkedAt = DateTime.Now.ToString("dd/MM HH:mm"); } }
            return Json();
        }

        public static string Json()
        {
            lock (lk)
            {
                bool viaUpd = from.Contains(Current) && upd != null;
                StringBuilder sb = new StringBuilder("{\"ok\":true,\"enabled\":" + (AppSettings.UpCheck ? "true" : "false"));
                sb.Append(",\"current\":").Append(Js.S(Current)).Append(",\"latest\":").Append(Js.S(latest)).Append(",\"date\":").Append(Js.S(date))
                  .Append(",\"newer\":").Append(Newer ? "true" : "false").Append(",\"small\":").Append(viaUpd ? "true" : "false")
                  .Append(",\"state\":").Append(Js.S(state)).Append(",\"progress\":").Append(progress).Append(",\"error\":").Append(Js.S(error))
                  .Append(",\"checked\":").Append(Js.S(checkedAt)).Append(",\"repo\":").Append(Js.S(REPO))
                  .Append(",\"size\":").Append(viaUpd ? updSize ?? "0" : fullSize ?? "0")
                  .Append(",\"files\":[").Append(viaUpd ? string.Join(",", files.Select(x => Js.S(x)).ToArray()) : "").Append(']');
                sb.Append(",\"notes_pt\":[").Append(string.Join(",", notesPt.Select(x => Js.S(x)).ToArray())).Append(']');
                sb.Append(",\"notes_en\":[").Append(string.Join(",", notesEn.Select(x => Js.S(x)).ToArray())).Append("]}");
                return sb.ToString();
            }
        }

        static void Download(string rel, string sha, string dst)
        {
            ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
            HttpWebRequest rq = (HttpWebRequest)WebRequest.Create(RAW + string.Join("/", rel.Split('/').Select(x => Uri.EscapeDataString(x)).ToArray()));
            rq.UserAgent = "NEXUS-Monitor/" + Current; rq.Timeout = 30000; rq.ReadWriteTimeout = 30000;
            using (WebResponse r = rq.GetResponse())
            using (Stream s = r.GetResponseStream())
            using (FileStream f = File.Create(dst))
            {
                long total = r.ContentLength, got = 0; byte[] buf = new byte[65536]; int n;
                while ((n = s.Read(buf, 0, buf.Length)) > 0)
                {
                    f.Write(buf, 0, n); got += n;
                    if (total > 0) progress = (int)(got * 100 / total);
                }
            }
            if (!string.IsNullOrEmpty(sha))
            {
                string h;
                using (SHA256 a = SHA256.Create()) using (FileStream f = File.OpenRead(dst)) h = BitConverter.ToString(a.ComputeHash(f)).Replace("-", "");
                if (!h.Equals(sha, StringComparison.OrdinalIgnoreCase)) { try { File.Delete(dst); } catch { } throw new Exception(Lang.L("o ficheiro descarregado não confere (SHA-256)")); }
            }
        }

        // descarrega o zip certo (o pequeno se esta versão está até 2 atrás), confere-o, extrai e corre o ATUALIZAR NEXUS.bat
        // como o NEXUS já corre como administrador, o .bat herda isso e não aparece o aviso do Windows
        public static string Install()
        {
            lock (lk)
            {
                if (!Newer) return "{\"ok\":false,\"error\":" + Js.S(Lang.L("Já tens a versão mais recente.")) + "}";
                if (state == "downloading" || state == "installing") return Json();
                state = "downloading"; progress = 0; error = null;
            }
            ThreadPool.QueueUserWorkItem(delegate
            {
                try
                {
                    bool small = from.Contains(Current) && upd != null;
                    string root = Path.Combine(Path.GetTempPath(), "NEXUS_update_" + latest);
                    try { if (Directory.Exists(root)) Directory.Delete(root, true); } catch { }
                    Directory.CreateDirectory(root);
                    string zip = Path.Combine(root, "nexus.zip");
                    Download(small ? upd : full, small ? updSha : fullSha, zip);
                    lock (lk) state = "installing";
                    string outDir = Path.Combine(root, "x");
                    ProcessStartInfo ex = new ProcessStartInfo("powershell.exe", "-NoProfile -ExecutionPolicy Bypass -Command \"Expand-Archive -LiteralPath '" + zip.Replace("'", "''") + "' -DestinationPath '" + outDir.Replace("'", "''") + "' -Force\"");
                    ex.UseShellExecute = false; ex.CreateNoWindow = true;
                    using (Process p = Process.Start(ex)) p.WaitForExit(120000);
                    string list = Directory.GetFiles(outDir, "nexus_ficheiros.txt", SearchOption.AllDirectories).FirstOrDefault();
                    if (list == null) throw new Exception(Lang.L("o zip não tem os ficheiros do NEXUS"));
                    string dir = Path.GetDirectoryName(list), upBat = Path.Combine(dir, "ATUALIZAR NEXUS.bat");
                    if (!File.Exists(upBat))
                    {
                        // o zip completo não traz o atualizador: vem à parte, do mesmo sítio
                        if (string.IsNullOrEmpty(bat)) throw new Exception(Lang.L("falta o ATUALIZAR NEXUS.bat"));
                        Download(bat, batSha, upBat);
                    }
                    ProcessStartInfo run = new ProcessStartInfo("cmd.exe", "/c \"\"" + upBat + "\" 1\"");
                    run.WorkingDirectory = dir; run.UseShellExecute = false;
                    Process.Start(run);
                    // o .bat fecha o NEXUS, atualiza e volta a abri-lo
                }
                catch (Exception e2)
                {
                    lock (lk) { state = "error"; error = e2.Message; }
                }
            });
            return Json();
        }
    }
}
