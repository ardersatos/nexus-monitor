﻿// NEXUS // MONITOR - janelas: overlay em jogo, alertas, painel do ícone e o tema dos menus
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Linq;
using System.Management;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Reflection;
using System.Security.Principal;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Win32;

namespace Nexus
{

    // ------------------------------------------------------------ overlay em jogo (tipo o Alt+R da NVIDIA)
    // Caixa sempre à frente com FPS, CPU, GPU, temperaturas, RAM… Os cliques passam para o jogo.
    // Funciona por cima de jogos em janela e sem bordas (ecrã inteiro exclusivo não deixa nada por cima).
    // Atalho global para mostrar/esconder; "MOVER NO ECRÃ" deixa arrastá-la com o rato.
    class GameOverlay : Form
    {
        static GameOverlay cur;
        static HotkeyWin hk;
        static bool keyOk = true;
        public static bool KeyOk { get { return keyOk; } }
        bool editing; DateTime editAt;
        Point dragFrom; bool dragging;
        readonly System.Windows.Forms.Timer tick = new System.Windows.Forms.Timer();
        Font fLbl, fVal, fHint;
        List<string[]> rows = new List<string[]>();     // {rótulo, valor, cor}

        [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int cx, int cy, uint flags);
        [DllImport("user32.dll")] static extern int GetWindowLong(IntPtr h, int i);
        [DllImport("user32.dll")] static extern int SetWindowLong(IntPtr h, int i, int v);
        [DllImport("user32.dll")] static extern bool RegisterHotKey(IntPtr h, int id, uint mods, uint vk);
        [DllImport("user32.dll")] static extern bool UnregisterHotKey(IntPtr h, int id);

        // "alt+shift+o" → {mods, vk}
        public static uint[] ParseKey(string k)
        {
            if (string.IsNullOrEmpty(k)) return null;
            uint mods = 0, vk = 0;
            foreach (string p0 in k.Split('+'))
            {
                string p = p0.Trim();
                if (p == "alt") mods |= 1; else if (p == "ctrl") mods |= 2; else if (p == "shift") mods |= 4; else if (p == "win") mods |= 8;
                else if (p.Length == 1 && char.IsLetterOrDigit(p[0])) vk = (uint)char.ToUpperInvariant(p[0]);
                else if (p.Length >= 2 && p.Length <= 3 && p[0] == 'f') { int n; if (int.TryParse(p.Substring(1), out n) && n >= 1 && n <= 12) vk = (uint)(0x70 + n - 1); else return null; }
                else if (p == "home") vk = 0x24; else if (p == "end") vk = 0x23; else if (p == "insert") vk = 0x2D; else if (p == "pageup") vk = 0x21; else if (p == "pagedown") vk = 0x22;
                else return null;
            }
            if (vk == 0) return null;
            if (mods == 0 && !(vk >= 0x70 && vk <= 0x7B)) return null;    // letra sozinha não: ia apanhar o que escreves
            return new uint[] { mods, vk };
        }

        class HotkeyWin : NativeWindow
        {
            public HotkeyWin() { CreateHandle(new CreateParams()); }
            protected override void WndProc(ref Message m)
            {
                if (m.Msg == 0x0312)
                {
                    if (m.WParam.ToInt32() == 8) { ThreadPool.QueueUserWorkItem(delegate { try { Medicao.Toggle(); } catch { } }); }
                    else Toggle();
                }
                base.WndProc(ref m);
            }
        }
        static string keyNow = null;
        static bool benchKey;
        static void RegisterKey()
        {
            if (hk == null) hk = new HotkeyWin();
            if (keyNow == AppSettings.OverlayKey) return;
            UnregisterHotKey(hk.Handle, 7);
            keyNow = AppSettings.OverlayKey;
            uint[] k = ParseKey(keyNow);
            keyOk = k == null ? keyNow == "" : RegisterHotKey(hk.Handle, 7, k[0] | 0x4000, k[1]);   // 0x4000: sem repetir ao segurar
            if (!benchKey) { benchKey = true; RegisterHotKey(hk.Handle, 8, 1 | 4 | 0x4000, (uint)'M'); }       // Alt+Shift+M: medir os FPS
        }

        // (thread da interface) aplica as opções: liga/desliga, atalho, tamanho, posição
        public static void Apply()
        {
            try { RegisterKey(); } catch { keyOk = false; }
            // o perfil do jogo aberto pode ligar o overlay mesmo com ele desligado nas opções
            if (AppSettings.OverlayOn || Perfis.OverlayOverride() == 1)
            {
                if (cur == null || cur.IsDisposed) { cur = new GameOverlay(); }
                cur.Refresh2();
            }
            else if (cur != null && !cur.IsDisposed && !cur.editing) { cur.Close(); cur = null; }
        }
        public static void Toggle()
        {
            AppSettings.OverlayOn = !AppSettings.OverlayOn;
            try { AppSettings.Save(); } catch { }
            Apply();
        }
        // "MOVER NO ECRÃ": mostra a caixa e deixa arrastá-la; duplo clique (ou 60 s) acaba
        public static void Edit()
        {
            if (!AppSettings.OverlayOn) { AppSettings.OverlayOn = true; try { AppSettings.Save(); } catch { } }
            Apply();
            if (cur == null) return;
            cur.editing = true; cur.editAt = DateTime.UtcNow;
            cur.SetClickThrough(false);
            cur.Cursor = Cursors.SizeAll;
            cur.Refresh2();
            if (!cur.Visible) cur.Show();
            try { cur.Activate(); } catch { }
        }
        void EndEdit()
        {
            editing = false; dragging = false; Cursor = Cursors.Default;
            SetClickThrough(true);
            SavePos();
            Refresh2();
        }

        GameOverlay()
        {
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            TopMost = true;
            StartPosition = FormStartPosition.Manual;
            DoubleBuffered = true;
            Size = new Size(10, 10);
            tick.Interval = 500;
            tick.Tick += delegate { try { Refresh2(); } catch { } };
            MouseDown += delegate(object o, MouseEventArgs e) { if (editing && e.Button == MouseButtons.Left) { dragging = true; dragFrom = e.Location; editAt = DateTime.UtcNow; } };
            MouseMove += delegate(object o, MouseEventArgs e) { if (editing && dragging) { Location = new Point(Left + e.X - dragFrom.X, Top + e.Y - dragFrom.Y); editAt = DateTime.UtcNow; } };
            MouseUp += delegate { if (editing && dragging) { dragging = false; SavePos(); } };
            MouseDoubleClick += delegate { if (editing) EndEdit(); };
            KeyDown += delegate(object o, KeyEventArgs e) { if (editing && (e.KeyCode == Keys.Escape || e.KeyCode == Keys.Enter)) EndEdit(); };
            FormClosed += delegate { tick.Stop(); };
            tick.Start();
        }
        protected override bool ShowWithoutActivation { get { return true; } }
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x00000080 | 0x00000008;                       // fora do Alt+Tab, à frente (a transparência é o WinForms que gere, pela Opacity)
                if (!editing) cp.ExStyle |= 0x08000000 | 0x00000020;        // sem foco e os cliques passam para o jogo (menos quando se está a mover)
                return cp;
            }
        }
        void SetClickThrough(bool on)
        {
            // o WinForms reaplica os estilos (CreateParams) quando a opacidade muda, por isso o estado vem de "editing"
            int ex = GetWindowLong(Handle, -20);
            ex = on ? (ex | 0x20 | 0x08000000) : (ex & ~0x20 & ~0x08000000);
            SetWindowLong(Handle, -20, ex);
            try { UpdateStyles(); } catch { }
        }

        Rectangle Scr { get { return Screen.PrimaryScreen.Bounds; } }
        const int M = 10;   // margem para a beira do ecrã
        void SavePos()
        {
            Rectangle r = Scr;
            int fw = Math.Max(1, r.Width - Width - 2 * M), fh = Math.Max(1, r.Height - Height - 2 * M);
            AppSettings.OverlayX = Math.Max(0, Math.Min(1000, (int)Math.Round((Left - r.Left - M) * 1000.0 / fw)));
            AppSettings.OverlayY = Math.Max(0, Math.Min(1000, (int)Math.Round((Top - r.Top - M) * 1000.0 / fh)));
            try { AppSettings.Save(); } catch { }
        }

        static string ColorHex(Color c) { return c.ToArgb().ToString(); }

        // lê os valores, mede, posiciona e mostra/esconde
        public void Refresh2()
        {
            if (editing && (DateTime.UtcNow - editAt).TotalSeconds > 60) { EndEdit(); return; }
            double sc = AppSettings.OverlayScale / 100.0;
            if (fLbl == null || Math.Abs(fVal.Size - 11f * (float)sc) > 0.01)
            {
                if (fLbl != null) { fLbl.Dispose(); fVal.Dispose(); fHint.Dispose(); }
                fLbl = new Font("Consolas", 8.5f * (float)sc); fVal = new Font("Consolas", 11f * (float)sc, FontStyle.Bold); fHint = new Font("Segoe UI", 8.5f);
            }
            double cpu, ramPct, ramGb; double? cpuT, gpu, gpuT;
            Stats.OverlaySnap(out cpu, out cpuT, out gpu, out gpuT, out ramPct, out ramGb);
            double? fps = null, ft = null, lat = null; string game = null;
            string g = PresentMonReader.Json();
            if (g == "null") g = Rtss.Json();
            CultureInfo ci = CultureInfo.InvariantCulture;
            if (g != "null")
            {
                System.Text.RegularExpressions.Match mm;
                if ((mm = System.Text.RegularExpressions.Regex.Match(g, "\"fps\":([0-9.]+)")).Success) fps = double.Parse(mm.Groups[1].Value, ci);
                if ((mm = System.Text.RegularExpressions.Regex.Match(g, "\"frametime\":([0-9.]+)")).Success) ft = double.Parse(mm.Groups[1].Value, ci);
                if ((mm = System.Text.RegularExpressions.Regex.Match(g, "\"latency\":([0-9.]+)")).Success) lat = double.Parse(mm.Groups[1].Value, ci);
                if ((mm = System.Text.RegularExpressions.Regex.Match(g, "\"name\":\"([^\"]*)\"")).Success) game = mm.Groups[1].Value;
            }
            int po = Perfis.OverlayOverride();     // perfil do jogo: 1 = mostrar, 0 = esconder, -1 = como nas opções
            bool show = editing || po == 1 || (po != 0 && (!AppSettings.OverlayGameOnly || Optimizer.Playing || fps.HasValue));
            if (!show) { if (Visible) Hide(); return; }

            Color c1 = AppSettings.ThemeColor("c1"), ok = AppSettings.ThemeColor("ok"), warn = AppSettings.ThemeColor("warn"), crit = AppSettings.ThemeColor("crit"), txt = AppSettings.ThemeColor("txt");
            Func<double, double, double, Color> lvl = (lv, lw2, lc) => lv >= lc ? crit : lv >= lw2 ? warn : txt;
            rows.Clear();
            foreach (string it in AppSettings.OverlayItems.Split(','))
            {
                switch (it)
                {
                    case "fps": rows.Add(new[] { "FPS", fps.HasValue ? Math.Round(fps.Value).ToString() : "--", ColorHex(c1) }); break;
                    case "ft": rows.Add(new[] { "FRAME", ft.HasValue ? ft.Value.ToString("0.0", ci) + " ms" : "--", ColorHex(txt) }); break;
                    case "lat": rows.Add(new[] { Lang.L("LATÊNCIA"), lat.HasValue ? lat.Value.ToString("0", ci) + " ms" : "--", ColorHex(txt) }); break;
                    case "cpu": rows.Add(new[] { "CPU", Math.Round(cpu) + "%", ColorHex(lvl(cpu, 85, 97)) }); break;
                    case "cput": rows.Add(new[] { "CPU °C", cpuT.HasValue ? Math.Round(cpuT.Value) + "°" : "--", ColorHex(cpuT.HasValue ? lvl(cpuT.Value, AppSettings.AlertCpu - 8, AppSettings.AlertCpu) : txt) }); break;
                    case "gpu": rows.Add(new[] { "GPU", gpu.HasValue ? Math.Round(gpu.Value) + "%" : "--", ColorHex(txt) }); break;
                    case "gput": rows.Add(new[] { "GPU °C", gpuT.HasValue ? Math.Round(gpuT.Value) + "°" : "--", ColorHex(gpuT.HasValue ? lvl(gpuT.Value, AppSettings.AlertGpu - 8, AppSettings.AlertGpu) : txt) }); break;
                    case "ram": rows.Add(new[] { "RAM", Math.Round(ramPct) + "%", ColorHex(lvl(ramPct, 85, AppSettings.AlertRam)) }); break;
                    case "ramgb": rows.Add(new[] { "RAM", ramGb.ToString("0.0", ci) + " GB", ColorHex(txt) }); break;
                    case "game": if (game != null) rows.Add(new[] { Lang.L("JOGO"), game, ColorHex(ok) }); break;
                    case "bott":
                        {
                            string bt = Analise.Bottleneck;
                            if (bt != "") rows.Add(new[] { Lang.L("LIMITE"), bt == "GPU" ? "GPU" : bt == "CPU" ? "CPU" : bt == "LIMITE" ? Lang.L("FPS/VSYNC") : "OK", ColorHex(bt == "CPU" ? warn : txt) });
                        }
                        break;
                    case "time": rows.Add(new[] { Lang.L("HORA"), DateTime.Now.ToString("HH:mm"), ColorHex(txt) }); break;
                }
            }
            string alr = AppSettings.OverlayAlerts ? Analise.Alert : null;
            if (alr != null) rows.Insert(0, new[] { "⚠", alr, ColorHex(crit) });
            if (Medicao.Recording || Medicao.Waiting)
                rows.Insert(0, new[] { Medicao.Recording ? "● REC" : Lang.L("MEDIR EM"), Medicao.SecondsLeft + " s", ColorHex(crit) });
            if (rows.Count == 0) rows.Add(new[] { "NEXUS", "--", ColorHex(c1) });

            // medir
            int pad = (int)(8 * sc), gap = (int)(14 * sc), w, h;
            using (Graphics gr = CreateGraphics())
            {
                if (AppSettings.OverlayStyle == "row")
                {
                    w = pad; h = 0;
                    foreach (string[] r in rows) { Size a = TextRenderer.MeasureText(gr, r[0], fLbl), b = TextRenderer.MeasureText(gr, r[1], fVal); w += a.Width + b.Width + gap; h = Math.Max(h, b.Height); }
                    w += pad - gap; h += pad * 2;
                }
                else
                {
                    int lw = 0, vw = 0, rh = 0;
                    foreach (string[] r in rows) { Size a = TextRenderer.MeasureText(gr, r[0], fLbl), b = TextRenderer.MeasureText(gr, r[1], fVal); lw = Math.Max(lw, a.Width); vw = Math.Max(vw, b.Width); rh = Math.Max(rh, b.Height); }
                    w = pad * 2 + lw + gap + vw; h = pad * 2 + rows.Count * rh;
                }
            }
            if (editing) { w = Math.Max(w, 250); h += 22; }
            Rectangle s = Scr;
            int x = s.Left + M + (int)Math.Round((s.Width - w - 2 * M) * AppSettings.OverlayX / 1000.0);
            int y = s.Top + M + (int)Math.Round((s.Height - h - 2 * M) * AppSettings.OverlayY / 1000.0);
            if (Width != w || Height != h) Size = new Size(w, h);
            if (!dragging && !editing && (Left != x || Top != y)) Location = new Point(x, y);
            if (editing && !dragging && (DateTime.UtcNow - editAt).TotalSeconds < 0.6) Location = new Point(x, y);
            // nunca 100%: com Opacity = 1 o WinForms deixa de configurar a janela transparente e o Windows não a mostra
            double op = editing ? 0.99 : Math.Min(0.99, AppSettings.OverlayOp / 100.0);
            if (Math.Abs(Opacity - op) > 0.001) Opacity = op;
            if (!Visible) Show();
            try { SetWindowPos(Handle, new IntPtr(-1), 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0010); } catch { }
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Color bg = AppSettings.ThemeColor("panel"), c1 = AppSettings.ThemeColor("c1"), dim = AppSettings.ThemeColor("dim");
            g.Clear(Color.FromArgb(255, bg.R / 2, bg.G / 2, bg.B / 2));
            using (Pen p = new Pen(Color.FromArgb(editing ? 255 : 90, c1)) { DashStyle = editing ? System.Drawing.Drawing2D.DashStyle.Dash : System.Drawing.Drawing2D.DashStyle.Solid })
                g.DrawRectangle(p, 0, 0, Width - 1, Height - 1);
            using (SolidBrush b = new SolidBrush(c1)) g.FillRectangle(b, 0, 0, 3, Height);
            double sc = AppSettings.OverlayScale / 100.0;
            int pad = (int)(8 * sc), gap = (int)(14 * sc);
            if (AppSettings.OverlayStyle == "row")
            {
                int x = pad;
                foreach (string[] r in rows)
                {
                    Size a = TextRenderer.MeasureText(g, r[0], fLbl), b = TextRenderer.MeasureText(g, r[1], fVal);
                    int vh = b.Height;
                    TextRenderer.DrawText(g, r[0], fLbl, new Point(x, pad + vh - a.Height - 1), dim);
                    TextRenderer.DrawText(g, r[1], fVal, new Point(x + a.Width - 2, pad), Color.FromArgb(int.Parse(r[2])));
                    x += a.Width + b.Width + gap;
                }
            }
            else
            {
                int lw = 0, rh = 0;
                foreach (string[] r in rows) { lw = Math.Max(lw, TextRenderer.MeasureText(g, r[0], fLbl).Width); rh = Math.Max(rh, TextRenderer.MeasureText(g, r[1], fVal).Height); }
                int y = pad;
                foreach (string[] r in rows)
                {
                    Size a = TextRenderer.MeasureText(g, r[0], fLbl);
                    TextRenderer.DrawText(g, r[0], fLbl, new Point(pad, y + (rh - a.Height) / 2 + 1), dim);
                    Size b = TextRenderer.MeasureText(g, r[1], fVal);
                    TextRenderer.DrawText(g, r[1], fVal, new Point(Width - pad - b.Width, y), Color.FromArgb(int.Parse(r[2])));
                    y += rh;
                }
            }
            if (editing)
                TextRenderer.DrawText(g, Lang.L("Arrasta · duplo clique para acabar"), fHint, new Rectangle(0, Height - 22, Width, 20), c1, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
        }
    }
    // ------------------------------------------------------------ painel ao passar o rato pelo ícone
    // atualiza a cada segundo sem piscar e desaparece quando o rato sai de cima do ícone

    // Notificação do NEXUS no canto do ecrã para os alertas: fica por cima de tudo (também de jogos em janela
    // sem bordas), não rouba o foco e, durante um jogo, aparece meio transparente e não apanha cliques.
    class AlertToast : Form
    {
        static AlertToast current;
        readonly string title, msg;
        bool gaming;
        readonly System.Windows.Forms.Timer life = new System.Windows.Forms.Timer(), top = new System.Windows.Forms.Timer();
        readonly Font fTitle = new Font("Consolas", 10.5f, FontStyle.Bold), fMsg = new Font("Segoe UI", 10f);
        DateTime born = DateTime.UtcNow;

        public static void Show(string title, string msg)
        {
            try { if (current != null && !current.IsDisposed) current.Close(); } catch { }
            current = new AlertToast(title, msg, Optimizer.Playing);
            current.Show();
        }

        // pré-visualização ao mexer nos sliders das opções: mostra (ou atualiza) um alerta de exemplo com essa opacidade
        public static void Preview(bool game, int op)
        {
            if (current != null && !current.IsDisposed && current.preview && current.gaming == game)
            {
                current.previewOp = op / 100.0; current.born = DateTime.UtcNow; current.Opacity = current.previewOp; current.Invalidate();
                return;
            }
            try { if (current != null && !current.IsDisposed) current.Close(); } catch { }
            current = new AlertToast(Lang.L(game ? "Pré-visualização · em jogo" : "Pré-visualização · fora de jogo"),
                                     Lang.L("CPU a 92 °C (limite 85 °C)."), game);
            current.preview = true; current.previewOp = op / 100.0; current.Opacity = current.previewOp;
            current.Show();
        }
        bool preview; double previewOp;
        double BaseOp { get { return preview ? previewOp : (gaming ? AppSettings.AlertOpGame : AppSettings.AlertOp) / 100.0; } }

        AlertToast(string title, string msg, bool gaming)
        {
            this.title = title; this.msg = msg; this.gaming = gaming;
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            TopMost = true;
            StartPosition = FormStartPosition.Manual;
            DoubleBuffered = true;
            using (Graphics g = CreateGraphics())
            {
                int w = Math.Max((int)g.MeasureString(title, fTitle).Width, (int)g.MeasureString(msg, fMsg).Width) + 62;
                Size = new Size(Math.Min(Math.Max(w, 300), 520), 74);
            }
            Rectangle wa = Screen.PrimaryScreen.WorkingArea;
            Location = new Point(wa.Right - Width - 16, wa.Bottom - Height - 16);
            Opacity = BaseOp;
            if (!gaming)
            {
                Cursor = Cursors.Hand;
                // ✕ no canto fecha; o resto da notificação abre o monitor
                MouseClick += delegate(object sender, MouseEventArgs e)
                {
                    if (!preview && (e.X < Width - 30 || e.Y > 30)) Program.OpenMonitor();
                    Close();
                };
            }
            life.Interval = 100;
            life.Tick += delegate
            {
                // fica o tempo escolhido nas opções; com o rato por cima não desaparece
                if (!gaming && Bounds.Contains(Control.MousePosition)) { born = DateTime.UtcNow.AddSeconds(-1); Opacity = BaseOp; }
                double t = (DateTime.UtcNow - born).TotalSeconds, total = preview ? 6 : Secs;
                if (t > total) { Close(); return; }
                if (t > total - 0.6) Opacity = BaseOp * Math.Max(0, (total - t) / 0.6);   // desaparece suave
                Invalidate();
            };
            top.Interval = 700;
            top.Tick += delegate { KeepOnTop(); };
            Shown += delegate { KeepOnTop(); life.Start(); top.Start(); };
            FormClosed += delegate { life.Stop(); top.Stop(); };
        }

        double Secs { get { return Math.Max(3, gaming ? AppSettings.AlertSecsGame : AppSettings.AlertSecs); } }
        protected override bool ShowWithoutActivation { get { return true; } }
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x08000000 | 0x00000080 | 0x00000008 | 0x00080000;   // sem foco, fora do Alt+Tab, sempre à frente, transparência
                if (gaming) cp.ExStyle |= 0x00000020;                                 // em jogo: os cliques passam para o jogo
                return cp;
            }
        }

        [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int cx, int cy, uint flags);
        void KeepOnTop() { try { SetWindowPos(Handle, new IntPtr(-1), 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0010 | 0x0040); } catch { } }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            Color bg = AppSettings.ThemeColor("panel"), crit = AppSettings.ThemeColor("crit"), txt = AppSettings.ThemeColor("txt");
            using (SolidBrush b = new SolidBrush(bg)) g.FillRectangle(b, ClientRectangle);
            using (SolidBrush b = new SolidBrush(Color.FromArgb(28, crit))) g.FillRectangle(b, ClientRectangle);
            using (Pen p = new Pen(crit)) g.DrawRectangle(p, 0, 0, Width - 1, Height - 1);
            // barra lateral a pulsar devagar
            double t = (DateTime.UtcNow - born).TotalSeconds;
            int a = (int)(150 + 105 * (0.5 + 0.5 * Math.Sin(t * 4)));
            using (SolidBrush b = new SolidBrush(Color.FromArgb(a, crit))) g.FillRectangle(b, 0, 0, 5, Height);
            using (SolidBrush b = new SolidBrush(crit)) g.DrawString("⚠ " + title, fTitle, b, 18, 13);
            using (SolidBrush b = new SolidBrush(txt)) g.DrawString(msg, fMsg, b, 18, 39);
            if (!gaming) using (SolidBrush b = new SolidBrush(Color.FromArgb(170, txt))) g.DrawString("✕", fMsg, b, Width - 24, 6);
            // barra fina em baixo: quanto tempo falta
            double left = Math.Max(0, 1 - (DateTime.UtcNow - born).TotalSeconds / (preview ? 6 : Secs));
            using (SolidBrush b = new SolidBrush(Color.FromArgb(160, crit))) g.FillRectangle(b, 5, Height - 3, (int)((Width - 6) * left), 2);
        }
    }

    class HoverPopup : Form
    {
        Point anchor;
        DateTime touched;
        List<string> lines = new List<string>();
        readonly System.Windows.Forms.Timer refresh = new System.Windows.Forms.Timer(), watch = new System.Windows.Forms.Timer();
        readonly Font fTitle = new Font("Consolas", 9.5f, FontStyle.Bold), fLine = new Font("Consolas", 9.5f);

        public HoverPopup()
        {
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            TopMost = true;
            StartPosition = FormStartPosition.Manual;
            DoubleBuffered = true;
            refresh.Interval = 1000;
            refresh.Tick += delegate { Reload(); KeepOnTop(); };
            watch.Interval = 150;
            watch.Tick += delegate
            {
                Point m = Control.MousePosition;
                // o rato saiu de cima do ícone (o Windows só avisa quando ele se mexe por cima)
                if (Math.Abs(m.X - anchor.X) > 12 || Math.Abs(m.Y - anchor.Y) > 12 || (DateTime.UtcNow - touched).TotalSeconds > 60) Hide();
            };
        }

        protected override bool ShowWithoutActivation { get { return true; } }
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x08000000 | 0x00000080 | 0x00000008;   // sem foco, fora do Alt+Tab, sempre à frente
                return cp;
            }
        }

        public void Touch()
        {
            anchor = Control.MousePosition;
            touched = DateTime.UtcNow;
            if (Visible) return;
            Reload();
            Rectangle wa = Screen.FromPoint(anchor).WorkingArea;
            int x = Math.Max(wa.Left + 4, Math.Min(anchor.X - Width / 2, wa.Right - Width - 4));
            // bem acima do ícone, para não ficar por baixo da janela dos ícones ocultos nem da barra do Windows
            int y = Math.Min(anchor.Y, wa.Bottom) - Height - 64;
            if (y < wa.Top) y = anchor.Y + 26;
            Location = new Point(x, y);
            Show();
            KeepOnTop();
            refresh.Start(); watch.Start();
        }

        public new void Hide()
        {
            refresh.Stop(); watch.Stop();
            if (Visible) base.Hide();
        }

        [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int cx, int cy, uint flags);
        // o Windows põe a janela dos ícones ocultos por cima de tudo: volta a pôr o painel à frente
        void KeepOnTop()
        {
            try { SetWindowPos(Handle, new IntPtr(-1), 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0010 | 0x0040); } catch { }   // TOPMOST, sem mover/redimensionar/ativar
        }

        void Reload()
        {
            try { lines = Stats.MenuLines(); } catch { }
            using (Graphics g = CreateGraphics())
            {
                int w = (int)g.MeasureString("NEXUS // MONITOR", fTitle).Width;
                foreach (string l in lines) w = Math.Max(w, (int)g.MeasureString(l, fLine).Width);
                Size sz = new Size(w + 30, 34 + lines.Count * 19 + 8);
                if (Size != sz) Size = sz;
            }
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            Color bg = AppSettings.ThemeColor("panel"), c1 = AppSettings.ThemeColor("c1"), txt = AppSettings.ThemeColor("txt"), ok = AppSettings.ThemeColor("ok");
            using (SolidBrush b = new SolidBrush(bg)) g.FillRectangle(b, ClientRectangle);
            using (Pen p = new Pen(Color.FromArgb(120, c1))) g.DrawRectangle(p, 0, 0, Width - 1, Height - 1);
            using (SolidBrush a = new SolidBrush(c1)) g.FillRectangle(a, 12, 0, 40, 2);
            using (SolidBrush t = new SolidBrush(c1)) g.DrawString("NEXUS // MONITOR", fTitle, t, 12, 10);
            int y = 34;
            foreach (string l in lines)
            {
                using (SolidBrush t = new SolidBrush(l.StartsWith("JOGO") ? ok : txt)) g.DrawString(l, fLine, t, 12, y);
                y += 19;
            }
        }
    }

    class DarkRenderer : ToolStripProfessionalRenderer
    {
        // tudo a partir do tema atual, a cada desenho
        static Color Mix(Color a, Color b, double t) { return Color.FromArgb((int)(a.R + (b.R - a.R) * t), (int)(a.G + (b.G - a.G) * t), (int)(a.B + (b.B - a.B) * t)); }
        static Color Bg { get { return AppSettings.ThemeColor("panel"); } }
        static Color Hover { get { return Mix(AppSettings.ThemeColor("panel"), AppSettings.ThemeColor("c1"), 0.18); } }
        static Color Line { get { return Mix(AppSettings.ThemeColor("panel"), AppSettings.ThemeColor("c1"), 0.45); } }
        static Color Soft { get { return Mix(AppSettings.ThemeColor("panel"), AppSettings.ThemeColor("txt"), 0.45); } }

        protected override void OnRenderToolStripBackground(ToolStripRenderEventArgs e)
        {
            using (SolidBrush b = new SolidBrush(Bg)) e.Graphics.FillRectangle(b, e.AffectedBounds);
        }

        protected override void OnRenderToolStripBorder(ToolStripRenderEventArgs e)
        {
            using (Pen p = new Pen(Line))
                e.Graphics.DrawRectangle(p, 0, 0, e.ToolStrip.Width - 1, e.ToolStrip.Height - 1);
        }

        protected override void OnRenderMenuItemBackground(ToolStripItemRenderEventArgs e)
        {
            Rectangle r = new Rectangle(2, 0, e.Item.Width - 4, e.Item.Height);
            using (SolidBrush b = new SolidBrush(e.Item.Selected ? Hover : Bg)) e.Graphics.FillRectangle(b, r);
            if (e.Item.Selected)
                using (SolidBrush a = new SolidBrush(AppSettings.ThemeColor("c1"))) e.Graphics.FillRectangle(a, 2, 2, 2, e.Item.Height - 4);
            if ((e.Item.Tag as string) == "toggle")
            {
                e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                int s = 13, x = 8, y = (e.Item.Height - s) / 2;
                using (Pen p = new Pen(Soft)) e.Graphics.DrawRectangle(p, x, y, s, s);
            }
        }

        protected override void OnRenderItemCheck(ToolStripItemImageRenderEventArgs e)
        {
            int s = 13, x = 8, y = (e.Item.Height - s) / 2;
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            Color c = AppSettings.ThemeColor("c1");
            using (SolidBrush b = new SolidBrush(Color.FromArgb(50, c))) e.Graphics.FillRectangle(b, x, y, s, s);
            using (Pen p = new Pen(c, 2f)) e.Graphics.DrawLines(p, new[] { new Point(x + 3, y + 7), new Point(x + 6, y + 10), new Point(x + 11, y + 3) });
        }

        protected override void OnRenderImageMargin(ToolStripRenderEventArgs e) { }

        protected override void OnRenderArrow(ToolStripArrowRenderEventArgs e)
        {
            e.ArrowColor = AppSettings.ThemeColor("dim");
            base.OnRenderArrow(e);
        }

        protected override void OnRenderSeparator(ToolStripSeparatorRenderEventArgs e)
        {
            int y = e.Item.Height / 2;
            using (Pen p = new Pen(Mix(AppSettings.ThemeColor("panel"), AppSettings.ThemeColor("c1"), 0.25))) e.Graphics.DrawLine(p, 6, y, e.Item.Width - 6, y);
        }

        protected override void OnRenderItemText(ToolStripItemTextRenderEventArgs e)
        {
            e.TextColor = e.Item.ForeColor;
            base.OnRenderItemText(e);
        }
    }
}
