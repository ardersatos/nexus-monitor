﻿# NEXUS Monitor - ficheiros do instalador e do update
#   -Modo Contar   : quantos ficheiros da pasta extraída são novos/diferentes da instalação
#   -Modo Copiar   : copia só o que mudou para a instalação e apaga o que está a mais lá
#   -Modo Escolher : janela para escolher a pasta de instalação
#   -Modo Procurar : encontra a pasta onde o NEXUS 1.7+ está instalado
#   -Modo ApagarOutras : apaga todas as outras cópias do NEXUS (não a pasta -Destino)
#   -Modo Antiga   : procura uma instalação antiga (versões que corriam da pasta extraída)
#   -Modo Limpar   : apaga os ficheiros extraídos (do zip) e a pasta, se ficar vazia
#   -Modo Verificar: (update) confirma que os ficheiros que o update NÃO traz já estão iguais na instalação
#   -Modo Base     : (update) a versão para que o update foi feito
param([string]$Modo, [string]$Origem, [string]$Destino)
$ErrorActionPreference = 'SilentlyContinue'

# o que nunca se apaga na pasta instalada (é criado na instalação ou descarregado)
$manter = @('NEXUS Monitor.exe', 'versao.txt',
            'streamdeck\com.nexus.monitor.sdPlugin\NexusDeck.exe',
            'streamdeck\com.nexus.monitor.sdPlugin\nexus_path.txt',
            'streamdeck\com.nexus.monitor.sdPlugin\nexus_build.txt')
$pastasManter = @('lhm\', 'presentmon\', 'gdu\')
# ficheiros do pacote que não vão para a pasta instalada
$soPacote = @('INSTALAR NEXUS.bat', 'ATUALIZAR NEXUS.bat', 'nexus_ficheiros.ps1', 'nexus_ficheiros.txt', 'nexus_destino.txt')

function Lista([string]$pasta) {
    $f = Join-Path $pasta 'nexus_ficheiros.txt'
    if (-not (Test-Path -LiteralPath $f)) { return @() }
    Get-Content -LiteralPath $f -Encoding UTF8 | ForEach-Object { $_.Trim() } | Where-Object { $_ -and -not $_.StartsWith('#') } | ForEach-Object { $_.Split('|')[0] }
}
# linhas "caminho|sha256" (a impressão digital de cada ficheiro da versão nova)
function ListaHash([string]$pasta) {
    $f = Join-Path $pasta 'nexus_ficheiros.txt'
    if (-not (Test-Path -LiteralPath $f)) { return @() }
    Get-Content -LiteralPath $f -Encoding UTF8 | ForEach-Object { $_.Trim() } | Where-Object { $_ -and -not $_.StartsWith('#') -and $_.Contains('|') }
}
function Hash([string]$p) { if (Test-Path -LiteralPath $p) { (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash } else { '' } }
function Igual([string]$a, [string]$b) {
    if (-not (Test-Path -LiteralPath $b)) { return $false }
    (Get-FileHash -LiteralPath $a -Algorithm SHA256).Hash -eq (Get-FileHash -LiteralPath $b -Algorithm SHA256).Hash
}
function Seguro([string]$p) {
    # nunca mexe em raízes de disco nem em pastas do sistema / do utilizador
    if (-not $p) { return $false }
    $p = [IO.Path]::GetFullPath($p).TrimEnd('\')
    if ($p.Length -le 3) { return $false }
    foreach ($x in @($env:WINDIR, $env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:ProgramData, $env:USERPROFILE, $env:APPDATA, $env:LOCALAPPDATA,
                     [Environment]::GetFolderPath('MyDocuments'), [Environment]::GetFolderPath('Desktop'), (Join-Path $env:USERPROFILE 'Downloads'))) {
        if ($x -and $p -ieq $x.TrimEnd('\')) { return $false }
    }
    return $true
}

function Pasta([string]$p) {
    $p = [IO.Path]::GetFullPath($p).TrimEnd('\')
    if ((Split-Path $p -Leaf) -ne 'NEXUS Monitor') { $p = Join-Path $p 'NEXUS Monitor' }
    $win = [IO.Path]::GetFullPath($env:WINDIR).TrimEnd('\')
    if ($p.StartsWith($win + '\', [StringComparison]::OrdinalIgnoreCase) -or -not (Seguro $p)) { return '!' }
    if (-not (Test-Path -LiteralPath ([IO.Path]::GetPathRoot($p)))) { return '!' }
    return $p
}
function Copias([string]$dest, [string]$aqui) {
    $cands = @()
    $pt = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'NEXUS Monitor\pasta.txt'
    if (Test-Path -LiteralPath $pt) { $cands += (Get-Content -LiteralPath $pt -Raw).Trim() }
    foreach ($p in @(Get-Process -Name 'NEXUS Monitor')) { if ($p.Path) { $cands += (Split-Path $p.Path) } }
    $cands += (Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\NEXUS Monitor').InstallLocation
    $run = (Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' -Name 'NEXUS Monitor').'NEXUS Monitor'
    if ($run -match '"([^"]+)"') { $cands += (Split-Path $Matches[1]) }
    $x = schtasks /query /tn 'NEXUS Monitor' /xml 2>$null | Out-String
    if ($x -match '<Command>([^<]+)</Command>') { $cands += (Split-Path ([Net.WebUtility]::HtmlDecode($Matches[1]).Trim('"'))) }
    $sh = New-Object -ComObject WScript.Shell
    foreach ($f in @('Programs', 'Desktop')) {
        $l = Join-Path ([Environment]::GetFolderPath($f)) 'NEXUS Monitor.lnk'
        if (Test-Path -LiteralPath $l) { $t = $sh.CreateShortcut($l).TargetPath; if ($t) { $cands += (Split-Path $t) } }
    }
    $cands += (Join-Path $env:LOCALAPPDATA 'Programs\NEXUS Monitor')
    # cópias soltas (versões que corriam da pasta extraída): Transferências, Ambiente de trabalho e Documentos, até 2 níveis
    foreach ($base in @((Join-Path $env:USERPROFILE 'Downloads'), [Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('MyDocuments'))) {
        if (-not $base -or -not (Test-Path -LiteralPath $base)) { continue }
        foreach ($d in @(Get-ChildItem -LiteralPath $base -Directory -Depth 1 -ErrorAction SilentlyContinue)) {
            if ((Test-Path -LiteralPath (Join-Path $d.FullName 'NEXUS Monitor.exe')) -and (Test-Path -LiteralPath (Join-Path $d.FullName 'NexusMonitor.cs'))) { $cands += $d.FullName }
        }
    }
    $fora = @()
    foreach ($z in @($dest, $aqui)) { if ($z) { $fora += [IO.Path]::GetFullPath($z).TrimEnd('\') } }
    $vistos = @{}
    foreach ($c in $cands) {
        if (-not $c) { continue }
        $c = [IO.Path]::GetFullPath($c).TrimEnd('\')
        if ($vistos.ContainsKey($c.ToLower())) { continue }; $vistos[$c.ToLower()] = 1
        if ($fora | Where-Object { $_ -ieq $c }) { continue }
        if (Test-Path -LiteralPath (Join-Path $c 'NexusMonitor.cs')) { $c }
    }
}
function ApagarCopia([string]$c) {
    # só apaga se tiver mesmo cara de NEXUS e não for uma pasta do sistema/utilizador
    if (-not (Seguro $c)) { return $false }
    if (-not (Test-Path -LiteralPath (Join-Path $c 'NexusMonitor.cs'))) { return $false }
    if (-not (Test-Path -LiteralPath (Join-Path $c 'index.html'))) { return $false }
    Remove-Item -LiteralPath $c -Recurse -Force
    return -not (Test-Path -LiteralPath $c)
}

switch ($Modo) {
    'Contar' {
        $n = 0
        foreach ($r in (Lista $Origem)) { $s = Join-Path $Origem $r; if ((Test-Path -LiteralPath $s) -and -not (Igual $s (Join-Path $Destino $r))) { $n++ } }
        Write-Output $n
    }
    'Copiar' {
        if (-not (Seguro $Destino)) { Write-Output '0 0'; exit 1 }
        $lista = @(Lista $Origem)
        $copiados = 0; $apagados = 0
        foreach ($r in $lista) {
            $s = Join-Path $Origem $r; $d = Join-Path $Destino $r
            if (-not (Test-Path -LiteralPath $s)) { continue }
            if (Igual $s $d) { continue }
            New-Item -ItemType Directory -Force -Path (Split-Path $d) | Out-Null
            Copy-Item -LiteralPath $s -Destination $d -Force
            $copiados++
        }
        # o que está a mais na instalação (de versões antigas) sai
        $base = [IO.Path]::GetFullPath($Destino).TrimEnd('\') + '\'
        Get-ChildItem -LiteralPath $Destino -Recurse -File -Force | ForEach-Object {
            $rel = $_.FullName.Substring($base.Length)
            $guardar = ($lista -contains $rel) -or ($manter -contains $rel)
            foreach ($pm in $pastasManter) { if ($rel.StartsWith($pm, [StringComparison]::OrdinalIgnoreCase)) { $guardar = $true } }
            if (-not $guardar) { Remove-Item -LiteralPath $_.FullName -Force; $apagados++ }
        }
        Get-ChildItem -LiteralPath $Destino -Recurse -Directory -Force | Sort-Object { $_.FullName.Length } -Descending | ForEach-Object {
            if (-not (Get-ChildItem -LiteralPath $_.FullName -Force)) { Remove-Item -LiteralPath $_.FullName -Force }
        }
        Write-Output "$copiados $apagados"
    }
    'Verificar' {
        # o update só traz o que mudou: o resto tem de estar já igual na instalação (senão é preciso a release completa).
        # Escreve 0 se está tudo bem, ou o número de ficheiros em falta seguido dos primeiros nomes.
        $falta = @()
        foreach ($l in (ListaHash $Origem)) {
            $p = $l.Split('|'); $r = $p[0]; $h = $p[1]
            $s = Join-Path $Origem $r
            if (Test-Path -LiteralPath $s) { if ((Hash $s) -ne $h) { $falta += $r }; continue }
            $d = Join-Path $Destino $r
            # módulos que o instalador tira quando o PC não os tem (Stream Deck)
            $opcional = $r.StartsWith('streamdeck\', [StringComparison]::OrdinalIgnoreCase) -or $r -ieq 'INSTALAR ADDON STREAM DECK.bat'
            if (-not (Test-Path -LiteralPath $d)) { if (-not $opcional) { $falta += $r }; continue }
            if ((Hash $d) -ne $h -and -not ($opcional -or $r.EndsWith('.txt', [StringComparison]::OrdinalIgnoreCase))) { $falta += $r }
        }
        if ($falta.Count -eq 0) { Write-Output 0 } else { Write-Output ("$($falta.Count) " + (($falta | Select-Object -First 3) -join ', ')) }
    }
    'Base' {
        $f = Join-Path $Origem 'nexus_ficheiros.txt'
        $b = Get-Content -LiteralPath $f -Encoding UTF8 | Where-Object { $_ -match '^# base (.+)$' } | Select-Object -First 1
        if ($b -match '^# base (.+)$') { Write-Output $Matches[1].Trim() }
    }
    'Antiga' {
        # todas as outras cópias do NEXUS neste PC (versões antigas e instalações noutras pastas), uma por linha
        foreach ($c in (Copias $Destino $Origem)) { Write-Output $c }
    }
    'ApagarOutras' {
        # apaga todas as outras cópias (o utilizador escolheu instalar só na pasta $Destino)
        $ok = 0; $falha = 0
        foreach ($c in (Copias $Destino $Origem)) { if (ApagarCopia $c) { $ok++ } else { $falha++ } }
        Write-Output "$ok $falha"
    }
    'Escolher' {
        # janela para escolher a pasta; devolve a pasta final (com "NEXUS Monitor" no fim), nada se cancelar,
        # "!" se não servir e "?" se a janela não abrir (o instalador pede então para escrever o caminho)
        try {
            $ErrorActionPreference = 'Stop'
            Add-Type -AssemblyName System.Windows.Forms
            Add-Type -AssemblyName System.Drawing
            [System.Windows.Forms.Application]::EnableVisualStyles()
            # dono visível (mas transparente) e sempre por cima: sem isto a janela pode abrir ATRÁS da consola
            # (o Windows não deixa um script roubar o foco) e o instalador parece parado
            $dono = New-Object System.Windows.Forms.Form
            $dono.TopMost = $true; $dono.ShowInTaskbar = $true; $dono.Opacity = 0
            $dono.FormBorderStyle = 'None'; $dono.StartPosition = 'CenterScreen'; $dono.Size = New-Object System.Drawing.Size(1, 1)
            $dono.Text = 'NEXUS Monitor'
            $dono.Show()
            # o Windows só deixa trazer uma janela para a frente depois de uma tecla: um Alt "fantasma" desbloqueia isso
            Add-Type -Namespace NexusUi -Name W -MemberDefinition '[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h); [DllImport("user32.dll")] public static extern void keybd_event(byte vk, byte sc, uint f, UIntPtr x); [DllImport("user32.dll")] public static extern IntPtr GetLastActivePopup(IntPtr h); [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr h, uint m, IntPtr w, IntPtr l);'
            [NexusUi.W]::keybd_event(0x12, 0, 0, [UIntPtr]::Zero); [NexusUi.W]::keybd_event(0x12, 0, 2, [UIntPtr]::Zero)
            [void][NexusUi.W]::SetForegroundWindow($dono.Handle); $dono.Activate(); $dono.BringToFront()
            # se ao fim de 3 minutos ninguém escolheu (janela escondida ou bloqueada), fecha e o instalador pede para escrever
            $tm = New-Object System.Windows.Forms.Timer; $tm.Interval = 180000
            $tm.add_Tick({ $tm.Stop(); $script:expirou = $true; $j = [NexusUi.W]::GetLastActivePopup($dono.Handle); if ($j -ne $dono.Handle) { [void][NexusUi.W]::PostMessage($j, 0x10, [IntPtr]::Zero, [IntPtr]::Zero) } }); $tm.Start()
            $d = New-Object System.Windows.Forms.FolderBrowserDialog
            $d.Description = 'Escolhe onde instalar o NEXUS Monitor (é criada a pasta "NEXUS Monitor" lá dentro)'
            $d.ShowNewFolderButton = $true
            $ini = $Destino; while ($ini -and -not (Test-Path -LiteralPath $ini)) { $ini = Split-Path $ini }
            if ($ini) { $d.SelectedPath = $ini }
            $r = $d.ShowDialog($dono)
            $tm.Stop(); $dono.Close(); $dono.Dispose()
            if ($script:expirou) { Write-Output '?'; exit }
            if ($r -ne [System.Windows.Forms.DialogResult]::OK -or -not $d.SelectedPath) { exit }
            $p = $d.SelectedPath
        } catch { Write-Output '?'; exit }
        Write-Output (Pasta $p)
    }
    'Validar' {
        # caminho escrito à mão: devolve a pasta final ou "!"
        if (-not $Destino) { exit }
        try { Write-Output (Pasta ($Destino.Trim().Trim('"'))) } catch { Write-Output '!' }
    }
    'Procurar' {
        # onde está instalado o NEXUS 1.7+ (pode não ser a pasta por defeito): o que está a correr,
        # o registo das Aplicações do Windows, a pasta.txt das definições, a tarefa e o arranque
        $cands = @()
        $p = Get-Process -Name 'NEXUS Monitor' | Select-Object -First 1
        if ($p -and $p.Path) { $cands += (Split-Path $p.Path) }
        $cands += (Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\NEXUS Monitor').InstallLocation
        $pt = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'NEXUS Monitor\pasta.txt'
        if (Test-Path -LiteralPath $pt) { $cands += (Get-Content -LiteralPath $pt -Raw).Trim() }
        $x = schtasks /query /tn 'NEXUS Monitor' /xml 2>$null | Out-String
        if ($x -match '<Command>([^<]+)</Command>') { $cands += (Split-Path ([Net.WebUtility]::HtmlDecode($Matches[1]).Trim('"'))) }
        $run = (Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' -Name 'NEXUS Monitor').'NEXUS Monitor'
        if ($run -match '"([^"]+)"') { $cands += (Split-Path $Matches[1]) }
        foreach ($c in $cands) {
            if (-not $c) { continue }
            $c = [IO.Path]::GetFullPath($c).TrimEnd('\')
            # só conta uma instalação a sério (1.7+ tem versao.txt), não uma pasta extraída de um zip antigo
            if ((Test-Path -LiteralPath (Join-Path $c 'NEXUS Monitor.exe')) -and (Test-Path -LiteralPath (Join-Path $c 'versao.txt')) -and (Seguro $c)) { Write-Output $c; break }
        }
    }
    'ApagarAntiga' {
        if (-not (ApagarCopia $Origem)) { exit 1 }
    }
    'Limpar' {
        # apaga só o que veio no zip (nunca outros ficheiros que estejam na mesma pasta)
        if (-not (Seguro $Origem)) { exit 1 }
        $lista = @(Lista $Origem) + $soPacote + @('erro.txt', 'erro_deck.txt', '_log.txt')
        foreach ($r in $lista) { Remove-Item -LiteralPath (Join-Path $Origem $r) -Force }
        # restos de instalações antigas feitas nesta pasta (programa compilado e descarregados)
        foreach ($r in @('NEXUS Monitor.exe', 'streamdeck\com.nexus.monitor.sdPlugin\NexusDeck.exe',
                         'streamdeck\com.nexus.monitor.sdPlugin\nexus_path.txt', 'streamdeck\com.nexus.monitor.sdPlugin\nexus_build.txt')) {
            Remove-Item -LiteralPath (Join-Path $Origem $r) -Force
        }
        foreach ($d in @('lhm', 'presentmon', 'gdu', 'lhm_tmp')) { Remove-Item -LiteralPath (Join-Path $Origem $d) -Recurse -Force }
        Get-ChildItem -LiteralPath $Origem -Recurse -Directory -Force | Sort-Object { $_.FullName.Length } -Descending | ForEach-Object {
            if (-not (Get-ChildItem -LiteralPath $_.FullName -Force)) { Remove-Item -LiteralPath $_.FullName -Force }
        }
        if (-not (Get-ChildItem -LiteralPath $Origem -Force)) { Remove-Item -LiteralPath $Origem -Force }
    }
}
