@echo off
chcp 65001 >NUL
setlocal EnableExtensions
title NEXUS Monitor · Plugin Stream Deck
cd /d "%~dp0"
for /F %%a in ('echo prompt $E ^| cmd') do set "ESC=%%a"
set "C=%ESC%[96m" & set "M=%ESC%[95m" & set "G=%ESC%[92m" & set "Y=%ESC%[93m" & set "R=%ESC%[91m" & set "D=%ESC%[90m" & set "B=%ESC%[1m" & set "N=%ESC%[0m"
set "HR=%D%  ────────────────────────────────────────────────────────────%N%"

cls
echo.
echo   %M%◆%N% %B%NEXUS MONITOR%N%  %D%· plugin Stream Deck%N%
echo %HR%
echo   %D%Instala só o plugin. O NEXUS já tem de estar instalado.%N%
echo.

if not exist "streamdeck\NexusDeck.cs" (
  echo   %R%✗%N% Faltam ficheiros - extrai o zip primeiro e corre este ficheiro da pasta extraída.
  goto erro
)
set "SDEXE="
if exist "streamdeck\procurar_streamdeck.ps1" for /f "usebackq delims=" %%p in (`powershell -NoProfile -ExecutionPolicy Bypass -File "streamdeck\procurar_streamdeck.ps1"`) do set "SDEXE=%%p"
if not defined SDEXE (
  echo   %R%✗%N% Não encontrei a app Stream Deck neste PC.
  goto erro
)
set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
set "PLUGSRC=%~dp0streamdeck\com.nexus.monitor.sdPlugin"
set "PLUGDST=%APPDATA%\Elgato\StreamDeck\Plugins\com.nexus.monitor.sdPlugin"

rem já está instalado e igual? então não mexe na Stream Deck
set "PLUGHASH="
for /f "usebackq delims=" %%h in (`powershell -NoProfile -Command "((Get-FileHash -Algorithm SHA256 -LiteralPath 'streamdeck\NexusDeck.cs','streamdeck\com.nexus.monitor.sdPlugin\pi.html','streamdeck\com.nexus.monitor.sdPlugin\manifest.json' | ForEach-Object Hash) -join '').Substring(0,40)"`) do set "PLUGHASH=%%h"
set "PLUGHASH=%PLUGHASH%@%~dp0"
set "OLDHASH="
if exist "%PLUGDST%\nexus_build.txt" set /p OLDHASH=<"%PLUGDST%\nexus_build.txt"
if exist "%PLUGDST%\NexusDeck.exe" if "%OLDHASH%"=="%PLUGHASH%" (
  echo   %G%✓%N% O plugin já está instalado e atualizado - nada a fazer.
  echo.
  timeout /t 5 >NUL
  exit /b 0
)

<NUL set /p "=%N%   %D%[1/2]%N%  Criar o plugin           "
del "%PLUGSRC%\NexusDeck.exe" >NUL 2>NUL
"%CSC%" /nologo /codepage:65001 /target:winexe /optimize+ /out:"%PLUGSRC%\NexusDeck.exe" /r:System.Drawing.dll /r:System.Web.Extensions.dll /r:System.Core.dll "streamdeck\NexusDeck.cs" > erro_deck.txt 2>&1
if not exist "%PLUGSRC%\NexusDeck.exe" (
  echo %R%✗%N% erro:
  type erro_deck.txt
  goto erro
)
del erro_deck.txt >NUL 2>NUL
> "%PLUGSRC%\nexus_build.txt" echo %PLUGHASH%
if exist "%~dp0NEXUS Monitor.exe" (
  > "%PLUGSRC%\nexus_path.txt" echo %~dp0NEXUS Monitor.exe
) else if exist "%LOCALAPPDATA%\Programs\NEXUS Monitor\NEXUS Monitor.exe" (
  > "%PLUGSRC%\nexus_path.txt" echo %LOCALAPPDATA%\Programs\NEXUS Monitor\NEXUS Monitor.exe
) else (
  powershell -NoProfile -Command "$p = (Get-Process 'NEXUS Monitor' -ErrorAction SilentlyContinue | Select-Object -First 1).Path; if ($p) { Set-Content -LiteralPath '%PLUGSRC%\nexus_path.txt' -Value $p }" >NUL 2>NUL
)
echo %G%✓%N% %D%criado%N%

<NUL set /p "=%N%   %D%[2/2]%N%  Instalar na Stream Deck  "
taskkill /im "StreamDeck.exe" /f >NUL 2>NUL
taskkill /im "NexusDeck.exe" /f >NUL 2>NUL
timeout /t 2 /nobreak >NUL
if exist "%PLUGDST%" rmdir /s /q "%PLUGDST%" >NUL 2>NUL
xcopy "%PLUGSRC%" "%PLUGDST%\" /e /i /y /q >NUL
explorer.exe "%SDEXE%"
if not exist "%PLUGDST%\NexusDeck.exe" (
  echo %R%✗%N% não consegui copiar
  goto erro
)
echo %G%✓%N% %D%a Stream Deck vai reabrir%N%
echo.
echo %HR%
echo   %G%%B%✓ Pronto!%N%  Na app Stream Deck procura a categoria %C%NEXUS Monitor%N%.
echo %HR%
echo.
timeout /t 6 >NUL
exit /b 0

:erro
echo.
pause
exit /b 1
