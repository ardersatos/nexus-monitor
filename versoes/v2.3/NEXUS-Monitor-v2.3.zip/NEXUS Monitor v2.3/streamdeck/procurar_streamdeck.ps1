# NEXUS - procura a app Stream Deck (Elgato). Escreve o caminho do StreamDeck.exe ou nada.
$c = @()
$c += Join-Path $env:ProgramFiles 'Elgato\StreamDeck\StreamDeck.exe'
if (${env:ProgramFiles(x86)}) { $c += Join-Path ${env:ProgramFiles(x86)} 'Elgato\StreamDeck\StreamDeck.exe' }
$p = Get-Process -Name StreamDeck -ErrorAction SilentlyContinue | Select-Object -First 1
if ($p -and $p.Path) { $c += $p.Path }
$keys = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
Get-ItemProperty $keys -ErrorAction SilentlyContinue |
    Where-Object { $_.DisplayName -like '*Stream Deck*' -and $_.InstallLocation } |
    ForEach-Object { $c += Join-Path $_.InstallLocation 'StreamDeck.exe' }
$c | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -First 1
