// NEXUS // MONITOR - medir os FPS a sério (antes / depois das otimizações), com os frames que o PresentMon vê
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;

namespace Nexus
{
    // Grava o tempo de cada frame do jogo durante 30 s a 3 min e calcula: FPS médio, 1% low, 0.1% low,
    // frametime médio e quantas quebras (frames 2,5x mais lentos do que o normal) houve.
    // Os resultados ficam em Documentos\NEXUS Monitor\medicoes.txt para comparar antes/depois.
    // Começa pela página Performance (com uns segundos para voltares ao jogo) ou com Alt+Shift+M dentro do jogo.
    static class Medicao
    {
        public class R
        {
            public string Id, Game, Label, When;
            public double Secs, Avg, Low1, Low01, Ft;
            public int Frames, Stutters, Tweaks;
        }

        static readonly object lk = new object();
        static volatile bool rec;
        static Dictionary<string, List<float>> frames = new Dictionary<string, List<float>>(StringComparer.OrdinalIgnoreCase);
        static DateTime startAt, endAt;
        static string label = "", lastError;
        static Timer timer;
        static List<R> results;
        const int MaxFrames = 1500000;

        static string FileR { get { return Path.Combine(AppSettings.Dir, "medicoes.txt"); } }
        public static bool Recording { get { return rec; } }
        public static bool Waiting { get { return !rec && timer != null && DateTime.Now < startAt; } }
        public static int SecondsLeft
        {
            get
            {
                DateTime n = DateTime.Now;
                if (rec) return Math.Max(0, (int)Math.Ceiling((endAt - n).TotalSeconds));
                if (timer != null && n < startAt) return (int)Math.Ceiling((startAt - n).TotalSeconds);
                return 0;
            }
        }

        // chamado pelo leitor do PresentMon a cada frame (tem de ser muito rápido)
        public static void Frame(string app, double ft)
        {
            if (!rec || double.IsNaN(ft) || ft <= 0 || ft > 2000) return;
            lock (lk)
            {
                List<float> l;
                if (!frames.TryGetValue(app, out l)) { l = new List<float>(65536); frames[app] = l; }
                if (l.Count < MaxFrames) l.Add((float)ft);
            }
        }

        // começa daqui a "delay" segundos e grava durante "secs" segundos
        public static string Start(int secs, int delay, string lbl)
        {
            lock (lk)
            {
                if (rec || timer != null) return "já está a medir";
                if (!PresentMonReader.Active) return "abre o jogo primeiro";
                secs = Math.Max(15, Math.Min(300, secs)); delay = Math.Max(0, Math.Min(60, delay));
                label = (lbl ?? "").Trim(); if (label.Length > 40) label = label.Substring(0, 40);
                frames = new Dictionary<string, List<float>>(StringComparer.OrdinalIgnoreCase);
                lastError = null;
                startAt = DateTime.Now.AddSeconds(delay);
                endAt = startAt.AddSeconds(secs);
                int s2 = secs;
                // o mesmo temporizador começa (depois do "delay") e acaba (depois de "secs") a medição
                timer = new Timer(delegate
                {
                    bool begin = false;
                    lock (lk)
                    {
                        if (timer == null) return;
                        if (!rec) { rec = true; startAt = DateTime.Now; endAt = startAt.AddSeconds(s2); begin = true; }
                    }
                    if (begin) { try { timer.Change(s2 * 1000, Timeout.Infinite); } catch { } }
                    else Finish(false);
                }, null, delay * 1000, Timeout.Infinite);
                return null;
            }
        }
        public static void Stop() { Finish(true); }

        // segurança: se o temporizador falhar, a página acaba a medição quando o tempo passar
        public static void Poll()
        {
            if (rec && DateTime.Now >= endAt) Finish(false);
        }

        static void Finish(bool cancelled)
        {
            Dictionary<string, List<float>> f;
            double secs;
            lock (lk)
            {
                if (timer != null) { try { timer.Dispose(); } catch { } timer = null; }
                bool was = rec;
                rec = false;
                if (!was) return;
                f = frames; frames = new Dictionary<string, List<float>>(StringComparer.OrdinalIgnoreCase);
                secs = (DateTime.Now - startAt).TotalSeconds;
            }
            if (cancelled && secs < 10) { lastError = "cancelada"; return; }
            KeyValuePair<string, List<float>> best = f.OrderByDescending(kv => kv.Value.Count).FirstOrDefault();
            if (best.Value == null || best.Value.Count < 100) { lastError = "não vi frames do jogo (estava em ecrã inteiro exclusivo ou minimizado?)"; return; }
            R r = Calc(best.Value);
            r.Id = DateTime.Now.Ticks.ToString(CultureInfo.InvariantCulture);
            r.Game = Path.GetFileNameWithoutExtension(best.Key);
            r.Label = label;
            r.When = DateTime.Now.ToString("dd/MM HH:mm", CultureInfo.InvariantCulture);
            try { r.Tweaks = Tweaks.ChangedCount(); } catch { r.Tweaks = -1; }
            lock (lk)
            {
                Load();
                results.Insert(0, r);
                while (results.Count > 60) results.RemoveAt(results.Count - 1);
                SaveAll();
            }
            try { Program.Notify("NEXUS · " + Lang.L("Medição acabada"), r.Game + ": " + Math.Round(r.Avg) + " FPS · 1% low " + Math.Round(r.Low1)); } catch { }
        }

        static R Calc(List<float> l)
        {
            R r = new R();
            int n = l.Count;
            double sum = 0; foreach (float x in l) sum += x;
            float[] s = l.ToArray(); Array.Sort(s);
            double median = s[n / 2];
            Func<double, double> pct = p => s[Math.Min(n - 1, (int)Math.Floor(p * (n - 1)))];
            r.Frames = n; r.Secs = sum / 1000.0;
            r.Avg = n / (sum / 1000.0);
            r.Ft = sum / n;
            r.Low1 = 1000.0 / pct(0.99);
            r.Low01 = 1000.0 / pct(0.999);
            int st = 0; foreach (float x in l) if (x > median * 2.5 && x > 8) st++;
            r.Stutters = st;
            return r;
        }

        // ---------------- ficheiro
        static void Load()
        {
            if (results != null) return;
            results = new List<R>();
            try
            {
                if (File.Exists(FileR))
                    foreach (string line in File.ReadAllLines(FileR, Encoding.UTF8))
                    {
                        string[] c = line.Split('|');
                        if (c.Length < 12) continue;
                        CultureInfo ci = CultureInfo.InvariantCulture;
                        R r = new R { Id = c[0], Game = c[1], Label = c[2], When = c[3] };
                        double.TryParse(c[4], NumberStyles.Float, ci, out r.Secs); double.TryParse(c[5], NumberStyles.Float, ci, out r.Avg);
                        double.TryParse(c[6], NumberStyles.Float, ci, out r.Low1); double.TryParse(c[7], NumberStyles.Float, ci, out r.Low01);
                        double.TryParse(c[8], NumberStyles.Float, ci, out r.Ft); int.TryParse(c[9], out r.Frames); int.TryParse(c[10], out r.Stutters); int.TryParse(c[11], out r.Tweaks);
                        results.Add(r);
                    }
            }
            catch { }
        }
        static string Clean(string v) { return (v ?? "").Replace("|", "/").Replace("\r", " ").Replace("\n", " "); }
        static void SaveAll()
        {
            try
            {
                Directory.CreateDirectory(AppSettings.Dir);
                CultureInfo ci = CultureInfo.InvariantCulture;
                File.WriteAllLines(FileR, results.Select(r => string.Join("|", new[] { r.Id, Clean(r.Game), Clean(r.Label), r.When,
                    r.Secs.ToString("0.0", ci), r.Avg.ToString("0.0", ci), r.Low1.ToString("0.0", ci), r.Low01.ToString("0.0", ci), r.Ft.ToString("0.00", ci),
                    r.Frames.ToString(ci), r.Stutters.ToString(ci), r.Tweaks.ToString(ci) })).ToArray(), new UTF8Encoding(false));
            }
            catch { }
        }

        public static void Reload() { lock (lk) results = null; }

        // ---------------- API
        static string Q(string v) { return v == null ? "null" : "\"" + v.Replace("\\", "\\\\").Replace("\"", "\\\"") + "\""; }
        static string N(double v) { return double.IsNaN(v) || double.IsInfinity(v) ? "0" : v.ToString("0.0", CultureInfo.InvariantCulture); }
        public static string Json()
        {
            Poll();
            lock (lk)
            {
                Load();
                int live = 0; foreach (List<float> l in frames.Values) live = Math.Max(live, l.Count);
                StringBuilder sb = new StringBuilder("{\"ok\":true,\"recording\":");
                sb.Append(rec ? "true" : "false").Append(",\"waiting\":").Append(Waiting ? "true" : "false").Append(",\"left\":").Append(SecondsLeft)
                  .Append(",\"frames\":").Append(live).Append(",\"game_ready\":").Append(PresentMonReader.Active ? "true" : "false")
                  .Append(",\"label\":").Append(Q(label)).Append(",\"error\":").Append(Q(lastError)).Append(",\"results\":[");
                bool first = true;
                foreach (R r in results)
                {
                    if (!first) sb.Append(','); first = false;
                    sb.Append("{\"id\":").Append(Q(r.Id)).Append(",\"game\":").Append(Q(r.Game)).Append(",\"label\":").Append(Q(r.Label)).Append(",\"when\":").Append(Q(r.When))
                      .Append(",\"secs\":").Append(N(r.Secs)).Append(",\"avg\":").Append(N(r.Avg)).Append(",\"low1\":").Append(N(r.Low1)).Append(",\"low01\":").Append(N(r.Low01))
                      .Append(",\"ft\":").Append(N(r.Ft)).Append(",\"frames\":").Append(r.Frames).Append(",\"stutters\":").Append(r.Stutters).Append(",\"tweaks\":").Append(r.Tweaks).Append('}');
                }
                return sb.Append("]}").ToString();
            }
        }
        public static string StartJson(string secs, string delay, string lbl)
        {
            int s, d;
            if (!int.TryParse(secs, out s)) s = 60;
            if (!int.TryParse(delay, out d)) d = 10;
            string e = Start(s, d, lbl);
            return e == null ? Json() : "{\"ok\":false,\"error\":" + Q(e) + "}";
        }
        public static string Delete(string id)
        {
            lock (lk) { Load(); results.RemoveAll(r => r.Id == id); SaveAll(); }
            return Json();
        }
        // atalho dentro do jogo: começa já (60 s) ou pára
        public static void Toggle()
        {
            if (rec || timer != null) { Stop(); return; }
            string e = Start(60, 0, Lang.L("atalho"));
            try { Program.Notify("NEXUS", e == null ? Lang.L("A medir os FPS durante 60 s…") : Lang.L("Não deu para medir:") + " " + Lang.L(e)); } catch { }
        }
    }
}
