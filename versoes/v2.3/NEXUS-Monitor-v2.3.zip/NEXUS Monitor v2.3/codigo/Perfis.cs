// NEXUS // MONITOR - perfis por jogo: overlay, boost e otimizações que se ligam sozinhos quando um jogo abre e voltam ao fechar
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;

namespace Nexus
{
    // Cada perfil é para um jogo (pelo nome do .exe). Quando a deteção de jogo vê esse jogo:
    //  - o overlay e o boost (prioridade, desempenho máximo, limpar RAM) seguem o perfil em vez das opções gerais;
    //  - as otimizações escolhidas que ainda não estão ligadas são ligadas só enquanto o jogo está aberto.
    // Ao fechar o jogo tudo volta. Se o NEXUS fechar a meio, a lista do que foi ligado fica guardada e é reposta
    // no próximo arranque (perfil_sessao.txt). Otimizações que precisam de reiniciar não entram (não serviam).
    static class Perfis
    {
        public class P
        {
            public string Exe = "", Overlay = "", Prio = "", Power = "", Ram = "";   // "" = como nas opções, "1" = sim, "0" = não
            public List<string> Tw = new List<string>();
            public int Fps;      // limite de FPS (RivaTuner), 0 = sem limite
        }

        static readonly object lk = new object();
        static List<P> list;
        static Dictionary<string, DateTime> seen;
        static P cur;
        static string curGame;
        static List<string> applied = new List<string>();

        static string FileP { get { return Path.Combine(AppSettings.Dir, "perfis.txt"); } }
        static string FileSeen { get { return Path.Combine(AppSettings.Dir, "perfis_jogos.txt"); } }
        static string FileSess { get { return Path.Combine(AppSettings.Dir, "perfil_sessao.txt"); } }

        public static string Norm(string g)
        {
            if (string.IsNullOrEmpty(g)) return null;
            g = g.Trim().ToLowerInvariant();
            if (g.EndsWith(".exe")) g = g.Substring(0, g.Length - 4);
            foreach (char c in g) if (c == '|' || c == '\r' || c == '\n') return null;
            return g.Length == 0 || g.Length > 80 ? null : g;
        }
        static string Tri(string v) { return v == "1" || v == "0" ? v : ""; }

        // ---------------- ficheiros
        static void Load()
        {
            if (list != null) return;
            list = new List<P>();
            try
            {
                if (File.Exists(FileP))
                    foreach (string line in File.ReadAllLines(FileP, Encoding.UTF8))
                    {
                        string[] c = line.Split('|');
                        if (c.Length < 6 || Norm(c[0]) == null) continue;
                        P p = new P { Exe = Norm(c[0]), Overlay = Tri(c[1]), Prio = Tri(c[2]), Power = Tri(c[3]), Ram = Tri(c[4]) };
                        foreach (string t in c[5].Split(',')) if (t.Trim() != "") p.Tw.Add(t.Trim());
                        if (c.Length > 6) int.TryParse(c[6], out p.Fps);
                        list.Add(p);
                    }
            }
            catch { }
        }
        static void SaveList()
        {
            try
            {
                Directory.CreateDirectory(AppSettings.Dir);
                File.WriteAllLines(FileP, list.Select(p => p.Exe + "|" + p.Overlay + "|" + p.Prio + "|" + p.Power + "|" + p.Ram + "|" + string.Join(",", p.Tw.ToArray()) + "|" + p.Fps).ToArray(), new UTF8Encoding(false));
            }
            catch { }
        }
        static void LoadSeen()
        {
            if (seen != null) return;
            seen = new Dictionary<string, DateTime>();
            try
            {
                if (File.Exists(FileSeen))
                    foreach (string line in File.ReadAllLines(FileSeen, Encoding.UTF8))
                    {
                        string[] c = line.Split('|'); long t;
                        if (c.Length == 2 && Norm(c[0]) != null && long.TryParse(c[1], out t)) seen[Norm(c[0])] = new DateTime(t);
                    }
            }
            catch { }
        }
        static void Seen(string g)
        {
            LoadSeen();
            seen[g] = DateTime.Now;
            // guarda só os 30 jogos mais recentes
            foreach (string k in seen.OrderByDescending(kv => kv.Value).Skip(30).Select(kv => kv.Key).ToList()) seen.Remove(k);
            try
            {
                Directory.CreateDirectory(AppSettings.Dir);
                File.WriteAllLines(FileSeen, seen.Select(kv => kv.Key + "|" + kv.Value.Ticks).ToArray(), new UTF8Encoding(false));
            }
            catch { }
        }
        static void SaveSession()
        {
            try
            {
                if (applied.Count == 0) { if (File.Exists(FileSess)) File.Delete(FileSess); return; }
                Directory.CreateDirectory(AppSettings.Dir);
                File.WriteAllText(FileSess, string.Join(",", applied.ToArray()), new UTF8Encoding(false));
            }
            catch { }
        }

        // ---------------- jogo abre / fecha (chamado pela deteção de jogo, fora da thread da interface)
        public static void Start(string game)
        {
            lock (lk)
            {
                Load();
                string g = Norm(game);
                if (g == null || g == "ecrã inteiro") return;
                curGame = g;
                Seen(g);
                cur = list.FirstOrDefault(p => p.Exe == g);
                if (cur != null && cur.Tw.Count > 0 && applied.Count == 0)
                {
                    try { applied = Tweaks.ApplyTemp(cur.Tw); } catch { applied = new List<string>(); }
                    SaveSession();
                }
            }
            Program.Ui(GameOverlay.Apply);
        }
        public static void Stop()
        {
            lock (lk)
            {
                if (applied.Count > 0)
                {
                    try { Tweaks.RevertTemp(applied); } catch { }
                    applied = new List<string>();
                }
                SaveSession();
                cur = null; curGame = null;
            }
            Program.Ui(GameOverlay.Apply);
        }
        // no arranque: se o NEXUS fechou a meio de um jogo com perfil, repõe o que tinha ficado ligado
        public static void RecoverSession()
        {
            lock (lk)
            {
                try
                {
                    if (!File.Exists(FileSess)) return;
                    string[] ids = File.ReadAllText(FileSess, Encoding.UTF8).Split(',').Select(x => x.Trim()).Where(x => x != "").ToArray();
                    if (ids.Length > 0) Tweaks.RevertTemp(ids);
                    File.Delete(FileSess);
                }
                catch { }
            }
        }

        // o que vale agora: o perfil do jogo aberto, ou as opções gerais
        public static bool Want(string k, bool def)
        {
            P c = cur;
            if (c == null) return def;
            string v = k == "prio" ? c.Prio : k == "power" ? c.Power : k == "ram" ? c.Ram : c.Overlay;
            return v == "1" ? true : v == "0" ? false : def;
        }
        // -1 = como nas opções, 0 = escondido neste jogo, 1 = mostrado neste jogo
        public static int OverlayOverride()
        {
            P c = cur;
            if (c == null) return -1;
            return c.Overlay == "1" ? 1 : c.Overlay == "0" ? 0 : -1;
        }

        public static void Reload() { lock (lk) { list = null; seen = null; } }

        // ---------------- API
        static string Q(string v) { return v == null ? "null" : "\"" + v.Replace("\\", "\\\\").Replace("\"", "\\\"") + "\""; }
        public static string Json()
        {
            lock (lk)
            {
                Load(); LoadSeen();
                StringBuilder sb = new StringBuilder("{\"ok\":true,\"active\":");
                sb.Append(Q(cur != null ? cur.Exe : null)).Append(",\"game\":").Append(Q(curGame)).Append(",\"applied\":[")
                  .Append(string.Join(",", applied.Select(x => Q(x)).ToArray())).Append("],\"profiles\":[");
                bool first = true;
                foreach (P p in list.OrderBy(x => x.Exe))
                {
                    if (!first) sb.Append(','); first = false;
                    sb.Append("{\"exe\":").Append(Q(p.Exe)).Append(",\"overlay\":").Append(Q(p.Overlay)).Append(",\"prio\":").Append(Q(p.Prio))
                      .Append(",\"power\":").Append(Q(p.Power)).Append(",\"ram\":").Append(Q(p.Ram)).Append(",\"fps\":").Append(p.Fps).Append(",\"tweaks\":[")
                      .Append(string.Join(",", p.Tw.Select(x => Q(x)).ToArray())).Append("]}");
                }
                sb.Append("],\"rtss\":").Append(FpsLimite.Available ? "true" : "false").Append(",\"fpserr\":").Append(Q(fpsErr)).Append(",\"recent\":[");
                first = true;
                foreach (KeyValuePair<string, DateTime> kv in seen.OrderByDescending(x => x.Value))
                {
                    if (!first) sb.Append(','); first = false;
                    sb.Append("{\"exe\":").Append(Q(kv.Key)).Append(",\"last\":").Append(Q(kv.Value.ToString("dd/MM HH:mm", CultureInfo.InvariantCulture))).Append('}');
                }
                return sb.Append("]}").ToString();
            }
        }
        static string fpsErr;
        public static string SaveQ(string exe, string overlay, string prio, string power, string ram, string tweaks, string fps)
        {
            string g = Norm(exe);
            if (g == null) return "{\"ok\":false,\"error\":\"nome\"}";
            HashSet<string> ok = Tweaks.TempIds();
            lock (lk)
            {
                Load();
                P p = list.FirstOrDefault(x => x.Exe == g);
                if (p == null) { p = new P { Exe = g }; list.Add(p); }
                p.Overlay = Tri(overlay); p.Prio = Tri(prio); p.Power = Tri(power); p.Ram = Tri(ram);
                p.Tw = (tweaks ?? "").Split(',').Select(x => x.Trim()).Where(x => x != "" && ok.Contains(x)).Distinct().ToList();
                int f; fpsErr = null;
                if (fps != null && int.TryParse(fps, out f))
                {
                    f = Math.Max(0, Math.Min(1000, f));
                    if (f != p.Fps && (f > 0 || p.Fps > 0)) fpsErr = FpsLimite.Set(g, f);   // o RivaTuner guarda o limite no perfil do .exe
                    if (fpsErr == null) p.Fps = f;
                }
                SaveList();
            }
            return Json();
        }
        public static string Delete(string exe)
        {
            string g = Norm(exe);
            lock (lk)
            {
                Load();
                list.RemoveAll(x => x.Exe == g);
                SaveList();
            }
            return Json();
        }
    }
}
