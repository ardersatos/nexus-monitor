@echo off
chcp 65001 >NUL
setlocal EnableExtensions
title NEXUS Monitor · Desinstalar
cd /d "%~dp0"
for /F %%a in ('echo prompt $E ^| cmd') do set "ESC=%%a"
set "C=%ESC%[96m" & set "M=%ESC%[95m" & set "G=%ESC%[92m" & set "Y=%ESC%[93m" & set "R=%ESC%[91m" & set "D=%ESC%[90m" & set "B=%ESC%[1m" & set "N=%ESC%[0m"
set "HR=%D%  ────────────────────────────────────────────────────────────%N%"
set "DIR=%~dp0"
if "%DIR:~-1%"=="\" set "DIR=%DIR:~0,-1%"
set "PLUG=%APPDATA%\Elgato\StreamDeck\Plugins\com.nexus.monitor.sdPlugin"
set "CFG=%USERPROFILE%\Documents\NEXUS Monitor"
for /f "usebackq delims=" %%d in (`powershell -NoProfile -Command "[Environment]::GetFolderPath('MyDocuments')"`) do set "CFG=%%d\NEXUS Monitor"

rem ---- precisa de administrador (tarefa agendada, firewall, driver)
net session >NUL 2>NUL
if errorlevel 1 (
  echo.
  echo   %Y%!%N% No aviso do Windows carrega em %B%Sim%N%.
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b 0
)

rem ================================================================ CONFIRMAR
cls
echo.
echo   %R%◆%N% %B%NEXUS MONITOR%N%  %D%· desinstalar%N%
echo %HR%
echo.
echo   Vai ser removido:
echo.
echo     %D%·%N% o NEXUS Monitor %D%(fecha-o, mesmo que esteja aberto)%N%
echo     %D%·%N% o arranque automático, a regra da firewall e os atalhos
if exist "%PLUG%" echo     %D%·%N% o plugin da Stream Deck
echo     %D%·%N% esta pasta: %D%%DIR%%N%
echo.
set "PAWN="
call :temPawn && set "PAWN=1"
if defined PAWN (
  echo   O driver %C%PawnIO%N% também está instalado.
  echo   %D%Outros programas podem usá-lo - FanControl, OpenRGB, LibreHardwareMonitor...%N%
  choice /c SN /n /m "  %C%»%N% Remover também o PawnIO? (S/N): "
)
set "RMPAWN="
if defined PAWN if not errorlevel 2 set "RMPAWN=1"
echo.
set "RMCFG="
if not exist "%CFG%" goto confirmar
echo   As definições estão em %D%%CFG%%N%
echo   %D%Tema, opções e a chave do telemóvel. Se ficarem, voltam ao reinstalar.%N%
choice /c SN /n /m "  %C%»%N% Apagar também as definições? (S/N): "
if not errorlevel 2 set "RMCFG=1"
echo.
:confirmar
echo %HR%
choice /c SN /n /m "  %R%»%N% Desinstalar o NEXUS agora? (S/N): "
if errorlevel 2 goto cancelado

rem ================================================================ REMOVER
cls
echo.
echo   %R%◆%N% %B%NEXUS MONITOR%N%  %D%· a desinstalar%N%
echo %HR%
echo.
set /a TOTAL=4, I=0
if exist "%PLUG%" set /a TOTAL+=1
if defined RMPAWN set /a TOTAL+=1

call :passo "Fechar o NEXUS"
call :fecharNexus
call :ok "fechado"

call :passo "Arranque e atalhos"
schtasks /delete /tn "NEXUS Monitor" /f >NUL 2>NUL
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "NEXUS Monitor" /f >NUL 2>NUL
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\NEXUS Monitor" /f >NUL 2>NUL
netsh advfirewall firewall delete rule name="NEXUS Monitor" >NUL 2>NUL
for /f "usebackq delims=" %%s in (`powershell -NoProfile -Command "[Environment]::GetFolderPath('Programs')"`) do del "%%s\NEXUS Monitor.lnk" >NUL 2>NUL
for /f "usebackq delims=" %%s in (`powershell -NoProfile -Command "[Environment]::GetFolderPath('Desktop')"`) do del "%%s\NEXUS Monitor.lnk" >NUL 2>NUL
rem plugin do SignalRGB (cores do tema)
for /f "usebackq delims=" %%s in (`powershell -NoProfile -Command "[Environment]::GetFolderPath('MyDocuments')"`) do del "%%s\WhirlwindFX\Plugins\NEXUS_Monitor.js" >NUL 2>NUL
rmdir /s /q "%LOCALAPPDATA%\NEXUS" >NUL 2>NUL
call :ok "arranque, firewall, menu Iniciar e Aplicações"

call :passo "Definições"
if defined RMCFG (
  rmdir /s /q "%CFG%" >NUL 2>NUL
  if exist "%CFG%" (call :falha "não consegui apagar %CFG%") else (call :ok "apagadas")
) else (
  call :ok "ficam em Documentos\NEXUS Monitor"
)

if not exist "%PLUG%" goto pawn
call :passo "Plugin Stream Deck"
set "SDEXE="
if exist "streamdeck\procurar_streamdeck.ps1" for /f "usebackq delims=" %%p in (`powershell -NoProfile -ExecutionPolicy Bypass -File "streamdeck\procurar_streamdeck.ps1"`) do set "SDEXE=%%p"
taskkill /im "StreamDeck.exe" /f >NUL 2>NUL
taskkill /im "NexusDeck.exe" /f >NUL 2>NUL
timeout /t 2 /nobreak >NUL
rmdir /s /q "%PLUG%" >NUL 2>NUL
if defined SDEXE explorer.exe "%SDEXE%"
if exist "%PLUG%" (call :falha "não consegui apagar") else (call :ok "removido")

:pawn
if not defined RMPAWN goto pasta
call :passo "Driver PawnIO"
where winget >NUL 2>NUL && winget uninstall --id namazso.PawnIO -e --silent --accept-source-agreements >NUL 2>NUL
call :temPawn || (call :ok "removido" & goto pasta)
rem o winget não resolveu: usa o desinstalador registado no Windows
powershell -NoProfile -Command "$e = Get-ItemProperty 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*','HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*' -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -like 'PawnIO*' } | Select-Object -First 1; $c = if ($e.QuietUninstallString) { $e.QuietUninstallString } else { $e.UninstallString }; if ($c) { Start-Process -FilePath 'cmd.exe' -ArgumentList '/c', $c -Wait }" >NUL 2>NUL
call :temPawn && (call :falha "remove em Definições - Aplicações - PawnIO") || call :ok "removido"

:pasta
call :passo "Pasta do NEXUS"
call :ok "vai ser apagada ao fechar esta janela"
echo.
echo %HR%
echo   %G%%B%✓ NEXUS desinstalado.%N%
echo   %D%Se o ícone ainda aparecer junto ao relógio, passa-lhe o rato por cima.%N%
echo %HR%
echo.
set "RM=%TEMP%\nexus_desinstalar.bat"
> "%RM%" echo @echo off
>>"%RM%" echo timeout /t 2 /nobreak ^>NUL
>>"%RM%" echo rmdir /s /q "%DIR%"
>>"%RM%" echo if exist "%DIR%" ( timeout /t 3 /nobreak ^>NUL ^& rmdir /s /q "%DIR%" )
rem a última linha apaga o próprio script sem o erro "The batch file cannot be found"
>>"%RM%" echo (goto) 2^>NUL ^& del "%%~f0"
timeout /t 5 >NUL
cd /d "%TEMP%"
rem cmd /c: a janela fecha sozinha quando acabar
start "" /min cmd /c ""%RM%""
exit

:cancelado
echo.
echo   %D%Cancelado - nada foi alterado.%N%
timeout /t 3 >NUL
exit /b 0

rem ================================================================ FUNÇÕES
:passo
set /a I+=1
set "PNOME=%~1                         "
<NUL set /p "=%N%   %D%[%I%/%TOTAL%]%N%  %PNOME:~0,24%"
exit /b 0

:ok
echo %G%✓%N% %D%%~1%N%
exit /b 0

:falha
echo %R%✗%N% %~1
exit /b 0

rem fecha o NEXUS com calma (retoma apps em pausa pelo modo jogo) e só depois à força
:fecharNexus
curl -s -m 3 -X POST http://127.0.0.1:8765/api/shutdown >NUL 2>NUL
timeout /t 2 /nobreak >NUL
taskkill /im "NEXUS Monitor.exe" /f >NUL 2>NUL
taskkill /im "PresentMon.exe" /f >NUL 2>NUL
timeout /t 1 /nobreak >NUL
exit /b 0

:temPawn
powershell -NoProfile -Command "if (Get-ItemProperty 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*','HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*' -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -like 'PawnIO*' }) { exit 0 } else { exit 1 }" >NUL 2>NUL
exit /b %errorlevel%
