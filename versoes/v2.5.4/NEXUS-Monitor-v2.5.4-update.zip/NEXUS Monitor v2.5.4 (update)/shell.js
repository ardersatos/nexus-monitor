/* NEXUS Monitor - menu lateral (a mesma navegação em todas as páginas)
   Painel · Jogos · Otimizar · Dispositivos · Hardware · Discos · Rede · Saúde do PC · Definições
   Usado por index.html, perf.html e disk.html. Não muda nada no PC: só arruma a navegação. */
(function(){
  if(window.NXSHELL) return;
  const T = s => (window.NX && NX.T ? NX.T(s) : s);
  const E = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'})[c]);
  const page = () => { const p = location.pathname.replace(/\.html$/, ''); return p === '/' || p === '/index' ? '/' : p; };
  // secções: chave, ícone, nome, página, separador (na Performance), frase que explica a secção
  const S = [
    { k:'painel', ic:'◈', t:'Painel', pg:'/', d:'O estado do teu PC agora e o que precisa de atenção.' },
    { k:'jogos', ic:'🎮', t:'Jogos', pg:'/perf', tab:'jogos', d:'Tudo o que o NEXUS faz quando jogas: acelerar, medir, overlay e perfis por jogo.' },
    { k:'otim', ic:'⚡', t:'Otimizar', pg:'/perf', tab:'otim', d:'Otimizações do Windows, cenários, arranque e apps a mais. Tudo pode ser reposto.' },
    { k:'ctl', ic:'🖱', t:'Dispositivos', pg:'/perf', tab:'ctl', d:'Rato, teclado e auscultadores de qualquer marca, som, equalizador, macros e teclas.' },
    { k:'hw', ic:'🖥', t:'Hardware', pg:'/perf', tab:'hw', d:'As peças do teu PC, placa gráfica, ventoinhas, testes, drivers e BIOS.' },
    { k:'discos', ic:'💾', t:'Discos', pg:'/disk', d:'O que ocupa espaço, limpeza, saúde dos discos e desinstalar programas.' },
    { k:'rede', ic:'🌐', t:'Rede', pg:'/perf', tab:'rede', d:'Ping, DNS, rota para jogos, Wi-Fi e quem está a usar a internet.' },
    { k:'saude', ic:'🩺', t:'Saúde do PC', pg:'/perf', tab:'saude', d:'Primeiros socorros, crashes, segurança, Windows e avisos.' },
  ];
  const SET = { k:'def', ic:'⚙', t:'Definições', d:'Tudo num só sítio, por assunto.' };
  const local = ['localhost','127.0.0.1'].includes(location.hostname);

  function current(){
    const p = page();
    if(p === '/disk') return 'discos';
    if(p === '/perf'){ const h = (location.hash || '').slice(1); const a = { inicio:'otim', sis:'saude', diag:'saude', comando:'jogos' }; const k = a[h] || h; return S.some(s => s.k === k) ? k : (/^socorro-/.test(h) ? 'saude' : 'otim'); }
    return 'painel';
  }
  function css(){
    const st = document.createElement('style'); st.id = 'nxShellCss';
    st.textContent = `
body.nxshell{padding-left:232px}
.nxside{position:fixed;left:0;top:0;bottom:0;width:216px;z-index:50;display:flex;flex-direction:column;gap:2px;padding:16px 10px;border-right:1px solid var(--line);background:color-mix(in srgb,var(--panel) 70%,var(--bg));overflow-y:auto}
.nxside .nlogo{display:flex;align-items:center;gap:11px;padding:2px 10px 18px;text-decoration:none;color:var(--txt)}
.nxside .nlogo i{width:26px;height:26px;border:1.5px solid var(--c1);border-radius:4px;transform:rotate(45deg);display:grid;place-items:center;box-shadow:0 0 12px color-mix(in srgb,var(--c1) 35%,transparent);flex:none}
.nxside .nlogo i::after{content:"";width:9px;height:9px;border-radius:2px;background:var(--c1)}
.nxside .nlogo b{font-size:14px;letter-spacing:.24em;font-weight:600}.nxside .nlogo small{display:block;font-size:9.5px;letter-spacing:.14em;color:var(--dim);margin-top:2px}
.nxside a.ni{display:flex;align-items:center;gap:11px;padding:9px 12px;border-radius:9px;color:var(--dim);text-decoration:none;font-size:12.5px;position:relative;letter-spacing:.02em;cursor:pointer}
.nxside a.ni:hover{color:var(--txt);background:color-mix(in srgb,var(--txt) 5%,transparent)}
.nxside a.ni .ic{width:18px;text-align:center;font-size:14px}
.nxside a.ni.on{color:var(--txt);background:color-mix(in srgb,var(--c1) 12%,transparent)}
.nxside a.ni.on::before{content:"";position:absolute;left:-10px;top:8px;bottom:8px;width:3px;border-radius:2px;background:var(--c1);box-shadow:0 0 8px var(--c1)}
.nxside .nsep{height:1px;background:var(--line);margin:10px 8px}
.nxside .nfoot{margin-top:auto;padding:10px 12px;border:1px solid var(--line);border-radius:10px;font-size:10.5px;color:var(--dim);line-height:1.6}
.nxside .nfoot b{color:var(--ok);font-weight:normal}
.nxhead{display:flex;align-items:flex-end;gap:16px;margin:4px 0 16px;flex-wrap:wrap}
.nxhead h1{font-size:21px;font-weight:600;letter-spacing:.03em;margin:0;color:var(--txt)}
.nxhead p{margin:5px 0 0;color:var(--dim);font-size:12px;letter-spacing:.01em}
.nxhead .nxr{margin-left:auto;display:flex;gap:8px;align-items:center}
/* mais limpo: títulos das caixas menos espaçados */
body.nxshell .card h2{letter-spacing:.16em}
@media (max-width:900px){
  body.nxshell{padding-left:0;padding-top:52px}
  .nxside{bottom:auto;right:0;width:auto;height:52px;flex-direction:row;align-items:center;padding:6px 8px;overflow-x:auto;overflow-y:hidden;border-right:0;border-bottom:1px solid var(--line)}
  .nxside .nlogo{padding:0 8px 0 2px}.nxside .nlogo span,.nxside .nfoot,.nxside .nsep{display:none}
  .nxside a.ni{white-space:nowrap;padding:8px 10px}.nxside a.ni.on::before{display:none}
}`;
    document.head.appendChild(st);
  }
  function href(s){ return s.pg + (s.tab ? '#' + s.tab : ''); }
  function go(s, ev){
    // na mesma página (ex.: de Jogos para Rede na Performance) muda de separador sem recarregar
    if(s.pg === page() && s.tab && typeof showTab === 'function'){ if(ev) ev.preventDefault(); showTab(s.tab); scrollTo({ top: 0 }); mark(); return; }
    if(s.pg === page() && !s.tab){ if(ev) ev.preventDefault(); scrollTo({ top: 0, behavior: 'smooth' }); }
  }
  function openSettings(ev){
    if(ev) ev.preventDefault();
    if(page() === '/' && document.getElementById('opts')){ const o = document.getElementById('opts'); o.classList.add('open'); if(typeof loadOpts === 'function') try { loadOpts(); } catch(e){} return; }
    location.href = '/#opcoes';
  }
  let nav = null;
  function build(){
    nav = document.createElement('nav'); nav.className = 'nxside'; nav.id = 'nxSide';
    nav.innerHTML = `<a class="nlogo" href="/"><i></i><span><b>NEXUS</b><small>MONITOR</small></span></a>` +
      S.map(s => `<a class="ni" data-k="${s.k}" href="${href(s)}" title="${E(T(s.d))}"><span class="ic">${s.ic}</span>${E(T(s.t))}</a>`).join('') +
      `<div class="nsep"></div><a class="ni" data-k="def" href="/#opcoes" title="${E(T(SET.d))}"><span class="ic">${SET.ic}</span>${E(T(SET.t))}</a>` +
      `<div class="nfoot"><b>● ${E(T('A funcionar'))}</b><br><span id="nxVer"></span></div>`;
    document.body.prepend(nav);
    nav.querySelectorAll('a.ni').forEach(a => a.onclick = ev => { const k = a.dataset.k; if(k === 'def'){ ev.stopPropagation(); return openSettings(ev); } const s = S.find(x => x.k === k); if(s) go(s, ev); });
    document.body.classList.add('nxshell');
    fetch('/api/update', { cache: 'no-store' }).then(r => r.json()).then(j => { const v = document.getElementById('nxVer'); if(v && j && j.current) v.textContent = 'v' + j.current; }).catch(() => {});
  }
  function mark(){
    if(!nav) return;
    const k = current();
    nav.querySelectorAll('a.ni').forEach(a => a.classList.toggle('on', a.dataset.k === k));
    const s = S.find(x => x.k === k), h = document.getElementById('nxHead');
    if(h && s){ h.querySelector('h1').textContent = T(s.t); h.querySelector('p').textContent = T(s.d); }
  }
  // título e frase da secção, por cima do conteúdo
  function head(){
    let anchor = null;
    if(page() === '/perf') anchor = document.querySelector('.grid');
    else if(page() === '/disk') anchor = document.getElementById('dtabs');
    if(!anchor) return;
    const h = document.createElement('div'); h.className = 'nxhead'; h.id = 'nxHead';
    h.innerHTML = '<div><h1></h1><p></p></div><div class="nxr"></div>';
    anchor.parentNode.insertBefore(h, anchor);
    // a pesquisa da Performance passa para o cabeçalho
    const ps = document.getElementById('pSearch'); if(ps){ const r = h.querySelector('.nxr'); r.appendChild(ps); const n = document.getElementById('pSearchN'); if(n) r.appendChild(n); }
  }
  // o que deixa de ser preciso (a navegação antiga): fica escondido, não apagado, para não partir nada
  function tidy(){
    const st = document.createElement('style');
    st.textContent = `
body.nxshell header .logo, body.nxshell header a.back, body.nxshell #scanBtn, body.nxshell #perfBtn, body.nxshell header > h1{display:none!important}
body.nxshell #ptabs > button{display:none!important}
body.nxshell #ptabs{display:none!important}
body.nxshell header{min-height:0}
body.nxshell .nxhead #pSearch{width:260px;background:var(--track);border:1px solid var(--line);border-radius:8px;color:var(--txt);font:inherit;font-size:12px;padding:8px 10px}
body.nxshell .nxhead #pSearchN{font-size:11px;color:var(--dim)}`;
    document.head.appendChild(st);
  }
  function init(){
    if(document.body.classList.contains('kiosk') || /[?&](kiosk|montest)=/.test(location.search)) return;
    css(); tidy(); build(); head(); mark();
    addEventListener('hashchange', mark);
    if(page() === '/' && location.hash === '#opcoes') setTimeout(() => openSettings(), 400);
  }
  window.NXSHELL = { sections: S, mark, current };
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
