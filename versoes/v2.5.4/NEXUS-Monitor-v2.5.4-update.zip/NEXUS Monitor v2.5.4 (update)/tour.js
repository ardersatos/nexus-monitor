/* NEXUS Monitor - tutorial que passa pelas páginas (Monitor, Performance, Deep Scan)
   Cada passo diz em que página está; ao mudar de página o tutorial continua de onde ia.
   Usado por index.html, perf.html e disk.html. Nada sai do PC: o passo atual fica só no browser. */
(function(){
  if(window.NXTOUR) return;
  const T = s => (window.NX && NX.T ? NX.T(s) : s);
  const E = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'})[c]);
  const PC = ['localhost','127.0.0.1'].includes(location.hostname);
  const KEY = 'nx_tour';
  const page = () => { const p = location.pathname.replace(/\.html$/, ''); return p === '/' || p === '/index' ? '/' : p; };

  // pg: página · tab: separador dessa página · el: o que se destaca · pc: só no PC
  const S = [
    { pg:'/', c:true, hero:true, t:'BEM-VINDO AO NEXUS', p: () => PC ? 'O monitor e o otimizador do teu PC. Tudo é lido e fica neste PC: nada sai da tua rede. Vamos dar uma volta pelas páginas principais (2 minutos)?'
                                                            : 'Estás a ver o teu PC no telemóvel, em tempo real. Tudo passa só pela tua rede Wi-Fi. Vamos dar uma volta rápida?' },
    { pg:'/', el:'#statusLine', t:'O ESTADO NUMA FRASE', p:'Diz-te se está tudo bem ou o que precisa de atenção (temperaturas, RAM, discos), com um atalho para resolver. Podes ignorar um aviso: deixa de contar quando o problema passa.' },
    { pg:'/', all:'.grid > .card.s3', t:'OS CARTÕES', p:'Processador, memória, temperatura e placa gráfica, sempre a atualizar. Quando alguma coisa aquece demais, o cartão fica vermelho.' },
    { pg:'/', el:'.netcard', t:'REDE E TESTE DE VELOCIDADE', p:'Download e upload em direto. TESTAR VELOCIDADE mede a internet e a latência; só corre quando carregas.' },
    { pg:'/', el:'#nxSide', t:'O MENU', p:'Tudo arrumado por assunto: Jogos, Otimizar, Dispositivos, Hardware, Discos, Rede e Saúde do PC. Carrega em SEGUINTE e o tutorial leva-te a cada um.' },
    { pg:'/', el:'#nxSide [data-k="def"]', t:'DEFINIÇÕES', p:'Tema e cores, idioma, arranque com o Windows, avisos, atualizações, telemóvel e integrações, por assunto. É aqui que podes voltar a ver este tutorial.' },

    { pg:'/perf', tab:'otim', el:'#sumCard', pc:true, t:'OTIMIZAR O WINDOWS', p:'Um clique aplica as otimizações recomendadas para o teu PC. Antes de mudar, o NEXUS guarda o valor original: REPOR volta tudo atrás. As que pedem reiniciar estão marcadas.' },
    { pg:'/perf', tab:'otim', el:'#scnCard', pc:true, t:'CENÁRIOS', p:'Silencioso, normal ou máximo num clique (energia, placa e ventoinhas). Podes guardar o teu próprio cenário.' },
    { pg:'/perf', tab:'jogos', el:'#turboCard', pc:true, t:'BOOST DE JOGO', p:'Quando abres um jogo, o NEXUS pausa o que está a mais, muda a energia e dá prioridade ao jogo. Nunca mexe no jogo nem no anti-cheat, e tudo volta ao normal quando fechas.' },
    { pg:'/perf', tab:'jogos', el:'#ovCard', pc:true, t:'OVERLAY EM JOGO', p:'FPS, temperaturas e uso por cima do jogo. Alt+Shift+O mostra e esconde. Dica: em MEDIR FPS comparas o antes e o depois de cada mudança.' },
    { pg:'/perf', tab:'ctl', el:'#devCard', pc:true, t:'OS TEUS DISPOSITIVOS', p:'Rato, teclado e auscultadores: bateria, DPI, taxa e tempo até adormecer, sem as apps das marcas. Se algum não aparece, usa "Ensina-o ao NEXUS" no fim da caixa.' },
    { pg:'/perf', tab:'ctl', el:'#eqCard', pc:true, t:'EQUALIZADOR', p:'Para todo o som do PC. Se o NEXUS reconhecer os teus auscultadores, aplica a correção certa para eles. Mexer numa barra liga-o.' },
    { pg:'/perf', tab:'rede', el:'#rtCard', pc:true, t:'ROTA PARA JOGOS', p:'Testa se a ligação ao servidor do jogo fica mais rápida pela rede da Cloudflare (como a ExitLag, grátis) e usa-a só nesse jogo. É opcional e é a única coisa que passa por fora: desligada, nada sai do PC.' },
    { pg:'/perf', tab:'hw', el:'#hwCard', pc:true, t:'VERIFICAÇÕES', p:'Erros comuns que roubam FPS: monitor a menos Hz do que suporta, RAM sem XMP, um só módulo de RAM. Cada aviso diz como resolver.' },
    { pg:'/perf', tab:'saude', el:'#aidCard', pc:true, t:'PRIMEIROS SOCORROS', p:'Jogo que crasha, PC quente, lag, ecrã azul… Passo a passo, do mais simples ao mais difícil, com atalhos para cada ferramenta.' },
    { pg:'/perf', el:'#pSearch', pc:true, t:'PROCURAR', p:'Não sabes onde está alguma coisa? Escreve aqui (ex.: "ventoinha", "ping", "ecrã azul") e o NEXUS mostra a caixa certa.' },
    { pg:'/perf', tab:'saude', el:'#nxHead', pc:true, t:'CADA SECÇÃO EXPLICADA', p:'No topo diz o que há na secção, e cada caixa diz numa frase o que faz; o ⓘ ao lado do título mostra a explicação completa. A seguir: os Discos.' },

    { pg:'/disk', tab:'analisar', el:'#dtabs', t:'DISCOS', p: () => PC ? 'Vê o que ocupa espaço nos discos, limpa o lixo do Windows, vê a saúde dos discos e desinstala programas sem deixar restos.'
                                                                          : 'Vê o que ocupa espaço nos discos do PC. Limpar, apagar e desinstalar faz-se no próprio PC.' },
    { pg:'/disk', tab:'saude', el:'#healthCard', t:'SAÚDE DOS DISCOS', p:'A saúde lida pelo próprio Windows e a vida que resta aos SSD. Se algum disco tiver aviso, faz cópia do que é importante.' },
    { pg:'/', c:true, t:'TUDO PRONTO', p:'Já conheces o essencial. Os avisos aparecem no canto do ecrã quando precisares, e este tutorial está nas Opções se quiseres rever.' },
  ].filter(s => PC || !s.pc);

  let i = 0, on = false, el = null, root = null, ending = false;
  function css(){
    if(document.getElementById('nxTourCss')) return;
    const st = document.createElement('style'); st.id = 'nxTourCss';
    st.textContent = `
.nxtour{position:fixed;inset:0;z-index:400;pointer-events:none;display:none}.nxtour.on{display:block}
.nxtour .nxblk{position:fixed;inset:0;pointer-events:auto;background:transparent}
.nxtour .nxspot{position:fixed;border-radius:12px;pointer-events:none;border:1.5px solid var(--c1);box-shadow:0 0 0 9999px color-mix(in srgb,var(--bg) 78%,transparent),0 0 18px color-mix(in srgb,var(--c1) 45%,transparent);transition:all .4s cubic-bezier(.3,.8,.3,1)}
.nxtour .nxspot::after{content:"";position:absolute;inset:-6px;border-radius:inherit;border:1px solid color-mix(in srgb,var(--c1) 50%,transparent);animation:nxTourRing 1.8s ease-out infinite}
.nxtour .nxspot.nxcenter{border-color:transparent;box-shadow:0 0 0 9999px color-mix(in srgb,var(--bg) 82%,transparent)}.nxtour .nxspot.nxcenter::after{display:none}
@keyframes nxTourRing{0%{opacity:.9;transform:scale(1)}100%{opacity:0;transform:scale(1.06)}}
.nxtour .nxtip{position:fixed;width:min(380px,calc(100vw - 24px));pointer-events:auto;background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:16px 16px 12px;box-shadow:0 18px 50px rgba(0,0,0,.5);transition:left .35s,top .35s;font-family:var(--mono,monospace)}
.nxtour .nxtip::before{content:"";position:absolute;top:-1px;left:20px;width:40px;height:2px;border-radius:2px;background:var(--c2);box-shadow:0 0 10px var(--c2)}
.nxtour .nxtip .nxk{font-size:9.5px;letter-spacing:.24em;color:var(--dim)}.nxtour .nxtip .nxk b{color:var(--c2);font-weight:normal;margin-left:8px}
.nxtour .nxtip h4{margin:6px 0 6px;font-size:14px;letter-spacing:.12em;color:var(--c1)}
.nxtour .nxtip p{margin:0;font-size:12.5px;line-height:1.6;color:var(--txt)}
.nxtour .nxtip .nxbar{height:2px;background:var(--track);border-radius:2px;margin:12px 0 10px;overflow:hidden}
.nxtour .nxtip .nxbar i{display:block;height:100%;background:linear-gradient(90deg,var(--c1),var(--c2));transition:width .45s}
.nxtour .nxtip .nxrow{display:flex;gap:8px;align-items:center}.nxtour .nxtip .nxrow .nxsp{flex:1}
.nxtour .nxtip button{background:transparent;border:1px solid var(--line);border-radius:8px;color:var(--txt);font:inherit;font-size:10px;letter-spacing:.18em;padding:7px 12px;cursor:pointer}
.nxtour .nxtip button:hover{border-color:var(--c1);color:var(--c1)}.nxtour .nxtip button.nxgo{border-color:var(--c1);color:var(--c1)}
.nxtour .nxtip button.nxskip{border:0;color:var(--dim);padding-left:0}
.nxtour .nxhero{display:grid;place-items:center;margin:4px 0 12px}
.nxtour .nxhero i{width:34px;height:34px;border:1.5px solid var(--c1);border-radius:5px;transform:rotate(45deg);display:grid;place-items:center;box-shadow:0 0 16px color-mix(in srgb,var(--c1) 45%,transparent);animation:nxTourSpin 1.2s cubic-bezier(.3,.8,.3,1)}
.nxtour .nxhero i::after{content:"";width:11px;height:11px;border-radius:2px;background:var(--c1)}
@keyframes nxTourSpin{from{transform:rotate(-135deg) scale(.4);opacity:0}}
@media (max-width:700px){.nxtour .nxtip{width:calc(100vw - 20px);padding:14px 14px 10px;border-radius:14px}.nxtour .nxtip p{font-size:13px}.nxtour .nxtip button{padding:10px 14px}}`;
    document.head.appendChild(st);
  }
  function dom(){
    if(root) return root;
    css();
    root = document.createElement('div'); root.className = 'nxtour';
    root.innerHTML = '<div class="nxblk"></div><div class="nxspot"></div><div class="nxtip"></div>';
    document.body.appendChild(root);
    return root;
  }
  function visible(e){ if(!e) return false; const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0 && getComputedStyle(e).visibility !== 'hidden'; }
  function target(s){
    if(s.c) return null;
    if(s.all){
      const l = [...document.querySelectorAll(s.all)].filter(visible);
      return l.length ? { getBoundingClientRect(){ const r = l.map(e => e.getBoundingClientRect());
        const L = Math.min(...r.map(x => x.left)), Tp = Math.min(...r.map(x => x.top)), R = Math.max(...r.map(x => x.right)), B = Math.max(...r.map(x => x.bottom));
        return { left:L, top:Tp, right:R, bottom:B, width:R-L, height:B-Tp }; }, scrollIntoView(o){ l[0].scrollIntoView(o); } } : null;
    }
    const e = document.querySelector(s.el);
    return visible(e) ? e : null;
  }
  function place(){
    if(!on) return;
    const spot = root.querySelector('.nxspot'), tip = root.querySelector('.nxtip');
    const vw = innerWidth, vh = innerHeight, tw = tip.offsetWidth, th = tip.offsetHeight;
    if(!el){
      spot.classList.add('nxcenter');
      Object.assign(spot.style, { left: vw/2 + 'px', top: vh/2 + 'px', width: '0px', height: '0px' });
      Object.assign(tip.style, vw < 700 ? { left: '10px', top: Math.max(10, (vh - th)/2) + 'px' } : { left: (vw - tw)/2 + 'px', top: Math.max(12, (vh - th)/2) + 'px' });
      return;
    }
    spot.classList.remove('nxcenter');
    const r = el.getBoundingClientRect(), pad = 8;
    Object.assign(spot.style, { left: (r.left - pad) + 'px', top: (r.top - pad) + 'px', width: (r.width + pad*2) + 'px', height: (r.height + pad*2) + 'px' });
    if(vw < 700){ const low = r.top + r.height/2 > vh/2; Object.assign(tip.style, { left: '10px', top: (low ? 10 : vh - th - 10) + 'px' }); return; }
    let top = r.bottom + 16, left = Math.min(vw - tw - 12, Math.max(12, r.left + r.width/2 - tw/2));
    if(top + th > vh - 12) top = r.top - th - 16;
    if(top < 12){
      top = Math.min(vh - th - 12, Math.max(12, r.top + Math.min(r.height, vh)/2 - th/2));
      if(vw - r.right - pad >= tw + 24) left = r.right + pad + 16;
      else if(r.left - pad >= tw + 24) left = r.left - pad - 16 - tw;
      else top = Math.min(vh - th - 12, Math.max(12, r.top + 12));
    }
    Object.assign(tip.style, { left: left + 'px', top: top + 'px' });
  }
  const save = n => { try { localStorage.setItem(KEY, JSON.stringify({ i: n, at: Date.now() })); } catch(e){} };
  function go(n, dir){
    n = Math.max(0, Math.min(S.length - 1, n));
    const s = S[n];
    // passo noutra página: vai para lá e continua
    if(s.pg !== page()){ save(n); location.href = s.pg + (s.tab ? '#' + s.tab : ''); return; }
    // separador desta página
    if(s.tab){ try { if(page() === '/perf' && typeof showTab === 'function') showTab(s.tab); else if(page() === '/disk' && typeof showDTab === 'function') showDTab(s.tab); } catch(e){} }
    i = n; save(n);
    setTimeout(() => show(dir || 1), s.tab ? 250 : 0);
  }
  function show(dir){
    const s = S[i];
    el = target(s);
    if(!s.c && !el){ if(i + dir >= 0 && i + dir < S.length) return go(i + dir, dir); }   // não existe neste PC: salta
    const tip = root.querySelector('.nxtip'), last = i === S.length - 1;
    const sec = s.pg === '/perf' && window.NXSHELL ? NXSHELL.sections.find(x => x.tab === (s.tab || (typeof curTab === 'string' ? curTab : ''))) : null;
    const where = sec ? T(sec.t).toUpperCase() : T({ '/': 'PAINEL', '/disk': 'DISCOS' }[s.pg] || '');
    tip.innerHTML = `${s.nxhero ? '<div class="nxhero"><i></i></div>' : ''}
      <div class="nxk">${E(T('PASSO'))} ${i + 1} / ${S.length}<b>${E(where)}</b></div><h4>${E(T(s.t))}</h4><p>${E(T(typeof s.p === 'function' ? s.p() : s.p))}</p>
      <div class="nxbar"><i style="width:${(i + 1) / S.length * 100}%"></i></div>
      <div class="nxrow">${!last ? `<button class="nxskip" data-a="end">${E(T('SALTAR'))}</button>` : ''}<span class="nxsp"></span>
        ${i > 0 ? `<button data-a="prev">← ${E(T('ANTERIOR'))}</button>` : ''}
        <button class="nxgo" data-a="next">${last ? E(T('COMEÇAR')) : i === 0 ? E(T('VAMOS LÁ')) + ' →' : E(T('SEGUINTE')) + ' →'}</button></div>`;
    tip.querySelectorAll('[data-a]').forEach(b => b.onclick = () => act(b.dataset.a));
    if(el){ const r = el.getBoundingClientRect(); if(r.top < 80 || r.bottom > innerHeight - 40) el.scrollIntoView({ behavior: 'smooth', block: 'center' }); }
    requestAnimationFrame(place); setTimeout(place, 450);
  }
  function act(a){ if(a === 'end') end(); else if(a === 'prev') go(i - 1, -1); else if(i === S.length - 1) end(); else go(i + 1, 1); }
  function open(){ dom(); on = true; root.classList.add('on'); document.querySelectorAll('.themes.open,.nxmodal.open').forEach(x => x.classList.remove('open')); }
  function start(){ if(on) return; open(); go(0, 1); }
  function end(){
    if(ending) return; ending = true;
    on = false; if(root) root.classList.remove('on');
    try { localStorage.removeItem(KEY); } catch(e){}
    fetch('/api/settings?tutorial=1', { method: 'POST' }).catch(() => {});   // vale para o PC e para o telemóvel
    try { document.dispatchEvent(new Event('nxtourend')); } catch(e){}
    setTimeout(() => ending = false, 500);
  }
  // a página acabou de abrir: se o tutorial vinha de outra página, continua aqui
  function resume(){
    let st = null; try { st = JSON.parse(localStorage.getItem(KEY) || 'null'); } catch(e){}
    if(!st || typeof st.i !== 'number' || Date.now() - st.at > 15 * 60 * 1000 || !S[st.i]) { try { localStorage.removeItem(KEY); } catch(e){} return false; }
    if(S[st.i].pg !== page()) return false;
    setTimeout(() => { open(); go(st.i, 1); }, 900);   // espera que a página desenhe os cartões
    return true;
  }
  addEventListener('resize', () => place());
  addEventListener('scroll', () => place(), true);
  addEventListener('keydown', e => {
    if(!on) return;
    if(e.key === 'Escape') end();
    else if(e.key === 'ArrowRight' || e.key === 'Enter'){ e.preventDefault(); act('next'); }
    else if(e.key === 'ArrowLeft') act('prev');
  });
  window.NXTOUR = { start, end, resume, get running(){ return on; } };
  if(document.body.classList.contains('kiosk')) return;
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', resume); else resume();
})();
