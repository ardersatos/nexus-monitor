﻿// NEXUS // MONITOR - vibração do comando, teste de velocidade e cores do SignalRGB
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Linq;
using System.Management;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Reflection;
using System.Security.Principal;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Win32;

namespace Nexus
{

    // ------------------------------------------------------------ vibração dos comandos (página COMANDO)
    // O browser só faz vibrar alguns comandos; aqui o NEXUS fala direto com eles:
    // XInput (Xbox e a maioria dos comandos de PC) e DualShock 4 / DualSense por HID (USB e Bluetooth).
    static class PadRumble
    {
        [StructLayout(LayoutKind.Sequential)] struct XV { public ushort L; public ushort R; }
        [StructLayout(LayoutKind.Sequential)] struct XS { public uint Pkt; public ushort Btn; public byte LT; public byte RT; public short LX; public short LY; public short RX; public short RY; }
        [DllImport("xinput1_4.dll", EntryPoint = "XInputSetState")] static extern int XSet14(int i, ref XV v);
        [DllImport("xinput1_4.dll", EntryPoint = "XInputGetState")] static extern int XGet14(int i, out XS s);
        [DllImport("xinput9_1_0.dll", EntryPoint = "XInputSetState")] static extern int XSet91(int i, ref XV v);
        [DllImport("xinput9_1_0.dll", EntryPoint = "XInputGetState")] static extern int XGet91(int i, out XS s);
        static bool old;
        static int XSet(int i, ref XV v) { if (!old) try { return XSet14(i, ref v); } catch (DllNotFoundException) { old = true; } catch (EntryPointNotFoundException) { old = true; } return XSet91(i, ref v); }
        static int XGet(int i, out XS st) { if (!old) try { return XGet14(i, out st); } catch (DllNotFoundException) { old = true; } catch (EntryPointNotFoundException) { old = true; } return XGet91(i, out st); }

        [StructLayout(LayoutKind.Sequential)] struct HIDD_ATTRIBUTES { public int Size; public ushort VendorID; public ushort ProductID; public ushort VersionNumber; }
        [StructLayout(LayoutKind.Sequential)] struct HIDP_CAPS
        {
            public ushort Usage, UsagePage, InputReportByteLength, OutputReportByteLength, FeatureReportByteLength;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 17)] public ushort[] Reserved;
            public ushort NumberLinkCollectionNodes, NumberInputButtonCaps, NumberInputValueCaps, NumberInputDataIndices,
                          NumberOutputButtonCaps, NumberOutputValueCaps, NumberOutputDataIndices, NumberFeatureButtonCaps, NumberFeatureValueCaps, NumberFeatureDataIndices;
        }
        [StructLayout(LayoutKind.Sequential)] struct SP_DID { public int cbSize; public Guid Guid; public int Flags; public IntPtr Reserved; }
        [DllImport("hid.dll")] static extern void HidD_GetHidGuid(out Guid g);
        [DllImport("hid.dll")] static extern bool HidD_GetAttributes(Microsoft.Win32.SafeHandles.SafeFileHandle h, ref HIDD_ATTRIBUTES a);
        [DllImport("hid.dll")] static extern bool HidD_GetPreparsedData(Microsoft.Win32.SafeHandles.SafeFileHandle h, out IntPtr p);
        [DllImport("hid.dll")] static extern bool HidD_FreePreparsedData(IntPtr p);
        [DllImport("hid.dll")] static extern int HidP_GetCaps(IntPtr p, out HIDP_CAPS c);
        [DllImport("hid.dll")] static extern bool HidD_SetOutputReport(Microsoft.Win32.SafeHandles.SafeFileHandle h, byte[] b, int len);
        [DllImport("setupapi.dll", SetLastError = true)] static extern IntPtr SetupDiGetClassDevs(ref Guid g, IntPtr e, IntPtr w, int flags);
        [DllImport("setupapi.dll", SetLastError = true)] static extern bool SetupDiEnumDeviceInterfaces(IntPtr set, IntPtr info, ref Guid g, int idx, ref SP_DID d);
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Auto)] static extern bool SetupDiGetDeviceInterfaceDetail(IntPtr set, ref SP_DID d, IntPtr detail, int size, out int req, IntPtr info);
        [DllImport("setupapi.dll")] static extern bool SetupDiDestroyDeviceInfoList(IntPtr set);
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Auto)] static extern Microsoft.Win32.SafeHandles.SafeFileHandle CreateFile(string n, uint access, uint share, IntPtr sa, uint disp, uint flags, IntPtr t);
        [DllImport("kernel32.dll", SetLastError = true)] static extern bool WriteFile(Microsoft.Win32.SafeHandles.SafeFileHandle h, byte[] b, int n, out int w, IntPtr o);

        static readonly int[] DS4 = { 0x05c4, 0x09cc, 0x0ba0 };       // DualShock 4 (v1, v2, adaptador sem fios)
        static readonly int[] DS5 = { 0x0ce6, 0x0df2 };               // DualSense, DualSense Edge
        static System.Threading.Timer stopTimer;
        static readonly object gate = new object();
        static int seq;

        static List<string> HidPaths()
        {
            List<string> r = new List<string>();
            Guid g; HidD_GetHidGuid(out g);
            IntPtr set = SetupDiGetClassDevs(ref g, IntPtr.Zero, IntPtr.Zero, 0x12); // PRESENT | DEVICEINTERFACE
            if (set == IntPtr.Zero || set == new IntPtr(-1)) return r;
            try
            {
                for (int i = 0; i < 256; i++)
                {
                    SP_DID d = new SP_DID(); d.cbSize = Marshal.SizeOf(typeof(SP_DID));
                    if (!SetupDiEnumDeviceInterfaces(set, IntPtr.Zero, ref g, i, ref d)) break;
                    int req; SetupDiGetDeviceInterfaceDetail(set, ref d, IntPtr.Zero, 0, out req, IntPtr.Zero);
                    if (req <= 0) continue;
                    IntPtr buf = Marshal.AllocHGlobal(req);
                    try
                    {
                        Marshal.WriteInt32(buf, IntPtr.Size == 8 ? 8 : 4 + Marshal.SystemDefaultCharSize);
                        if (SetupDiGetDeviceInterfaceDetail(set, ref d, buf, req, out req, IntPtr.Zero))
                            r.Add(Marshal.PtrToStringAuto(new IntPtr(buf.ToInt64() + 4)));
                    }
                    finally { Marshal.FreeHGlobal(buf); }
                }
            }
            finally { SetupDiDestroyDeviceInfoList(set); }
            return r;
        }

        static uint[] crcT;
        static uint Crc(byte[] b, int n)
        {
            if (crcT == null)
            {
                uint[] t = new uint[256];
                for (uint i = 0; i < 256; i++) { uint c = i; for (int k = 0; k < 8; k++) c = (c & 1) != 0 ? 0xEDB88320 ^ (c >> 1) : c >> 1; t[i] = c; }
                crcT = t;
            }
            uint x = 0xFFFFFFFF;
            x = crcT[(x ^ 0xA2) & 0xFF] ^ (x >> 8);           // semente do Bluetooth (cabeçalho de saída)
            for (int i = 0; i < n; i++) x = crcT[(x ^ b[i]) & 0xFF] ^ (x >> 8);
            return ~x;
        }
        static void PutCrc(byte[] b) { uint c = Crc(b, 74); b[74] = (byte)c; b[75] = (byte)(c >> 8); b[76] = (byte)(c >> 16); b[77] = (byte)(c >> 24); }

        static bool Write(Microsoft.Win32.SafeHandles.SafeFileHandle h, byte[] b)
        {
            int w;
            if (WriteFile(h, b, b.Length, out w, IntPtr.Zero)) return true;
            return HidD_SetOutputReport(h, b, b.Length);
        }

        // devolve quantos comandos PlayStation receberam o pedido
        static int Sony(byte weak, byte strong, int wantPid)
        {
            int n = 0;
            foreach (string path in HidPaths())
            {
                using (Microsoft.Win32.SafeHandles.SafeFileHandle h = CreateFile(path, 0xC0000000, 3, IntPtr.Zero, 3, 0, IntPtr.Zero))
                {
                    if (h.IsInvalid) continue;
                    HIDD_ATTRIBUTES a = new HIDD_ATTRIBUTES(); a.Size = Marshal.SizeOf(typeof(HIDD_ATTRIBUTES));
                    if (!HidD_GetAttributes(h, ref a) || a.VendorID != 0x054c) continue;
                    bool ds4 = Array.IndexOf(DS4, (int)a.ProductID) >= 0, ds5 = Array.IndexOf(DS5, (int)a.ProductID) >= 0;
                    if (!ds4 && !ds5) continue;
                    if (wantPid > 0 && a.ProductID != wantPid) continue;
                    IntPtr pp; if (!HidD_GetPreparsedData(h, out pp)) continue;
                    HIDP_CAPS caps; HidP_GetCaps(pp, out caps); HidD_FreePreparsedData(pp);
                    int len = caps.OutputReportByteLength;
                    if (len < 32) continue;                        // não é a interface de saída do comando
                    byte[] b;
                    if (ds4 && len < 78)
                    {   // DualShock 4 por USB: relatório 0x05
                        b = new byte[len]; b[0] = 0x05; b[1] = 0x01; b[4] = weak; b[5] = strong;
                    }
                    else if (ds4)
                    {   // DualShock 4 por Bluetooth: relatório 0x11 com CRC
                        b = new byte[len]; b[0] = 0x11; b[1] = 0xC0; b[3] = 0x01; b[6] = weak; b[7] = strong; PutCrc(b);
                    }
                    else if (len < 78)
                    {   // DualSense por USB: relatório 0x02 (vibração "compatível")
                        b = new byte[len]; b[0] = 0x02; b[1] = 0x03; b[3] = weak; b[4] = strong; if (len > 39) b[39] = 0x04;
                    }
                    else
                    {   // DualSense por Bluetooth: relatório 0x31 com CRC
                        b = new byte[len]; b[0] = 0x31; b[1] = (byte)((seq++ & 0x0F) << 4); b[2] = 0x10;
                        b[3] = 0x03; b[5] = weak; b[6] = strong; b[41] = 0x04; PutCrc(b);
                    }
                    try { if (Write(h, b)) n++; } catch { }
                }
            }
            return n;
        }

        static int XInput(ushort weak, ushort strong)
        {
            int n = 0;
            for (int i = 0; i < 4; i++)
            {
                try
                {
                    XS st; if (XGet(i, out st) != 0) continue;
                    XV v = new XV(); v.L = strong; v.R = weak;  // motor esquerdo = forte, direito = fraco
                    if (XSet(i, ref v) == 0) n++;
                }
                catch { }
            }
            return n;
        }

        static string lastVia = "";
        public static string Rumble(double weak, double strong, int ms, string vid, string pid, bool xi)
        {
            lock (gate)
            {
                weak = Math.Max(0, Math.Min(1, weak)); strong = Math.Max(0, Math.Min(1, strong));
                ms = Math.Max(0, Math.Min(10000, ms));
                int wantPid = 0; try { if (!string.IsNullOrEmpty(pid)) wantPid = Convert.ToInt32(pid, 16); } catch { }
                bool sony = (vid ?? "").ToLowerInvariant() == "054c";
                List<string> via = new List<string>();
                int n = 0;
                if (sony || !xi)
                {
                    int s = Sony((byte)(weak * 255), (byte)(strong * 255), sony ? wantPid : 0);
                    if (s > 0) { n += s; via.Add("PlayStation HID"); }
                }
                if (!sony || n == 0)
                {
                    int x = XInput((ushort)(weak * 65535), (ushort)(strong * 65535));
                    if (x > 0) { n += x; via.Add("XInput"); }
                }
                if (stopTimer != null) { stopTimer.Dispose(); stopTimer = null; }
                if (n > 0 && ms > 0 && (weak > 0 || strong > 0))
                {
                    string v2 = vid, p2 = pid; bool x2 = xi;
                    stopTimer = new System.Threading.Timer(delegate { try { Rumble(0, 0, 0, v2, p2, x2); } catch { } }, null, ms, System.Threading.Timeout.Infinite);
                }
                if (weak == 0 && strong == 0 && n == 0) { XInput(0, 0); try { Sony(0, 0, 0); } catch { } }
                lastVia = string.Join(" + ", via.ToArray());
                return "{\"ok\":" + (n > 0 ? "true" : "false") + ",\"n\":" + n + ",\"via\":\"" + lastVia + "\"}";
            }
        }
    }

    // ------------------------------------------------------------ teste de velocidade (cartão REDE)
    // Mesmo método do motor open source da Cloudflare (MIT, o que corre em speed.cloudflare.com):
    // pedidos HTTP ao servidor Cloudflare mais próximo. Sem programas extra; só corre quando se carrega no botão.
    static class SpeedTest
    {
        const string BASE = "https://speed.cloudflare.com";
        static readonly object gate = new object();
        static volatile bool running, stop;
        static string phase = "idle", colo = "", country = "", error = "", diag = "";
        static int runId;
        static double progress, live, ping = -1, jitter = -1, down = -1, up = -1, pingDown = -1, pingUp = -1;
        static long usedBytes; static DateTime when = DateTime.MinValue;

        static string N(double v, int d) { return v < 0 ? "null" : Math.Round(v, d).ToString(CultureInfo.InvariantCulture); }
        static string Q(string v) { return "\"" + (v ?? "").Replace("\\", "\\\\").Replace("\"", "\\\"") + "\""; }
        public static string Json()
        {
            lock (gate)
                return "{\"running\":" + (running ? "true" : "false") + ",\"phase\":" + Q(phase) + ",\"progress\":" + N(progress, 3) +
                    ",\"live\":" + N(live, 1) + ",\"ping\":" + N(ping, 1) + ",\"jitter\":" + N(jitter, 1) + ",\"down\":" + N(down, 1) + ",\"up\":" + N(up, 1) +
                    ",\"pingDown\":" + N(pingDown, 1) + ",\"pingUp\":" + N(pingUp, 1) + ",\"colo\":" + Q(colo) + ",\"country\":" + Q(country) +
                    ",\"mb\":" + N(usedBytes / 1048576.0, 0) + ",\"when\":" + (when == DateTime.MinValue ? "null" : Q(when.ToString("HH:mm"))) + ",\"error\":" + Q(error) + ",\"diag\":" + Q(diag) + "}";
        }
        public static void Stop() { stop = true; }
        public static bool Start()
        {
            lock (gate)
            {
                if (running) return false;
                running = true; stop = false; error = ""; diag = ""; phase = "ping"; progress = 0; live = 0; runId++;
                ping = jitter = down = up = pingDown = pingUp = -1; usedBytes = 0;
            }
            Thread t = new Thread(Run); t.IsBackground = true; t.Name = "NEXUS speedtest"; t.Start();
            return true;
        }

        static HttpWebRequest Req(string url, string group)
        {
            HttpWebRequest r = (HttpWebRequest)WebRequest.Create(url);
            r.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) NEXUS-Monitor"; r.Timeout = 15000; r.ReadWriteTimeout = 15000; r.KeepAlive = true;
            r.Accept = "*/*"; r.Referer = BASE + "/"; r.AutomaticDecompression = DecompressionMethods.None;
            r.Proxy = WebRequest.DefaultWebProxy; r.ConnectionGroupName = group;
            return r;
        }

        // tempo até o servidor responder, sem o tempo que o próprio servidor gastou (cabeçalho Server-Timing)
        static double Ping(string group)
        {
            Stopwatch sw = Stopwatch.StartNew();
            HttpWebRequest r = Req(BASE + "/__down?bytes=0", group);
            using (HttpWebResponse resp = (HttpWebResponse)r.GetResponse())
            {
                double ms = sw.Elapsed.TotalMilliseconds;
                string st = resp.Headers["Server-Timing"] ?? "";
                System.Text.RegularExpressions.Match m = System.Text.RegularExpressions.Regex.Match(st, @"dur=([\d.]+)");
                if (m.Success) { double d; if (double.TryParse(m.Groups[1].Value, NumberStyles.Float, CultureInfo.InvariantCulture, out d)) ms -= d; }
                using (Stream s = resp.GetResponseStream()) { }
                return Math.Max(0.1, ms);
            }
        }
        static double Median(List<double> l) { if (l.Count == 0) return -1; List<double> c = new List<double>(l); c.Sort(); return c[c.Count / 2]; }

        static void Run()
        {
            try
            {
                ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072 | (SecurityProtocolType)768 | SecurityProtocolType.Tls;
                ServicePointManager.Expect100Continue = false;
                ServicePointManager.UseNagleAlgorithm = false;   // pedidos pequenos (latência) saem logo, sem esperar
                if (ServicePointManager.DefaultConnectionLimit < 32) ServicePointManager.DefaultConnectionLimit = 32;

                // onde fica o servidor (código do aeroporto, ex.: LIS)
                try
                {
                    HttpWebRequest r = Req(BASE + "/cdn-cgi/trace", "p");
                    using (WebResponse resp = r.GetResponse()) using (StreamReader sr = new StreamReader(resp.GetResponseStream()))
                        foreach (string line in sr.ReadToEnd().Split('\n'))
                        {
                            if (line.StartsWith("colo=")) lock (gate) colo = line.Substring(5).Trim();
                            if (line.StartsWith("loc=")) lock (gate) country = line.Substring(4).Trim();
                        }
                }
                catch { }

                // 1) latência sem carga: 20 pedidos vazios (o 1.º abre a ligação e não conta)
                List<double> p = new List<double>();
                for (int i = 0; i < 21 && !stop; i++)
                {
                    try { double ms = Ping("p"); if (i > 0) p.Add(ms); } catch { }
                    lock (gate) progress = 0.1 * i / 20.0;
                }
                if (p.Count == 0) throw new Exception("sem_ligacao");
                double jit = 0; for (int i = 1; i < p.Count; i++) jit += Math.Abs(p[i] - p[i - 1]);
                lock (gate) { ping = Median(p); jitter = p.Count > 1 ? jit / (p.Count - 1) : 0; }

                // 2) download e 3) upload, cada um ~10 s com várias ligações ao mesmo tempo
                double d, ld; Measure(false, 6, 0.1, 0.55, out d, out ld);
                lock (gate) { down = d; pingDown = ld; }
                if (!stop) { double u, lu; Measure(true, 4, 0.55, 1.0, out u, out lu); lock (gate) { up = u; pingUp = lu; } }
                lock (gate) { phase = stop ? "stopped" : "done"; progress = 1; live = 0; when = DateTime.Now; }
            }
            catch (Exception ex)
            {
                lock (gate) { phase = "error"; error = ex.Message == "sem_ligacao" ? "no_connection" : ex.GetType().Name; live = 0; }
            }
            finally { running = false; }
        }

        static void Measure(bool upload, int streams, double p0, double p1, out double mbps, out double loadedPing)
        {
            lock (gate) phase = upload ? "up" : "down";
            const double DUR = 10.0, WARM = 2.0;          // os primeiros 2 s não contam (a ligação ainda está a acelerar)
            long total = 0; bool done = false;
            byte[] payload = null;
            if (upload) { payload = new byte[8 * 1024 * 1024]; new Random().NextBytes(payload); }
            List<Thread> ws = new List<Thread>();
            List<HttpWebRequest> live2 = new List<HttpWebRequest>();
            int okReq = 0, failReq = 0;
            for (int k = 0; k < streams; k++)
            {
                string grp = "r" + runId + (upload ? "u" : "d") + k;   // ligações novas em cada teste
                Thread w = new Thread(delegate ()
                {
                    byte[] buf = new byte[65536];
                    while (!done && !stop)
                    {
                        HttpWebRequest r = null;
                        try
                        {
                            if (!upload)
                            {
                                r = Req(BASE + "/__down?bytes=100000000", grp); r.KeepAlive = false;
                                lock (live2) live2.Add(r);
                                using (WebResponse resp = r.GetResponse()) using (Stream s = resp.GetResponseStream())
                                {
                                    Interlocked.Increment(ref okReq);
                                    int n;
                                    while (!done && !stop && (n = s.Read(buf, 0, buf.Length)) > 0) Interlocked.Add(ref total, n);
                                    if (done || stop) r.Abort();                 // não ficar a descarregar o resto
                                }
                            }
                            else
                            {
                                r = Req(BASE + "/__up", grp); r.KeepAlive = false;
                                lock (live2) live2.Add(r);
                                r.Method = "POST"; r.ContentType = "application/octet-stream"; r.ContentLength = payload.Length;
                                r.AllowWriteStreamBuffering = false; r.SendChunked = false;
                                using (Stream s = r.GetRequestStream())
                                    for (int off = 0; off < payload.Length && !done && !stop; off += 65536)
                                    {
                                        int n = Math.Min(65536, payload.Length - off);
                                        s.Write(payload, off, n); Interlocked.Add(ref total, n);
                                    }
                                if (!done && !stop) using (WebResponse resp = r.GetResponse()) { Interlocked.Increment(ref okReq); }
                            }
                        }
                        catch (Exception ex)
                        {
                            if (!done && !stop)
                            {
                                Interlocked.Increment(ref failReq);
                                string m = ex.GetType().Name + ": " + ex.Message;
                                WebException we = ex as WebException;
                                if (we != null && we.Response is HttpWebResponse) m = "HTTP " + (int)((HttpWebResponse)we.Response).StatusCode + " " + m;
                                lock (gate) if (diag == "") diag = (upload ? "up " : "down ") + m;
                                Thread.Sleep(300);
                            }
                        }
                        finally { if (r != null) lock (live2) live2.Remove(r); }
                    }
                });
                w.IsBackground = true; w.Start(); ws.Add(w);
            }
            // latência com a linha ocupada (numa ligação à parte)
            List<double> lp = new List<double>();
            Thread pinger = new Thread(delegate ()
            {
                while (!done && !stop)
                {
                    try { double ms = Ping("lp"); lock (lp) lp.Add(ms); } catch { }
                    Thread.Sleep(400);
                }
            });
            pinger.IsBackground = true; pinger.Start();

            Stopwatch sw = Stopwatch.StartNew();
            long warmBytes = -1; double warmT = 0;
            Queue<KeyValuePair<double, long>> win = new Queue<KeyValuePair<double, long>>();
            while (!stop)
            {
                Thread.Sleep(150);
                double t = sw.Elapsed.TotalSeconds; long b = Interlocked.Read(ref total);
                win.Enqueue(new KeyValuePair<double, long>(t, b));
                while (win.Count > 2 && t - win.Peek().Key > 1.0) win.Dequeue();
                KeyValuePair<double, long> first = win.Peek();
                double lv = t > first.Key ? (b - first.Value) * 8 / 1e6 / (t - first.Key) : 0;
                if (warmBytes < 0 && t >= WARM) { warmBytes = b; warmT = t; }
                lock (gate) { live = lv; progress = p0 + (p1 - p0) * Math.Min(1, t / DUR); }
                if (t >= DUR) break;
            }
            done = true;
            double tEnd = sw.Elapsed.TotalSeconds; long bEnd = Interlocked.Read(ref total);
            // fecha já as ligações que ainda estão a meio (senão ficavam a descarregar/enviar o resto)
            lock (live2) foreach (HttpWebRequest r in live2) try { r.Abort(); } catch { }
            mbps = warmBytes >= 0 && tEnd > warmT ? (bEnd - warmBytes) * 8 / 1e6 / (tEnd - warmT) : (tEnd > 0 ? bEnd * 8 / 1e6 / tEnd : 0);
            lock (lp) loadedPing = Median(lp);
            lock (gate) usedBytes += bEnd;
            // as ligações fecham sozinhas; não esperar por elas mais do que um instante
            foreach (Thread w in ws) w.Join(500);
            if (bEnd == 0) lock (gate) if (diag == "") diag = (upload ? "up" : "down") + " 0 bytes (ok=" + okReq + " falhas=" + failReq + ")";
        }
    }

    // ------------------------------------------------------------ cores do SignalRGB
    // O plugin "NEXUS Monitor" do SignalRGB envia as cores do efeito (4 pontos, 10x por segundo) para
    // 127.0.0.1:47821. O NEXUS só escuta com a opção ligada; desligada, a porta nem é aberta.
    static class RgbSync
    {
        public const int PORT = 47821;
        static readonly object gate = new object();
        static System.Net.Sockets.UdpClient udp;
        static Thread th;
        static byte[][] cols = new byte[4][];
        static DateTime lastPkt = DateTime.MinValue;
        static long packets;

        public static bool SignalInstalled
        {
            get
            {
                string la = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                return Directory.Exists(Path.Combine(la, "VortxEngine")) || Directory.Exists(Path.Combine(la, "WhirlwindFX", "SignalRgb"));
            }
        }
        // o plugin fica em Documentos\WhirlwindFX\Plugins (o SignalRGB carrega-o de lá e mostra-o em Dispositivos).
        // Vem dentro do NEXUS: não se descarrega nada da internet.
        public static string PluginPath
        {
            get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "WhirlwindFX", "Plugins", "NEXUS_Monitor.js"); }
        }
        static bool AddonCopy()
        {
            try
            {
                string addons = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "WhirlwindFX", "SignalRgb", "cache", "addons");
                if (!Directory.Exists(addons)) return false;
                foreach (string d in Directory.GetDirectories(addons))
                    if (File.Exists(Path.Combine(d, "NEXUS_Monitor.js"))) return true;
            }
            catch { }
            return false;
        }
        public static bool PluginInstalled { get { return File.Exists(PluginPath) || AddonCopy(); } }

        // copia o plugin (ou atualiza-o se mudou). Só se o SignalRGB estiver instalado.
        public static bool InstallPlugin()
        {
            diskAt = DateTime.MinValue;   // o estado na página atualiza logo
            if (!SignalInstalled) return false;
            if (AddonCopy()) return true;     // já foi instalado como add-on: não duplica
            try
            {
                string f = PluginPath;
                string txt = PLUGIN_JS.Replace("\r\n", "\n").Replace("\n", "\r\n");
                if (File.Exists(f) && File.ReadAllText(f) == txt) return true;
                Directory.CreateDirectory(Path.GetDirectoryName(f));
                File.WriteAllText(f, txt, new UTF8Encoding(false));
                return true;
            }
            catch { return false; }
        }

        const string PLUGIN_JS = @"// NEXUS Monitor - plugin para o SignalRGB
// Aparece no SignalRGB como um aparelho com 4 ""LEDs"". Em cada imagem o SignalRGB dá a cor do efeito nesses
// 4 pontos e o plugin envia-as (cerca de 30 vezes por segundo) só para este PC (127.0.0.1, porta 47821),
// onde o NEXUS as usa para as cores do tema. Não fala com a internet nem com outros aparelhos.
import udp from ""@SignalRGB/udp"";

export function Name() { return ""NEXUS Monitor""; }
export function Version() { return ""1.2.0""; }
export function Type() { return ""network""; }
export function Publisher() { return ""NEXUS Monitor""; }
export function Size() { return [4, 1]; }
export function DefaultPosition() { return [100, 60]; }
export function DefaultScale() { return 8.0; }
export function LedNames() { return [""Principal"", ""Secundária"", ""Destaque"", ""Extra""]; }
export function LedPositions() { return [[0, 0], [1, 0], [2, 0], [3, 0]]; }
export function ControllableParameters() { return []; }
/* global
controller:readonly
*/

const PORT = 47821;
let socket;
let last = 0;

export function Initialize() {
	device.setName(""NEXUS Monitor"");
	device.setControllableLeds(LedNames(), LedPositions());
	socket = udp.createSocket();
}

export function Render() {
	const now = Date.now();
	if (now - last < 33) { return; }           // ~30 vezes por segundo: acompanha o efeito sem atraso e não pesa
	last = now;
	const packet = [0x4E, 0x58, 0x01];          // ""NX"", versão 1
	const pos = LedPositions();
	for (let i = 0; i < pos.length; i++) {
		const c = device.color(pos[i][0], pos[i][1]);
		packet.push(c[0] & 0xFF, c[1] & 0xFF, c[2] & 0xFF);
	}
	try { socket.write(packet, ""127.0.0.1"", PORT); }
	catch (e) {                                  // o NEXUS esteve fechado: abre um socket novo e continua
		try { socket.close(); } catch (e2) { }
		try { socket = udp.createSocket(); } catch (e3) { }
	}
}

export function Shutdown(suspend) {
	try { socket.write([0x4E, 0x58, 0x00], ""127.0.0.1"", PORT); socket.close(); } catch (e) { }
}

export function ImageUrl() { return """"; }

// O ""aparelho"" é sempre o próprio PC: não há nada para procurar na rede, cria-se logo.
export function DiscoveryService() {
	this.IconUrl = """";
	this.created = false;

	this.Initialize = function() {
		service.log(""NEXUS Monitor: a ligar ao NEXUS neste PC"");
	};

	this.Update = function() {
		if (this.created) { return; }
		this.created = true;
		if (service.getController(""nexus-monitor-local"") === undefined) {
			const cont = new NexusLink();
			service.addController(cont);
			service.announceController(cont);
		}
	};

	this.Discovered = function(value) { };
}

class NexusLink {
	constructor() {
		this.id = ""nexus-monitor-local"";
		this.name = ""NEXUS Monitor"";
		this.ip = ""127.0.0.1"";
		this.port = PORT;
	}
	update() { }
}
";

        // a porta abre-se na primeira vez que se liga e fica aberta (só neste PC); desligar só faz ignorar as cores.
        // Fechar e voltar a abrir a porta falhava às vezes no Windows e as cores não voltavam.
        static volatile bool enabled;
        // só trabalha enquanto alguma coisa mostra as cores: uma página do NEXUS à vista, o menu do ícone aberto
        // ou teclas do NEXUS na Stream Deck. Sem nada à vista, os pacotes são ignorados logo à chegada.
        static DateTime lastWatch = DateTime.MinValue, lastAny = DateTime.MinValue, lastProc = DateTime.MinValue;
        public static void Watch() { lastWatch = DateTime.Now; }
        static bool Watched { get { return (DateTime.Now - lastWatch).TotalSeconds < 2.5; } }
        public static void SetActive(bool on)
        {
            lock (gate)
            {
                enabled = on;
                if (!on) { lastPkt = DateTime.MinValue; ov = null; iconKey = ""; }
                if (on) Open();
                if (on && iconT == null) iconT = new System.Threading.Timer(IconTick, null, 400, 400);
            }
            Program.ApplyTrayTheme();
        }
        static void Open()
        {
            if (udp != null) return;
            try
            {
                udp = new System.Net.Sockets.UdpClient(new IPEndPoint(IPAddress.Loopback, PORT));
                try { udp.Client.IOControl(-1744830452, new byte[] { 0 }, null); } catch { }   // SIO_UDP_CONNRESET: ignora erros de "porta fechada"
                th = new Thread(Loop); th.IsBackground = true; th.Name = "NEXUS rgb"; th.Start();
            }
            catch { udp = null; }
        }

        static void Loop()
        {
            System.Net.Sockets.UdpClient u = udp;
            IPEndPoint ep = new IPEndPoint(IPAddress.Any, 0);
            while (u != null && u == udp)
            {
                try
                {
                    byte[] d = u.Receive(ref ep);
                    if (!enabled) continue;
                    if (d.Length < 3 || d[0] != 0x4E || d[1] != 0x58) continue;         // "NX"
                    if (!IPAddress.IsLoopback(ep.Address)) continue;                      // só deste PC
                    if (d[2] == 0x00) { lock (gate) { lastPkt = lastAny = DateTime.MinValue; ov = null; } continue; }   // o SignalRGB fechou
                    lastAny = DateTime.Now;
                    if (!Watched) { if (ov != null) lock (gate) ov = null; continue; }  // nada à vista: não gasta nada
                    byte[][] nc = new byte[4][];
                    for (int i = 0; i < 4 && 3 + i * 3 + 2 < d.Length; i++) nc[i] = new byte[] { d[3 + i * 3], d[4 + i * 3], d[5 + i * 3] };
                    double[][] tg = Target(nc);
                    lock (gate)
                    {
                        DateTime now = DateTime.Now;
                        double dt = Math.Max(1, Math.Min(250, (now - lastProc).TotalMilliseconds));
                        // atraso escolhido nas opções: 0 = instantâneo; quanto maior, mais suave (e mais atrasado)
                        double al = AppSettings.RgbDelay <= 0 ? 1 : 1 - Math.Exp(-dt / AppSettings.RgbDelay);
                        cols = nc; lastPkt = lastProc = now; packets++;
                        if (tg == null) ov = null;
                        else if (ov == null) ov = tg;
                        else for (int i = 0; i < 2; i++) for (int k = 0; k < 3; k++) ov[i][k] += (tg[i][k] - ov[i][k]) * al;
                    }
                }
                catch
                {
                    if (u != udp) break;
                    Thread.Sleep(200);
                }
            }
        }

        static double[][] ov;          // c1 e c2 já ajustados ao tema (null = usa o tema normal)
        static System.Threading.Timer iconT;
        static string iconKey = "";

        // cor do efeito -> cor que se lê bem no tema (escuro ou claro). Pretos/apagados ficam com a cor do tema.
        static double[] Legible(byte[] c, bool light)
        {
            if (c == null || Math.Max(c[0], Math.Max(c[1], c[2])) < 18) return null;
            double r = c[0] / 255.0, g = c[1] / 255.0, b = c[2] / 255.0;
            double mx = Math.Max(r, Math.Max(g, b)), mn = Math.Min(r, Math.Min(g, b)), h = 0, sat = 0, l = (mx + mn) / 2;
            if (mx != mn)
            {
                double dd = mx - mn; sat = l > .5 ? dd / (2 - mx - mn) : dd / (mx + mn);
                h = mx == r ? (g - b) / dd + (g < b ? 6 : 0) : mx == g ? (b - r) / dd + 2 : (r - g) / dd + 4; h /= 6;
            }
            return Hsl(h, Math.Max(sat, .15), light ? Math.Min(.45, Math.Max(.28, l)) : Math.Max(.55, Math.Min(.72, l)));
        }
        static double[] Hsl(double h, double sat, double l)
        {
            double q = l < .5 ? l * (1 + sat) : l + sat - l * sat, p = 2 * l - q;
            Func<double, double> f = t => { t = (t % 1 + 1) % 1; return t < 1 / 6.0 ? p + (q - p) * 6 * t : t < .5 ? q : t < 2 / 3.0 ? p + (q - p) * (2 / 3.0 - t) * 6 : p; };
            return new[] { f(h + 1 / 3.0) * 255, f(h) * 255, f(h - 1 / 3.0) * 255 };
        }
        static double HueOf(double[] c)
        {
            double r = c[0], g = c[1], b = c[2], mx = Math.Max(r, Math.Max(g, b)), mn = Math.Min(r, Math.Min(g, b));
            if (mx == mn) return 0;
            double dd = mx - mn;
            double h = mx == r ? (g - b) / dd + (g < b ? 6 : 0) : mx == g ? (b - r) / dd + 2 : (r - g) / dd + 4;
            return h / 6;
        }
        static double[][] Target(byte[][] nc)
        {
            Color bg = AppSettings.BaseColor("bg");
            bool light = (0.299 * bg.R + 0.587 * bg.G + 0.114 * bg.B) / 255 > .5;
            double[] a = Legible(nc[0], light), b = Legible(nc[1], light);
            if (a == null && b == null) return null;                      // efeito apagado: tema normal
            if (a == null) a = b;
            // efeito de uma cor só: a secundária fica um tom ao lado para os gradientes não ficarem lisos
            if (b == null || Math.Abs(a[0] - b[0]) + Math.Abs(a[1] - b[1]) + Math.Abs(a[2] - b[2]) < 40)
                b = Hsl(HueOf(a) + 0.09, .75, light ? .38 : .64);
            return new[] { a, b };
        }
        static string HexD(double[] c)
        {
            StringBuilder sb = new StringBuilder(6);
            for (int i = 0; i < 3; i++) sb.Append(((int)Math.Round(Math.Max(0, Math.Min(255, c[i])))).ToString("x2"));
            return sb.ToString();
        }

        // "c1"/"c2" do SignalRGB (hex sem #) ou null se não estiver a receber
        public static string Override(string k)
        {
            lock (gate)
            {
                if (!enabled || ov == null || udp == null || !Watched || (DateTime.Now - lastPkt).TotalSeconds >= 3) return null;
                return HexD(k == "c1" ? ov[0] : ov[1]);
            }
        }

        // ícone da bandeja: segue a cor (no máximo 2,5 vezes por segundo)
        static void IconTick(object o)
        {
            try
            {
                if (enabled && udp == null) lock (gate) Open();          // a porta não abriu: tenta de novo
                string k = Override("c1") ?? "";
                if (k == iconKey) return;
                if (k != "" && iconKey != "")
                {
                    int a = Convert.ToInt32(k, 16), b = Convert.ToInt32(iconKey, 16);
                    if (Math.Abs((a >> 16) - (b >> 16)) + Math.Abs((a >> 8 & 255) - (b >> 8 & 255)) + Math.Abs((a & 255) - (b & 255)) < 12) return;
                }
                iconKey = k;
                Program.ApplyTrayTheme();
            }
            catch { }
        }

        static string Hex(byte[] c) { return c == null ? "null" : "\"#" + c[0].ToString("x2") + c[1].ToString("x2") + c[2].ToString("x2") + "\""; }
        public static bool Live { get { lock (gate) return enabled && udp != null && (DateTime.Now - lastPkt).TotalSeconds < 3; } }
        // a página pede isto 20 vezes por segundo com as cores ao vivo: o que está no disco (SignalRGB e plugin instalados)
        // vê-se de 10 em 10 s em vez de a cada pedido
        static bool sigCache, plugCache; static DateTime diskAt = DateTime.MinValue;
        public static string Json()
        {
            if ((DateTime.Now - diskAt).TotalSeconds > 10) { try { sigCache = SignalInstalled; plugCache = PluginInstalled; } catch { } diskAt = DateTime.Now; }
            lock (gate)
            {
                bool live = enabled && udp != null && (DateTime.Now - lastAny).TotalSeconds < 3;
                return "{\"on\":" + (AppSettings.RgbSync ? "true" : "false") + ",\"listening\":" + (enabled && udp != null ? "true" : "false") + ",\"live\":" + (live ? "true" : "false") +
                    ",\"signalrgb\":" + (sigCache ? "true" : "false") + ",\"plugin\":" + (plugCache ? "true" : "false") +
                    ",\"delay\":" + AppSettings.RgbDelay + ",\"c1\":" + (live && ov != null ? "\"#" + HexD(ov[0]) + "\"" : "null") + ",\"c2\":" + (live && ov != null ? "\"#" + HexD(ov[1]) + "\"" : "null") +
                    ",\"colors\":[" + string.Join(",", cols.Select(Hex).ToArray()) + "]}";
            }
        }
    }
}
