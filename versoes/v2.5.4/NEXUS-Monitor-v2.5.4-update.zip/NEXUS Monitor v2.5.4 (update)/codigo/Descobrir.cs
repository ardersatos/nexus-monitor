﻿// NEXUS Monitor - modo "descobrir": ensinar ao NEXUS um aparelho que ele não conhece
// 1) o NEXUS lê tudo o que o aparelho deixa ler (só LEITURA: relatórios "feature", de entrada e o que ele envia sozinho)
// 2) mudas uma coisa (ligas o cabo, mudas o DPI na app da marca...) e o NEXUS lê outra vez
// 3) mostra que bytes mudaram; escolhes o que é cada um e passa a aparecer na lista de aparelhos
// Nada é escrito no aparelho e nada sai do PC.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using Microsoft.Win32.SafeHandles;

namespace Nexus
{
    static class Descobrir
    {
        [DllImport("hid.dll")] static extern bool HidD_GetInputReport(SafeFileHandle h, byte[] b, int len);

        static readonly object lk = new object();
        static readonly Dictionary<string, Dictionary<string, byte[]>> snaps = new Dictionary<string, Dictionary<string, byte[]>>();
        static volatile bool busy;

        // identidade de uma coleção que não muda entre arranques: página, uso, tamanhos e a ordem entre iguais
        static string Sig(List<Hid.Dev> g, Hid.Dev d)
        {
            string b = d.UsagePage.ToString("x4") + "." + d.Usage.ToString("x4") + "." + d.InLen + "." + d.FeatLen;
            int n = g.Where(x => x.UsagePage == d.UsagePage && x.Usage == d.Usage && x.InLen == d.InLen && x.FeatLen == d.FeatLen).ToList().IndexOf(d);
            return b + "." + n;
        }
        static string GroupId(string parent) { return ((uint)parent.ToLowerInvariant().GetHashCode()).ToString("x8"); }
        static List<IGrouping<string, Hid.Dev>> Groups()
        {
            return Hid.Find().Where(d => d.UsagePage >= 0xFF00 || d.FeatLen > 0 || d.UsagePage == 0x0C || d.UsagePage == 0x06)
                .GroupBy(d => Hid.Parent(d.Path)).ToList();
        }
        static string Known(ushort vid, ushort pid)
        {
            if (vid == 0x1532 || vid == 0x046D) return "Razer/Logitech";
            if (HsTable.All.Any(s => s.Vid == vid && s.Pids.Contains(pid))) return "tabela";
            if (vid == 0x03F0 && pid == 0x05B7) return "HyperX";
            return Cfg23.Get("disc_" + vid.ToString("x4") + pid.ToString("x4"), "") != "" ? "ensinado" : "";
        }

        public static string List()
        {
            var b = new StringBuilder("{\"ok\":true,\"devs\":[");
            bool first = true;
            foreach (var g in Groups())
            {
                Hid.Dev d = g.First(); var l = g.ToList();
                string name = l.Select(x => x.Product).FirstOrDefault(x => !string.IsNullOrEmpty(x)) ?? "";
                if (!first) b.Append(','); first = false;
                b.Append("{\"id\":").Append(Js.S(GroupId(g.Key))).Append(",\"name\":").Append(Js.S(name == "" ? "?" : name))
                 .Append(",\"vid\":").Append(Js.S(d.Vid.ToString("X4"))).Append(",\"pid\":").Append(Js.S(d.Pid.ToString("X4")))
                 .Append(",\"cols\":").Append(l.Count).Append(",\"known\":").Append(Js.S(Known(d.Vid, d.Pid))).Append('}');
            }
            return b.Append("]}").ToString();
        }

        // lê tudo o que dá para ler deste aparelho
        static Dictionary<string, byte[]> Read(List<Hid.Dev> g, int listenMs) { return Read(g, listenMs, null, null); }
        static Dictionary<string, byte[]> Read(List<Hid.Dev> g, int listenMs, HashSet<string> only) { return Read(g, listenMs, only, null); }
        // only: lê só estas chaves (as receitas guardadas); null = tudo (modo descobrir)
        // all: guarda TODAS as leituras de cada chave (para ver o que muda sozinho, ex.: contadores)
        static Dictionary<string, byte[]> Read(List<Hid.Dev> g, int listenMs, HashSet<string> only, Dictionary<string, List<byte[]>> all)
        {
            Action<string, byte[]> keep = (k, a) => { if (all == null) return; lock (all) { List<byte[]> l; if (!all.TryGetValue(k, out l)) all[k] = l = new List<byte[]>(); if (l.Count < 12) l.Add(a); } };
            var r = new Dictionary<string, byte[]>();
            var threads = new List<Thread>();
            foreach (Hid.Dev d in g)
            {
                string sig = Sig(g, d);
                if (only != null && !only.Any(k => k.StartsWith(sig + "|"))) continue;   // nada a ler nesta coleção
                SafeFileHandle h = HidIo.Open(d.Path);
                if (h.IsInvalid) { h.Dispose(); h = Hid.CreateFile(d.Path, 0, 3, IntPtr.Zero, 3, 0x40000000, IntPtr.Zero); }
                if (h.IsInvalid) { h.Dispose(); continue; }
                // relatórios "feature" e de entrada pedidos diretamente (números 0 a 63)
                if (d.FeatLen > 1)
                    for (int id = 0; id < 64; id++)
                    {
                        if (only != null && !only.Contains(sig + "|F|" + id)) continue;
                        byte[] a = new byte[d.FeatLen]; a[0] = (byte)id;
                        if (Hid.HidD_GetFeature(h, a, a.Length)) { lock (r) r[sig + "|F|" + id] = a; keep(sig + "|F|" + id, a); }
                    }
                if (d.InLen > 1)
                    for (int id = 0; id < 16; id++)
                    {
                        if (only != null && !only.Contains(sig + "|I|" + id)) continue;
                        byte[] a = new byte[d.InLen]; a[0] = (byte)id;
                        if (HidD_GetInputReport(h, a, a.Length)) { lock (r) r[sig + "|I|" + id] = a; keep(sig + "|I|" + id, a); }
                    }
                // e o que o aparelho envia sozinho (só nas coleções do fabricante; teclados e ratos normais o Windows não deixa)
                if (d.InLen > 1 && listenMs > 0 && h != null && (only == null || only.Any(k => k.StartsWith(sig + "|L|"))))
                {
                    SafeFileHandle hh = h; Hid.Dev dd = d;
                    Thread t = new Thread(() =>
                    {
                        DateTime end = DateTime.UtcNow.AddMilliseconds(listenMs);
                        while (DateTime.UtcNow < end)
                        {
                            byte[] a = HidIo.Read(hh, dd.InLen, (int)Math.Max(1, (end - DateTime.UtcNow).TotalMilliseconds));
                            if (a == null) break;
                            lock (r) r[sig + "|L|" + a[0]] = a;
                            keep(sig + "|L|" + a[0], a);
                        }
                        hh.Dispose();
                    }) { IsBackground = true };
                    threads.Add(t); t.Start();
                }
                else h.Dispose();
            }
            foreach (Thread t in threads) t.Join(listenMs + 1500);
            return r;
        }

        public static string Snap(string id, string tag)
        {
            if (busy) return Ps23.Ok(false, Lang.L("Já está a ler. Espera um segundo."));
            var g = Groups().FirstOrDefault(x => GroupId(x.Key) == id);
            if (g == null) return Ps23.Ok(false, Lang.L("Aparelho não encontrado. Está ligado?"));
            busy = true;
            try
            {
                // 3 leituras seguidas (a 1.ª também ouve o que o aparelho manda sozinho): o que muda entre elas é ruído
                // (contadores, relógios) e não serve para nada; o que fica igual é que pode ser bateria, DPI...
                var all = new Dictionary<string, List<byte[]>>();
                List<Hid.Dev> l = g.ToList();
                var r = Read(l, 2000, null, all);
                for (int i = 0; i < 2; i++) { Thread.Sleep(150); foreach (var kv in Read(l, 0, null, all)) if (!r.ContainsKey(kv.Key)) r[kv.Key] = kv.Value; }
                string t = tag == "B" ? "B" : "A";
                lock (lk) { snaps[id + "|" + t] = r; samples[id + "|" + t] = all; if (t == "A") samples.Remove(id + "|B"); }
                return "{\"ok\":true,\"n\":" + r.Count + "}";
            }
            finally { busy = false; }
        }

        // ------------------------------------------------------------ perceber sozinho o que é cada leitura
        static readonly Dictionary<string, Dictionary<string, List<byte[]>>> samples = new Dictionary<string, Dictionary<string, List<byte[]>>>();
        // bateria de iões de lítio: tensão (mV) -> % aproximada
        static readonly int[][] LIION = { new[] { 3300, 0 }, new[] { 3500, 5 }, new[] { 3600, 10 }, new[] { 3700, 30 }, new[] { 3750, 45 }, new[] { 3800, 55 }, new[] { 3850, 65 }, new[] { 3900, 75 }, new[] { 4000, 85 }, new[] { 4100, 95 }, new[] { 4200, 100 } };
        public static int MvToPct(int mv)
        {
            if (mv <= LIION[0][0]) return 0;
            for (int i = 1; i < LIION.Length; i++)
                if (mv <= LIION[i][0]) return LIION[i - 1][1] + (mv - LIION[i - 1][0]) * (LIION[i][1] - LIION[i - 1][1]) / (LIION[i][0] - LIION[i - 1][0]);
            return 100;
        }
        class Cand { public string K, What, Fmt, Name, Now, Why; public int O, Cv = -1, Score; }
        static int U16(byte[] a, int o, bool le) { return le ? a[o] | (a[o + 1] << 8) : (a[o] << 8) | a[o + 1]; }
        // valor de um byte/palavra em todas as leituras de uma chave; null = mudou sozinho entre leituras (ruído)
        static int? Stable(List<byte[]> l, int o, int size, bool le)
        {
            int? v = null;
            foreach (byte[] a in l)
            {
                if (a.Length < o + size) return null;
                int x = size == 1 ? a[o] : U16(a, o, le);
                if (v == null) v = x; else if (v.Value != x) return null;
            }
            return v;
        }

        // goal: bat (bateria) | chg (a carregar) | dpi | any (o que mudou)   hint: a % que a app da marca mostra (opcional)
        public static string Analyze(string id, string goal, string hintS)
        {
            Dictionary<string, List<byte[]>> A, B;
            lock (lk) { samples.TryGetValue(id + "|A", out A); samples.TryGetValue(id + "|B", out B); }
            if (A == null) return Ps23.Ok(false, Lang.L("Faz primeiro a leitura."));
            if ((goal == "chg" || goal == "dpi" || goal == "any") && B == null) return Ps23.Ok(false, Lang.L("Faz primeiro as duas leituras."));
            int hint; bool hasHint = int.TryParse(hintS, out hint) && hint >= 0 && hint <= 100;
            var c = new List<Cand>(); int noisy = 0, bytes = 0;
            foreach (var kv in A)
            {
                List<byte[]> la = kv.Value, lb = null;
                if (B != null) B.TryGetValue(kv.Key, out lb);
                bool vendor = kv.Key.StartsWith("ff");   // coleção do fabricante: é lá que costumam estar a bateria e afins
                int len = la.Min(x => x.Length);
                for (int o = 1; o < len; o++)
                {
                    bytes++;
                    int? a1 = Stable(la, o, 1, true), b1 = lb != null ? Stable(lb, o, 1, true) : null;
                    if (a1 == null) { noisy++; continue; }
                    int a = a1.Value;
                    bool changed = b1 != null && b1.Value != a;
                    // --- bateria
                    if (goal == "bat" || goal == "any")
                    {
                        Action<string, int, int, string> bat = (fmt, pct, baseScore, why) =>
                        {
                            int s = baseScore + (vendor ? 2 : 0);
                            if (hasHint) { int d = Math.Abs(pct - hint); if (d <= 1) s += 10; else if (d <= 3) s += 6; else if (d <= 6) s += 1; else return; }
                            if (b1 != null) { int d2 = Math.Abs(b1.Value - a); if (changed && d2 <= 6) s += 3; else if (changed) s -= 4; }
                            if (pct == 0 || pct == 100) s -= 2;   // 0 e 100 aparecem em muitos sítios por acaso
                            c.Add(new Cand { K = kv.Key, O = o, What = "bat", Fmt = fmt, Now = pct + " %", Score = s, Why = why });
                        };
                        if (a >= 1 && a <= 100) bat("pct", a, 3, Lang.L("está entre 0 e 100 e não muda sozinho"));
                        if (a > 100 && a <= 255) bat("255", (int)Math.Round(a * 100 / 255.0), 1, Lang.L("parece uma escala de 0 a 255"));
                        if (o + 1 < len)
                            foreach (bool le in new[] { true, false })
                            {
                                int? mv = Stable(la, o, 2, le);
                                if (mv != null && mv.Value >= 3300 && mv.Value <= 4400)
                                    bat(le ? "mvle" : "mvbe", MvToPct(mv.Value), 5, string.Format(Lang.L("parece a tensão da bateria ({0} mV)"), mv.Value));
                            }
                    }
                    // --- a carregar: mudou quando ligaste o cabo, e é um sinal simples (0/1, um bit, um estado pequeno)
                    if ((goal == "chg" || goal == "any") && changed)
                    {
                        int b = b1.Value, x = a ^ b, bits = 0; for (int q = x; q != 0; q >>= 1) bits += q & 1;
                        int s = (a <= 4 && b <= 4 ? 5 : 0) + (bits == 1 ? 4 : 0) + ((a == 0 && b == 1) || (a == 1 && b == 0) ? 3 : 0) + (vendor ? 1 : 0);
                        if (s > 0) c.Add(new Cand { K = kv.Key, O = o, What = "chg", Fmt = "raw", Cv = b, Score = s, Now = a + " → " + b,
                            Why = bits == 1 ? Lang.L("mudou só um bit quando ligaste o cabo") : Lang.L("mudou para um estado simples quando ligaste o cabo") });
                    }
                    // --- DPI: número de 2 bytes entre 100 e 30000, redondo, que mudou quando mudaste o DPI (X e Y costumam vir lado a lado)
                    if ((goal == "dpi" || goal == "any") && o + 1 < len && lb != null)
                        foreach (bool le in new[] { true, false })
                        {
                            int? da = Stable(la, o, 2, le), db = Stable(lb, o, 2, le);
                            if (da == null || db == null || da.Value == db.Value) continue;
                            int va = da.Value, vb = db.Value;
                            if (va < 100 || vb < 100 || va > 30000 || vb > 30000 || va % 50 != 0 || vb % 50 != 0) continue;
                            int s = 6 + (va % 100 == 0 && vb % 100 == 0 ? 1 : 0);
                            if (o + 3 < len && Stable(la, o + 2, 2, le) == da && Stable(lb, o + 2, 2, le) == db) s += 3;   // X = Y
                            c.Add(new Cand { K = kv.Key, O = o, What = "val", Fmt = le ? "le" : "be", Name = "DPI", Score = s, Now = va + " → " + vb,
                                Why = Lang.L("número redondo entre 100 e 30000 que mudou com o DPI") });
                        }
                    // --- outra coisa que mudou
                    if (goal == "any" && changed)
                        c.Add(new Cand { K = kv.Key, O = o, What = "val", Fmt = "raw", Score = 1, Now = a + " → " + b1.Value, Why = Lang.L("mudou entre as duas leituras") });
                }
            }
            // a mesma posição só aparece uma vez (a melhor explicação) e no máximo 8 sugestões
            var best = c.OrderByDescending(x => x.Score).GroupBy(x => x.K + "|" + x.O).Select(x => x.First()).Take(goal == "any" ? 20 : 8).ToList();
            int top = best.Count > 0 ? best[0].Score : 0, second = best.Count > 1 ? best[1].Score : -99;
            var sb = new StringBuilder("{\"ok\":true,\"reads\":" + A.Values.Sum(x => x.Count) + ",\"bytes\":" + bytes + ",\"noisy\":" + noisy + ",\"sure\":" +
                (top >= 10 && top - second >= 4 ? "true" : "false") + ",\"cands\":[");
            for (int i = 0; i < best.Count; i++)
            {
                Cand x = best[i];
                string conf = x.Score >= 10 ? "alta" : x.Score >= 6 ? "media" : "baixa";
                if (i > 0) sb.Append(',');
                sb.Append("{\"k\":").Append(Js.S(x.K)).Append(",\"o\":").Append(x.O).Append(",\"what\":").Append(Js.S(x.What)).Append(",\"fmt\":").Append(Js.S(x.Fmt))
                  .Append(",\"cv\":").Append(x.Cv).Append(",\"name\":").Append(Js.S(x.Name ?? "")).Append(",\"now\":").Append(Js.S(x.Now))
                  .Append(",\"why\":").Append(Js.S(x.Why)).Append(",\"conf\":").Append(Js.S(conf)).Append(",\"score\":").Append(x.Score).Append('}');
            }
            return sb.Append("]}").ToString();
        }

        // o que mudou entre a 1.ª e a 2.ª leitura
        public static string Diff(string id)
        {
            Dictionary<string, byte[]> a, b;
            lock (lk) { snaps.TryGetValue(id + "|A", out a); snaps.TryGetValue(id + "|B", out b); }
            if (a == null || b == null) return Ps23.Ok(false, Lang.L("Faz primeiro as duas leituras."));
            var rows = new List<string>();
            foreach (var kv in a)
            {
                byte[] y; if (!b.TryGetValue(kv.Key, out y)) continue;
                byte[] x = kv.Value; int n = Math.Min(x.Length, y.Length);
                for (int i = 1; i < n && rows.Count < 80; i++)
                {
                    if (x[i] == y[i]) continue;
                    int le0 = i + 1 < n ? x[i] | (x[i + 1] << 8) : -1, le1 = i + 1 < n ? y[i] | (y[i + 1] << 8) : -1;
                    int be0 = i + 1 < n ? (x[i] << 8) | x[i + 1] : -1, be1 = i + 1 < n ? (y[i] << 8) | y[i + 1] : -1;
                    rows.Add("{\"k\":" + Js.S(kv.Key) + ",\"o\":" + i + ",\"a\":" + x[i] + ",\"b\":" + y[i] + ",\"le\":[" + le0 + "," + le1 + "],\"be\":[" + be0 + "," + be1 + "]}");
                }
            }
            int same = a.Keys.Count(k => b.ContainsKey(k));
            return "{\"ok\":true,\"reads\":" + same + ",\"rows\":[" + string.Join(",", rows.ToArray()) + "]}";
        }

        // receita: "chave|byte|o que é|formato|valor quando carrega|nome" (uma por linha, separadas por ;)
        // o que é: bat | chg | val    formato: pct (já é %) | 255 (0-255) | le | be (2 bytes) | raw
        public static string Save(string id, string key, string off, string what, string fmt, string chgVal, string name, string kind)
        {
            var g = Groups().FirstOrDefault(x => GroupId(x.Key) == id);
            if (g == null) return Ps23.Ok(false, Lang.L("Aparelho não encontrado. Está ligado?"));
            int o; if (!int.TryParse(off, out o) || o < 1 || o > 1024 || string.IsNullOrEmpty(key) || key.Length > 80) return Ps23.Ok(false, "?");
            if (what != "bat" && what != "chg" && what != "val") return Ps23.Ok(false, "?");
            if (fmt != "pct" && fmt != "255" && fmt != "le" && fmt != "be" && fmt != "raw" && fmt != "mvle" && fmt != "mvbe") fmt = "raw";
            Hid.Dev d = g.First();
            string ck = "disc_" + d.Vid.ToString("x4") + d.Pid.ToString("x4");
            var lines = Cfg23.Get(ck, "").Split(';').Where(x => x != "" && !x.StartsWith("kind=")).ToList();
            lines.RemoveAll(x => { var p = x.Split('|'); return p.Length > 6 && (what != "val" ? p[3] == what : p[6] == Clean(name)); });
            int cv; int.TryParse(chgVal, out cv);
            // a chave tem "|" lá dentro (coleção|F|n): guarda-se com "/" para não baralhar os campos da receita
            lines.Add(Clean(key.Replace("|", "/")) + "|" + o + "|" + "x" + "|" + what + "|" + fmt + "|" + cv + "|" + Clean(name));
            lines.Insert(0, "kind=" + (kind == "mouse" || kind == "keyboard" || kind == "headset" ? kind : "other"));
            Cfg23.Set(ck, string.Join(";", lines.ToArray()));
            ThreadPool.QueueUserWorkItem(delegate { try { Aparelhos.Scan(); } catch { } });
            return Ps23.Ok(true, null);
        }
        public static string Del(string vidpid)
        {
            if (string.IsNullOrEmpty(vidpid) || vidpid.Length != 8) return Ps23.Ok(false, "?");
            Cfg23.Set("disc_" + vidpid.ToLowerInvariant(), null);
            ThreadPool.QueueUserWorkItem(delegate { try { Aparelhos.Scan(); } catch { } });
            return Ps23.Ok(true, null);
        }
        static string Clean(string s) { return (s ?? "").Replace("|", "").Replace(";", "").Trim(); }

        // aparelhos ensinados que estão ligados agora
        public static List<Aparelho> Devices()
        {
            var r = new List<Aparelho>();
            var all = Cfg23.Prefix("disc_").ToDictionary(kv => kv.Key, kv => kv.Value);
            if (all.Count == 0) return r;
            foreach (var g in Groups())
            {
                Hid.Dev d = g.First();
                string v; if (!all.TryGetValue(d.Vid.ToString("x4") + d.Pid.ToString("x4"), out v) || string.IsNullOrEmpty(v)) continue;
                DiscDev x = new DiscDev(g.ToList(), v, GroupId(g.Key));
                try { x.Refresh(); } catch { }
                r.Add(x);
            }
            return r;
        }

        class DiscDev : Aparelho
        {
            readonly List<Hid.Dev> g; readonly List<string[]> rec = new List<string[]>();
            public readonly List<KeyValuePair<string, string>> Values = new List<KeyValuePair<string, string>>();
            public DiscDev(List<Hid.Dev> grp, string cfg, string gid)
            {
                g = grp; Hid.Dev d = g[0]; Vid = d.Vid; Pid = d.Pid; Brand = "";
                Name = g.Select(x => x.Product).FirstOrDefault(x => !string.IsNullOrEmpty(x)) ?? ("USB " + d.Vid.ToString("X4") + ":" + d.Pid.ToString("X4"));
                Id = "disc:" + d.Vid.ToString("x4") + d.Pid.ToString("x4") + ":" + gid;
                foreach (string l in cfg.Split(';'))
                {
                    if (l.StartsWith("kind=")) { Kind = l.Substring(5); continue; }
                    string[] p = l.Split('|'); if (p.Length < 7) continue;
                    p[0] = KeyOf(p[0]); int o; if (p[0] == null || !int.TryParse(p[1], out o)) continue;
                    rec.Add(p);
                }
                Taught = true;
            }
            public override void Refresh()
            {
                Err = "";
                // lê só as chaves de que as receitas precisam
                var need = new HashSet<string>(rec.Select(p => p[0]));
                var data = Read(g, rec.Any(p => p[0].Contains("|L|")) ? 1200 : 0, need);
                Values.Clear(); int bat = -1; int chg = -1;
                foreach (string[] p in rec)
                {
                    byte[] a; int o; int.TryParse(p[1], out o);
                    if (!data.TryGetValue(p[0], out a) || a.Length <= o) continue;
                    int raw = a[o];
                    if ((p[4] == "le" || p[4] == "be" || p[4] == "mvle" || p[4] == "mvbe") && a.Length > o + 1) raw = p[4] == "le" || p[4] == "mvle" ? a[o] | (a[o + 1] << 8) : (a[o] << 8) | a[o + 1];
                    int val = p[4] == "255" ? (int)Math.Round(raw * 100.0 / 255) : p[4] == "mvle" || p[4] == "mvbe" ? MvToPct(raw) : raw;
                    if (p[3] == "bat") bat = Math.Min(100, val);
                    else if (p[3] == "chg") { int cv; int.TryParse(p[5], out cv); chg = raw == cv ? 1 : 0; }
                    else Values.Add(new KeyValuePair<string, string>(p[6] == "" ? "?" : p[6], val.ToString(CultureInfo.InvariantCulture)));
                }
                Battery = bat; Charging = chg == 1; ChargeUnknown = chg < 0;
                Extra = Values.ToList();
            }
            public override bool SetDpi(int dpi) { return false; }
            // "ff00.0001.64.0.0/F/5" -> "ff00.0001.64.0.0|F|5". As receitas antigas perderam os "|" ("...0.0F5"): recupera-as também
            static string KeyOf(string s)
            {
                if (s.Contains("/")) return s.Replace("/", "|");
                var m = System.Text.RegularExpressions.Regex.Match(s, @"^(.+\.\d+)([FIL])(\d+)$");
                return m.Success ? m.Groups[1].Value + "|" + m.Groups[2].Value + "|" + m.Groups[3].Value : null;
            }
        }
    }
}
