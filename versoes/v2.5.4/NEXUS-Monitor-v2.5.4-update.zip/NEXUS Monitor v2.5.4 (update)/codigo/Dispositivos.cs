﻿// NEXUS // MONITOR - ratos e teclados Razer e Logitech: DPI, taxa de envio, níveis de DPI, bateria e outras funções,
// falando diretamente com o aparelho (sem o Synapse nem o G HUB). Tudo opcional e só dentro do PC.
// Cada função só aparece se o aparelho responder a ela (o NEXUS pergunta ao aparelho o que ele sabe fazer).
//  - Razer: relatórios "feature" de 90 bytes (protocolo documentado pelo projeto OpenRazer).
//  - Logitech: HID++ 2.0 (protocolo documentado pela Logitech e pelo projeto Solaar), com fio, Bluetooth ou recetor.
using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using Microsoft.Win32.SafeHandles;

namespace Nexus
{
    // ================================================================ acesso HID do Windows
    static class Hid
    {
        [StructLayout(LayoutKind.Sequential)] public struct ATTR { public int Size; public ushort Vid, Pid, Ver; }
        [StructLayout(LayoutKind.Sequential)] public struct CAPS
        {
            public ushort Usage, UsagePage, InLen, OutLen, FeatLen;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 17)] public ushort[] Reserved;
            public ushort a, b, c, d, e, f, g, h, i, j;
        }
        [StructLayout(LayoutKind.Sequential)] struct IFDATA { public int cbSize; public Guid cls; public int flags; public IntPtr reserved; }

        [DllImport("hid.dll")] static extern void HidD_GetHidGuid(out Guid g);
        [DllImport("hid.dll")] static extern bool HidD_GetAttributes(SafeFileHandle h, ref ATTR a);
        [DllImport("hid.dll")] static extern bool HidD_GetPreparsedData(SafeFileHandle h, out IntPtr p);
        [DllImport("hid.dll")] static extern bool HidD_FreePreparsedData(IntPtr p);
        [DllImport("hid.dll")] static extern int HidP_GetCaps(IntPtr p, out CAPS c);
        [DllImport("hid.dll")] public static extern bool HidD_SetFeature(SafeFileHandle h, byte[] b, int len);
        [DllImport("hid.dll")] public static extern bool HidD_GetFeature(SafeFileHandle h, byte[] b, int len);
        [DllImport("hid.dll")] static extern bool HidD_GetProductString(SafeFileHandle h, byte[] b, int len);
        [DllImport("hid.dll")] static extern bool HidD_GetSerialNumberString(SafeFileHandle h, byte[] b, int len);
        [DllImport("setupapi.dll", SetLastError = true)] static extern IntPtr SetupDiGetClassDevs(ref Guid g, IntPtr e, IntPtr w, int flags);
        [DllImport("setupapi.dll", SetLastError = true)] static extern bool SetupDiEnumDeviceInterfaces(IntPtr set, IntPtr info, ref Guid g, int idx, ref IFDATA d);
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)] static extern bool SetupDiGetDeviceInterfaceDetail(IntPtr set, ref IFDATA d, IntPtr detail, int size, out int need, IntPtr info);
        [DllImport("setupapi.dll")] static extern bool SetupDiDestroyDeviceInfoList(IntPtr set);
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)] public static extern SafeFileHandle CreateFile(string n, uint acc, uint share, IntPtr sec, uint disp, uint flags, IntPtr tpl);

        public class Dev { public string Path, Product = "", Serial = ""; public ushort Vid, Pid, UsagePage, Usage, InLen, OutLen, FeatLen; }

        public static List<Dev> Find(params ushort[] vids)
        {
            List<Dev> r = new List<Dev>();
            Guid g; HidD_GetHidGuid(out g);
            IntPtr set = SetupDiGetClassDevs(ref g, IntPtr.Zero, IntPtr.Zero, 0x12);   // presentes + interfaces
            if (set == IntPtr.Zero || set == new IntPtr(-1)) return r;
            try
            {
                for (int i = 0; i < 512; i++)
                {
                    IFDATA d = new IFDATA(); d.cbSize = Marshal.SizeOf(typeof(IFDATA));
                    if (!SetupDiEnumDeviceInterfaces(set, IntPtr.Zero, ref g, i, ref d)) break;
                    int need; SetupDiGetDeviceInterfaceDetail(set, ref d, IntPtr.Zero, 0, out need, IntPtr.Zero);
                    if (need <= 0) continue;
                    IntPtr buf = Marshal.AllocHGlobal(need);
                    try
                    {
                        Marshal.WriteInt32(buf, IntPtr.Size == 8 ? 8 : 6);
                        if (!SetupDiGetDeviceInterfaceDetail(set, ref d, buf, need, out need, IntPtr.Zero)) continue;
                        string path = Marshal.PtrToStringUni(new IntPtr(buf.ToInt64() + 4));
                        Dev dv = Probe(path, vids);
                        if (dv != null) r.Add(dv);
                    }
                    finally { Marshal.FreeHGlobal(buf); }
                }
            }
            finally { SetupDiDestroyDeviceInfoList(set); }
            return r;
        }

        static Dev Probe(string path, ushort[] vids)
        {
            using (SafeFileHandle h = CreateFile(path, 0, 3, IntPtr.Zero, 3, 0, IntPtr.Zero))   // sem leitura/escrita: chega para ler os dados
            {
                if (h.IsInvalid) return null;
                ATTR a = new ATTR(); a.Size = Marshal.SizeOf(typeof(ATTR));
                if (!HidD_GetAttributes(h, ref a) || (vids.Length > 0 && !vids.Contains(a.Vid))) return null;
                Dev d = new Dev { Path = path, Vid = a.Vid, Pid = a.Pid };
                IntPtr pp;
                if (HidD_GetPreparsedData(h, out pp))
                {
                    try { CAPS c; if (HidP_GetCaps(pp, out c) == 0x110000) { d.UsagePage = c.UsagePage; d.Usage = c.Usage; d.InLen = c.InLen; d.OutLen = c.OutLen; d.FeatLen = c.FeatLen; } }
                    finally { HidD_FreePreparsedData(pp); }
                }
                byte[] s = new byte[256];
                if (HidD_GetProductString(h, s, s.Length)) d.Product = Encoding.Unicode.GetString(s).TrimEnd('\0').Trim();
                s = new byte[256];
                if (HidD_GetSerialNumberString(h, s, s.Length)) d.Serial = Encoding.Unicode.GetString(s).TrimEnd('\0').Trim();
                return d;
            }
        }

        // a parte do caminho que identifica o aparelho físico (as várias "coleções" do mesmo aparelho partilham-na)
        public static string Parent(string path)
        {
            string p = path.ToLowerInvariant();
            int i = p.IndexOf("&col"); if (i > 0) { int j = p.IndexOf('#', i); p = p.Substring(0, i) + (j > 0 ? p.Substring(j) : ""); }
            i = p.IndexOf("&mi_"); if (i > 0) p = p.Substring(0, i);
            return p;
        }
    }

    // ================================================================ o que é comum aos aparelhos
    abstract class Aparelho
    {
        public string Id = "", Name = "", Brand = "", Kind = "mouse";   // mouse | keyboard | other
        public ushort Vid, Pid;
        public bool Wireless;
        // o que o aparelho sabe fazer (só aparece na página o que estiver aqui)
        public int Dpi = -1, DpiMin = 100, DpiMax = 0, DpiStep = 50;
        public List<int> DpiList = new List<int>();          // Logitech: lista fixa de valores (se o rato a tiver)
        public List<int> Stages = new List<int>(); public int Stage = -1;   // níveis de DPI guardados no rato
        public int Rate = -1; public List<int> Rates = new List<int>();     // Hz
        public int Battery = -1; public bool Charging, ChargeUnknown;
        public int KbGame = -1;   // modo jogo do próprio teclado: -1 não tem, 0 desligado, 1 ligado
        public int Idle = -1;                                 // segundos até adormecer (sem fios)
        public int Smart = -1, SmartAuto = -1, HiRes = -1, FnSwap = -1, Onboard = -1, Sidetone = -1;
        public string Err = "";
        public bool Taught;
        public bool Sleeping;
        public bool IdleSettable, IdleRO;   // IdleRO: só se consegue ler (muda-se na app da marca)                             // dá para mudar o tempo para adormecer/desligar mesmo sem o conseguir ler                                 // sem fios: o recetor está ligado mas o aparelho está a dormir ou desligado                                   // ensinado pelo utilizador (modo descobrir)
        public List<KeyValuePair<string, string>> Extra = new List<KeyValuePair<string, string>>();   // outros valores lidos (só leitura)
        public abstract void Refresh();
        public abstract bool SetDpi(int dpi);
        public virtual bool SetRate(int hz) { return false; }
        public virtual bool SetStages(List<int> st, int active) { return false; }
        public virtual bool SetIdle(int s) { return false; }
        public virtual bool SetSmart(int mode, int auto) { return false; }
        public virtual bool SetHiRes(bool on) { return false; }
        public virtual bool SetFnSwap(bool on) { return false; }
        public virtual bool SetSidetone(int v) { return false; }
        public virtual bool SetKbGame(bool on) { return false; }
        public virtual void Close() { }
        public Aparelho Copy() { Aparelho c = (Aparelho)MemberwiseClone(); c.Stages = Stages.ToList(); c.Rates = Rates.ToList(); c.DpiList = DpiList.ToList(); c.Extra = Extra.ToList(); return c; }
        // o que esta leitura não conseguiu ler fica com o valor anterior
        public void KeepFrom(Aparelho o)
        {
            if (o == null) return;
            if (Battery < 0 && o.Battery >= 0) { Battery = o.Battery; Charging = o.Charging; ChargeUnknown = o.ChargeUnknown; }
            if (Dpi <= 0 && o.Dpi > 0) { Dpi = o.Dpi; if (DpiMax <= 0) { DpiMin = o.DpiMin; DpiMax = o.DpiMax; DpiStep = o.DpiStep; } }
            if (Stages.Count == 0 && o.Stages.Count > 0) { Stages = o.Stages.ToList(); Stage = o.Stage; }
            if (Rate <= 0 && o.Rate > 0) { Rate = o.Rate; Rates = o.Rates.ToList(); }
            if (Idle <= 0 && o.Idle > 0) { Idle = o.Idle; IdleRO = o.IdleRO; }
            if (KbGame < 0 && o.KbGame >= 0) KbGame = o.KbGame;
            if (Sidetone < 0 && o.Sidetone >= 0) Sidetone = o.Sidetone;
            if (Err != "" && o.Err == "" && (Dpi > 0 || Rate > 0 || Battery >= 0)) Err = "";   // uma falha isolada não mostra aviso
        }

        public string Json()
        {
            StringBuilder b = new StringBuilder("{");
            b.Append("\"id\":").Append(Js.S(Id)).Append(",\"name\":").Append(Js.S(Name)).Append(",\"brand\":").Append(Js.S(Brand)).Append(",\"kind\":").Append(Js.S(Kind))
             .Append(",\"wireless\":").Append(Wireless ? "true" : "false");
            if (Dpi > 0) b.Append(",\"dpi\":").Append(Dpi).Append(",\"dpiMin\":").Append(DpiMin).Append(",\"dpiMax\":").Append(DpiMax).Append(",\"dpiStep\":").Append(DpiStep);
            if (DpiList.Count > 0) b.Append(",\"dpiList\":[").Append(string.Join(",", DpiList.Select(x => x.ToString()).ToArray())).Append(']');
            if (Stages.Count > 0) b.Append(",\"stages\":[").Append(string.Join(",", Stages.Select(x => x.ToString()).ToArray())).Append("],\"stage\":").Append(Stage);
            if (Rate > 0) b.Append(",\"rate\":").Append(Rate).Append(",\"rates\":[").Append(string.Join(",", Rates.Select(x => x.ToString()).ToArray())).Append(']');
            if (Battery >= 0) b.Append(",\"battery\":").Append(Battery).Append(",\"charging\":").Append(Charging ? "true" : "false").Append(ChargeUnknown ? ",\"chgUnknown\":true" : "");
            if (Idle > 0) b.Append(",\"idle\":").Append(Idle);
            if (Smart > 0) b.Append(",\"smart\":").Append(Smart).Append(",\"smartAuto\":").Append(SmartAuto);
            if (HiRes >= 0) b.Append(",\"hires\":").Append(HiRes == 1 ? "true" : "false");
            if (FnSwap >= 0) b.Append(",\"fnswap\":").Append(FnSwap == 1 ? "true" : "false");
            if (Onboard > 0) b.Append(",\"onboard\":").Append(Onboard == 1 ? "true" : "false");
            if (Sidetone >= 0) b.Append(",\"sidetone\":").Append(Sidetone);
            if (KbGame >= 0) b.Append(",\"kbgame\":").Append(KbGame == 1 ? "true" : "false");
            if (Sleeping) b.Append(",\"sleeping\":true");
            if (IdleSettable) b.Append(",\"idleSet\":true");
            if (IdleRO) b.Append(",\"idleRO\":true");
            if (Taught) b.Append(",\"taught\":true,\"vidpid\":").Append(Js.S(Vid.ToString("x4") + Pid.ToString("x4")));
            if (Extra.Count > 0) b.Append(",\"extra\":[").Append(string.Join(",", Extra.Select(kv => "[" + Js.S(kv.Key) + "," + Js.S(kv.Value) + "]").ToArray())).Append(']');
            if (Err != "") b.Append(",\"err\":").Append(Js.S(Err));
            return b.Append('}').ToString();
        }
    }

    // ================================================================ Razer
    class RazerDev : Aparelho
    {
        readonly string path; byte tid = 0x1F; bool tidOk;
        static readonly object io = new object();
        public RazerDev(Hid.Dev d)
        {
            path = d.Path; Vid = d.Vid; Pid = d.Pid; Brand = "Razer";
            Name = d.Product != "" ? d.Product : "Razer " + d.Pid.ToString("X4");
            if (!Name.StartsWith("Razer", StringComparison.OrdinalIgnoreCase)) Name = "Razer " + Name;
            string n = Name.ToLowerInvariant();
            if (Name.EndsWith(" Dongle", StringComparison.OrdinalIgnoreCase)) Name = Name.Substring(0, Name.Length - 7);   // "Razer Viper Ultimate Dongle" -> "Razer Viper Ultimate"
            Kind = n.Contains("keyboard") || n.Contains("blackwidow") || n.Contains("huntsman") || n.Contains("ornata") || n.Contains("cynosa") || n.Contains("deathstalker") ? "keyboard" : n.Contains("headset") || n.Contains("kraken") || n.Contains("barracuda") || n.Contains("blackshark") || n.Contains("nari") ? "headset" : "mouse";
            Wireless = n.Contains("wireless") || n.Contains("hyperspeed") || n.Contains("dongle") || n.Contains("pro click") || n.Contains("viper ultimate") || n.Contains("v2 pro") || n.Contains("v3 pro");
            Id = "rz:" + Pid.ToString("x4") + ":" + Hid.Parent(path).GetHashCode().ToString("x8");
        }

        // um pedido e a resposta (null se o aparelho não respondeu bem)
        byte[] Cmd(byte cls, byte id, byte size, params byte[] args)
        {
            lock (io)
                using (SafeFileHandle h = Hid.CreateFile(path, 0xC0000000, 3, IntPtr.Zero, 3, 0, IntPtr.Zero))
                {
                    SafeFileHandle hh = h;
                    if (h.IsInvalid) { hh = Hid.CreateFile(path, 0, 3, IntPtr.Zero, 3, 0, IntPtr.Zero); if (hh.IsInvalid) return null; }
                    try
                    {
                        byte[] tries = tidOk ? new[] { tid } : new byte[] { 0x1F, 0x3F, 0x9F, 0xFF };
                        // outros programas (SignalRGB, iCUE, Synapse...) também falam com o aparelho e baralham as respostas: tenta até 3 vezes
                        for (int attempt = 0; attempt < (tidOk ? 3 : 1); attempt++)
                        {
                        if (attempt > 0) Thread.Sleep(30 + attempt * 40);
                        foreach (byte t in tries)
                        {
                            byte[] r = new byte[91];
                            r[2] = t; r[6] = size; r[7] = cls; r[8] = id;
                            for (int i = 0; i < args.Length && i < 80; i++) r[9 + i] = args[i];
                            byte crc = 0; for (int i = 3; i < 89; i++) crc ^= r[i]; r[89] = crc;
                            if (!Hid.HidD_SetFeature(hh, r, r.Length)) continue;
                            // o Synapse (se estiver aberto) fala com o mesmo aparelho: só conta a resposta a ESTE pedido
                            // lê muitas vezes e depressa: o SignalRGB/iCUE manda as luzes dezenas de vezes por segundo e cada pedido dele
                            // apaga a resposta ao nosso; apanhá-la logo que fica pronta evita a "luta" (sem ter de os fechar)
                            Stopwatch sw = Stopwatch.StartNew();
                            while (sw.ElapsedMilliseconds < (tidOk ? 250 : 450))
                            {
                                Thread.Sleep(1);
                                byte[] a = new byte[91];
                                if (!Hid.HidD_GetFeature(hh, a, a.Length)) break;
                                if (a[7] != cls || a[8] != id || a[1] == 0x00 || a[1] == 0x01) continue;   // de outro pedido, ou ainda ocupado
                                if (a[1] == 0x02) { tid = t; tidOk = true; return a; }
                                if (a[1] == 0x05) { tid = t; tidOk = true; return null; }   // este aparelho não tem esta função (mas o id está certo)
                                if (a[1] == 0x04) { asleep = true; return null; }               // o recetor respondeu, mas o rato não (a dormir ou desligado)
                                break;                                            // falhou: tenta o próximo id
                            }
                        }
                        }
                        return null;
                    }
                    finally { if (!ReferenceEquals(hh, h)) hh.Dispose(); }
                }
        }

        public override void Refresh()
        {
            Err = ""; asleep = false;
            byte[] a = Cmd(0x04, 0x85, 0x07, 0x01);                    // DPI atual
            if (asleep) { Sleeping = true; Dpi = -1; Rate = -1; Battery = -1; Stages.Clear(); Rates.Clear(); Idle = -1; Wireless = true; return; }   // fica com o que já se sabia
            Sleeping = false;
            if (a != null) { Dpi = (a[10] << 8) | a[11]; if (DpiMax == 0) DpiMax = GuessMax(); }
            else Dpi = -1;
            a = Cmd(0x04, 0x86, 0x26, 0x01);                           // níveis de DPI
            Stages.Clear();
            if (a != null && a[11] > 0 && a[11] <= 5)
            {
                int n = a[11], act = a[10];
                for (int i = 0; i < n; i++) { int o = 12 + i * 7; int x = (a[o + 1] << 8) | a[o + 2]; if (x > 0) Stages.Add(x); }
                Stage = act >= 1 && act <= Stages.Count ? act - 1 : -1;
                if (Stages.Count > 0 && Stages.Max() > DpiMax) DpiMax = Stages.Max();
            }
            // taxa de envio: primeiro a nova (até 8000 Hz), depois a clássica
            Rates.Clear(); Rate = -1;
            a = Cmd(0x00, 0xC0, 0x01, 0x00);
            if (a != null && a[10] != 0)
            {
                int[] map = { 8000, 4000, 2000, 1000, 500, 250, 125 };
                for (int i = 0; i < 7; i++) if ((a[10] & (1 << i)) != 0) Rate = map[i];
                Rates.AddRange(new[] { 125, 250, 500, 1000, 2000, 4000, 8000 }); hyper = true;
            }
            else
            {
                a = Cmd(0x00, 0x85, 0x01);
                if (a != null) { Rate = a[9] == 0x01 ? 1000 : a[9] == 0x02 ? 500 : a[9] == 0x08 ? 125 : -1; if (Rate > 0) Rates.AddRange(new[] { 125, 500, 1000 }); }
            }
            // modo jogo do teclado (a luz "jogo" dos Razer: o próprio teclado desliga a tecla Windows)
            if (Kind == "keyboard") { a = Cmd(0x03, 0x80, 0x03, 0x01, 0x08); KbGame = a != null ? (a[11] == 1 ? 1 : 0) : -1; }
            a = Cmd(0x07, 0x80, 0x02);                                 // bateria
            if (a == null && Kind == "mouse") a = Cmd(0x07, 0x80, 0x50);   // alguns recetores sem fios só respondem ao pedido longo
            if (a != null) { Battery = (int)Math.Round(a[10] * 100.0 / 255); a = Cmd(0x07, 0x84, 0x02); Charging = a != null && a[10] == 1; if (Battery > 0 || Charging) Wireless = true; }
            else Battery = -1;
            a = Wireless ? (Cmd(0x07, 0x83, 0x02) ?? Cmd(0x07, 0x83, 0x50)) : null;   // tempo até adormecer
            Idle = a != null ? (a[9] << 8) | a[10] : -1;
            if (Dpi < 0 && Rate < 0 && Battery < 0 && Kind != "keyboard") Err = Busy();
        }
        bool hyper, asleep;
        // que programa pode estar a falar com o aparelho ao mesmo tempo
        internal static string Busy()
        {
            string[][] apps = { new[] { "SignalRgb", "SignalRGB" }, new[] { "SignalRgbLauncher", "SignalRGB" }, new[] { "iCUE", "Corsair iCUE" }, new[] { "RazerCentralService", "Razer Synapse" }, new[] { "Razer Synapse", "Razer Synapse" },
                new[] { "Razer Synapse 3", "Razer Synapse" }, new[] { "OpenRGB", "OpenRGB" }, new[] { "ArmouryCrate.Service", "Armoury Crate" }, new[] { "lghub_agent", "Logitech G HUB" }, new[] { "LightingService", "Armoury Crate" } };
            var on = new List<string>();
            foreach (string[] a in apps) try { if (Process.GetProcessesByName(a[0]).Length > 0 && !on.Contains(a[1])) on.Add(a[1]); } catch { }
            return on.Count > 0
                ? Lang.L("Este aparelho não respondeu. Está aberto um programa que também fala com ele:") + " " + string.Join(", ", on.ToArray()) + ". " + Lang.L("Fecha-o (ou desliga lá este aparelho) e carrega em PROCURAR.")
                : Lang.L("Este aparelho não respondeu. Carrega em PROCURAR daqui a uns segundos.");
        }
        int GuessMax()
        {
            string n = Name.ToLowerInvariant();
            if (n.Contains("v3") || n.Contains("v4") || n.Contains("pro 2") || n.Contains("viper v3") || n.Contains("basilisk v3 pro")) return 30000;
            if (n.Contains("v2") || n.Contains("viper") || n.Contains("basilisk v3")) return 26000;
            if (n.Contains("orochi v2") || n.Contains("deathadder v2")) return 20000;
            return 16000;
        }
        public override bool SetDpi(int dpi)
        {
            dpi = Math.Max(100, Math.Min(DpiMax > 0 ? DpiMax : 30000, dpi));
            bool ok = Cmd(0x04, 0x05, 0x07, 0x01, (byte)(dpi >> 8), (byte)dpi, (byte)(dpi >> 8), (byte)dpi, 0, 0) != null;
            if (!ok) { byte[] a = Cmd(0x04, 0x85, 0x07, 0x01); ok = a != null && ((a[10] << 8) | a[11]) == dpi; }   // a resposta pode ter-se perdido mas o rato mudou
            if (ok) Dpi = dpi;
            return ok;
        }
        public override bool SetRate(int hz)
        {
            bool ok;
            if (hyper)
            {
                int[] map = { 8000, 4000, 2000, 1000, 500, 250, 125 };
                int i = Array.IndexOf(map, hz); if (i < 0) return false;
                ok = Cmd(0x00, 0x40, 0x02, 0x00, (byte)(1 << i)) != null;
            }
            else
            {
                byte v = (byte)(hz >= 1000 ? 0x01 : hz >= 500 ? 0x02 : 0x08);
                ok = Cmd(0x00, 0x05, 0x01, v) != null;
                if (!ok) { byte[] a = Cmd(0x00, 0x85, 0x01); ok = a != null && a[9] == v; }   // confirma lendo outra vez
            }
            if (ok) Rate = hz;
            return ok;
        }
        public override bool SetStages(List<int> st, int active)
        {
            if (st.Count < 1 || st.Count > 5) return false;
            byte[] args = new byte[3 + st.Count * 7];
            args[0] = 0x01; args[1] = (byte)(Math.Max(0, Math.Min(st.Count - 1, active)) + 1); args[2] = (byte)st.Count;
            for (int i = 0; i < st.Count; i++)
            {
                int v = Math.Max(100, Math.Min(DpiMax > 0 ? DpiMax : 30000, st[i])), o = 3 + i * 7;
                args[o] = (byte)(i + 1); args[o + 1] = (byte)(v >> 8); args[o + 2] = (byte)v; args[o + 3] = (byte)(v >> 8); args[o + 4] = (byte)v;
            }
            bool ok = Cmd(0x04, 0x06, 0x26, args) != null;
            if (ok) { Stages = st.ToList(); Stage = active; Dpi = st[Math.Max(0, Math.Min(st.Count - 1, active))]; }
            return ok;
        }
        public override bool SetKbGame(bool on)
        {
            if (KbGame < 0) return false;
            bool ok = Cmd(0x03, 0x00, 0x03, 0x01, 0x08, (byte)(on ? 1 : 0)) != null;
            if (ok) KbGame = on ? 1 : 0;
            return ok;
        }
        public override bool SetIdle(int s)
        {
            s = Math.Max(60, Math.Min(900, s));
            bool ok = Cmd(0x07, 0x03, 0x02, (byte)(s >> 8), (byte)s) != null;
            if (ok) Idle = s;
            return ok;
        }
    }

    // ================================================================ Logitech (HID++ 2.0)
    class LogiDev : Aparelho
    {
        readonly string path; readonly byte idx;
        readonly Dictionary<ushort, byte> feat = new Dictionary<ushort, byte>();
        static readonly object io = new object();
        int rateMode;   // 1 = 0x8060 (ms), 2 = 0x8061 (índices)
        int[] extMap = { 125, 250, 500, 1000, 2000, 4000, 8000 };

        LogiDev(string p, byte devIdx) { path = p; idx = devIdx; Brand = "Logitech"; }

        // procura os aparelhos atrás de uma coleção "longa" HID++ (com fio/Bluetooth: índice 0xFF; recetor: 1 a 6)
        public static List<LogiDev> Find(Hid.Dev d)
        {
            List<LogiDev> r = new List<LogiDev>();
            LogiDev direct = new LogiDev(d.Path, 0xFF) { Vid = d.Vid, Pid = d.Pid };
            if (direct.Ping()) { direct.Init(d); r.Add(direct); return r; }
            for (byte i = 1; i <= 6; i++)
            {
                LogiDev x = new LogiDev(d.Path, i) { Vid = d.Vid, Pid = d.Pid, Wireless = true };
                if (x.Ping()) { x.Init(d); r.Add(x); }
            }
            return r;
        }

        static readonly Random rnd = new Random();
        // pedido HID++ longo (20 bytes) e resposta; null se erro ou sem resposta
        byte[] Call(byte fi, byte fn, params byte[] p)
        {
            lock (io)
                using (SafeFileHandle h = Hid.CreateFile(path, 0xC0000000, 3, IntPtr.Zero, 3, 0x40000000, IntPtr.Zero))   // leitura com espera limitada
                {
                    if (h.IsInvalid) return null;
                    using (FileStream fs = new FileStream(h, FileAccess.ReadWrite, 20, true))
                    {
                        byte sw = (byte)(rnd.Next(1, 15));
                        byte[] q = new byte[20]; q[0] = 0x11; q[1] = idx; q[2] = fi; q[3] = (byte)((fn << 4) | sw);
                        for (int i = 0; i < p.Length && i < 16; i++) q[4 + i] = p[i];
                        try { fs.Write(q, 0, 20); } catch { return null; }
                        DateTime end = DateTime.UtcNow.AddMilliseconds(fi == 0 && fn == 1 ? 400 : 900);
                        while (DateTime.UtcNow < end)
                        {
                            byte[] a = new byte[20];
                            IAsyncResult ar;
                            try { ar = fs.BeginRead(a, 0, 20, null, null); } catch { return null; }
                            int left = (int)Math.Max(1, (end - DateTime.UtcNow).TotalMilliseconds);
                            if (!ar.AsyncWaitHandle.WaitOne(left)) { return null; }   // ao fechar o handle a leitura pendente é cancelada
                            int n; try { n = fs.EndRead(ar); } catch { return null; }
                            if (n < 7 || a[1] != idx) continue;
                            if (a[0] == 0x11 && a[2] == 0xFF && a[3] == fi) return null;                       // erro HID++ 2.0
                            if (a[0] == 0x10 && a[2] == 0x8F) return null;                                      // erro HID++ 1.0 (ex.: recetor sem aparelho)
                            if ((a[0] == 0x11 || a[0] == 0x12) && a[2] == fi && a[3] == q[3]) return a;
                        }
                        return null;
                    }
                }
        }
        bool Ping() { byte[] a = Call(0x00, 0x1, 0, 0, 0x5A); return a != null && a[4] >= 2; }   // protocolo 2.0 ou mais
        byte F(ushort id)
        {
            byte v; lock (feat) if (feat.TryGetValue(id, out v)) return v;
            byte[] a = Call(0x00, 0x0, (byte)(id >> 8), (byte)id);
            if (a == null) return 0;   // sem resposta (ocupado, a dormir): não fica marcado como "não tem" para sempre
            v = a[4];
            lock (feat) feat[id] = v; return v;
        }

        void Init(Hid.Dev d)
        {
            // nome do aparelho
            byte fn = F(0x0005); string nm = "";
            if (fn != 0)
            {
                byte[] a = Call(fn, 0); int len = a != null ? a[4] : 0;
                for (int i = 0; i < len && i < 64; i += 16) { byte[] b = Call(fn, 1, (byte)i); if (b == null) break; nm += Encoding.ASCII.GetString(b, 4, Math.Min(16, len - i)); }
                byte[] t = Call(fn, 2); if (t != null) Kind = t[4] == 0 ? "keyboard" : t[4] >= 3 && t[4] <= 5 ? "mouse" : t[4] == 8 ? "headset" : "other";
            }
            Name = (nm.Trim('\0', ' ') != "" ? nm.Trim('\0', ' ') : d.Product != "" ? d.Product : "Logitech " + d.Pid.ToString("X4"));
            if (!Name.StartsWith("Logitech", StringComparison.OrdinalIgnoreCase) && !Name.StartsWith("G", StringComparison.Ordinal) && !Name.StartsWith("MX", StringComparison.Ordinal)) Name = "Logitech " + Name;
            if (fn == 0 && Name.ToLowerInvariant().Contains("keyboard")) Kind = "keyboard";
            Id = "lg:" + d.Pid.ToString("x4") + ":" + idx.ToString("x2") + ":" + Hid.Parent(path).GetHashCode().ToString("x8");
        }

        static int W(byte[] a, int o) { return (a[o] << 8) | a[o + 1]; }
        public override void Refresh()
        {
            Err = "";
            byte f = F(0x2201);                                                // DPI
            if (f != 0)
            {
                byte[] a = Call(f, 2, 0);
                Dpi = a != null ? W(a, 5) : -1;
                if (DpiMax == 0)
                {
                    DpiList.Clear(); List<int> raw = new List<int>();
                    byte[] l = Call(f, 1, 0);
                    if (l != null) for (int o = 5; o + 1 < 20; o += 2) { int v = W(l, o); if (v == 0) break; raw.Add(v); }
                    // valores com 0xE000: passo entre o anterior e o seguinte (intervalo contínuo)
                    bool range = false;
                    for (int i = 0; i < raw.Count; i++)
                        if ((raw[i] & 0xE000) == 0xE000) { range = true; DpiStep = raw[i] & 0x1FFF; }
                        else DpiList.Add(raw[i]);
                    if (DpiList.Count > 0) { DpiMin = DpiList.Min(); DpiMax = DpiList.Max(); }
                    if (range) DpiList.Clear();
                    if (DpiMax == 0) DpiMax = 25600;
                }
            }
            Rates.Clear(); Rate = -1;
            f = F(0x8061);
            if (f != 0)
            {
                byte[] l = Call(f, 1, 0); byte[] c = Call(f, 2);
                if (l != null) { int m = W(l, 4); for (int i = 0; i < 7; i++) if ((m & (1 << i)) != 0) Rates.Add(extMap[i]); }
                if (c != null && c[4] < 7) Rate = extMap[c[4]];
                rateMode = 2;
            }
            else if ((f = F(0x8060)) != 0)
            {
                byte[] l = Call(f, 0); byte[] c = Call(f, 1);
                if (l != null) for (int i = 0; i < 8; i++) if ((l[4] & (1 << i)) != 0) Rates.Add(1000 / (i + 1));
                if (c != null && c[4] > 0) Rate = 1000 / c[4];
                rateMode = 1;
            }
            Rates = Rates.Distinct().OrderBy(x => x).ToList();
            if (Rate > 0 && !Rates.Contains(Rate)) Rates.Add(Rate);
            Battery = -1;
            if ((f = F(0x1004)) != 0) { byte[] a = Call(f, 1); if (a != null) { Battery = a[4]; Charging = a[6] == 1 || a[6] == 2; Wireless = true; } }
            else if ((f = F(0x1000)) != 0) { byte[] a = Call(f, 0); if (a != null) { Battery = a[4]; Charging = a[6] >= 1 && a[6] <= 3; Wireless = true; } }
            else if ((f = F(0x1F20)) != 0) { byte[] a = Call(f, 0); if (a != null) { int mv = W(a, 4); if (mv > 2500) { Battery = Math.Max(0, Math.Min(100, (mv - 3450) * 100 / 750)); Charging = (a[6] & 0x03) != 0; Wireless = true; } } }   // auscultadores: tensão da bateria
            else if ((f = F(0x1001)) != 0) { byte[] a = Call(f, 0); if (a != null) { int mv = W(a, 4); Battery = Math.Max(0, Math.Min(100, (mv - 3500) * 100 / 700)); Charging = (a[6] & 0x80) != 0; Wireless = true; } }
            Onboard = -1;
            if ((f = F(0x8100)) != 0) { byte[] a = Call(f, 2); if (a != null) Onboard = a[4]; }
            Smart = -1;
            if ((f = F(0x2110)) != 0) { byte[] a = Call(f, 0); if (a != null) { Smart = a[4]; SmartAuto = a[5]; } }
            HiRes = -1;
            if ((f = F(0x2121)) != 0) { byte[] a = Call(f, 1); if (a != null) HiRes = (a[4] & 0x02) != 0 ? 1 : 0; }
            Sidetone = -1;
            if ((f = F(0x8300)) != 0) { byte[] a = Call(f, 0); if (a != null) Sidetone = a[4]; }   // ouvir a própria voz nos auscultadores
            FnSwap = -1;
            if ((f = F(0x40A2)) != 0) { byte[] a = Call(f, 0); if (a != null) FnSwap = a[4] & 1; }
            else if ((f = F(0x40A0)) != 0) { byte[] a = Call(f, 0); if (a != null) FnSwap = a[4] & 1; }
            if (Dpi < 0 && Rate < 0 && Battery < 0 && Smart < 0 && FnSwap < 0 && Sidetone < 0) Err = Lang.L("Este aparelho não respondeu. Se o G HUB estiver aberto, fecha-o e tenta outra vez.");
        }
        void Host()
        {
            // no modo "memória do rato" (perfis do G HUB guardados no rato) o rato ignora o DPI vindo do PC: passa a obedecer ao PC
            byte f = F(0x8100);
            if (f != 0 && Onboard == 1) { if (Call(f, 1, 2) != null) Onboard = 2; }
        }
        public override bool SetDpi(int dpi)
        {
            byte f = F(0x2201); if (f == 0) return false;
            Host();
            if (DpiList.Count > 0) dpi = DpiList.OrderBy(x => Math.Abs(x - dpi)).First();
            else { dpi = Math.Max(DpiMin, Math.Min(DpiMax, dpi)); if (DpiStep > 0) dpi = (int)Math.Round(dpi / (double)DpiStep) * DpiStep; }
            bool ok = Call(f, 3, 0, (byte)(dpi >> 8), (byte)dpi) != null;
            if (ok) Dpi = dpi;
            return ok;
        }
        public override bool SetRate(int hz)
        {
            Host();
            bool ok = false;
            if (rateMode == 2) { int i = Array.IndexOf(extMap, hz); byte f = F(0x8061); if (i >= 0 && f != 0) ok = Call(f, 3, (byte)i) != null; }
            else if (rateMode == 1) { byte f = F(0x8060); if (f != 0 && hz > 0) ok = Call(f, 2, (byte)Math.Max(1, Math.Min(8, 1000 / hz))) != null; }
            if (ok) Rate = hz;
            return ok;
        }
        public override bool SetSmart(int mode, int auto)
        {
            byte f = F(0x2110); if (f == 0) return false;
            bool ok = Call(f, 1, (byte)mode, (byte)Math.Max(0, Math.Min(255, auto))) != null;
            if (ok) { Smart = mode; SmartAuto = auto; }
            return ok;
        }
        public override bool SetHiRes(bool on)
        {
            byte f = F(0x2121); if (f == 0) return false;
            byte[] a = Call(f, 1); if (a == null) return false;
            byte m = (byte)(on ? (a[4] | 0x02) : (a[4] & ~0x02));
            bool ok = Call(f, 2, m) != null;
            if (ok) HiRes = on ? 1 : 0;
            return ok;
        }
        public override bool SetSidetone(int v)
        {
            byte f = F(0x8300); if (f == 0) return false;
            v = Math.Max(0, Math.Min(100, v));
            bool ok = Call(f, 1, (byte)v) != null;
            if (ok) Sidetone = v;
            return ok;
        }
        public override bool SetFnSwap(bool on)
        {
            byte f = F(0x40A2); if (f == 0) f = F(0x40A0); if (f == 0) return false;
            bool ok = Call(f, 1, (byte)(on ? 1 : 0)) != null;
            if (ok) FnSwap = on ? 1 : 0;
            return ok;
        }
    }

    // ================================================================ HyperX (HP) sem fios: bateria
    // Cloud III Wireless: pedido 66 89 -> resposta 66 89 xx yy <bateria %> (descoberto no NEXUS a comparar com o NGENUITY)
    class HyperXDev : Aparelho
    {
        readonly string path; readonly int inLen, outLen;
        public HyperXDev(Hid.Dev d)
        {
            path = d.Path; inLen = d.InLen; outLen = d.OutLen; Vid = d.Vid; Pid = d.Pid; Brand = "HyperX"; Kind = "headset"; Wireless = true;
            Name = d.Product != "" ? d.Product : "HyperX " + d.Pid.ToString("X4");
            if (!Name.StartsWith("HyperX", StringComparison.OrdinalIgnoreCase)) Name = "HyperX " + Name;
            Id = "hx:" + Pid.ToString("x4") + ":" + Hid.Parent(path).GetHashCode().ToString("x8");
        }
        // pedido -> resposta pelo HidIo (com o buffer fixo enquanto o Windows lê/escreve)
        byte[] Ask(byte rid, byte cmd)
        {
            using (SafeFileHandle h = HidIo.Open(path))
            {
                if (h.IsInvalid) return null;
                if (!HidIo.Write(h, new byte[] { rid, cmd }, outLen)) return null;
                DateTime end = DateTime.UtcNow.AddMilliseconds(600);
                while (DateTime.UtcNow < end)
                {
                    byte[] a = HidIo.Read(h, inLen, (int)Math.Max(1, (end - DateTime.UtcNow).TotalMilliseconds));
                    if (a == null) return null;
                    if (a.Length >= 5 && a[0] == rid && a[1] == cmd) return a;
                }
                return null;
            }
        }
        public override void Refresh()
        {
            Err = "";
            byte[] a = Ask(0x66, 0x89);
            Battery = a != null && a[4] > 0 && a[4] <= 100 ? a[4] : -1;   // 0 % = auscultadores desligados (o recetor responde por eles): aparecem como desligados, com a última bateria
            Charging = false; ChargeUnknown = true;   // estes auscultadores não dizem se estão a carregar
            byte[] t = Ask(0x66, 0x85);                // minutos até desligarem sozinhos (só leitura: muda-se no NGENUITY)
            if (t != null && t[2] > 0 && t[2] <= 240) { Idle = t[2] * 60; IdleRO = true; }
        }
        public override bool SetDpi(int dpi) { return false; }
    }

    // ================================================================ lista de aparelhos, API e perfis
    static class Aparelhos
    {
        static readonly object lk = new object();
        static List<Aparelho> list = new List<Aparelho>();
        static DateTime scanned = DateTime.MinValue;
        static bool scanning, quick;
        static DateTime quickAt = DateTime.MinValue;
        static readonly object io = new object();   // um pedido de cada vez aos aparelhos (procura, atualização, mudanças)
        public static bool Enabled { get { return Cfg23.On("dev_on", false); } }

        public static void Scan()
        {
            lock (lk) { if (scanning) return; scanning = true; }
            try
            {
              lock (io)
              {
                List<Aparelho> acc = new List<Aparelho>();   // nunca é trocada: um aparelho que responda tarde não mexe na lista final
                List<Hid.Dev> all = Hid.Find(new ushort[] { 0x1532, 0x046D }.Concat(HsTable.Vids).Distinct().ToArray());
                // cada aparelho é lido em paralelo e aparece na lista logo que responde (antes era um de cada vez: demorava)
                Action<Aparelho> add = a =>
                {
                    lock (acc) { if (acc.Any(x => x.Id == a.Id)) return; acc.Add(a); }
                    lock (lk)
                    {
                        int i0 = list.FindIndex(x => x.Id == a.Id);
                        if (i0 >= 0) { a.KeepFrom(list[i0]); list[i0] = a; } else list.Add(a);
                    }
                };
                var jobs = new List<Thread>();
                Action<Action> job = w => { Thread t = new Thread(() => { try { w(); } catch { } }) { IsBackground = true }; jobs.Add(t); t.Start(); };
                // Razer: a coleção com relatórios "feature" de 90 bytes, uma por aparelho físico
                foreach (var g in all.Where(d => d.Vid == 0x1532 && d.FeatLen == 91).GroupBy(d => Hid.Parent(d.Path)))
                {
                    RazerDev r = new RazerDev(g.First());
                    string nl = r.Name.ToLowerInvariant();
                    if (nl.Contains("addressable") || nl.Contains("rgb controller") || nl.Contains("mouse dock") || nl.Contains("base station") || nl.Contains("seiren") || nl.Contains("charging pad") || nl.Contains("mouse bungee")) continue;   // só luzes / bases / microfones
                    job(() =>
                    {
                        try { r.Refresh(); } catch (Exception e) { r.Err = e.Message; }
                        if (r.Battery == 0 && !r.Charging && r.Dpi <= 0) r.Battery = -1;   // "0 %" sem mais nada = não tem bateria
                        if (r.Battery < 0 && r.Kind != "headset") r.Wireless = nl.Contains("wireless") || nl.Contains("dongle") || nl.Contains("hyperspeed");
                        if (r.Dpi > 0 || r.Rate > 0 || r.Battery > 0 || r.Sleeping || r.Kind == "keyboard") { r.Err = r.Kind == "keyboard" && r.Rate < 0 && r.Battery < 0 ? "" : r.Err; add(r); }
                    });
                }
                // Logitech: a coleção HID++ longa (página 0xFF00, 20 bytes)
                foreach (Hid.Dev d0 in all.Where(q => q.Vid == 0x046D && (q.UsagePage == 0xFF00 || q.UsagePage == 0xFF43) && q.InLen == 20).ToList())
                {
                    Hid.Dev d = d0;
                    job(() =>
                    {
                        foreach (LogiDev l in LogiDev.Find(d))
                        {
                            try { l.Refresh(); } catch (Exception e) { l.Err = e.Message; }
                            add(l);
                        }
                    });
                }
                // HyperX sem fios (bateria)
                foreach (Hid.Dev d0 in all.Where(q => q.Vid == 0x03F0 && q.UsagePage == 0xFF13 && q.InLen >= 32 && q.OutLen >= 32).ToList())
                {
                    Hid.Dev d = d0;
                    job(() => { HyperXDev x = new HyperXDev(d); x.Refresh(); if (x.Battery >= 0) add(x); });
                }
                // auscultadores de outras marcas (SteelSeries, Corsair, HyperX/Kingston) e os que tu ensinaste ao NEXUS
                job(() => { foreach (HsDev x in HsTable.Find(all)) add(x); });
                job(() => { foreach (Aparelho x in Descobrir.Devices()) add(x); });
                foreach (Thread t in jobs) t.Join(20000);
                List<Aparelho> found; lock (acc) found = new List<Aparelho>(acc);
                List<Aparelho> prev; lock (lk) prev = list.ToList();
                foreach (Aparelho a in found) a.KeepFrom(prev.FirstOrDefault(p => p.Id == a.Id));
                lock (lk) { list = found; scanned = DateTime.UtcNow; quickAt = DateTime.UtcNow; }
                try { Remember(found); } catch { }
              }
            }
            finally { lock (lk) scanning = false; }
        }
        static Aparelho Get(string id) { lock (lk) return list.FirstOrDefault(x => x.Id == id); }
        public static List<Aparelho> All { get { lock (lk) return list.ToList(); } }

        public static string Json()
        {
            bool sc; List<Aparelho> l; DateTime when;
            lock (lk) { sc = scanning; l = list.ToList(); when = scanned; }
            // a página está aberta: mantém tudo atual. Bateria, DPI e taxa leem-se a cada poucos segundos;
            // procurar aparelhos novos (mais pesado) só de vez em quando ou com PROCURAR
            // com um jogo aberto não se fala com os aparelhos (cada pedido ao rato/teclado pode notar-se no jogo); fica o último valor
            if (Enabled && !sc && !Macros.InGame)
            {
                double age = (DateTime.UtcNow - when).TotalSeconds;
                if (age > 90 || (l.Count == 0 && age > 15)) ThreadPool.QueueUserWorkItem(delegate { try { Scan(); } catch { } });
                else if (l.Count > 0 && (DateTime.UtcNow - quickAt).TotalSeconds > 4) QuickRefresh();
            }
            return "{\"ok\":true,\"on\":" + (Enabled ? "true" : "false") + ",\"scanning\":" + (sc ? "true" : "false") + ",\"scanned\":" + (when == DateTime.MinValue ? "false" : "true") +
                   ",\"keep\":" + KeepDays + ",\"devs\":[" + string.Join(",", l.Select(x => x.Json()).Concat(Enabled ? Offline(l) : new List<string>()).ToArray()) + "]}";
        }
        static void QuickRefresh()
        {
            lock (lk) { if (quick || scanning) return; quick = true; }
            ThreadPool.QueueUserWorkItem(delegate
            {
                try
                {
                    lock (io)
                        foreach (Aparelho a in All)
                        {
                            // lê para uma cópia e só no fim troca: a página nunca vê um aparelho a meio da leitura
                            Aparelho c = a.Copy();
                            try { c.Refresh(); } catch { }
                            c.KeepFrom(a);   // uma leitura falhada (o Synapse/G HUB também falam com o aparelho) não apaga o que já se sabia
                            lock (lk) { int i = list.IndexOf(a); if (i >= 0) list[i] = c; }
                        }
                }
                finally { lock (lk) { quick = false; quickAt = DateTime.UtcNow; } }
                try { Remember(All); } catch { }
            });
        }

        // ---- memória: os dispositivos ficam na lista mesmo desligados (com a última bateria) até N dias sem aparecer
        static readonly Dictionary<string, string> memLast = new Dictionary<string, string>();
        static string MemClean(string s) { return (s ?? "").Replace("\t", " ").Replace("\r", " ").Replace("\n", " "); }
        static void Remember(List<Aparelho> l)
        {
            long now = DateTime.UtcNow.Ticks;
            foreach (Aparelho a in l)
            {
                if (string.IsNullOrEmpty(a.Id)) continue;
                string key = "dm_" + a.Id, prev;
                lock (memLast) memLast.TryGetValue(key, out prev);
                if (prev == null) prev = Cfg23.Get(key, null);
                string[] p = prev == null ? null : prev.Split('\t');
                long seen0 = 0; int bat0 = -1;
                if (p != null && p.Length > 5) { long.TryParse(p[5], out seen0); int.TryParse(p[3], out bat0); }
                int bat = a.Battery >= 0 ? a.Battery : bat0;   // a dormir não diz a bateria: fica a última conhecida
                // grava só quando muda alguma coisa ou de 10 em 10 minutos (para saber quando foi visto pela última vez)
                if (p != null && bat == bat0 && now - seen0 < TimeSpan.FromMinutes(10).Ticks) continue;
                string rec = MemClean(a.Name) + "\t" + MemClean(a.Kind) + "\t" + MemClean(a.Brand) + "\t" + bat + "\t" + (a.Charging ? "1" : "0") + "\t" + now + "\t" + (a.Wireless ? "1" : "0");
                lock (memLast) memLast[key] = rec;
                Cfg23.Set(key, rec);
            }
        }
        public static int KeepDays { get { int d = Cfg23.Int("dev_keep", 7); return d < 1 ? 7 : Math.Min(365, d); } }
        // os que já não estão ligados (desligados, auscultadores arrumados…), para a lista
        static List<string> Offline(List<Aparelho> on)
        {
            var r = new List<string>();
            foreach (var kv in Cfg23.Prefix("dm_"))
            {
                string id = kv.Key;
                if (on.Any(x => x.Id == id)) continue;
                string[] p = kv.Value.Split('\t'); if (p.Length < 7) continue;
                long seen; if (!long.TryParse(p[5], out seen)) continue;
                TimeSpan age = DateTime.UtcNow - new DateTime(seen, DateTimeKind.Utc);
                if (age.TotalDays > KeepDays) { lock (memLast) memLast.Remove("dm_" + id); Cfg23.Set("dm_" + id, null); continue; }   // não aparece há mais de N dias: sai sozinho
                int bat; int.TryParse(p[3], out bat);
                r.Add("{\"id\":" + Js.S(id) + ",\"name\":" + Js.S(p[0]) + ",\"kind\":" + Js.S(p[1]) + ",\"brand\":" + Js.S(p[2]) + ",\"wireless\":" + (p[6] == "1" ? "true" : "false") +
                      ",\"offline\":true,\"seenMin\":" + (long)Math.Max(0, age.TotalMinutes) + (bat >= 0 ? ",\"battery\":" + bat + ",\"charging\":false" : "") + "}");
            }
            return r;
        }
        public static string Forget(string id)
        {
            if (string.IsNullOrEmpty(id)) return Ps23.Ok(false, "?");
            lock (memLast) memLast.Remove("dm_" + id);
            Cfg23.Set("dm_" + id, null);
            return Json();
        }
        public static string SetKeep(string days)
        {
            int d; if (int.TryParse(days, out d) && d >= 1 && d <= 365) Cfg23.Set("dev_keep", d.ToString());
            return Json();
        }
        public static void KbGameAll(bool on)
        {
            if (!Enabled) return;
            ThreadPool.QueueUserWorkItem(delegate { try { lock (io) foreach (Aparelho a in All.Where(x => x.KbGame >= 0)) a.SetKbGame(on); } catch { } });
        }
        public static string SetOn(bool on)
        {
            Cfg23.Set("dev_on", on ? "1" : "0");
            if (on) ThreadPool.QueueUserWorkItem(delegate { try { Scan(); } catch { } });
            else lock (lk) list = new List<Aparelho>();
            return Json();
        }
        public static string Refresh()
        {
            if (!Enabled) return Ps23.Ok(false, Lang.L("Liga primeiro os aparelhos."));
            ThreadPool.QueueUserWorkItem(delegate { try { Scan(); } catch { } });
            Thread.Sleep(50);
            return Json();
        }
        // muda uma definição: k = dpi | rate | stages | idle | smart | hires | fnswap
        public static string Set(string id, string k, string v)
        {
            Aparelho a = Get(id); if (a == null || !Enabled) return Ps23.Ok(false, Lang.L("Aparelho não encontrado. Carrega em PROCURAR."));
            bool ok = false; int n;
            try
            {
              lock (io)
                switch (k)
                {
                    case "dpi": ok = int.TryParse(v, out n) && a.SetDpi(n); break;
                    case "rate": ok = int.TryParse(v, out n) && a.SetRate(n); break;
                    case "idle": ok = int.TryParse(v, out n) && a.SetIdle(n); break;
                    case "hires": ok = a.SetHiRes(v == "1"); break;
                    case "fnswap": ok = a.SetFnSwap(v == "1"); break;
                    case "sidetone": ok = int.TryParse(v, out n) && a.SetSidetone(n); break;
                    case "kbgame": ok = a.SetKbGame(v == "1"); break;
                    case "smart": { string[] p = (v ?? "").Split(','); int m, au; ok = p.Length == 2 && int.TryParse(p[0], out m) && int.TryParse(p[1], out au) && a.SetSmart(m, au); break; }
                    case "stages":
                        {
                            string[] p = (v ?? "").Split(';'); int act;
                            List<int> st = p[0].Split(',').Select(x => { int q; return int.TryParse(x, out q) ? q : 0; }).Where(x => x > 0).ToList();
                            ok = p.Length == 2 && int.TryParse(p[1], out act) && a.SetStages(st, act);
                            break;
                        }
                }
            }
            catch (Exception e) { return Ps23.Ok(false, e.Message); }
            return ok ? "{\"ok\":true,\"dev\":" + a.Json() + "}" : Ps23.Ok(false, Lang.L("O aparelho não aceitou. Se o Synapse ou o G HUB estiverem abertos, podem estar a mandar nele."));
        }

        // ---------- DPI rápido (atalhos e Stream Deck): passa ao nível seguinte / modo precisão enquanto se segura a tecla
        public static string CycleDpi(int dir)
        {
            Aparelho m = All.FirstOrDefault(x => x.Kind == "mouse" && x.Dpi > 0);
            if (m == null) return null;
            List<int> lv = m.Stages.Count > 1 ? m.Stages : m.DpiList.Count > 1 ? m.DpiList : new List<int> { 400, 800, 1600, 3200 };
            int i = lv.FindIndex(x => x >= m.Dpi); if (i < 0) i = lv.Count - 1;
            if (lv[i] == m.Dpi || dir < 0) i = (i + (dir < 0 ? -1 : 1) + lv.Count) % lv.Count;
            int target = lv[i];
            if (m.SetDpi(target)) { if (m.Stages.Count > 1) m.Stage = i; return m.Dpi + " DPI"; }
            return null;
        }
        static int precisionPrev = -1;
        public static void Precision(bool down)
        {
            Aparelho m = All.FirstOrDefault(x => x.Kind == "mouse" && x.Dpi > 0);
            if (m == null) return;
            if (down && precisionPrev < 0) { precisionPrev = m.Dpi; m.SetDpi(Math.Max(100, Cfg23.Int("dev_prec", 400))); }
            else if (!down && precisionPrev > 0) { m.SetDpi(precisionPrev); precisionPrev = -1; }
        }

        // ---------- perfis por jogo: DPI e taxa de envio de cada aparelho enquanto o jogo está aberto
        static readonly Dictionary<string, int[]> before = new Dictionary<string, int[]>();
        public static void GameStart(string game)
        {
            if (!Enabled || string.IsNullOrEmpty(game)) return;
            if (Macros.GmMode == 1) KbGameAll(true);   // modo jogo: também o do próprio teclado
            string g = Perfis.Norm(game); if (g == null) return;
            foreach (Aparelho a in All)
            {
                string v = Cfg23.Get("dev_p_" + g + "_" + a.Id, "");   // "dpi|hz"
                if (v == "") continue;
                string[] p = v.Split('|'); int d, r;
                lock (before) if (!before.ContainsKey(a.Id)) before[a.Id] = new[] { a.Dpi, a.Rate };
                if (p.Length > 0 && int.TryParse(p[0], out d) && d > 0 && d != a.Dpi) a.SetDpi(d);
                if (p.Length > 1 && int.TryParse(p[1], out r) && r > 0 && r != a.Rate) a.SetRate(r);
            }
        }
        public static void GameEnd()
        {
            if (Macros.GmMode == 1) KbGameAll(false);
            Dictionary<string, int[]> b; lock (before) { b = new Dictionary<string, int[]>(before); before.Clear(); }
            foreach (var kv in b)
            {
                Aparelho a = Get(kv.Key); if (a == null) continue;
                if (kv.Value[0] > 0 && a.Dpi != kv.Value[0]) a.SetDpi(kv.Value[0]);
                if (kv.Value[1] > 0 && a.Rate != kv.Value[1]) a.SetRate(kv.Value[1]);
            }
        }
        public static string SetProfile(string game, string id, string dpi, string hz)
        {
            string g = Perfis.Norm(game); if (g == null || string.IsNullOrEmpty(id)) return Ps23.Ok(false, "?");
            int d, r; int.TryParse(dpi, out d); int.TryParse(hz, out r);
            Cfg23.Set("dev_p_" + g + "_" + id, d > 0 || r > 0 ? d + "|" + r : null);
            return ProfileJson(game);
        }
        public static string ProfileJson(string game)
        {
            string g = Perfis.Norm(game); if (g == null) return "{\"ok\":true,\"p\":{}}";
            var l = Cfg23.Prefix("dev_p_" + g + "_");
            return "{\"ok\":true,\"p\":{" + string.Join(",", l.Select(kv => Js.S(kv.Key) + ":" + Js.S(kv.Value)).ToArray()) + "}}";
        }

        // bateria fraca: aviso uma vez por aparelho (abaixo de 15 %, sem estar a carregar)
        static readonly HashSet<string> warned = new HashSet<string>();
        static int ticks;
        public static void Tick()
        {
            if (!Enabled) return;
            if (++ticks % 120 != 5) return;   // a cada ~2 minutos
            if (Macros.InGame && ticks % 600 != 5) return;   // a jogar: só de 10 em 10 minutos (para o aviso de bateria fraca)
            ThreadPool.QueueUserWorkItem(delegate
            {
                try
                {
                    Scan();
                    foreach (Aparelho a in All.Where(x => x.Battery >= 0))
                    {
                        if (a.Battery > 0 && a.Battery <= Cfg23.Int("dev_low", 20) && !a.Charging) { lock (warned) { if (!warned.Add(a.Id)) continue; } Vigias23.Alert(Lang.L("🔋 Bateria fraca"), string.Format(Lang.L("{0}: {1}% de bateria."), a.Name, a.Battery)); }
                        else if (a.Battery > 25 || a.Charging) lock (warned) warned.Remove(a.Id);
                    }
                }
                catch { }
            });
        }
    }
}
