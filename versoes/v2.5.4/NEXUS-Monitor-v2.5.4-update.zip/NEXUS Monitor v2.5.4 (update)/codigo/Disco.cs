﻿// NEXUS // MONITOR - Deep Scan: limpeza rápida, análise do disco e desinstalador de programas
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Linq;
using System.Management;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Reflection;
using System.Security.Principal;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Win32;

namespace Nexus
{


    // ------------------------------------------------------------ limpeza rápida (presets de espaço em disco)
    static class Cleaner
    {
        [DllImport("shell32.dll", CharSet = CharSet.Unicode)] static extern int SHEmptyRecycleBin(IntPtr hwnd, string root, uint flags);
        // a estrutura do Windows é "empacotada" no 32-bit (20 bytes) e alinhada no 64-bit (24 bytes): com a errada o Windows recusa e a reciclagem dava sempre 0
        [StructLayout(LayoutKind.Sequential, Pack = 1)] struct SHQUERYRBINFO32 { public int cbSize; public long i64Size; public long i64NumItems; }
        [StructLayout(LayoutKind.Sequential, Pack = 8)] struct SHQUERYRBINFO64 { public int cbSize; public long i64Size; public long i64NumItems; }
        [DllImport("shell32.dll", CharSet = CharSet.Unicode, EntryPoint = "SHQueryRecycleBinW")] static extern int SHQueryRecycleBin32(string root, ref SHQUERYRBINFO32 info);
        [DllImport("shell32.dll", CharSet = CharSet.Unicode, EntryPoint = "SHQueryRecycleBinW")] static extern int SHQueryRecycleBin64(string root, ref SHQUERYRBINFO64 info);
        static long[] QueryRecycle()
        {
            try
            {
                if (IntPtr.Size == 8)
                {
                    SHQUERYRBINFO64 q = new SHQUERYRBINFO64(); q.cbSize = Marshal.SizeOf(typeof(SHQUERYRBINFO64));
                    if (SHQueryRecycleBin64(null, ref q) == 0) return new[] { q.i64Size, q.i64NumItems };
                }
                else
                {
                    SHQUERYRBINFO32 q = new SHQUERYRBINFO32(); q.cbSize = Marshal.SizeOf(typeof(SHQUERYRBINFO32));
                    if (SHQueryRecycleBin32(null, ref q) == 0) return new[] { q.i64Size, q.i64NumItems };
                }
            }
            catch { }
            // plano B: somar as pastas $Recycle.Bin de cada disco (só o que este utilizador consegue ler)
            long size = 0, n = 0;
            foreach (DriveInfo d in DriveInfo.GetDrives())
            {
                try
                {
                    if (!d.IsReady || d.DriveType != DriveType.Fixed) continue;
                    string rb = Path.Combine(d.RootDirectory.FullName, "$Recycle.Bin");
                    if (!Directory.Exists(rb)) continue;
                    foreach (string sid in Directory.GetDirectories(rb))
                        try
                        {
                            // $I... = um ficheiro de info por cada item apagado; o resto (incluindo pastas $R...) é o conteúdo
                            foreach (string f in Directory.EnumerateFiles(sid, "*", SearchOption.AllDirectories))
                                try
                                {
                                    string nm = Path.GetFileName(f);
                                    if (nm.StartsWith("$I", StringComparison.OrdinalIgnoreCase) && Path.GetDirectoryName(f).Length == sid.Length) { n++; continue; }
                                    if (nm.Equals("desktop.ini", StringComparison.OrdinalIgnoreCase)) continue;
                                    size += new FileInfo(f).Length;
                                }
                                catch { }
                        }
                        catch { }
                }
                catch { }
            }
            return new[] { size, n };
        }

        class Target { public string Path; public string Pattern; public bool Recursive = true; public int MinAgeHours; }
        static string Win { get { return Environment.GetFolderPath(Environment.SpecialFolder.Windows); } }
        static string LocalApp { get { return Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData); } }
        static string ProgData { get { return Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData); } }

        static List<Target> Targets(string id)
        {
            List<Target> t = new List<Target>();
            switch (id)
            {
                case "temp":
                    t.Add(new Target { Path = System.IO.Path.GetTempPath(), MinAgeHours = 24 });
                    t.Add(new Target { Path = System.IO.Path.Combine(Win, "Temp"), MinAgeHours = 24 });
                    break;
                case "wu":
                    t.Add(new Target { Path = System.IO.Path.Combine(Win, "SoftwareDistribution", "Download") });
                    t.Add(new Target { Path = System.IO.Path.Combine(Win, @"ServiceProfiles\NetworkService\AppData\Local\Microsoft\Windows\DeliveryOptimization\Cache") });
                    break;
                case "shaders":
                    foreach (string x in new[] { @"NVIDIA\DXCache", @"NVIDIA\GLCache", @"NVIDIA Corporation\NV_Cache", "D3DSCache", @"AMD\DxCache", @"AMD\DxcCache", @"AMD\GLCache", @"AMD\VkCache", @"Intel\ShaderCache" })
                        t.Add(new Target { Path = System.IO.Path.Combine(LocalApp, x) });
                    break;
                case "thumbs":
                    t.Add(new Target { Path = System.IO.Path.Combine(LocalApp, @"Microsoft\Windows\Explorer"), Pattern = "thumbcache_*.db", Recursive = false });
                    break;
                case "dumps":
                    t.Add(new Target { Path = System.IO.Path.Combine(LocalApp, "CrashDumps") });
                    t.Add(new Target { Path = System.IO.Path.Combine(Win, "Minidump") });
                    t.Add(new Target { Path = System.IO.Path.Combine(Win, "LiveKernelReports"), Pattern = "*.dmp" });
                    t.Add(new Target { Path = Win, Pattern = "MEMORY.DMP", Recursive = false });
                    t.Add(new Target { Path = System.IO.Path.Combine(ProgData, @"Microsoft\Windows\WER\ReportArchive") });
                    t.Add(new Target { Path = System.IO.Path.Combine(ProgData, @"Microsoft\Windows\WER\ReportQueue") });
                    t.Add(new Target { Path = System.IO.Path.Combine(LocalApp, @"Microsoft\Windows\WER\ReportArchive") });
                    t.Add(new Target { Path = System.IO.Path.Combine(LocalApp, @"Microsoft\Windows\WER\ReportQueue") });
                    break;
                case "logs":
                    // Windows\Logs inteiro: .log, os .cab comprimidos do CBS (CbsPersist_*.cab, chegam a GB) e .etl; só com mais de 3 dias
                    t.Add(new Target { Path = System.IO.Path.Combine(Win, "Logs"), MinAgeHours = 72 });
                    t.Add(new Target { Path = System.IO.Path.Combine(Win, "Panther"), Pattern = "*.log", MinAgeHours = 72 });
                    t.Add(new Target { Path = System.IO.Path.Combine(Win, "inf"), Pattern = "setupapi*.log", Recursive = false, MinAgeHours = 72 });
                    t.Add(new Target { Path = System.IO.Path.Combine(Win, @"System32\LogFiles\setupcln"), MinAgeHours = 72 });
                    t.Add(new Target { Path = System.IO.Path.Combine(Win, @"SoftwareDistribution\DataStore\Logs"), Pattern = "*.log", Recursive = false, MinAgeHours = 72 });
                    t.Add(new Target { Path = System.IO.Path.Combine(ProgData, @"Microsoft\Windows\WER\Temp"), MinAgeHours = 72 });
                    break;
            }
            return t;
        }
        public static readonly string[] Ids = { "temp", "recycle", "wu", "shaders", "thumbs", "dumps", "logs" };

        static IEnumerable<FileInfo> Files(Target t)
        {
            DirectoryInfo root = new DirectoryInfo(t.Path);
            if (!root.Exists) yield break;
            Stack<DirectoryInfo> st = new Stack<DirectoryInfo>(); st.Push(root);
            DateTime limit = DateTime.Now.AddHours(-t.MinAgeHours);
            while (st.Count > 0)
            {
                DirectoryInfo d = st.Pop();
                FileInfo[] fs = null;
                try { fs = d.GetFiles(t.Pattern ?? "*"); } catch { }
                if (fs != null) foreach (FileInfo f in fs) if (t.MinAgeHours == 0 || f.LastWriteTime < limit) yield return f;
                if (!t.Recursive) continue;
                DirectoryInfo[] ds = null;
                try { ds = d.GetDirectories(); } catch { }
                if (ds != null) foreach (DirectoryInfo x in ds) if ((x.Attributes & FileAttributes.ReparsePoint) == 0) st.Push(x);
            }
        }

        static long[] Measure(string id)
        {
            if (id == "recycle")
            {
                return QueryRecycle();
            }
            long size = 0, n = 0;
            foreach (Target t in Targets(id))
                foreach (FileInfo f in Files(t)) { try { size += f.Length; n++; } catch { } }
            return new[] { size, n };
        }

        static volatile bool busy;
        public static string ScanJson()
        {
            List<string> items = new List<string>();
            foreach (string id in Ids)
            {
                long[] m = Measure(id);
                items.Add("{\"id\":\"" + id + "\",\"size\":" + m[0] + ",\"count\":" + m[1] + "}");
            }
            return "{\"admin\":" + (Program.IsAdmin() ? "true" : "false") + ",\"busy\":" + (busy ? "true" : "false") + ",\"items\":[" + string.Join(",", items.ToArray()) + "]}";
        }

        public static string Run(string ids)
        {
            if (busy) return "{\"ok\":false,\"error\":\"busy\"}";
            busy = true;
            try
            {
                List<string> res = new List<string>();
                long total = 0;
                foreach (string id in (ids ?? "").Split(',').Where(x => Ids.Contains(x)).Distinct())
                {
                    long freed = 0, n = 0, skipped = 0;
                    if (id == "recycle")
                    {
                        long[] before = Measure("recycle");
                        try { SHEmptyRecycleBin(IntPtr.Zero, null, 0x1 | 0x2 | 0x4); } catch { }
                        long[] after = Measure("recycle");
                        freed = Math.Max(0, before[0] - after[0]); n = Math.Max(0, before[1] - after[1]);
                    }
                    else
                    {
                        foreach (Target t in Targets(id))
                        {
                            foreach (FileInfo f in Files(t).ToList())
                            {
                                try { long len = f.Length; f.Attributes = FileAttributes.Normal; f.Delete(); freed += len; n++; }
                                catch { skipped++; }   // em uso ou sem permissão: fica
                            }
                            if (t.Recursive && t.Pattern == null) RemoveEmptyDirs(t.Path);
                        }
                    }
                    total += freed;
                    res.Add("{\"id\":\"" + id + "\",\"freed\":" + freed + ",\"files\":" + n + ",\"skipped\":" + skipped + "}");
                }
                return "{\"ok\":true,\"freed\":" + total + ",\"items\":[" + string.Join(",", res.ToArray()) + "]}";
            }
            finally { busy = false; }
        }

        static void RemoveEmptyDirs(string root)
        {
            try
            {
                if (!Directory.Exists(root)) return;
                foreach (string d in Directory.GetDirectories(root))
                {
                    try
                    {
                        if ((File.GetAttributes(d) & FileAttributes.ReparsePoint) != 0) continue;
                        RemoveEmptyDirs(d);
                        if (!Directory.EnumerateFileSystemEntries(d).Any()) Directory.Delete(d);
                    }
                    catch { }
                }
            }
            catch { }
        }
    }

    static class DiskScan
    {
        class DNode
        {
            public string Name; public DNode Parent;
            public List<DNode> Dirs;
            public List<KeyValuePair<string, long>> Files;   // maiores ficheiros desta pasta
            public long Size, FileCount, DirCount, OtherSize, OtherCount;
        }

        static readonly object lk = new object();
        static string state = "idle", error, scanPath;
        static DNode root;
        static DateTime started, finished, lastUse = DateTime.UtcNow;
        static long files, dirs, bytes;
        static Process gdu;
        static readonly List<KeyValuePair<string, long>> topFiles = new List<KeyValuePair<string, long>>();   // caminho completo
        static readonly Dictionary<string, long[]> exts = new Dictionary<string, long[]>(StringComparer.OrdinalIgnoreCase);
        const int TOP = 150, PER_DIR = 25;

        public static Process Proc { get { return gdu; } }
        public static string GduExe { get { return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "gdu", "gdu.exe"); } }

        static string Q(string x) { return x == null ? "null" : "\"" + x.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\n", " ").Replace("\r", " ") + "\""; }

        public static string StateJson()
        {
            lastUse = DateTime.UtcNow;
            lock (lk)
            {
                double el = state == "scanning" ? (DateTime.UtcNow - started).TotalSeconds : (finished - started).TotalSeconds;
                return "{\"state\":" + Q(state) + ",\"path\":" + Q(scanPath) + ",\"elapsed\":" + Math.Round(Math.Max(0, el), 1).ToString(CultureInfo.InvariantCulture) +
                       ",\"files\":" + files + ",\"dirs\":" + dirs + ",\"bytes\":" + bytes + ",\"error\":" + Q(error) +
                       ",\"has_gdu\":" + (File.Exists(GduExe) ? "true" : "false") + ",\"installing\":" + (installing ? "true" : "false") + "}";
            }
        }

        public static string Start(string path)
        {
            lastUse = DateTime.UtcNow;
            if (string.IsNullOrEmpty(path) || !Directory.Exists(path)) return "{\"ok\":false,\"error\":\"pasta inválida\"}";
            if (!File.Exists(GduExe)) return "{\"ok\":false,\"error\":\"gdu\"}";
            lock (lk)
            {
                if (state == "scanning") return "{\"ok\":false,\"error\":\"já está a analisar\"}";
                Free();
                state = "scanning"; error = null; scanPath = path; started = DateTime.UtcNow; files = dirs = bytes = 0;
            }
            Thread t = new Thread(() => Run(path), 64 * 1024 * 1024);   // pilha grande: pastas muito fundas
            t.IsBackground = true;
            t.Start();
            return "{\"ok\":true}";
        }

        public static void Stop()
        {
            try { if (gdu != null && !gdu.HasExited) gdu.Kill(); } catch { }
        }

        public static void Free()
        {
            lock (lk)
            {
                root = null; topFiles.Clear(); exts.Clear(); hidCache.Clear();
                if (state == "done" || state == "error") state = "idle";
            }
            GC.Collect();
        }

        // chamado a cada 5 s: apaga a análise da memória se ninguém a vê há 15 minutos
        public static void Housekeeping()
        {
            if (root != null && state == "done" && (DateTime.UtcNow - lastUse).TotalMinutes > 15) Free();
        }

        static void Run(string path)
        {
            try
            {
                string arg = path.TrimEnd('\\');
                if (arg.Length == 2 && arg[1] == ':') arg += "\\";
                ProcessStartInfo psi = new ProcessStartInfo(GduExe, "-n -p -o - \"" + arg + (arg.EndsWith("\\") ? "\\" : "") + "\"");
                psi.UseShellExecute = false; psi.CreateNoWindow = true;
                psi.RedirectStandardOutput = true; psi.RedirectStandardError = true;
                psi.StandardOutputEncoding = Encoding.UTF8;
                gdu = Process.Start(psi);
                try { gdu.PriorityClass = ProcessPriorityClass.BelowNormal; } catch { }
                gdu.ErrorDataReceived += delegate { };
                gdu.BeginErrorReadLine();
                Parser ps = new Parser(gdu.StandardOutput);
                DNode r = ps.ParseRoot();
                gdu.WaitForExit(5000);
                if (r == null) throw new Exception("o gdu não devolveu resultados");
                r.Name = path;
                lock (lk) { root = r; state = "done"; finished = DateTime.UtcNow; }
            }
            catch (Exception ex)
            {
                lock (lk) { state = "error"; error = ex.Message; finished = DateTime.UtcNow; root = null; }
            }
            finally
            {
                try { if (gdu != null) { if (!gdu.HasExited) gdu.Kill(); gdu.Dispose(); } } catch { }
                gdu = null;
                GC.Collect();
            }
        }

        // leitor de JSON em streaming para o formato do ncdu/gdu: [1,2,{info},[{pasta},{ficheiro},[subpasta...],...]]
        class Parser
        {
            readonly TextReader r;
            int peek = -2;
            readonly StringBuilder sb = new StringBuilder();
            public Parser(TextReader tr) { r = tr; }

            int Peek() { if (peek == -2) peek = r.Read(); return peek; }
            int Next() { int c = Peek(); peek = -2; return c; }
            void Ws() { while (true) { int c = Peek(); if (c == ' ' || c == '\n' || c == '\r' || c == '\t') Next(); else return; } }
            void Expect(char ch) { Ws(); int c = Next(); if (c != ch) throw new Exception("JSON inesperado do gdu"); }

            string Str()
            {
                Ws(); if (Next() != '"') throw new Exception("JSON inesperado do gdu");
                sb.Length = 0;
                while (true)
                {
                    int c = Next();
                    if (c == -1) throw new Exception("resultado do gdu incompleto");
                    if (c == '"') return sb.ToString();
                    if (c == '\\')
                    {
                        int e = Next();
                        switch (e)
                        {
                            case 'n': sb.Append('\n'); break;
                            case 't': sb.Append('\t'); break;
                            case 'r': sb.Append('\r'); break;
                            case 'b': sb.Append('\b'); break;
                            case 'f': sb.Append('\f'); break;
                            case 'u':
                                char[] h = new char[4];
                                for (int i = 0; i < 4; i++) h[i] = (char)Next();
                                sb.Append((char)Convert.ToInt32(new string(h), 16));
                                break;
                            default: sb.Append((char)e); break;
                        }
                    }
                    else sb.Append((char)c);
                }
            }

            // lê um valor simples (número/true/false/null) ou salta um valor composto
            string Scalar()
            {
                Ws();
                int c = Peek();
                if (c == '"') return Str();
                if (c == '{' || c == '[') { Skip(); return null; }
                StringBuilder t = new StringBuilder();
                while (true)
                {
                    c = Peek();
                    if (c == ',' || c == '}' || c == ']' || c == -1 || c == ' ' || c == '\n' || c == '\r') break;
                    t.Append((char)Next());
                }
                return t.ToString();
            }

            void Skip()
            {
                Ws();
                int c = Peek();
                if (c == '"') { Str(); return; }
                if (c == '{' || c == '[')
                {
                    char close = c == '{' ? '}' : ']';
                    Next();
                    Ws();
                    if (Peek() == close) { Next(); return; }
                    while (true)
                    {
                        if (c == '{') { Str(); Expect(':'); }
                        Skip(); Ws();
                        int n = Next();
                        if (n == close) return;
                        if (n != ',') throw new Exception("JSON inesperado do gdu");
                    }
                }
                Scalar();
            }

            // objeto de um ficheiro ou da própria pasta: devolve nome e tamanho em disco
            void Obj(out string name, out long size)
            {
                name = null; long asize = -1, dsize = -1;
                Expect('{'); Ws();
                if (Peek() == '}') { Next(); size = 0; return; }
                while (true)
                {
                    string k = Str(); Expect(':');
                    if (k == "name") { Ws(); name = Str(); }
                    else if (k == "asize" || k == "dsize")
                    {
                        string v = Scalar(); long n;
                        if (long.TryParse(v, out n)) { if (k == "asize") asize = n; else dsize = n; }
                    }
                    else Skip();
                    Ws();
                    int c = Next();
                    if (c == '}') break;
                    if (c != ',') throw new Exception("JSON inesperado do gdu");
                }
                size = dsize >= 0 ? dsize : Math.Max(0, asize);
            }

            public DNode ParseRoot()
            {
                Expect('[');
                Skip(); Expect(',');      // versão principal
                Skip(); Expect(',');      // versão secundária
                Skip(); Expect(',');      // informação do programa
                Ws();
                DNode d = Dir(null);
                return d;
            }

            DNode Dir(DNode parent)
            {
                Expect('[');
                string name; long ignore;
                Obj(out name, out ignore);
                DNode d = new DNode { Name = name ?? "?", Parent = parent };
                Interlocked.Increment(ref dirs);
                while (true)
                {
                    Ws();
                    int c = Next();
                    if (c == ']') break;
                    if (c != ',') throw new Exception("JSON inesperado do gdu");
                    Ws();
                    if (Peek() == '[')
                    {
                        DNode sub = Dir(d);
                        if (d.Dirs == null) d.Dirs = new List<DNode>();
                        d.Dirs.Add(sub);
                        d.Size += sub.Size; d.FileCount += sub.FileCount; d.DirCount += sub.DirCount + 1;
                    }
                    else
                    {
                        string fn; long fs;
                        Obj(out fn, out fs);
                        AddFile(d, fn ?? "?", fs);
                    }
                }
                if (d.Dirs != null) d.Dirs.Sort((a, b) => b.Size.CompareTo(a.Size));
                if (d.Files != null) d.Files.Sort((a, b) => b.Value.CompareTo(a.Value));
                return d;
            }

            void AddFile(DNode d, string name, long size)
            {
                d.Size += size; d.FileCount++;
                Interlocked.Increment(ref files);
                Interlocked.Add(ref bytes, size);
                // pasta: guarda os maiores, o resto fica somado
                if (d.Files == null) d.Files = new List<KeyValuePair<string, long>>();
                d.Files.Add(new KeyValuePair<string, long>(name, size));
                if (d.Files.Count > PER_DIR * 2)
                {
                    d.Files.Sort((a, b) => b.Value.CompareTo(a.Value));
                    for (int i = PER_DIR; i < d.Files.Count; i++) { d.OtherSize += d.Files[i].Value; d.OtherCount++; }
                    d.Files.RemoveRange(PER_DIR, d.Files.Count - PER_DIR);
                }
                // tipos de ficheiro
                int dot = name.LastIndexOf('.');
                string ext = dot > 0 && name.Length - dot <= 10 ? name.Substring(dot + 1).ToLowerInvariant() : "(sem extensão)";
                long[] e;
                if (!exts.TryGetValue(ext, out e)) exts[ext] = e = new long[2];
                e[0] += size; e[1]++;
                // maiores ficheiros do disco
                if (topFiles.Count < TOP || size > topFiles[topFiles.Count - 1].Value)
                {
                    topFiles.Add(new KeyValuePair<string, long>(FullPath(d) + "\\" + name, size));
                    if (topFiles.Count > TOP * 2)
                    {
                        topFiles.Sort((a, b) => b.Value.CompareTo(a.Value));
                        topFiles.RemoveRange(TOP, topFiles.Count - TOP);
                    }
                    else if (topFiles.Count <= TOP) topFiles.Sort((a, b) => b.Value.CompareTo(a.Value));
                }
            }
        }

        // ficheiros/pastas ocultos (atributo do Windows): aparecem censurados até ativares a opção
        static readonly Dictionary<string, bool> hidCache = new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);
        static bool Censor { get { return !AppSettings.ShowHidden; } }
        static bool IsHiddenItem(string full)
        {
            bool h;
            if (hidCache.TryGetValue(full, out h)) return h;
            try { h = UserHidden(full, File.GetAttributes(full)); } catch { h = false; }
            if (hidCache.Count > 200000) hidCache.Clear();
            hidCache[full] = h;
            return h;
        }
        // só conta como "oculto" o que TU escondeste: o que o Windows ou os programas escondem fica à vista
        static readonly HashSet<string> WinHidden = new HashSet<string>(new[] {
            "appdata", "programdata", "$recycle.bin", "system volume information", "recovery", "$winreagent", "$sysreset",
            "$windows.~bt", "$windows.~ws", "$getcurrent", "config.msi", "documents and settings", "msocache", "perflogs", "boot",
            "pagefile.sys", "hiberfil.sys", "swapfile.sys", "dumpstack.log", "dumpstack.log.tmp", "bootmgr", "bootnxt", "bootsect.bak",
            "desktop.ini", "thumbs.db", "iconcache.db", "ntuser.ini", "ntuser.pol", "application data", "local settings", "cookies",
            "nethood", "printhood", "recent", "sendto", "start menu", "templates", "my documents", "meus documentos", "mis documentos",
            "mes documents", "eigene dateien", "default", "default user", "all users", "public", "onedrivetemp", "intel", "amd", "nvidia" },
            StringComparer.OrdinalIgnoreCase);
        static bool UserHidden(string full, FileAttributes a)
        {
            if ((a & FileAttributes.Hidden) == 0) return false;
            if ((a & (FileAttributes.System | FileAttributes.ReparsePoint)) != 0) return false;   // do sistema ou atalho do Windows
            string name = Path.GetFileName(full.TrimEnd('\\'));
            if (WinHidden.Contains(name) || name.StartsWith("ntuser.", StringComparison.OrdinalIgnoreCase) ||
                name.StartsWith("$", StringComparison.Ordinal) || name.StartsWith("~", StringComparison.Ordinal)) return false;
            string low = full.ToLowerInvariant();
            foreach (string root in SysRoots) if (low.StartsWith(root)) return false;              // escondido por programas/Windows
            if (low.Contains("\\appdata\\")) return false;
            return true;
        }
        static string[] sysRoots;
        static string[] SysRoots
        {
            get
            {
                if (sysRoots == null)
                {
                    List<string> l = new List<string>();
                    foreach (Environment.SpecialFolder f in new[] { Environment.SpecialFolder.Windows, Environment.SpecialFolder.ProgramFiles,
                             Environment.SpecialFolder.ProgramFilesX86, Environment.SpecialFolder.CommonApplicationData })
                    { string x = Environment.GetFolderPath(f); if (!string.IsNullOrEmpty(x)) l.Add(x.TrimEnd('\\').ToLowerInvariant() + "\\"); }
                    sysRoots = l.ToArray();
                }
                return sysRoots;
            }
        }

        // algum nível do caminho (abaixo da pasta analisada) está oculto?
        static bool HiddenPath(string full)
        {
            if (root == null || string.IsNullOrEmpty(full)) return false;
            string rp = FullPath(root).TrimEnd('\\');
            if (!full.StartsWith(rp + "\\", StringComparison.OrdinalIgnoreCase)) return false;
            string acc = rp;
            foreach (string part in full.Substring(rp.Length + 1).Split(new[] { '\\' }, StringSplitOptions.RemoveEmptyEntries))
            {
                acc += "\\" + part;
                if (IsHiddenItem(acc)) return true;
            }
            return false;
        }
        public static bool Blocked(string full) { lock (lk) return Censor && HiddenPath(full); }

        static string FullPath(DNode d)
        {
            List<string> parts = new List<string>();
            for (DNode x = d; x != null; x = x.Parent) parts.Add(x.Name.TrimEnd('\\'));
            parts.Reverse();
            return string.Join("\\", parts.ToArray());
        }

        static DNode Find(string rel)
        {
            DNode d = root;
            if (d == null || string.IsNullOrEmpty(rel)) return d;
            foreach (string part in rel.Split(new[] { '\\', '/' }, StringSplitOptions.RemoveEmptyEntries))
            {
                if (d.Dirs == null) return null;
                DNode nx = d.Dirs.FirstOrDefault(x => string.Equals(x.Name, part, StringComparison.OrdinalIgnoreCase));
                if (nx == null) return null;
                d = nx;
            }
            return d;
        }

        static string Kids(DNode d, int depth, int max)
        {
            List<string> items = new List<string>();
            string dFull = FullPath(d).TrimEnd('\\') + "\\";
            bool cen = Censor;
            int n = 0; long rest = 0; long restCount = 0;
            if (d.Dirs != null)
                foreach (DNode c in d.Dirs)
                {
                    if (n++ >= max) { rest += c.Size; restCount++; continue; }
                    if (cen && IsHiddenItem(dFull + c.Name)) { items.Add("{\"name\":\"\",\"hidden\":true,\"dir\":true,\"size\":" + c.Size + "}"); continue; }
                    items.Add("{\"name\":" + Q(c.Name) + ",\"dir\":true,\"size\":" + c.Size + ",\"files\":" + c.FileCount + ",\"dirs\":" + c.DirCount +
                              (depth > 1 ? ",\"kids\":" + Kids(c, depth - 1, 12) : "") + "}");
                }
            if (d.Files != null)
                foreach (KeyValuePair<string, long> f in d.Files)
                {
                    if (n++ >= max) { rest += f.Value; restCount++; continue; }
                    if (cen && IsHiddenItem(dFull + f.Key)) { items.Add("{\"name\":\"\",\"hidden\":true,\"dir\":false,\"size\":" + f.Value + "}"); continue; }
                    items.Add("{\"name\":" + Q(f.Key) + ",\"dir\":false,\"size\":" + f.Value + "}");
                }
            if (d.OtherCount + restCount > 0)
                items.Add("{\"name\":\"\",\"other\":true,\"dir\":false,\"size\":" + (d.OtherSize + rest) + ",\"count\":" + (d.OtherCount + restCount) + "}");
            return "[" + string.Join(",", items.ToArray()) + "]";
        }

        // conteúdo de uma pasta (2 níveis para o mapa)
        public static string DirJson(string rel)
        {
            lastUse = DateTime.UtcNow;
            lock (lk)
            {
                DNode d = Find(rel);
                if (d == null) return "{\"ok\":false}";
                if (Censor && d != root && HiddenPath(FullPath(d))) return "{\"ok\":false,\"hidden\":true}";
                return "{\"ok\":true,\"path\":" + Q(FullPath(d)) + ",\"rel\":" + Q(rel ?? "") + ",\"size\":" + d.Size + ",\"files\":" + d.FileCount +
                       ",\"dirs\":" + d.DirCount + ",\"kids\":" + Kids(d, 2, 300) + "}";
            }
        }

        public static string TopJson()
        {
            lastUse = DateTime.UtcNow;
            lock (lk)
            {
                if (root == null) return "{\"files\":[],\"exts\":[]}";
                bool cen = Censor;
                string f = string.Join(",", topFiles.Take(TOP).Select(x => cen && HiddenPath(x.Key)
                    ? "{\"path\":\"\",\"hidden\":true,\"size\":" + x.Value + "}"
                    : "{\"path\":" + Q(x.Key) + ",\"size\":" + x.Value + "}").ToArray());
                string e = string.Join(",", exts.OrderByDescending(x => x.Value[0]).Take(40)
                    .Select(x => "{\"ext\":" + Q(x.Key) + ",\"size\":" + x.Value[0] + ",\"count\":" + x.Value[1] + "}").ToArray());
                return "{\"files\":[" + f + "],\"exts\":[" + e + "]}";
            }
        }

        // abre a pasta (ou mostra o ficheiro) no Explorador, sem administrador
        public static void Open(string full)
        {
            try
            {
                if (string.IsNullOrEmpty(full) || Blocked(full)) return;
                if (File.Exists(full)) Front.Explorer("/select,\"" + full + "\"");
                else if (Directory.Exists(full)) Front.Explorer("\"" + full + "\"");
            }
            catch { }
        }

        // eliminar um ficheiro/pasta da análise: para a Reciclagem ou de vez (só no PC)
        // quão perigoso é apagar isto? block = o NEXUS não deixa; danger/warn = pede confirmação; ok = normal
        public static string[] Risk(string full)
        {
            string f;
            try { f = Path.GetFullPath(full).TrimEnd('\\'); } catch { return new[] { "block", "root" }; }
            string low = f.ToLowerInvariant(), name = Path.GetFileName(f).ToLowerInvariant();
            Func<Environment.SpecialFolder, string> sf = x => { string v = Environment.GetFolderPath(x); return string.IsNullOrEmpty(v) ? "\0" : v.TrimEnd('\\').ToLowerInvariant(); };
            Func<string, string, bool> under = (a, b) => a.StartsWith(b + "\\");
            string win = sf(Environment.SpecialFolder.Windows), pf = sf(Environment.SpecialFolder.ProgramFiles), pf86 = sf(Environment.SpecialFolder.ProgramFilesX86),
                   pd = sf(Environment.SpecialFolder.CommonApplicationData), prof = sf(Environment.SpecialFolder.UserProfile);
            string users = Path.GetDirectoryName(prof) ?? "\0", parent = (Path.GetDirectoryName(f) ?? "").ToLowerInvariant();
            string nexus = AppDomain.CurrentDomain.BaseDirectory.TrimEnd('\\').ToLowerInvariant();
            string temp = Path.GetTempPath().TrimEnd('\\').ToLowerInvariant();

            if (f.Length <= 3) return new[] { "block", "root" };
            if (low == nexus || under(low, nexus)) return new[] { "block", "nexus" };
            if (under(low, win + "\\temp")) return new[] { "ok", "" };
            if (under(low, win + "\\softwaredistribution\\download")) return new[] { "ok", "" };
            if (low == win || under(low, win)) return new[] { "block", "windows" };
            if (low == pf || low == pf86) return new[] { "block", "pf_root" };
            if (under(low, pf) || under(low, pf86)) return new[] { "danger", "program" };
            if (low == pd) return new[] { "block", "pd_root" };
            if (under(low, pd + "\\microsoft")) return new[] { "danger", "pd_ms" };
            if (under(low, pd)) return new[] { "danger", "programdata" };
            if (low == users || parent == users) return new[] { "block", "profile" };
            if (name == "appdata" || ((name == "local" || name == "roaming" || name == "locallow") && parent.EndsWith("\\appdata"))) return new[] { "block", "appdata_root" };
            if (low == temp || under(low, temp)) return low == temp ? new[] { "warn", "temp_root" } : new[] { "ok", "" };
            if (low.Contains("\\appdata\\roaming\\microsoft") || low.Contains("\\appdata\\local\\microsoft")) return new[] { "danger", "appdata_ms" };
            if (low.Contains("\\appdata\\roaming\\")) return new[] { "danger", "roaming" };
            if (low.Contains("\\appdata\\local\\") || low.Contains("\\appdata\\locallow\\")) return new[] { "warn", "local" };
            string[] sysNames = { "system volume information", "recovery", "$winreagent", "boot", "efi", "bootmgr", "bootnxt", "pagefile.sys",
                                  "hiberfil.sys", "swapfile.sys", "dumpstack.log.tmp", "$sysreset" };
            if (sysNames.Contains(name) || name.StartsWith("ntuser.")) return new[] { "block", "system_file" };
            if (name == "$recycle.bin") return new[] { "warn", "recycle" };
            if (name == "windows.old") return new[] { "warn", "winold" };
            if (name == "$windows.~bt" || name == "$windows.~ws" || name == "$getcurrent") return new[] { "warn", "upgrade" };
            if (parent == prof && new[] { "desktop", "documents", "downloads", "pictures", "music", "videos", "onedrive", "saved games", "favorites", "contacts" }.Contains(name))
                return new[] { "danger", "personal" };
            return new[] { "ok", "" };
        }
        public static string RiskJson(string full)
        {
            if (Blocked(full)) return "{\"level\":\"hidden\",\"key\":\"\"}";
            string[] r = Risk(full);
            return "{\"level\":\"" + r[0] + "\",\"key\":\"" + r[1] + "\"}";
        }

        public static string Delete(string full, bool permanent) { return Delete(full, permanent, false); }
        public static string Delete(string full, bool permanent, bool confirmed)
        {
            lastUse = DateTime.UtcNow;
            string rootPath;
            lock (lk) { if (root == null || state != "done") return "{\"ok\":false,\"error\":\"no_scan\"}"; rootPath = FullPath(root); }
            if (string.IsNullOrEmpty(full)) return "{\"ok\":false,\"error\":\"bad_path\"}";
            try { full = Path.GetFullPath(full).TrimEnd('\\'); } catch { return "{\"ok\":false,\"error\":\"bad_path\"}"; }
            string rp = rootPath.TrimEnd('\\');
            string win = Environment.GetFolderPath(Environment.SpecialFolder.Windows).TrimEnd('\\');
            bool inside = full.StartsWith(rp + "\\", StringComparison.OrdinalIgnoreCase);
            bool isDriveRoot = full.Length <= 3;
            if (!inside || isDriveRoot) return "{\"ok\":false,\"error\":\"outside\"}";
            string[] risk = Risk(full);
            if (risk[0] == "block") return "{\"ok\":false,\"error\":\"blocked\",\"key\":\"" + risk[1] + "\"}";
            if (risk[0] != "ok" && !confirmed) return "{\"ok\":false,\"error\":\"confirm\",\"key\":\"" + risk[1] + "\"}";
            if (Blocked(full)) return "{\"ok\":false,\"error\":\"hidden\"}";
            bool isDir = Directory.Exists(full), isFile = !isDir && File.Exists(full);
            try
            {
                var ui = Microsoft.VisualBasic.FileIO.UIOption.OnlyErrorDialogs;
                var rec = permanent ? Microsoft.VisualBasic.FileIO.RecycleOption.DeletePermanently : Microsoft.VisualBasic.FileIO.RecycleOption.SendToRecycleBin;
                if (isDir) Microsoft.VisualBasic.FileIO.FileSystem.DeleteDirectory(full, ui, rec);
                else if (isFile) Microsoft.VisualBasic.FileIO.FileSystem.DeleteFile(full, ui, rec);
            }
            catch (OperationCanceledException) { return "{\"ok\":false,\"error\":\"cancelled\"}"; }
            catch (Exception ex) { return "{\"ok\":false,\"error\":" + Q(ex.Message) + "}"; }
            if (Directory.Exists(full) || File.Exists(full)) return "{\"ok\":false,\"error\":\"still_there\"}";
            lock (lk) RemoveFromTree(full.Substring(rp.Length + 1), isDir);
            return "{\"ok\":true}";
        }

        // tira o item da árvore em memória e acerta os totais (sem voltar a analisar)
        static void RemoveFromTree(string rel, bool isDir)
        {
            if (root == null) return;
            int cut = rel.LastIndexOf('\\');
            DNode parent = Find(cut < 0 ? "" : rel.Substring(0, cut));
            string name = cut < 0 ? rel : rel.Substring(cut + 1);
            if (parent == null) return;
            long size = 0, fcount = 0, dcount = 0;
            DNode gone = isDir && parent.Dirs != null ? parent.Dirs.FirstOrDefault(x => string.Equals(x.Name, name, StringComparison.OrdinalIgnoreCase)) : null;
            if (gone != null)
            {
                parent.Dirs.Remove(gone);
                size = gone.Size; fcount = gone.FileCount; dcount = gone.DirCount + 1;
            }
            else if (!isDir && parent.Files != null)
            {
                int i = parent.Files.FindIndex(x => string.Equals(x.Key, name, StringComparison.OrdinalIgnoreCase));
                if (i >= 0) { size = parent.Files[i].Value; parent.Files.RemoveAt(i); fcount = 1; }
            }
            if (!isDir && fcount == 0)   // estava no grupo "outros itens"
            {
                string fp = FullPath(root).TrimEnd('\\') + "\\" + rel;
                int t = topFiles.FindIndex(x => string.Equals(x.Key, fp, StringComparison.OrdinalIgnoreCase));
                if (t >= 0) size = topFiles[t].Value;
                if (parent.OtherCount > 0) { parent.OtherCount--; parent.OtherSize = Math.Max(0, parent.OtherSize - size); }
                fcount = 1;
            }
            for (DNode x = parent; x != null; x = x.Parent)
            {
                x.Size = Math.Max(0, x.Size - size); x.FileCount = Math.Max(0, x.FileCount - fcount); x.DirCount = Math.Max(0, x.DirCount - dcount);
                if (x.Parent != null && x.Parent.Dirs != null) x.Parent.Dirs.Sort((a, b) => b.Size.CompareTo(a.Size));
            }
            files = Math.Max(0, files - fcount); dirs = Math.Max(0, dirs - dcount); bytes = Math.Max(0, bytes - size);
            string full = FullPath(root).TrimEnd('\\') + "\\" + rel;
            topFiles.RemoveAll(x => string.Equals(x.Key, full, StringComparison.OrdinalIgnoreCase) ||
                                    (isDir && x.Key.StartsWith(full + "\\", StringComparison.OrdinalIgnoreCase)));
            if (!isDir)
            {
                int dot = name.LastIndexOf('.');
                string ext = dot > 0 && name.Length - dot <= 10 ? name.Substring(dot + 1).ToLowerInvariant() : "(sem extensão)";
                long[] e;
                if (exts.TryGetValue(ext, out e)) { e[0] = Math.Max(0, e[0] - size); e[1] = Math.Max(0, e[1] - 1); if (e[1] == 0) exts.Remove(ext); }
            }
        }

        // descarregar o gdu se não veio com o instalador
        static volatile bool installing;
        public static string Install()
        {
            if (installing || File.Exists(GduExe)) return "{\"ok\":true}";
            installing = true;
            ThreadPool.QueueUserWorkItem(delegate
            {
                try
                {
                    string dir = Path.GetDirectoryName(GduExe), zip = Path.Combine(Path.GetTempPath(), "nexus_gdu.zip");
                    Directory.CreateDirectory(dir);
                    // um apóstrofo no nome do utilizador (ex.: O'Neil) partia o comando: escapa-se para o PowerShell
                    string gq = GduExe.Replace("'", "''"); dir = dir.Replace("'", "''"); zip = zip.Replace("'", "''");
                    string ps = "$ErrorActionPreference='Stop'; [Net.ServicePointManager]::SecurityProtocol='Tls12'; " +
                                "Invoke-WebRequest -UseBasicParsing 'https://github.com/dundee/gdu/releases/latest/download/gdu_windows_amd64.exe.zip' -OutFile '" + zip + "'; " +
                                "Expand-Archive -LiteralPath '" + zip + "' -DestinationPath '" + dir + "' -Force; " +
                                "Get-ChildItem -LiteralPath '" + dir + "' -Filter 'gdu*.exe' | Where-Object { $_.Name -ne 'gdu.exe' } | Select-Object -First 1 | Move-Item -Destination '" + gq + "' -Force; " +
                                "Remove-Item -LiteralPath '" + zip + "' -Force";
                    ProcessStartInfo psi = new ProcessStartInfo("powershell.exe", "-NoProfile -ExecutionPolicy Bypass -Command \"" + ps.Replace("\"", "\\\"") + "\"");
                    psi.UseShellExecute = false; psi.CreateNoWindow = true;
                    using (Process p = Process.Start(psi)) p.WaitForExit(120000);
                }
                catch { }
                installing = false;
            });
            return "{\"ok\":true}";
        }
    }

    static class Uninstaller
    {
        class App
        {
            public string Id, Name, Pub, Ver, Loc, Uninst, Quiet, Icon, Date, Key, Hive, Family, StoreFull;
            public bool View32, Store;
            public long Size = -1;
        }
        class Item
        {
            public int N;
            public string Kind, Label, Path, Extra, Level, Prog;
            public long Size = -1;
            public bool Admin;
        }

        static readonly object lk = new object();
        static List<App> apps = new List<App>(), store = null;
        static bool storeLoading;
        static readonly Dictionary<string, long> sizes = new Dictionary<string, long>(StringComparer.OrdinalIgnoreCase);
        static readonly Dictionary<string, byte[]> icons = new Dictionary<string, byte[]>();
        static Thread sizer;

        // estado da desinstalação em curso
        static App cur;
        static List<App> queue = new List<App>();
        static List<string> kept = new List<string>(), removed = new List<string>();
        static int qi;
        static string phase = "idle", msg = "";
        static bool keyGone, forced, quietMode;
        static List<Item> found = new List<Item>();
        static DateTime started;
        static volatile bool abandon;

        // JSON seguro: alguns programas gravam o nome no registo com caracteres nulos/de controlo no fim
        static string Q(string v)
        {
            if (v == null) return "null";
            StringBuilder b = new StringBuilder(v.Length + 2).Append('"');
            foreach (char c in v)
            {
                if (c == '\\') b.Append("\\\\");
                else if (c == '"') b.Append("\\\"");
                else if (c < ' ') { if (c == '\t' || c == '\r' || c == '\n') b.Append(' '); }
                else b.Append(c);
            }
            return b.Append('"').ToString();
        }
        static string S(object o)
        {
            if (o == null) return null;
            string v = new string(Convert.ToString(o).Where(c => c >= ' ' || c == '\t').ToArray()).Trim();
            return v.Length == 0 ? null : v;
        }

        // ---------------------------------------------------------------- lista
        public static string ListJson(bool withStore)
        {
            List<App> list = Read();
            lock (lk) apps = list;
            StartSizer(list);
            if (withStore && store == null && !storeLoading) { storeLoading = true; new Thread(LoadStore) { IsBackground = true }.Start(); }
            StringBuilder sb = new StringBuilder("{\"ok\":true,\"admin\":" + (Program.IsAdmin() ? "true" : "false") + ",\"sizing\":" + (sizer != null && sizer.IsAlive ? "true" : "false") +
                ",\"storeLoading\":" + (storeLoading ? "true" : "false") + ",\"apps\":[");
            List<App> all = new List<App>(list);
            lock (lk) if (withStore && store != null) all.AddRange(store);
            bool first = true;
            foreach (App a in all)
            {
                long sz = a.Size;
                if (sz < 0 && !string.IsNullOrEmpty(a.Loc)) lock (sizes) { long v; if (sizes.TryGetValue(a.Loc, out v)) sz = v; }
                if (!first) sb.Append(','); first = false;
                sb.Append("{\"id\":").Append(Q(a.Id)).Append(",\"name\":").Append(Q(a.Name)).Append(",\"pub\":").Append(Q(a.Pub)).Append(",\"ver\":").Append(Q(a.Ver))
                  .Append(",\"size\":").Append(sz).Append(",\"date\":").Append(Q(a.Date)).Append(",\"loc\":").Append(Q(a.Loc))
                  .Append(",\"store\":").Append(a.Store ? "true" : "false").Append(",\"icon\":").Append(!a.Store && !string.IsNullOrEmpty(a.Icon) ? "true" : "false").Append('}');
            }
            return sb.Append("]}").ToString();
        }

        static List<App> Read()
        {
            List<App> list = new List<App>();
            HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            ReadHive(list, seen, RegistryHive.LocalMachine, RegistryView.Registry64, "lm64");
            if (Environment.Is64BitOperatingSystem) ReadHive(list, seen, RegistryHive.LocalMachine, RegistryView.Registry32, "lm32");
            ReadHive(list, seen, RegistryHive.CurrentUser, RegistryView.Registry64, "cu64");
            if (Environment.Is64BitOperatingSystem) ReadHive(list, seen, RegistryHive.CurrentUser, RegistryView.Registry32, "cu32");
            return list.OrderBy(a => a.Name, StringComparer.CurrentCultureIgnoreCase).ToList();
        }

        const string UN = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall";
        static void ReadHive(List<App> list, HashSet<string> seen, RegistryHive hive, RegistryView view, string tag)
        {
            try
            {
                using (RegistryKey bk = RegistryKey.OpenBaseKey(hive, view))
                using (RegistryKey un = bk.OpenSubKey(UN))
                {
                    if (un == null) return;
                    foreach (string sub in un.GetSubKeyNames())
                    {
                        try
                        {
                            using (RegistryKey k = un.OpenSubKey(sub))
                            {
                                if (k == null) continue;
                                string name = S(k.GetValue("DisplayName"));
                                if (string.IsNullOrEmpty(name)) continue;
                                if (Convert.ToString(k.GetValue("SystemComponent")) == "1") continue;
                                if (k.GetValue("ParentKeyName") != null) continue;
                                string rt = S(k.GetValue("ReleaseType")) ?? "";
                                if (rt.IndexOf("update", StringComparison.OrdinalIgnoreCase) >= 0 || rt.IndexOf("hotfix", StringComparison.OrdinalIgnoreCase) >= 0) continue;
                                string un1 = S(k.GetValue("UninstallString")), q = S(k.GetValue("QuietUninstallString"));
                                if (string.IsNullOrEmpty(un1) && string.IsNullOrEmpty(q)) continue;
                                if (sub == "NEXUS Monitor") continue;     // o próprio NEXUS tem o desinstalador dele
                                string dedupe = name + "|" + (S(k.GetValue("DisplayVersion")) ?? "");
                                if (!seen.Add(dedupe)) continue;
                                App a = new App();
                                a.Id = "r:" + tag + ":" + sub; a.Key = sub; a.Hive = tag.Substring(0, 2); a.View32 = tag.EndsWith("32");
                                a.Name = name; a.Pub = S(k.GetValue("Publisher")); a.Ver = S(k.GetValue("DisplayVersion"));
                                a.Uninst = un1; a.Quiet = q;
                                string loc = S(k.GetValue("InstallLocation"));
                                if (!string.IsNullOrEmpty(loc)) { loc = loc.Trim('"').TrimEnd('\\'); if (loc.Length <= 3 || !Directory.Exists(loc) || BadLoc(loc)) loc = null; }
                                if (loc == null) loc = GuessLoc(S(k.GetValue("DisplayIcon")), un1, name);
                                a.Loc = loc;
                                a.Icon = S(k.GetValue("DisplayIcon"));
                                object es = k.GetValue("EstimatedSize");
                                if (es is int && (int)es > 0) a.Size = (long)(int)es * 1024;
                                string d = S(k.GetValue("InstallDate"));
                                if (d != null && d.Length == 8 && d.All(char.IsDigit)) a.Date = d.Substring(0, 4) + "-" + d.Substring(4, 2) + "-" + d.Substring(6, 2);
                                list.Add(a);
                            }
                        }
                        catch { }
                    }
                }
            }
            catch { }
        }

        // sem InstallLocation: tenta a pasta do ícone ou do desinstalador (se não for uma pasta do Windows)
        // pastas que não podem ser "a pasta do programa" (são partilhadas por muitos)
        static readonly string[] BadLocNames = { "common files", "microsoft", "windows", "windowsapps", "programs", "program files", "program files x86", "programdata",
            "appdata", "local", "roaming", "locallow", "users", "bin", "x64", "x86", "temp", "tmp", "system32", "syswow64", "installer", "package cache", "downloads", "desktop", "documents" };
        static bool BadLoc(string loc)
        {
            if (loc == null || loc.TrimEnd('\\').Length <= 3) return true;
            if (BadLocNames.Contains(Norm(Path.GetFileName(loc.TrimEnd('\\'))))) return true;
            return !SafeFolder(loc, true) || DiskScan.Risk(loc)[1] == "personal";
        }
        static string GuessLoc(string icon, string un, string appName)
        {
            string nn = Norm(appName);
            foreach (string s in new[] { icon, un })
            {
                string exe = ExeOf(s);
                if (exe == null || !File.Exists(exe)) continue;
                string dir = Path.GetDirectoryName(exe);
                if (dir == null || dir.Length <= 3 || !SafeFolder(dir, true)) continue;
                string nm = Path.GetFileName(dir).ToLowerInvariant();
                if (nm == "uninstall" || nm == "uninst" || nm == "bin") dir = Path.GetDirectoryName(dir);
                if (dir == null || BadLoc(dir)) continue;
                // só se a pasta tiver o nome do programa (senão podia ser uma pasta partilhada da empresa)
                string nd = Norm(Path.GetFileName(dir.TrimEnd('\\')));
                string w = nn.Split(' ').FirstOrDefault(x => x.Length >= 3) ?? "";
                if (nd.Length >= 3 && (nn.Contains(nd) || (w.Length >= 3 && nd.Contains(w)))) return dir.TrimEnd('\\');
            }
            return null;
        }

        static string ExeOf(string cmd)
        {
            if (string.IsNullOrEmpty(cmd)) return null;
            cmd = cmd.Trim();
            if (cmd.StartsWith("\"")) { int e = cmd.IndexOf('"', 1); return e > 1 ? cmd.Substring(1, e - 1) : null; }
            int c = cmd.IndexOf(','); if (c > 0 && cmd.IndexOf(".exe", StringComparison.OrdinalIgnoreCase) < 0) cmd = cmd.Substring(0, c);
            int x = cmd.IndexOf(".exe", StringComparison.OrdinalIgnoreCase);
            if (x > 0) return cmd.Substring(0, x + 4);
            int i = cmd.IndexOf(".ico", StringComparison.OrdinalIgnoreCase);
            if (i > 0) return cmd.Substring(0, i + 4);
            return File.Exists(cmd) ? cmd : null;
        }

        // tamanho das pastas que o registo não diz (em segundo plano, só uma vez)
        static void StartSizer(List<App> list)
        {
            List<string> todo;
            lock (sizes) todo = list.Where(a => a.Size < 0 && a.Loc != null && !sizes.ContainsKey(a.Loc)).Select(a => a.Loc).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            if (todo.Count == 0 || (sizer != null && sizer.IsAlive)) return;
            sizer = new Thread(() =>
            {
                foreach (string d in todo)
                {
                    long n = FolderSize(d, 300000);
                    lock (sizes) sizes[d] = n;
                }
            });
            sizer.IsBackground = true; sizer.Priority = ThreadPriority.BelowNormal; sizer.Start();
        }

        static long FolderSize(string dir, int maxFiles)
        {
            long total = 0; int n = 0;
            Stack<string> st = new Stack<string>(); st.Push(dir);
            while (st.Count > 0 && n < maxFiles)
            {
                string d = st.Pop();
                try
                {
                    DirectoryInfo di = new DirectoryInfo(d);
                    if ((di.Attributes & FileAttributes.ReparsePoint) != 0 && d != dir) continue;
                    foreach (FileInfo f in di.EnumerateFiles()) { total += f.Length; if (++n >= maxFiles) break; }
                    foreach (DirectoryInfo s in di.EnumerateDirectories()) st.Push(s.FullName);
                }
                catch { }
            }
            return total;
        }

        // apps da Loja (só as que se podem tirar; as do sistema ficam de fora)
        static void LoadStore()
        {
            List<App> list = new List<App>();
            try
            {
                string ps = "$ErrorActionPreference='SilentlyContinue';[Console]::OutputEncoding=[Text.Encoding]::UTF8;" +
                    "Get-AppxPackage | ?{ -not $_.IsFramework -and -not $_.NonRemovable -and $_.SignatureKind -eq 'Store' -and -not $_.IsResourcePackage } | %{ " +
                    "$m = Get-AppxPackageManifest $_; $n = $m.Package.Properties.DisplayName; if(-not $n -or $n -like 'ms-resource*'){ $n = $_.Name }; " +
                    "$p = $m.Package.Properties.PublisherDisplayName; if($p -like 'ms-resource*'){ $p = '' }; " +
                    "$sz = 0; if($_.InstallLocation){ $sz = (Get-ChildItem -LiteralPath $_.InstallLocation -Recurse -File -Force | Measure-Object Length -Sum).Sum }; " +
                    "@($n, $p, $_.Version, $_.PackageFullName, $_.PackageFamilyName, $_.InstallLocation, [int64]$sz) -join \"`t\" }";
                ProcessStartInfo psi = new ProcessStartInfo("powershell.exe", "-NoProfile -ExecutionPolicy Bypass -Command \"" + ps.Replace("\"", "\\\"") + "\"");
                psi.UseShellExecute = false; psi.CreateNoWindow = true; psi.RedirectStandardOutput = true; psi.StandardOutputEncoding = Encoding.UTF8;
                using (Process p = Process.Start(psi))
                {
                    string line;
                    while ((line = p.StandardOutput.ReadLine()) != null)
                    {
                        string[] c = line.Split('\t');
                        if (c.Length < 7 || string.IsNullOrEmpty(c[0])) continue;
                        App a = new App();
                        a.Store = true; a.Name = c[0].Trim(); a.Pub = c[1].Trim(); a.Ver = c[2].Trim(); a.StoreFull = c[3].Trim(); a.Family = c[4].Trim();
                        a.Loc = c[5].Trim(); a.Id = "s:" + a.StoreFull;
                        long sz; if (long.TryParse(c[6].Trim(), out sz)) a.Size = sz;
                        list.Add(a);
                    }
                    p.WaitForExit(60000);
                }
            }
            catch { }
            lock (lk) { store = list.OrderBy(a => a.Name, StringComparer.CurrentCultureIgnoreCase).ToList(); storeLoading = false; }
        }

        // ícone do programa em PNG (32x32), guardado em memória
        public static byte[] IconPng(string id)
        {
            lock (icons) { byte[] b; if (icons.TryGetValue(id, out b)) return b; }
            byte[] png = null;
            try
            {
                App a; lock (lk) a = apps.FirstOrDefault(x => x.Id == id);
                string f = a == null ? null : ExeOf(a.Icon);
                if (f != null && File.Exists(f))
                {
                    Icon ic = f.EndsWith(".ico", StringComparison.OrdinalIgnoreCase) ? new Icon(f, 32, 32) : Icon.ExtractAssociatedIcon(f);
                    if (ic != null)
                        using (ic)
                        using (Bitmap bm = new Bitmap(32, 32))
                        {
                            using (Graphics g = Graphics.FromImage(bm)) { g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic; g.DrawIcon(ic, new Rectangle(0, 0, 32, 32)); }
                            using (MemoryStream ms = new MemoryStream()) { bm.Save(ms, System.Drawing.Imaging.ImageFormat.Png); png = ms.ToArray(); }
                        }
                }
            }
            catch { }
            lock (icons) icons[id] = png;
            return png;
        }

        // ---------------------------------------------------------------- desinstalar
        // um ou vários programas (ids separados por vírgula). quiet = sem janelas quando o programa deixa.
        public static string Start(string ids, bool force, bool quiet)
        {
            lock (lk)
            {
                if (phase == "running" || phase == "scanning" || phase == "cleaning") return "{\"ok\":false,\"error\":\"busy\"}";
                List<App> q = new List<App>();
                foreach (string id in (ids ?? "").Split(','))
                {
                    if (id == "") continue;
                    App a = apps.FirstOrDefault(x => x.Id == id);
                    if (a == null && store != null) a = store.FirstOrDefault(x => x.Id == id);
                    if (a != null && !q.Contains(a)) q.Add(a);
                }
                if (q.Count == 0) return "{\"ok\":false,\"error\":\"not_found\"}";
                queue = q; qi = 0; cur = q[0]; forced = force; quietMode = quiet; keyGone = false; abandon = false;
                found = new List<Item>(); kept = new List<string>(); removed = new List<string>(); msg = ""; started = DateTime.Now;
                phase = force ? "scanning" : "running";
            }
            Thread t = new Thread(Work); t.IsBackground = true; t.Name = "NEXUS desinstalar"; t.Start();
            return "{\"ok\":true}";
        }

        public static void Abandon() { abandon = true; }

        static void Work()
        {
            try
            {
                List<App> gone = new List<App>();
                HashSet<string> batch = new HashSet<string>(queue.Select(x => x.Id));
                for (int i = 0; i < queue.Count; i++)
                {
                    App a = queue[i];
                    lock (lk) { qi = i; cur = a; started = DateTime.Now; abandon = false; if (!forced) phase = "running"; }
                    if (forced) { gone.Add(a); continue; }
                    if (a.Store) RunStore(a); else RunUninstaller(a, quietMode);
                    bool g = a.Store ? StoreGone(a) : !KeyExists(a);
                    if (!g && !a.Store)
                    {
                        // alguns desinstaladores só acabam depois (Steam/Epic pedem confirmação na janela deles e o
                        // processo que o NEXUS abriu fecha logo): espera até a entrada desaparecer ou carregares em "JÁ ACABOU"
                        string cmd = (a.Uninst ?? "") + " " + (a.Quiet ?? "");
                        bool launcher = cmd.IndexOf("://", StringComparison.Ordinal) >= 0 || cmd.IndexOf("steam.exe", StringComparison.OrdinalIgnoreCase) >= 0
                                        || cmd.IndexOf("EpicGamesLauncher", StringComparison.OrdinalIgnoreCase) >= 0;
                        lock (lk) msg = launcher ? "launcher" : "";
                        DateTime w0 = DateTime.Now;
                        double maxS = launcher ? 600 : 15;
                        while (!abandon && (DateTime.Now - w0).TotalSeconds < maxS && KeyExists(a)) Thread.Sleep(1500);
                        if (!KeyExists(a)) { Thread.Sleep(3000); g = true; }   // dá tempo ao desinstalador de acabar de apagar ficheiros
                        lock (lk) msg = "";
                    }
                    // continua instalado (cancelado, falhou ou não há desinstalador): não se procuram restos dele
                    lock (lk) { if (g) { gone.Add(a); removed.Add(a.Name); } else kept.Add(a.Name); }
                }
                keyGone = gone.Count > 0;
                if (gone.Count == 0) { lock (lk) phase = "notremoved"; return; }
                lock (lk) phase = "scanning";
                List<Item> all = new List<Item>();
                HashSet<string> seenAll = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                foreach (App a in gone)
                {
                    lock (lk) cur = a;
                    foreach (Item it in Scan(a, batch))
                        if (seenAll.Add(it.Kind + "|" + it.Path + "|" + it.Extra)) { it.Prog = a.Name; all.Add(it); }
                }
                int n = 0; foreach (Item it in all) it.N = ++n;
                lock (lk) { found = all; phase = "results"; }
            }
            catch (Exception ex) { lock (lk) { phase = "error"; msg = ex.Message; } }
        }

        static void RunUninstaller(App a, bool quiet)
        {
            string cmd = quiet && !string.IsNullOrEmpty(a.Quiet) ? a.Quiet : !string.IsNullOrEmpty(a.Uninst) ? a.Uninst : a.Quiet;
            string exe, args;
            Split(cmd, out exe, out args);
            // modo silencioso para os instaladores que o NEXUS conhece de certeza (Inno Setup)
            if (quiet && exe != null && System.Text.RegularExpressions.Regex.IsMatch(Path.GetFileName(exe), @"^unins\d{3}\.exe$", System.Text.RegularExpressions.RegexOptions.IgnoreCase)
                && args.IndexOf("SILENT", StringComparison.OrdinalIgnoreCase) < 0)
                args = (args + " /VERYSILENT /SUPPRESSMSGBOXES /NORESTART").Trim();
            if (exe == null) { msg = "no_uninstaller"; return; }
            if (Path.GetFileName(exe).Equals("msiexec.exe", StringComparison.OrdinalIgnoreCase) || exe.Equals("msiexec", StringComparison.OrdinalIgnoreCase))
            {
                // MsiExec /I{GUID} abre a reparação: para desinstalar é /X{GUID}
                args = System.Text.RegularExpressions.Regex.Replace(args, @"(?i)/i\s*(\{[0-9a-f\-]+\})", "/X$1");
                if (args.IndexOf("/x", StringComparison.OrdinalIgnoreCase) < 0) { string g = GuidOf(a.Key); if (g != null) args = "/X" + g; }
                if (quiet && args.IndexOf("/q", StringComparison.OrdinalIgnoreCase) < 0) args += " /qb /norestart";   // só a barra de progresso
            }
            else if (!File.Exists(exe)) { msg = "no_uninstaller"; return; }
            HashSet<int> before = new HashSet<int>(Process.GetProcesses().Select(p => p.Id));
            ProcessStartInfo psi = new ProcessStartInfo(exe, args);
            psi.UseShellExecute = true;
            try { if (Path.IsPathRooted(exe) && File.Exists(exe)) psi.WorkingDirectory = Path.GetDirectoryName(exe); } catch { }
            Process main;
            try { main = Process.Start(psi); }
            catch (System.ComponentModel.Win32Exception) { msg = "cancelled"; return; }   // UAC recusado
            DateTime t0 = DateTime.Now;
            if (main != null) while (!main.WaitForExit(500)) { if (abandon || (DateTime.Now - t0).TotalMinutes > 60) return; }
            // muitos desinstaladores copiam-se para a pasta Temp e o primeiro processo sai logo: espera pelos filhos
            int calm = 0;
            while (!abandon && (DateTime.Now - t0).TotalMinutes < 60)
            {
                bool any = false;
                foreach (Process p in Process.GetProcesses())
                {
                    try
                    {
                        if (before.Contains(p.Id)) continue;
                        string n = p.ProcessName.ToLowerInvariant();
                        if (n == "msiexec" || n == "conhost" || n == "werfault") continue;
                        bool unin = n.StartsWith("au_") || n.StartsWith("un_") || n.Contains("unins") || n.Contains("uninst") || n == "un" || n.Contains("setup") || n.Contains("remove");
                        string path = Optimizer.ExePath(p.Id); if (path == "") path = null;
                        bool inTemp = path != null && path.StartsWith(Path.GetTempPath(), StringComparison.OrdinalIgnoreCase);
                        bool inLoc = path != null && a.Loc != null && path.StartsWith(a.Loc + "\\", StringComparison.OrdinalIgnoreCase);
                        if (unin || inTemp || inLoc) { any = true; break; }
                    }
                    catch { }
                    finally { p.Dispose(); }
                }
                if (!any) { if (++calm >= 3) break; } else calm = 0;
                Thread.Sleep(700);
            }
        }

        static void Split(string cmd, out string exe, out string args)
        {
            exe = null; args = "";
            if (string.IsNullOrEmpty(cmd)) return;
            cmd = cmd.Trim();
            if (cmd.StartsWith("\"")) { int e = cmd.IndexOf('"', 1); if (e < 0) return; exe = cmd.Substring(1, e - 1); args = cmd.Substring(e + 1).Trim(); return; }
            int x = cmd.IndexOf(".exe", StringComparison.OrdinalIgnoreCase);
            if (x > 0) { exe = cmd.Substring(0, x + 4); args = cmd.Substring(x + 4).Trim(); return; }
            int sp = cmd.IndexOf(' ');
            exe = sp < 0 ? cmd : cmd.Substring(0, sp); args = sp < 0 ? "" : cmd.Substring(sp + 1);
        }

        static string GuidOf(string key)
        {
            System.Text.RegularExpressions.Match m = System.Text.RegularExpressions.Regex.Match(key ?? "", @"\{[0-9A-Fa-f\-]{36}\}");
            return m.Success ? m.Value : null;
        }

        static void RunStore(App a)
        {
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo("powershell.exe", "-NoProfile -ExecutionPolicy Bypass -Command \"Remove-AppxPackage -Package '" + a.StoreFull.Replace("'", "''") + "'\"");
                psi.UseShellExecute = false; psi.CreateNoWindow = true;
                using (Process p = Process.Start(psi)) p.WaitForExit(10 * 60000);
            }
            catch { }
        }

        static bool StoreGone(App a)
        {
            return !Directory.Exists(a.Loc ?? "\0");
        }

        static RegistryKey Base(string hive, bool v32)
        {
            return RegistryKey.OpenBaseKey(hive == "lm" ? RegistryHive.LocalMachine : RegistryHive.CurrentUser, v32 ? RegistryView.Registry32 : RegistryView.Registry64);
        }
        static bool KeyExists(App a)
        {
            try { using (RegistryKey b = Base(a.Hive, a.View32)) using (RegistryKey k = b.OpenSubKey(UN + "\\" + a.Key)) return k != null; }
            catch { return false; }
        }

        // ---------------------------------------------------------------- procurar restos
        static readonly string[] BigVendors = { "microsoft", "microsoft corporation", "windows", "google", "google llc", "intel", "intel corporation", "nvidia", "nvidia corporation",
            "amd", "advanced micro devices", "advanced micro devices, inc.", "realtek", "apple", "apple inc.", "adobe", "adobe inc.", "adobe systems incorporated", "oracle", "valve", "valve corporation",
            "mozilla", "the mozilla foundation", "logitech", "razer", "corsair", "asus", "msi", "dell", "hp", "hewlett-packard", "lenovo", "samsung", "epic games", "ubisoft", "electronic arts", "ea" };
        static readonly string[] Generic = { "common files", "microsoft", "windows", "windowsapps", "packages", "programs", "temp", "tmp", "cache", "caches", "data", "config", "logs", "log",
            "update", "updates", "installer", "installers", "downloads", "documents", "app", "apps", "application data", "users", "default", "public", "system", "system32", "drivers",
            "microsoft.net", "dotnet", "nuget", "npm", "pip", "java", "python", "steam", "steamapps", "common", "games", "game", "launcher", "client", "bin", "lib", "tools", "plugins", "x64", "x86",
            "crashdumps", "d3dscache", "nvidia", "amd", "intel", "google", "mozilla", "package cache", "start menu", "startup", "desktop", "icons", "fonts", "help", "uninstall" };

        static string Norm(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            s = s.ToLowerInvariant().Replace("®", "").Replace("™", "").Replace("©", "");
            s = System.Text.RegularExpressions.Regex.Replace(s, @"\((x64|x86|64-bit|32-bit|64 bit|32 bit|[a-z]{2}-[a-z]{2}|x64 [a-z]{2}-[a-z]{2}|x86 [a-z]{2}-[a-z]{2})\)", " ");
            s = System.Text.RegularExpressions.Regex.Replace(s, @"\b(x64|x86|64-bit|32-bit|amd64|win64|win32)\b", " ");
            s = System.Text.RegularExpressions.Regex.Replace(s, @"\bv?\d+(\.\d+)+\b", " ");
            s = System.Text.RegularExpressions.Regex.Replace(s, @"[^a-z0-9]+", " ");
            return System.Text.RegularExpressions.Regex.Replace(s, @"\s+", " ").Trim();
        }
        static string NormPub(string p)
        {
            string s = Norm(p);
            s = System.Text.RegularExpressions.Regex.Replace(s, @"\b(inc|ltd|llc|gmbh|corp|corporation|co|company|limited|s a|sa|ag|bv|b v|srl|software|technologies|technology|games|studios|studio|entertainment|interactive)\b", " ");
            return System.Text.RegularExpressions.Regex.Replace(s, @"\s+", " ").Trim();
        }

        // nomes que identificam o programa (o nome da pasta de instalação é o mais fiável)
        static List<string> Names(App a)
        {
            List<string> n = new List<string>();
            Action<string> add = x => { x = Norm(x); if (x.Length >= 3 && !Generic.Contains(x) && !n.Contains(x)) n.Add(x); };
            if (a.Loc != null) add(Path.GetFileName(a.Loc));
            add(a.Name);
            string np = NormPub(a.Pub), nn = Norm(a.Name);
            if (np.Length >= 2 && nn.StartsWith(np + " ")) add(nn.Substring(np.Length + 1));     // "Mozilla Firefox" -> "firefox"
            if (a.Store && a.Family != null) { int u = a.Family.IndexOf('_'); add(u > 0 ? a.Family.Substring(0, u) : a.Family); }
            return n;
        }

        // pastas que nunca se propõem (e tudo o que está por cima delas)
        static bool SafeFolder(string full, bool allowPf)
        {
            string[] r = DiskScan.Risk(full);
            if (r[0] == "block") return false;
            string low = full.TrimEnd('\\').ToLowerInvariant();
            string win = Environment.GetFolderPath(Environment.SpecialFolder.Windows).TrimEnd('\\').ToLowerInvariant();
            if (low == win || low.StartsWith(win + "\\")) return false;
            string nexus = AppDomain.CurrentDomain.BaseDirectory.TrimEnd('\\').ToLowerInvariant();
            if (low == nexus || low.StartsWith(nexus + "\\") || nexus.StartsWith(low + "\\")) return false;
            string set = AppSettings.Dir.TrimEnd('\\').ToLowerInvariant();
            if (low == set || low.StartsWith(set + "\\")) return false;
            return true;
        }

        static List<Item> Scan(App a, HashSet<string> batch)
        {
            List<Item> items = new List<Item>();
            HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            List<string> names = Names(a);
            string pub = NormPub(a.Pub);
            bool bigPub = pub.Length < 3 || BigVendors.Contains(Norm(a.Pub)) || BigVendors.Contains(pub) || Generic.Contains(pub);
            List<App> others;
            lock (lk) others = apps.Concat(store ?? new List<App>()).Where(x => x.Id != a.Id && !batch.Contains(x.Id)).ToList();
            // os outros programas que continuam instalados: as pastas deles nunca entram
            List<string> otherLocs = others.Where(x => !string.IsNullOrEmpty(x.Loc)).Select(x => x.Loc.TrimEnd('\\').ToLowerInvariant()).ToList();
            HashSet<string> otherNames = new HashSet<string>(others.SelectMany(x => Names(x)));
            Func<string, bool> ownedByOther = p =>
            {
                string l = p.TrimEnd('\\').ToLowerInvariant();
                foreach (string o in otherLocs) if (l == o || o.StartsWith(l + "\\") || l.StartsWith(o + "\\")) return true;
                return false;
            };
            string loc = a.Loc != null ? a.Loc.TrimEnd('\\') : null;
            Func<string, bool> inLoc = p => loc != null && (p.Equals(loc, StringComparison.OrdinalIgnoreCase) || p.StartsWith(loc + "\\", StringComparison.OrdinalIgnoreCase));

            Action<string, string, string> addPath = (path, level, why) =>
            {
                try
                {
                    path = Path.GetFullPath(path).TrimEnd('\\');
                    if (!seen.Add("f:" + path)) return;
                    if (!Directory.Exists(path) && !File.Exists(path)) return;
                    if (!SafeFolder(path, true) || ownedByOther(path)) return;
                    Item it = new Item { Kind = Directory.Exists(path) ? "dir" : "file", Path = path, Label = path, Level = level, Extra = why };
                    it.Size = it.Kind == "dir" ? FolderSize(path, 200000) : new FileInfo(path).Length;
                    it.Admin = NeedsAdminPath(path);
                    items.Add(it);
                }
                catch { }
            };

            // 1) a pasta onde estava instalado
            if (loc != null && !a.Store)
            {
                // só vem marcada se o nome da pasta tiver a ver com o programa (ex.: um jogo que diz estar em "D:\Jogos" não leva a pasta toda)
                string nd = Norm(Path.GetFileName(loc)), nn = Norm(a.Name), w = nn.Split(' ').FirstOrDefault(x => x.Length >= 3) ?? "";
                bool related = nd.Length >= 2 && (nn.Contains(nd) || (w.Length >= 3 && nd.Contains(w)) || nd == pub || names.Contains(nd));
                addPath(loc, related ? "safe" : "maybe", "install");
            }
            if (a.Store && a.Family != null)
            {
                addPath(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Packages", a.Family), "safe", "store_data");
            }

            // 2) pastas com o nome do programa nos sítios habituais
            string la = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), ra = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string prof = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            List<string[]> roots = new List<string[]> {
                new[] { Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "pf" },
                new[] { Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "pf" },
                new[] { Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Common Files"), "pf" },
                new[] { Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Common Files"), "pf" },
                new[] { Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "pd" },
                new[] { ra, "ra" }, new[] { la, "la" }, new[] { Path.Combine(la, "Programs"), "la" },
                new[] { Path.Combine(prof, "AppData", "LocalLow"), "la" },
                new[] { Path.GetTempPath(), "tmp" },
                new[] { Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "doc" },
                new[] { Path.Combine(prof, "Saved Games"), "doc" },
            };
            foreach (string[] r in roots)
            {
                if (string.IsNullOrEmpty(r[0]) || !Directory.Exists(r[0])) continue;
                string[] dirs;
                try { dirs = Directory.GetDirectories(r[0]); } catch { continue; }
                foreach (string d in dirs)
                {
                    string nd = Norm(Path.GetFileName(d));
                    if (nd.Length < 3) continue;
                    bool personal = r[1] == "doc";
                    if (names.Contains(nd) && !otherNames.Contains(nd))
                        addPath(d, personal ? "maybe" : "safe", personal ? "personal" : "name");
                    else if (!bigPub && nd == pub)
                    {
                        // pasta da empresa: entra a subpasta do programa; a da empresa só se não tiver mais nada
                        string[] subs; try { subs = Directory.GetDirectories(d); } catch { continue; }
                        int matched = 0;
                        foreach (string s in subs)
                        {
                            string ns = Norm(Path.GetFileName(s));
                            if (names.Contains(ns) && !otherNames.Contains(ns)) { addPath(s, personal ? "maybe" : "safe", personal ? "personal" : "name"); matched++; }
                        }
                        bool hasFiles = false; try { hasFiles = Directory.EnumerateFiles(d).Any(); } catch { }
                        bool otherPub = others.Any(o => NormPub(o.Pub) == pub);
                        if (!otherPub && subs.Length - matched == 0) addPath(d, personal ? "maybe" : (hasFiles ? "maybe" : "safe"), "publisher");
                    }
                }
            }

            // 3) atalhos (menu Iniciar e ambiente de trabalho) que apontam para o programa ou para nada
            List<string> lnkRoots = new List<string> {
                Environment.GetFolderPath(Environment.SpecialFolder.Programs), Environment.GetFolderPath(Environment.SpecialFolder.CommonPrograms),
                Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), Environment.GetFolderPath(Environment.SpecialFolder.CommonDesktopDirectory),
                Path.Combine(ra, @"Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar"),
            };
            foreach (string r in lnkRoots)
            {
                if (string.IsNullOrEmpty(r) || !Directory.Exists(r)) continue;
                IEnumerable<string> lnks;
                try { lnks = Directory.EnumerateFiles(r, "*.lnk", SearchOption.AllDirectories).Take(3000).ToList(); } catch { continue; }
                foreach (string l in lnks)
                {
                    string tgt = LinkTarget(l);
                    string nl = Norm(Path.GetFileNameWithoutExtension(l));
                    bool points = tgt != null && inLoc(tgt);
                    bool deadNamed = tgt != null && !File.Exists(tgt) && !Directory.Exists(tgt) && (names.Contains(nl) || names.Any(n => nl.StartsWith(n + " ")));
                    if (points || deadNamed) AddLink(items, seen, l, "safe");
                }
                // pastas do menu Iniciar com o nome do programa
                try
                {
                    foreach (string d in Directory.GetDirectories(r))
                    {
                        string nd = Norm(Path.GetFileName(d));
                        if (names.Contains(nd) && !otherNames.Contains(nd)) addPath(d, "safe", "startmenu");
                    }
                }
                catch { }
            }

            // 4) registo
            ScanRegistry(a, items, seen, names, pub, bigPub, otherNames, inLoc);

            // 5) serviços, tarefas agendadas e firewall que apontam para a pasta do programa
            if (loc != null && !a.Store)
            {
                ScanServices(items, seen, inLoc);
                ScanTasks(items, seen, loc);
                ScanFirewall(items, seen, loc);
            }

            int i = 0;
            foreach (Item it in items) it.N = ++i;
            return items;
        }

        static void AddLink(List<Item> items, HashSet<string> seen, string l, string level)
        {
            if (!seen.Add("f:" + l)) return;
            try { items.Add(new Item { Kind = "link", Path = l, Label = l, Level = level, Size = new FileInfo(l).Length, Admin = NeedsAdminPath(l) }); } catch { }
        }

        static string LinkTarget(string lnk)
        {
            try
            {
                Type t = Type.GetTypeFromProgID("WScript.Shell");
                object sh = Activator.CreateInstance(t);
                try
                {
                    object sc = t.InvokeMember("CreateShortcut", System.Reflection.BindingFlags.InvokeMethod, null, sh, new object[] { lnk });
                    string tp = Convert.ToString(sc.GetType().InvokeMember("TargetPath", System.Reflection.BindingFlags.GetProperty, null, sc, null));
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(sc);
                    return string.IsNullOrEmpty(tp) ? null : tp;
                }
                finally { System.Runtime.InteropServices.Marshal.ReleaseComObject(sh); }
            }
            catch { return null; }
        }

        static bool NeedsAdminPath(string p)
        {
            string low = p.ToLowerInvariant(), prof = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile).ToLowerInvariant();
            return !(low.StartsWith(prof + "\\") || low.StartsWith(Path.GetTempPath().ToLowerInvariant()));
        }

        static readonly string[] RegSkip = { "classes", "clients", "policies", "microsoft", "wow6432node", "registeredapplications", "odbc", "intel", "nvidia corporation", "amd", "google",
            "mozilla", "khronos", "wow6432", "partner", "windows", "description", "hardware", "system", "setup", "appdatalow", "netscape", "javasoft", "oem" };

        static void ScanRegistry(App a, List<Item> items, HashSet<string> seen, List<string> names, string pub, bool bigPub, HashSet<string> otherNames, Func<string, bool> inLoc)
        {
            Action<string, string, string> addKey = (path, level, why) =>
            {
                if (!seen.Add("k:" + path.ToLowerInvariant())) return;
                if (!RegExists(path)) return;
                items.Add(new Item { Kind = "key", Path = path, Label = path, Level = level, Extra = why, Admin = path.StartsWith("HKLM") });
            };
            // a própria entrada de desinstalação (se o desinstalador a deixou para trás)
            if (!a.Store && a.Key != null)
            {
                string root = a.Hive == "lm" ? "HKLM" : "HKCU";
                string sw = a.View32 && a.Hive == "lm" && Environment.Is64BitOperatingSystem ? @"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\" : UN + "\\";
                addKey(root + "\\" + sw + a.Key, "safe", "uninstall_entry");
            }
            // Software\<Programa> e Software\<Empresa>\<Programa>
            foreach (string sw in new[] { @"HKCU\Software", @"HKLM\SOFTWARE", @"HKLM\SOFTWARE\WOW6432Node" })
            {
                string[] subs = RegSubs(sw);
                foreach (string s in subs)
                {
                    string ns = Norm(s);
                    if (ns.Length < 3 || RegSkip.Contains(s.ToLowerInvariant())) continue;
                    if (names.Contains(ns) && !otherNames.Contains(ns)) { addKey(sw + "\\" + s, "safe", "name"); continue; }
                    if (!bigPub && NormPub(s) == pub)
                    {
                        string[] kids = RegSubs(sw + "\\" + s);
                        int matched = 0;
                        foreach (string k in kids)
                        {
                            string nk = Norm(k);
                            if (names.Contains(nk) && !otherNames.Contains(nk)) { addKey(sw + "\\" + s + "\\" + k, "safe", "name"); matched++; }
                        }
                        if (kids.Length - matched == 0 && RegValueCount(sw + "\\" + s) == 0) addKey(sw + "\\" + s, "maybe", "publisher");
                    }
                }
            }
            if (a.Store || a.Loc == null) return;
            // App Paths com o .exe do programa
            foreach (string ap in new[] { @"HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths", @"HKCU\Software\Microsoft\Windows\CurrentVersion\App Paths", @"HKLM\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths" })
                foreach (string s in RegSubs(ap))
                {
                    string v = RegDefault(ap + "\\" + s);
                    if (v != null && inLoc(v.Trim('"'))) addKey(ap + "\\" + s, "safe", "apppath");
                }
            // arranque automático
            foreach (string run in new[] { @"HKCU\Software\Microsoft\Windows\CurrentVersion\Run", @"HKCU\Software\Microsoft\Windows\CurrentVersion\RunOnce",
                                           @"HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run", @"HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce",
                                           @"HKLM\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run" })
                foreach (KeyValuePair<string, string> v in RegValues(run))
                {
                    string exe = ExeOf(v.Value);
                    if (exe != null && inLoc(exe) && seen.Add("v:" + run + "\\" + v.Key))
                        items.Add(new Item { Kind = "value", Path = run, Extra = v.Key, Label = run + "  →  " + v.Key, Level = "safe", Admin = run.StartsWith("HKLM") });
                }
            // Applications\<exe> (o "Abrir com")
            {
                foreach (string s in RegSubs(@"HKCU\Software\Classes\Applications").Concat(RegSubs(@"HKLM\SOFTWARE\Classes\Applications")))
                {
                    string cmd = RegDefault(@"HKCU\Software\Classes\Applications\" + s + @"\shell\open\command") ?? RegDefault(@"HKLM\SOFTWARE\Classes\Applications\" + s + @"\shell\open\command");
                    string exe = ExeOf(cmd);
                    if (exe != null && inLoc(exe))
                    {
                        addKey(@"HKCU\Software\Classes\Applications\" + s, "safe", "openwith");
                        addKey(@"HKLM\SOFTWARE\Classes\Applications\" + s, "safe", "openwith");
                    }
                }
            }
        }

        static RegistryKey OpenReg(string path, bool write)
        {
            int i = path.IndexOf('\\');
            string root = i < 0 ? path : path.Substring(0, i), sub = i < 0 ? "" : path.Substring(i + 1);
            RegistryKey b = RegistryKey.OpenBaseKey(root == "HKLM" ? RegistryHive.LocalMachine : RegistryHive.CurrentUser, RegistryView.Registry64);
            if (sub == "") return b;
            RegistryKey k = b.OpenSubKey(sub, write);
            b.Dispose();
            return k;
        }
        static bool RegExists(string path) { try { using (RegistryKey k = OpenReg(path, false)) return k != null; } catch { return false; } }
        static string[] RegSubs(string path) { try { using (RegistryKey k = OpenReg(path, false)) return k == null ? new string[0] : k.GetSubKeyNames(); } catch { return new string[0]; } }
        static int RegValueCount(string path) { try { using (RegistryKey k = OpenReg(path, false)) return k == null ? 0 : k.GetValueNames().Count(n => n != ""); } catch { return 0; } }
        static string RegDefault(string path) { try { using (RegistryKey k = OpenReg(path, false)) return k == null ? null : Convert.ToString(k.GetValue("")); } catch { return null; } }
        static List<KeyValuePair<string, string>> RegValues(string path)
        {
            List<KeyValuePair<string, string>> l = new List<KeyValuePair<string, string>>();
            try { using (RegistryKey k = OpenReg(path, false)) if (k != null) foreach (string n in k.GetValueNames()) l.Add(new KeyValuePair<string, string>(n, Convert.ToString(k.GetValue(n)))); } catch { }
            return l;
        }

        static void ScanServices(List<Item> items, HashSet<string> seen, Func<string, bool> inLoc)
        {
            foreach (string s in RegSubs(@"HKLM\SYSTEM\CurrentControlSet\Services"))
            {
                string img = null;
                try { using (RegistryKey k = OpenReg(@"HKLM\SYSTEM\CurrentControlSet\Services\" + s, false)) if (k != null) img = Convert.ToString(k.GetValue("ImagePath")); } catch { }
                string exe = ExeOf(Environment.ExpandEnvironmentVariables(img ?? ""));
                if (exe != null && inLoc(exe) && seen.Add("s:" + s))
                    items.Add(new Item { Kind = "service", Path = s, Label = s, Extra = exe, Level = "safe", Admin = true });
            }
        }

        static void ScanTasks(List<Item> items, HashSet<string> seen, string loc)
        {
            string root = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "Tasks");
            IEnumerable<string> files;
            try { files = Directory.EnumerateFiles(root, "*", SearchOption.AllDirectories).Take(5000).ToList(); } catch { return; }
            foreach (string f in files)
            {
                try
                {
                    if (new FileInfo(f).Length > 200000) continue;
                    string x = File.ReadAllText(f);
                    if (x.IndexOf(loc, StringComparison.OrdinalIgnoreCase) < 0) continue;
                    string tn = f.Substring(root.Length).Replace('/', '\\');
                    if (tn.StartsWith("\\Microsoft\\", StringComparison.OrdinalIgnoreCase)) continue;
                    if (seen.Add("t:" + tn)) items.Add(new Item { Kind = "task", Path = tn, Label = tn, Level = "safe", Admin = true });
                }
                catch { }
            }
        }

        static void ScanFirewall(List<Item> items, HashSet<string> seen, string loc)
        {
            foreach (KeyValuePair<string, string> v in RegValues(@"HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\FirewallRules"))
            {
                int i = v.Value.IndexOf("|App=", StringComparison.OrdinalIgnoreCase);
                if (i < 0) continue;
                int e = v.Value.IndexOf('|', i + 5);
                string app = Environment.ExpandEnvironmentVariables(e > 0 ? v.Value.Substring(i + 5, e - i - 5) : v.Value.Substring(i + 5));
                if (!(app.Equals(loc, StringComparison.OrdinalIgnoreCase) || app.StartsWith(loc + "\\", StringComparison.OrdinalIgnoreCase))) continue;
                string name = v.Key;
                int ni = v.Value.IndexOf("|Name=", StringComparison.OrdinalIgnoreCase);
                if (ni >= 0) { int ne = v.Value.IndexOf('|', ni + 6); name = ne > 0 ? v.Value.Substring(ni + 6, ne - ni - 6) : v.Value.Substring(ni + 6); }
                if (seen.Add("w:" + v.Key)) items.Add(new Item { Kind = "firewall", Path = v.Key, Label = name, Extra = app, Level = "safe", Admin = true });
            }
        }

        // ---------------------------------------------------------------- estado e limpeza
        public static string StatusJson()
        {
            lock (lk)
            {
                bool admin = Program.IsAdmin();
                StringBuilder sb = new StringBuilder("{\"phase\":\"" + phase + "\",\"msg\":" + Q(msg) + ",\"name\":" + Q(cur == null ? null : cur.Name) +
                    ",\"forced\":" + (forced ? "true" : "false") + ",\"gone\":" + (keyGone ? "true" : "false") + ",\"admin\":" + (admin ? "true" : "false") +
                    ",\"secs\":" + (int)(DateTime.Now - started).TotalSeconds + ",\"idx\":" + qi + ",\"total\":" + queue.Count + ",\"quiet\":" + (quietMode ? "true" : "false") +
                    ",\"kept\":[" + string.Join(",", kept.Select(Q).ToArray()) + "],\"removed\":[" + string.Join(",", removed.Select(Q).ToArray()) + "],\"items\":[");
                if (phase == "results" || phase == "done")
                    sb.Append(string.Join(",", found.Select(it => "{\"n\":" + it.N + ",\"kind\":\"" + it.Kind + "\",\"label\":" + Q(it.Label) + ",\"extra\":" + Q(it.Extra) +
                        ",\"level\":\"" + it.Level + "\",\"prog\":" + Q(it.Prog) + ",\"size\":" + it.Size + ",\"admin\":" + (it.Admin ? "true" : "false") + "}").ToArray()));
                return sb.Append("]}").ToString();
            }
        }

        public static string Reset()
        {
            lock (lk) { if (phase == "running" || phase == "scanning" || phase == "cleaning") return "{\"ok\":false}"; phase = "idle"; cur = null; found = new List<Item>(); }
            return "{\"ok\":true}";
        }

        public static string Clean(string ids)
        {
            List<Item> pick; App a;
            lock (lk)
            {
                if (phase != "results") return "{\"ok\":false,\"error\":\"state\"}";
                HashSet<int> want = new HashSet<int>((ids ?? "").Split(',').Select(x => { int v; return int.TryParse(x, out v) ? v : -1; }));
                pick = found.Where(it => want.Contains(it.N)).ToList();
                a = cur; phase = "cleaning";
            }
            bool admin = Program.IsAdmin();
            int ok = 0; List<string> fail = new List<string>();
            List<Item> doneItems = new List<Item>();
            StringBuilder log = new StringBuilder("NEXUS - limpeza do desinstalador - " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "\r\n\r\n");
            string bdir = null;
            Func<string> backupDir = () =>
            {
                if (bdir != null) return bdir;
                string nm = System.Text.RegularExpressions.Regex.Replace(queue.Count > 1 ? queue.Count + " programas" : (a.Name ?? "programa"), @"[^\w\- ]+", "").Trim();
                bdir = Path.Combine(AppSettings.Dir, "Backups do desinstalador", DateTime.Now.ToString("yyyy-MM-dd HH.mm") + " " + (nm.Length > 40 ? nm.Substring(0, 40) : nm));
                Directory.CreateDirectory(bdir);
                return bdir;
            };
            // serviços e tarefas primeiro (podem estar a prender ficheiros)
            foreach (Item it in pick.OrderBy(x => x.Kind == "service" ? 0 : x.Kind == "task" ? 1 : x.Kind == "firewall" ? 2 : x.Kind == "value" ? 3 : x.Kind == "key" ? 4 : 5))
            {
                if (it.Admin && !admin) { fail.Add(it.Label + " (admin)"); log.Append("FALHOU  ").Append(it.Kind).Append("  ").Append(it.Label).Append("  (precisa de administrador)\r\n"); continue; }
                try
                {
                    bool done = false;
                    string why = "";
                    switch (it.Kind)
                    {
                        case "service":
                            RegExport(@"HKLM\SYSTEM\CurrentControlSet\Services\" + it.Path, backupDir());
                            Run("sc.exe", "stop \"" + it.Path + "\"", 20000);
                            done = Run("sc.exe", "delete \"" + it.Path + "\"", 20000) == 0;
                            break;
                        case "task":
                            try { File.Copy(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "Tasks") + it.Path, Path.Combine(backupDir(), "tarefa " + Path.GetFileName(it.Path) + ".xml"), true); } catch { }
                            done = Run("schtasks.exe", "/delete /tn \"" + it.Path + "\" /f", 20000) == 0;
                            break;
                        case "firewall":
                            RegExport(@"HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\FirewallRules", backupDir());
                            done = Run("powershell.exe", "-NoProfile -Command \"Remove-NetFirewallRule -Name '" + it.Path.Replace("'", "''") + "' -ErrorAction Stop\"", 30000) == 0;
                            break;
                        case "value":
                            RegExport(it.Path, backupDir());
                            using (RegistryKey k = OpenReg(it.Path, true)) { if (k != null) { k.DeleteValue(it.Extra, false); done = k.GetValue(it.Extra) == null; } }
                            break;
                        case "key":
                            if (!RegExists(it.Path)) { done = true; break; }
                            RegExport(it.Path, backupDir());
                            int c = it.Path.LastIndexOf('\\');
                            using (RegistryKey p = OpenReg(it.Path.Substring(0, c), true)) { if (p != null) p.DeleteSubKeyTree(it.Path.Substring(c + 1), false); }
                            done = !RegExists(it.Path);
                            break;
                        default:   // dir, file, link: para a Reciclagem
                            if (!SafeFolder(it.Path, true)) { why = "pasta protegida"; break; }
                            if (it.Kind == "dir") why = KillInside(it.Path);   // programa ainda aberto prende os ficheiros
                            var ui = Microsoft.VisualBasic.FileIO.UIOption.OnlyErrorDialogs;
                            var rec = Microsoft.VisualBasic.FileIO.RecycleOption.SendToRecycleBin;
                            if (Directory.Exists(it.Path)) Microsoft.VisualBasic.FileIO.FileSystem.DeleteDirectory(it.Path, ui, rec);
                            else if (File.Exists(it.Path)) Microsoft.VisualBasic.FileIO.FileSystem.DeleteFile(it.Path, ui, rec);
                            done = !Directory.Exists(it.Path) && !File.Exists(it.Path);
                            break;
                    }
                    if (done) { ok++; doneItems.Add(it); log.Append("OK      "); }
                    else { fail.Add(it.Label + (why != "" && why != null && why.StartsWith("pasta") ? " (" + why + ")" : "")); log.Append("FALHOU  "); }
                    log.Append(it.Kind).Append("  ").Append(it.Label).Append(string.IsNullOrEmpty(why) ? "" : "  (" + why + ")").Append("\r\n");
                }
                catch (Exception ex) { fail.Add(it.Label + " (" + ex.Message + ")"); log.Append("FALHOU  ").Append(it.Kind).Append("  ").Append(it.Label).Append("  (").Append(ex.Message).Append(")\r\n"); }
            }
            // passados uns segundos, vê se alguma coisa voltou a aparecer (recriada por um programa que ainda corre)
            List<string> back = new List<string>();
            if (doneItems.Count > 0)
            {
                Thread.Sleep(3000);
                foreach (Item it in doneItems)
                {
                    bool again = it.Kind == "key" ? RegExists(it.Path) : (it.Kind == "dir" || it.Kind == "file" || it.Kind == "link") && (Directory.Exists(it.Path) || File.Exists(it.Path));
                    if (again) { back.Add(it.Label); log.Append("VOLTOU  ").Append(it.Kind).Append("  ").Append(it.Label).Append("\r\n"); }
                }
            }
            try { File.WriteAllText(Path.Combine(backupDir(), "registo.txt"), log.ToString(), new UTF8Encoding(true)); } catch { }
            // pastas vazias do menu Iniciar que ficaram para trás
            lock (lk) { phase = "done"; found = found.Where(it => !pick.Contains(it) || fail.Any(f => f.StartsWith(it.Label))).ToList(); }
            return "{\"ok\":true,\"done\":" + (ok - back.Count) + ",\"failed\":[" + string.Join(",", fail.Select(Q).ToArray()) + "],\"back\":[" + string.Join(",", back.Select(Q).ToArray()) + "],\"backup\":" + Q(bdir) + "}";
        }

        // fecha os programas que estão a correr a partir desta pasta (senão os ficheiros ficam presos)
        static string KillInside(string dir)
        {
            int n = 0;
            string d = dir.TrimEnd('\\') + "\\";
            foreach (Process p in Process.GetProcesses())
            {
                try
                {
                    string f = Optimizer.ExePath(p.Id); if (f == "") f = null;
                    if (f != null && f.StartsWith(d, StringComparison.OrdinalIgnoreCase) && p.Id != Process.GetCurrentProcess().Id) { p.Kill(); p.WaitForExit(5000); n++; }
                }
                catch { }
                finally { p.Dispose(); }
            }
            return n > 0 ? n + " programa(s) fechado(s) antes de apagar" : "";
        }

        static void RegExport(string key, string dir)
        {
            try
            {
                string f = Path.Combine(dir, System.Text.RegularExpressions.Regex.Replace(key, @"[\\/:*?""<>|]+", "_") + ".reg");
                if (f.Length > 240) f = Path.Combine(dir, "chave " + Math.Abs(key.GetHashCode()) + ".reg");
                Run("reg.exe", "export \"" + key + "\" \"" + f + "\" /y", 20000);
            }
            catch { }
        }

        static int Run(string exe, string args, int ms)
        {
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo(exe, args);
                psi.UseShellExecute = false; psi.CreateNoWindow = true;
                using (Process p = Process.Start(psi)) { if (!p.WaitForExit(ms)) { try { p.Kill(); } catch { } return -1; } return p.ExitCode; }
            }
            catch { return -1; }
        }
    }
}
