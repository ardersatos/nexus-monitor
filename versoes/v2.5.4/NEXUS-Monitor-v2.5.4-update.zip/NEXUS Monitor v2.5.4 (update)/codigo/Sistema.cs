﻿// NEXUS // MONITOR - cenários (silencioso / equilibrado / máximo), tempo de arranque, velocidade do disco, monitores, RAM (XMP), PCIe,
// bateria, ficheiros duplicados, crashes explicados, reparar o Windows (SFC/DISM), programas como administrador,
// vigiar transferências, não incomodar em jogo, limite de FPS automático, outros PCs da rede.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Eventing.Reader;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Management;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using Microsoft.Win32;

namespace Nexus
{
    // ------------------------------------------------------------ cenários: um clique muda plano de energia, limite da placa e ventoinhas
    static class Cenarios
    {
        const string BALANCED = "381b4222-f694-41f0-9685-ff5bb260df2e";
        static string FileC { get { return Path.Combine(AppSettings.Dir, "cenarios.txt"); } }
        public class C { public string Id, Name, Plan = "", Fans = ""; public int GpuPct; public List<string> Tw; }
        static string active = "";

        static List<C> Custom()
        {
            List<C> l = new List<C>();
            try
            {
                if (File.Exists(FileC))
                    foreach (string line in File.ReadAllLines(FileC, Encoding.UTF8))
                    {
                        string[] c = line.Split('|');
                        if (c.Length < 6) continue;
                        int g; int.TryParse(c[3], out g);
                        l.Add(new C { Id = c[0], Name = c[1], Plan = c[2], GpuPct = g, Fans = c[4], Tw = c[5].Split(',').Where(x => x != "").ToList() });
                    }
            }
            catch { }
            return l;
        }
        static void SaveCustom(List<C> l)
        {
            try { Directory.CreateDirectory(AppSettings.Dir); File.WriteAllLines(FileC, l.Select(x => x.Id + "|" + x.Name.Replace("|", "/") + "|" + x.Plan + "|" + x.GpuPct + "|" + x.Fans + "|" + string.Join(",", (x.Tw ?? new List<string>()).ToArray())).ToArray(), new UTF8Encoding(false)); }
            catch { }
        }
        public static string Json()
        {
            StringBuilder sb = new StringBuilder("{\"ok\":true,\"active\":" + Js.S(active) + ",\"custom\":[");
            sb.Append(string.Join(",", Custom().Select(x => "{\"id\":" + Js.S(x.Id) + ",\"name\":" + Js.S(x.Name) + ",\"gpu\":" + x.GpuPct + ",\"tweaks\":" + (x.Tw == null ? 0 : x.Tw.Count) + "}").ToArray()));
            return sb.Append("]}").ToString();
        }
        static void Gpu(int pct)
        {
            if (pct <= 0) return;
            string j = GpuCtl.Json();
            Match m = Regex.Match(j, "\"def\":([0-9.]+)"), mn = Regex.Match(j, "\"min\":([0-9.]+)"), mx = Regex.Match(j, "\"max\":([0-9.]+)");
            if (!m.Success) return;
            double def = double.Parse(m.Groups[1].Value, CultureInfo.InvariantCulture), w = def * pct / 100.0;
            if (mn.Success) w = Math.Max(w, double.Parse(mn.Groups[1].Value, CultureInfo.InvariantCulture));
            if (mx.Success) w = Math.Min(w, double.Parse(mx.Groups[1].Value, CultureInfo.InvariantCulture));
            GpuCtl.SetPower(Math.Round(w).ToString(CultureInfo.InvariantCulture));
        }
        static void FansPreset(string p)
        {
            if (string.IsNullOrEmpty(p)) return;
            foreach (string[] f in Embedded.Controls())
            {
                if (p == "auto") Ventoinhas.Set(f[0], "auto", null, null, null, null);
                else if (p == "quiet") Ventoinhas.Set(f[0], "curve", "max", null, "45,62,75,85", "25,35,60,100");
                else if (p == "max") Ventoinhas.Set(f[0], "curve", "max", null, "35,50,65,80", "50,70,90,100");
            }
        }
        public static string Apply(string id)
        {
            try
            {
                if (id == "quiet") { Tweaks.SetScheme(BALANCED); Gpu(75); FansPreset("quiet"); }
                else if (id == "normal") { Tweaks.SetScheme(BALANCED); Gpu(100); FansPreset("auto"); }
                else if (id == "max")
                {
                    string fast = null; try { fast = Tweaks.FastScheme(true); } catch { }
                    if (fast != null) Tweaks.SetScheme(fast);
                    Gpu(110); FansPreset("max");
                }
                else
                {
                    C c = Custom().FirstOrDefault(x => x.Id == id);
                    if (c == null) return "{\"ok\":false,\"error\":\"não existe\"}";
                    if (c.Plan != "") Tweaks.SetScheme(c.Plan);
                    Gpu(c.GpuPct);
                    // as otimizações ficam como estavam quando se guardou o cenário
                    List<string> now = Tweaks.ChangedIds();
                    List<string> on = c.Tw.Where(x => !now.Contains(x)).ToList(), off = now.Where(x => !c.Tw.Contains(x)).ToList();
                    if (on.Count > 0) Tweaks.Bulk(true, string.Join(",", on.ToArray()));
                    if (off.Count > 0) Tweaks.Bulk(false, string.Join(",", off.ToArray()));
                }
                active = id;
            }
            catch (Exception ex) { return "{\"ok\":false,\"error\":" + Js.S(ex.Message) + "}"; }
            return Json();
        }
        public static string Save(string name)
        {
            name = (name ?? "").Trim();
            if (name == "") name = Lang.L("O meu cenário");
            if (name.Length > 40) name = name.Substring(0, 40);
            int pct = 0;
            try
            {
                string j = GpuCtl.Json();
                Match l = Regex.Match(j, "\"limit\":([0-9.]+)"), d = Regex.Match(j, "\"def\":([0-9.]+)");
                if (l.Success && d.Success && double.Parse(d.Groups[1].Value, CultureInfo.InvariantCulture) > 0) pct = (int)Math.Round(double.Parse(l.Groups[1].Value, CultureInfo.InvariantCulture) / double.Parse(d.Groups[1].Value, CultureInfo.InvariantCulture) * 100);
            }
            catch { }
            List<C> list = Custom();
            C c = new C { Id = "c" + DateTime.Now.Ticks.ToString("x"), Name = name, Plan = Tweaks.ActiveScheme() ?? "", GpuPct = pct, Tw = Tweaks.ChangedIds() };
            list.Add(c);
            SaveCustom(list);
            active = c.Id;
            return Json();
        }
        public static string Delete(string id)
        {
            List<C> l = Custom(); l.RemoveAll(x => x.Id == id); SaveCustom(l);
            if (active == id) active = "";
            return Json();
        }
    }

    // ------------------------------------------------------------ quanto tempo o Windows demora a arrancar (registo do Windows, eventos 100-110)
    static class Boot
    {
        static string cache; static DateTime at = DateTime.MinValue;
        static Dictionary<string, string> Data(EventRecord e)
        {
            Dictionary<string, string> d = new Dictionary<string, string>();
            try
            {
                System.Xml.XmlDocument x = new System.Xml.XmlDocument(); x.LoadXml(e.ToXml());
                foreach (System.Xml.XmlNode n in x.GetElementsByTagName("Data"))
                    if (n.Attributes != null && n.Attributes["Name"] != null) d[n.Attributes["Name"].Value] = n.InnerText;
            }
            catch { }
            return d;
        }
        static string G(Dictionary<string, string> d, string k) { string v; return d.TryGetValue(k, out v) ? v : ""; }
        public static string Json()
        {
            lock (typeof(Boot))
            {
                if (cache != null && (DateTime.Now - at).TotalMinutes < 10) return cache;
                StringBuilder boots = new StringBuilder(), slow = new StringBuilder();
                int nb = 0, ns = 0;
                try
                {
                    EventLogQuery q = new EventLogQuery("Microsoft-Windows-Diagnostics-Performance/Operational", PathType.LogName, "*[System[(EventID>=100 and EventID<=110)]]") { ReverseDirection = true };
                    using (EventLogReader r = new EventLogReader(q))
                        for (EventRecord e = r.ReadEvent(); e != null && (nb < 10 || ns < 15); e = r.ReadEvent())
                            using (e)
                            {
                                Dictionary<string, string> d = Data(e);
                                string when = e.TimeCreated.HasValue ? e.TimeCreated.Value.ToString("dd/MM HH:mm") : "";
                                if (e.Id == 100 && nb < 10)
                                {
                                    if (nb++ > 0) boots.Append(',');
                                    boots.Append("{\"when\":").Append(Js.S(when)).Append(",\"total\":").Append(Js.S(G(d, "BootTime"))).Append(",\"main\":").Append(Js.S(G(d, "MainPathBootTime")))
                                         .Append(",\"post\":").Append(Js.S(G(d, "BootPostBootTime"))).Append('}');
                                }
                                else if (e.Id > 100 && ns < 15)
                                {
                                    string name = G(d, "FriendlyName"); if (name == "") name = G(d, "Name"); if (name == "") name = G(d, "FileName");
                                    if (name == "") continue;
                                    if (ns++ > 0) slow.Append(',');
                                    string kind = e.Id == 101 ? "app" : e.Id == 102 ? "driver" : e.Id == 103 ? "service" : e.Id == 109 ? "device" : "other";
                                    slow.Append("{\"when\":").Append(Js.S(when)).Append(",\"name\":").Append(Js.S(name)).Append(",\"kind\":").Append(Js.S(kind))
                                        .Append(",\"ms\":").Append(Js.S(G(d, "TotalTime"))).Append(",\"extra\":").Append(Js.S(G(d, "DegradationTime")))
                                        .Append(",\"file\":").Append(Js.S(G(d, "FileName"))).Append('}');
                                }
                            }
                }
                catch { }
                double up = Environment.TickCount / 1000.0;
                if (up < 0) up += 4294967.296;
                cache = "{\"ok\":true,\"uptime\":" + Js.N(up) + ",\"boots\":[" + boots + "],\"slow\":[" + slow + "]}";
                at = DateTime.Now;
                return cache;
            }
        }
    }

    // ------------------------------------------------------------ velocidade do disco: escrita/leitura sequencial e leitura aleatória 4K (sem cache do Windows)
    static class DiscoVel
    {
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        static extern IntPtr CreateFile(string name, uint access, uint share, IntPtr sec, uint disp, uint flags, IntPtr tmpl);
        [DllImport("kernel32.dll", SetLastError = true)] static extern bool WriteFile(IntPtr h, IntPtr buf, uint n, out uint done, IntPtr ov);
        [DllImport("kernel32.dll", SetLastError = true)] static extern bool ReadFile(IntPtr h, IntPtr buf, uint n, out uint done, IntPtr ov);
        [DllImport("kernel32.dll", SetLastError = true)] static extern bool SetFilePointerEx(IntPtr h, long dist, out long np, uint method);
        [DllImport("kernel32.dll", SetLastError = true)] static extern bool CloseHandle(IntPtr h);
        [DllImport("kernel32.dll", SetLastError = true)] static extern IntPtr VirtualAlloc(IntPtr a, UIntPtr size, uint type, uint prot);
        [DllImport("kernel32.dll", SetLastError = true)] static extern bool VirtualFree(IntPtr a, UIntPtr size, uint type);
        const uint GR = 0x80000000, GW = 0x40000000, NOBUF = 0x20000000, WTHRU = 0x80000000;

        static readonly object lk = new object();
        static string state = "idle", drive = "", phase = "", error, results = "{}";
        static int progress;
        public static string Json()
        {
            lock (lk)
            {
                StringBuilder d = new StringBuilder("[");
                bool first = true;
                foreach (DriveInfo di in DriveInfo.GetDrives())
                {
                    try
                    {
                        if (di.DriveType != DriveType.Fixed || !di.IsReady) continue;
                        if (!first) d.Append(','); first = false;
                        d.Append("{\"letter\":").Append(Js.S(di.Name.Substring(0, 1))).Append(",\"label\":").Append(Js.S(di.VolumeLabel)).Append(",\"free\":").Append(di.AvailableFreeSpace).Append('}');
                    }
                    catch { }
                }
                d.Append(']');
                return "{\"ok\":true,\"state\":" + Js.S(state) + ",\"drive\":" + Js.S(drive) + ",\"phase\":" + Js.S(phase) + ",\"progress\":" + progress +
                       ",\"error\":" + Js.S(error) + ",\"drives\":" + d + ",\"results\":" + results + "}";
            }
        }
        public static string Start(string letter, int mb)
        {
            lock (lk)
            {
                if (state == "running") return Json();
                if (string.IsNullOrEmpty(letter) || letter.Length != 1 || !char.IsLetter(letter[0])) return "{\"ok\":false,\"error\":\"disco\"}";
                if (Optimizer.GameName != null) return "{\"ok\":false,\"error\":" + Js.S(Lang.L("fecha o jogo primeiro")) + "}";
                mb = mb <= 256 ? 256 : mb <= 1024 ? 1024 : 4096;
                try { if (new DriveInfo(letter).AvailableFreeSpace < (long)mb * 1048576 * 2) return "{\"ok\":false,\"error\":" + Js.S(Lang.L("pouco espaço livre nesse disco")) + "}"; } catch { }
                state = "running"; drive = letter.ToUpperInvariant(); phase = ""; progress = 0; error = null;
            }
            string dl = drive; int size = mb;
            ThreadPool.QueueUserWorkItem(delegate { Run(dl, size); });
            return Json();
        }
        static void Run(string letter, int mb)
        {
            string f = letter + @":\nexus_teste_velocidade.tmp";
            IntPtr buf = IntPtr.Zero, h = new IntPtr(-1); const int BLK = 1 << 20;
            double wr = 0, rd = 0, rnd = 0;
            try
            {
                buf = VirtualAlloc(IntPtr.Zero, (UIntPtr)BLK, 0x3000, 0x04);
                byte[] fill = new byte[BLK]; new Random(7).NextBytes(fill); Marshal.Copy(fill, 0, buf, BLK);   // dados aleatórios: discos que comprimem não fazem batota
                int n = mb;   // blocos de 1 MB
                // escrita sequencial
                lock (lk) phase = "write";
                h = CreateFile(f, GR | GW, 0, IntPtr.Zero, 2, NOBUF | WTHRU, IntPtr.Zero);
                if (h == new IntPtr(-1)) throw new Exception(Lang.L("não consegui criar o ficheiro de teste") + " (" + Marshal.GetLastWin32Error() + ")");
                Stopwatch sw = Stopwatch.StartNew(); uint done;
                for (int i = 0; i < n; i++) { if (!WriteFile(h, buf, BLK, out done, IntPtr.Zero)) throw new Exception("write " + Marshal.GetLastWin32Error()); lock (lk) progress = i * 33 / n; }
                wr = mb / sw.Elapsed.TotalSeconds;
                CloseHandle(h); h = new IntPtr(-1);
                // leitura sequencial
                lock (lk) phase = "read";
                h = CreateFile(f, GR, 0, IntPtr.Zero, 3, NOBUF, IntPtr.Zero);
                if (h == new IntPtr(-1)) throw new Exception("read " + Marshal.GetLastWin32Error());
                sw.Restart();
                for (int i = 0; i < n; i++) { if (!ReadFile(h, buf, BLK, out done, IntPtr.Zero)) throw new Exception("read " + Marshal.GetLastWin32Error()); lock (lk) progress = 33 + i * 33 / n; }
                rd = mb / sw.Elapsed.TotalSeconds;
                // leitura aleatória de 4 KB durante 8 s (como abrir muitos ficheiros pequenos)
                lock (lk) phase = "random";
                Random r = new Random(); long blocks = (long)mb * 256, np; int ops = 0;
                sw.Restart();
                while (sw.Elapsed.TotalSeconds < 8)
                {
                    SetFilePointerEx(h, (long)(r.NextDouble() * blocks) * 4096, out np, 0);
                    if (!ReadFile(h, buf, 4096, out done, IntPtr.Zero)) break;
                    ops++;
                    if ((ops & 255) == 0) lock (lk) progress = 66 + (int)(sw.Elapsed.TotalSeconds / 8 * 34);
                }
                rnd = ops / sw.Elapsed.TotalSeconds;
                CloseHandle(h); h = new IntPtr(-1);
                lock (lk)
                {
                    results = Regex.Replace(results, "\"" + letter + "\":\\{[^}]*\\},?", "").Replace("{,", "{").Replace(",}", "}");
                    string one = "\"" + letter + "\":{\"write\":" + Js.N(wr) + ",\"read\":" + Js.N(rd) + ",\"iops\":" + Js.N(rnd) + ",\"mb\":" + mb + ",\"when\":" + Js.S(DateTime.Now.ToString("dd/MM HH:mm")) + "}";
                    results = results == "{}" ? "{" + one + "}" : results.Substring(0, results.Length - 1) + "," + one + "}";
                    state = "done"; phase = ""; progress = 100;
                }
            }
            catch (Exception ex) { lock (lk) { state = "error"; error = ex.Message; } }
            finally
            {
                // um erro a meio deixava o ficheiro aberto e ele não se apagava (até 4 GB perdidos no disco)
                if (h != new IntPtr(-1)) CloseHandle(h);
                if (buf != IntPtr.Zero) VirtualFree(buf, UIntPtr.Zero, 0x8000);
                try { File.Delete(f); } catch { }
            }
        }
    }

    // ------------------------------------------------------------ monitores (Hz atuais e máximos) , RAM (XMP/EXPO, canais) e PCIe da placa
    static class HwCheck
    {
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        struct DEVMODE
        {
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string dmDeviceName;
            public short dmSpecVersion, dmDriverVersion, dmSize, dmDriverExtra; public int dmFields;
            public int dmPositionX, dmPositionY, dmDisplayOrientation, dmDisplayFixedOutput;
            public short dmColor, dmDuplex, dmYResolution, dmTTOption, dmCollate;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string dmFormName;
            public short dmLogPixels; public int dmBitsPerPel, dmPelsWidth, dmPelsHeight, dmDisplayFlags, dmDisplayFrequency;
            public int dmICMMethod, dmICMIntent, dmMediaType, dmDitherType, dmReserved1, dmReserved2, dmPanningWidth, dmPanningHeight;
        }
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        struct DISPLAY_DEVICE
        {
            public int cb; [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string DeviceName;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceString; public int StateFlags;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceID; [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceKey;
        }
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern bool EnumDisplaySettings(string dev, int mode, ref DEVMODE dm);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern bool EnumDisplayDevices(string dev, uint i, ref DISPLAY_DEVICE dd, uint flags);

        public static int PrimaryHz()
        {
            DEVMODE dm = new DEVMODE(); dm.dmSize = (short)Marshal.SizeOf(typeof(DEVMODE));
            return EnumDisplaySettings(null, -1, ref dm) ? dm.dmDisplayFrequency : 0;
        }
        static string Displays()
        {
            StringBuilder sb = new StringBuilder("[");
            bool first = true;
            for (uint i = 0; i < 16; i++)
            {
                DISPLAY_DEVICE ad = new DISPLAY_DEVICE(); ad.cb = Marshal.SizeOf(typeof(DISPLAY_DEVICE));
                if (!EnumDisplayDevices(null, i, ref ad, 0)) break;
                if ((ad.StateFlags & 1) == 0) continue;   // não ligado ao ambiente de trabalho
                DEVMODE cur = new DEVMODE(); cur.dmSize = (short)Marshal.SizeOf(typeof(DEVMODE));
                if (!EnumDisplaySettings(ad.DeviceName, -1, ref cur)) continue;
                int maxHz = cur.dmDisplayFrequency;
                for (int m = 0; m < 2000; m++)
                {
                    DEVMODE dm = new DEVMODE(); dm.dmSize = (short)Marshal.SizeOf(typeof(DEVMODE));
                    if (!EnumDisplaySettings(ad.DeviceName, m, ref dm)) break;
                    if (dm.dmPelsWidth == cur.dmPelsWidth && dm.dmPelsHeight == cur.dmPelsHeight && dm.dmDisplayFrequency > maxHz) maxHz = dm.dmDisplayFrequency;
                }
                DISPLAY_DEVICE mon = new DISPLAY_DEVICE(); mon.cb = Marshal.SizeOf(typeof(DISPLAY_DEVICE));
                string mname = EnumDisplayDevices(ad.DeviceName, 0, ref mon, 0) ? mon.DeviceString : "";
                if (!first) sb.Append(','); first = false;
                sb.Append("{\"name\":").Append(Js.S(mname)).Append(",\"gpu\":").Append(Js.S(ad.DeviceString)).Append(",\"primary\":").Append((ad.StateFlags & 4) != 0 ? "true" : "false")
                  .Append(",\"w\":").Append(cur.dmPelsWidth).Append(",\"h\":").Append(cur.dmPelsHeight).Append(",\"hz\":").Append(cur.dmDisplayFrequency).Append(",\"maxhz\":").Append(maxHz).Append('}');
            }
            return sb.Append(']').ToString();
        }
        static string Ram()
        {
            StringBuilder sb = new StringBuilder("[");
            bool first = true;
            try
            {
                using (ManagementObjectSearcher s = new ManagementObjectSearcher("SELECT Capacity, Speed, ConfiguredClockSpeed, SMBIOSMemoryType, PartNumber, Manufacturer, BankLabel, DeviceLocator FROM Win32_PhysicalMemory"))
                    foreach (ManagementObject m in s.Get())
                    {
                        string part = (Convert.ToString(m["PartNumber"]) ?? "").Trim();
                        int rated = 0;
                        // a velocidade XMP costuma estar no nome do módulo (ex.: F4-3600C16, CMK16GX4M2B3200C16, KF432C16 = 3200)
                        Match x = Regex.Match(part, @"(?<!\d)(2[1-9]\d\d|3\d{3}|4\d{3}|5\d{3}|6\d{3}|7\d{3}|8\d{3})(?!\d)");
                        if (x.Success) rated = int.Parse(x.Groups[1].Value);
                        else { Match k = Regex.Match(part, @"^KF\d?(\d{2})C", RegexOptions.IgnoreCase); if (k.Success) rated = int.Parse(k.Groups[1].Value) * 100; }
                        if (!first) sb.Append(','); first = false;
                        sb.Append("{\"gb\":").Append(Convert.ToInt64(m["Capacity"] ?? 0) / 1073741824).Append(",\"speed\":").Append(Convert.ToInt32(m["Speed"] ?? 0))
                          .Append(",\"cur\":").Append(Convert.ToInt32(m["ConfiguredClockSpeed"] ?? 0)).Append(",\"type\":").Append(Convert.ToInt32(m["SMBIOSMemoryType"] ?? 0))
                          .Append(",\"part\":").Append(Js.S(part)).Append(",\"maker\":").Append(Js.S((Convert.ToString(m["Manufacturer"]) ?? "").Trim()))
                          .Append(",\"slot\":").Append(Js.S((Convert.ToString(m["DeviceLocator"]) ?? "").Trim())).Append(",\"rated\":").Append(rated).Append('}');
                    }
            }
            catch { }
            return sb.Append(']').ToString();
        }
        static string Pcie()
        {
            try
            {
                string smi = Path.Combine(Environment.SystemDirectory, "nvidia-smi.exe");
                if (!File.Exists(smi)) return "null";
                {
                    string o = ProcOut.Run(smi, "--query-gpu=pcie.link.gen.current,pcie.link.gen.max,pcie.link.width.current,pcie.link.width.max --format=csv,noheader,nounits", 8000);
                    string[] c = o.Split('\n')[0].Split(',');
                    if (c.Length < 4) return "null";
                    Func<string, string> n = v => { int i; return int.TryParse(v.Trim(), out i) ? i.ToString() : "null"; };
                    return "{\"gen\":" + n(c[0]) + ",\"genmax\":" + n(c[1]) + ",\"width\":" + n(c[2]) + ",\"widthmax\":" + n(c[3]) + "}";
                }
            }
            catch { return "null"; }
        }
        public static string Json()
        {
            return "{\"ok\":true,\"displays\":" + Displays() + ",\"ram\":" + Ram() + ",\"pcie\":" + Pcie() + "}";
        }
    }

    // ------------------------------------------------------------ bateria (portáteis): saúde, ciclos e capacidade real
    static class Bateria
    {
        static long Q(string cls, string prop)
        {
            try
            {
                using (ManagementObjectSearcher s = new ManagementObjectSearcher(@"root\wmi", "SELECT " + prop + " FROM " + cls))
                    foreach (ManagementObject m in s.Get()) return Convert.ToInt64(m[prop]);
            }
            catch { }
            return -1;
        }
        public static string Json()
        {
            int pct = -1, run = -1; string status = "";
            try
            {
                using (ManagementObjectSearcher s = new ManagementObjectSearcher("SELECT EstimatedChargeRemaining, EstimatedRunTime, BatteryStatus FROM Win32_Battery"))
                    foreach (ManagementObject m in s.Get())
                    {
                        pct = Convert.ToInt32(m["EstimatedChargeRemaining"] ?? -1); run = Convert.ToInt32(m["EstimatedRunTime"] ?? -1);
                        status = Convert.ToString(m["BatteryStatus"]); break;
                    }
            }
            catch { }
            if (pct < 0) return "{\"ok\":true,\"present\":false}";
            long design = Q("BatteryStaticData", "DesignedCapacity"), full = Q("BatteryFullChargedCapacity", "FullChargedCapacity"), cycles = Q("BatteryCycleCount", "CycleCount");
            long rate = Q("BatteryStatus", "DischargeRate"), online = Q("BatteryStatus", "PowerOnline");
            return "{\"ok\":true,\"present\":true,\"pct\":" + pct + ",\"runmin\":" + (run > 0 && run < 71582788 ? run : -1) + ",\"design\":" + design + ",\"full\":" + full +
                   ",\"health\":" + (design > 0 && full > 0 ? Math.Min(100, full * 100 / design) : -1) + ",\"cycles\":" + cycles + ",\"rate\":" + rate + ",\"plugged\":" + (online == 1 ? "true" : "false") + ",\"status\":" + Js.S(status) + "}";
        }
    }

    // ------------------------------------------------------------ ficheiros duplicados (mesmo conteúdo), para mandar para a Reciclagem
    static class Duplicados
    {
        static readonly object lk = new object();
        static string state = "idle", folder = "", result = "[]", error; static int progress, scanned; static long waste;
        public static string Json()
        {
            lock (lk) return "{\"ok\":true,\"state\":" + Js.S(state) + ",\"folder\":" + Js.S(folder) + ",\"progress\":" + progress + ",\"scanned\":" + scanned +
                             ",\"waste\":" + waste + ",\"error\":" + Js.S(error) + ",\"groups\":" + result + "}";
        }
        public static string Start(string dir, int minMb)
        {
            lock (lk)
            {
                if (state == "running") return Json();
                if (string.IsNullOrEmpty(dir) || !Directory.Exists(dir)) return "{\"ok\":false,\"error\":" + Js.S(Lang.L("Essa pasta não existe.")) + "}";
                state = "running"; folder = dir; progress = 0; scanned = 0; waste = 0; result = "[]"; error = null;
            }
            long min = Math.Max(1, minMb) * 1048576L;
            ThreadPool.QueueUserWorkItem(delegate { Run(dir, min); });
            return Json();
        }
        static string Hash(string f, bool partial)
        {
            using (FileStream s = new FileStream(f, FileMode.Open, FileAccess.Read, FileShare.ReadWrite, 1 << 16))
            using (SHA256 h = SHA256.Create())
            {
                if (!partial) return BitConverter.ToString(h.ComputeHash(s));
                byte[] b = new byte[65536]; int n = s.Read(b, 0, b.Length);
                return BitConverter.ToString(h.ComputeHash(b, 0, n));
            }
        }
        static void Run(string dir, long min)
        {
            try
            {
                Dictionary<long, List<string>> bySize = new Dictionary<long, List<string>>();
                Stack<string> st = new Stack<string>(); st.Push(dir);
                while (st.Count > 0)
                {
                    string d = st.Pop();
                    try
                    {
                        DirectoryInfo di = new DirectoryInfo(d);
                        if ((di.Attributes & FileAttributes.ReparsePoint) != 0 && d != dir) continue;
                        foreach (DirectoryInfo sd in di.GetDirectories()) st.Push(sd.FullName);
                        foreach (FileInfo fi in di.GetFiles())
                        {
                            lock (lk) scanned++;
                            if (fi.Length < min) continue;
                            List<string> l; if (!bySize.TryGetValue(fi.Length, out l)) bySize[fi.Length] = l = new List<string>();
                            l.Add(fi.FullName);
                        }
                    }
                    catch { }
                }
                List<KeyValuePair<long, List<string>>> cand = bySize.Where(x => x.Value.Count > 1).ToList();
                StringBuilder sb = new StringBuilder("["); bool first = true; int done = 0; long w = 0; int groups = 0;
                foreach (KeyValuePair<long, List<string>> kv in cand.OrderByDescending(x => x.Key))
                {
                    done++; lock (lk) progress = done * 100 / Math.Max(1, cand.Count);
                    // primeiro só os primeiros 64 KB; depois o ficheiro inteiro, só para os que batem
                    foreach (IGrouping<string, string> g1 in kv.Value.GroupBy(f => { try { return Hash(f, true); } catch { return Guid.NewGuid().ToString(); } }).Where(g => g.Count() > 1))
                        foreach (IGrouping<string, string> g2 in g1.GroupBy(f => { try { return Hash(f, false); } catch { return Guid.NewGuid().ToString(); } }).Where(g => g.Count() > 1))
                        {
                            if (groups++ >= 300) break;
                            List<string> files = g2.OrderBy(f => { try { return File.GetCreationTime(f); } catch { return DateTime.MaxValue; } }).ToList();
                            w += kv.Key * (files.Count - 1);
                            if (!first) sb.Append(','); first = false;
                            sb.Append("{\"size\":").Append(kv.Key).Append(",\"files\":[").Append(string.Join(",", files.Select(f => Js.S(f)).ToArray())).Append("]}");
                        }
                }
                lock (lk) { result = sb.Append(']').ToString(); waste = w; state = "done"; progress = 100; }
            }
            catch (Exception ex) { lock (lk) { state = "error"; error = ex.Message; } }
        }
        // apaga (para a Reciclagem) só ficheiros que estão no resultado e só se fica pelo menos uma cópia
        public static string Delete(string body)
        {
            int n = 0; long freed = 0;
            List<string> want = (body ?? "").Replace("\r", "").Split('\n').Where(x => x.Trim() != "").ToList();
            string res; lock (lk) res = result;
            foreach (string f in want)
            {
                if (!res.Contains(Js.S(f))) continue;
                try
                {
                    long len = new FileInfo(f).Length;
                    Microsoft.VisualBasic.FileIO.FileSystem.DeleteFile(f, Microsoft.VisualBasic.FileIO.UIOption.OnlyErrorDialogs, Microsoft.VisualBasic.FileIO.RecycleOption.SendToRecycleBin);
                    n++; freed += len;
                    lock (lk) result = result.Replace(Js.S(f) + ",", "").Replace("," + Js.S(f), "");
                }
                catch { }
            }
            return "{\"ok\":true,\"deleted\":" + n + ",\"freed\":" + freed + "}";
        }
    }

    // ------------------------------------------------------------ crashes: ecrãs azuis, desligares inesperados, erros de hardware e programas que fecham
    static class Crashes
    {
        static string cache; static DateTime at = DateTime.MinValue;
        static readonly Dictionary<string, string[]> Codes = new Dictionary<string, string[]> {
            { "0x0000001a", new[] { "MEMORY_MANAGEMENT", "Problema na memória RAM. Desliga o XMP/EXPO para testar e corre o teste de estabilidade com RAM." } },
            { "0x00000050", new[] { "PAGE_FAULT_IN_NONPAGED_AREA", "Costuma ser RAM instável ou um driver com erro (antivírus, placa gráfica, rede)." } },
            { "0x0000000a", new[] { "IRQL_NOT_LESS_OR_EQUAL", "Um driver fez asneira. Atualiza os drivers da placa-mãe, rede e placa gráfica." } },
            { "0x000000d1", new[] { "DRIVER_IRQL_NOT_LESS_OR_EQUAL", "Driver com erro, muitas vezes o da rede ou do Wi-Fi. Atualiza-o." } },
            { "0x0000003b", new[] { "SYSTEM_SERVICE_EXCEPTION", "Erro num driver ou serviço do sistema. Atualiza os drivers e corre a reparação do Windows." } },
            { "0x0000007e", new[] { "SYSTEM_THREAD_EXCEPTION_NOT_HANDLED", "Um driver falhou. Vê qual nos detalhes e atualiza-o." } },
            { "0x0000001e", new[] { "KMODE_EXCEPTION_NOT_HANDLED", "Erro de um driver em modo kernel. Atualiza os drivers." } },
            { "0x00000124", new[] { "WHEA_UNCORRECTABLE_ERROR", "Erro de hardware: processador, RAM ou overclock/undervolt instável. Volta às definições de fábrica na BIOS." } },
            { "0x00000116", new[] { "VIDEO_TDR_FAILURE", "A placa gráfica deixou de responder. Reinstala o driver gráfico e tira overclocks da placa." } },
            { "0x00000117", new[] { "VIDEO_TDR_TIMEOUT_DETECTED", "A placa gráfica demorou demasiado. Driver gráfico ou overclock da placa." } },
            { "0x00000133", new[] { "DPC_WATCHDOG_VIOLATION", "Muitas vezes firmware do SSD ou drivers de armazenamento. Atualiza o firmware do SSD e o chipset." } },
            { "0x0000009f", new[] { "DRIVER_POWER_STATE_FAILURE", "Um driver não acordou da suspensão. Atualiza os drivers (rede, USB, placa gráfica)." } },
            { "0x000000ef", new[] { "CRITICAL_PROCESS_DIED", "Um processo essencial do Windows morreu. Corre a reparação do Windows (SFC/DISM)." } },
            { "0x00000139", new[] { "KERNEL_SECURITY_CHECK_FAILURE", "Driver incompatível ou memória instável. Atualiza drivers e testa a RAM." } },
            { "0x000000c5", new[] { "DRIVER_CORRUPTED_EXPOOL", "Driver com erro de memória. Atualiza os drivers recentes." } },
            { "0x0000007f", new[] { "UNEXPECTED_KERNEL_MODE_TRAP", "Hardware instável (RAM, processador) ou temperaturas altas." } },
            { "0x00000101", new[] { "CLOCK_WATCHDOG_TIMEOUT", "O processador deixou de responder: overclock/undervolt instável ou BIOS antiga." } },
        };
        static string Explain(string code)
        {
            string c = code.ToLowerInvariant();
            if (c.StartsWith("0x") && c.Length < 10) c = "0x" + c.Substring(2).PadLeft(8, '0');
            string[] v; return Codes.TryGetValue(c, out v) ? v[0] + "|" + v[1] : "|" + "Vê se aconteceu depois de instalar algum driver ou programa.";
        }
        public static string Json()
        {
            lock (typeof(Crashes))
            {
                if (cache != null && (DateTime.Now - at).TotalMinutes < 5) return cache;
                StringBuilder sys = new StringBuilder(), apps = new StringBuilder();
                Dictionary<string, int[]> appCount = new Dictionary<string, int[]>();
                Dictionary<string, string> appLast = new Dictionary<string, string>();
                int n = 0;
                string since = DateTime.UtcNow.AddDays(-30).ToString("yyyy-MM-ddTHH:mm:ss.000Z");
                try
                {
                    string q = "*[System[TimeCreated[@SystemTime>='" + since + "'] and (EventID=41 or EventID=1001 or EventID=6008)]]";
                    using (EventLogReader r = new EventLogReader(new EventLogQuery("System", PathType.LogName, q) { ReverseDirection = true }))
                        for (EventRecord e = r.ReadEvent(); e != null && n < 30; e = r.ReadEvent())
                            using (e)
                            {
                                string prov = e.ProviderName ?? "", when = e.TimeCreated.HasValue ? e.TimeCreated.Value.ToString("dd/MM/yyyy HH:mm") : "";
                                string kind, title, why;
                                if (e.Id == 1001 && prov.IndexOf("WER", StringComparison.OrdinalIgnoreCase) < 0 && prov.IndexOf("BugCheck", StringComparison.OrdinalIgnoreCase) < 0) continue;
                                if (e.Id == 1001)
                                {
                                    string msg = ""; try { msg = e.FormatDescription() ?? ""; } catch { }
                                    if (msg == "") try { msg = string.Join(" ", e.Properties.Select(p => Convert.ToString(p.Value)).ToArray()); } catch { }
                                    Match m = Regex.Match(msg, @"0x[0-9a-fA-F]{8}");
                                    string[] ex = Explain(m.Success ? m.Value : "").Split('|');
                                    kind = "bsod"; title = Lang.L("Ecrã azul") + (ex[0] != "" ? ": " + ex[0] : (m.Success ? " " + m.Value : "")); why = Lang.L(ex[1]);
                                }
                                else if (e.Id == 41) { kind = "power"; title = Lang.L("O PC desligou-se sem encerrar"); why = Lang.L("Falha de energia, botão carregado, crash ou fonte/temperaturas. Se acontece em jogo, vê as temperaturas e a fonte."); }
                                else { kind = "unexpected"; title = Lang.L("Encerramento inesperado"); why = Lang.L("O Windows não fechou bem da última vez."); }
                                if (n++ > 0) sys.Append(',');
                                sys.Append("{\"when\":").Append(Js.S(when)).Append(",\"kind\":").Append(Js.S(kind)).Append(",\"title\":").Append(Js.S(title)).Append(",\"why\":").Append(Js.S(why)).Append('}');
                            }
                }
                catch { }
                int whea = 0;
                try
                {
                    string q = "*[System[Provider[@Name='Microsoft-Windows-WHEA-Logger'] and TimeCreated[@SystemTime>='" + since + "']]]";
                    using (EventLogReader r = new EventLogReader(new EventLogQuery("System", PathType.LogName, q)))
                        for (EventRecord e = r.ReadEvent(); e != null && whea < 999; e = r.ReadEvent()) using (e) whea++;
                }
                catch { }
                try
                {
                    string q = "*[System[TimeCreated[@SystemTime>='" + since + "'] and (EventID=1000 or EventID=1002)]]";
                    int k = 0;
                    using (EventLogReader r = new EventLogReader(new EventLogQuery("Application", PathType.LogName, q) { ReverseDirection = true }))
                        for (EventRecord e = r.ReadEvent(); e != null && k < 500; e = r.ReadEvent(), k++)
                            using (e)
                            {
                                string app = ""; try { app = Convert.ToString(e.Properties[0].Value); } catch { }
                                if (app == "") continue;
                                int[] c; if (!appCount.TryGetValue(app, out c)) appCount[app] = c = new int[2];
                                c[e.Id == 1002 ? 1 : 0]++;
                                if (!appLast.ContainsKey(app) && e.TimeCreated.HasValue) appLast[app] = e.TimeCreated.Value.ToString("dd/MM HH:mm");
                            }
                }
                catch { }
                bool first = true;
                foreach (KeyValuePair<string, int[]> kv in appCount.OrderByDescending(x => x.Value[0] + x.Value[1]).Take(12))
                {
                    if (!first) apps.Append(','); first = false;
                    string last; appLast.TryGetValue(kv.Key, out last);
                    apps.Append("{\"app\":").Append(Js.S(kv.Key)).Append(",\"crash\":").Append(kv.Value[0]).Append(",\"hang\":").Append(kv.Value[1]).Append(",\"last\":").Append(Js.S(last ?? "")).Append('}');
                }
                cache = "{\"ok\":true,\"system\":[" + sys + "],\"whea\":" + whea + ",\"apps\":[" + apps + "]}";
                at = DateTime.Now;
                return cache;
            }
        }
    }

    // ------------------------------------------------------------ reparar o Windows: DISM (repara a imagem) e depois SFC (repara os ficheiros)
    static class Reparar
    {
        static readonly object lk = new object();
        static string state = "idle", step = "", lastLine = "", verdict = "", log = "";
        static int pct;
        public static string Json() { lock (lk) return "{\"ok\":true,\"state\":" + Js.S(state) + ",\"step\":" + Js.S(step) + ",\"pct\":" + pct + ",\"line\":" + Js.S(lastLine) + ",\"verdict\":" + Js.S(verdict) + ",\"log\":" + Js.S(log) + "}"; }
        public static string Start()
        {
            lock (lk) { if (state == "running") return Json(); state = "running"; step = "dism"; pct = 0; lastLine = ""; verdict = ""; log = ""; }
            ThreadPool.QueueUserWorkItem(delegate { Run(); });
            return Json();
        }
        static int Exec(string exe, string args, Encoding enc)
        {
            ProcessStartInfo psi = new ProcessStartInfo(exe, args) { UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true, RedirectStandardError = false, StandardOutputEncoding = enc };   // erros não lidos enchiam e bloqueavam
            using (Process p = Process.Start(psi))
            {
                StringBuilder line = new StringBuilder(); int ch;
                while ((ch = p.StandardOutput.Read()) >= 0)
                {
                    char c = (char)ch;
                    if (c == '\0') continue;
                    if (c == '\r' || c == '\n')
                    {
                        string l = line.ToString().Trim(); line.Length = 0;
                        if (l == "") continue;
                        Match m = Regex.Match(l, @"(\d{1,3})[.,]?\d*\s?%");
                        lock (lk)
                        {
                            if (m.Success) { int v; if (int.TryParse(m.Groups[1].Value, out v)) pct = Math.Min(100, v); }
                            else { lastLine = l; log += l + "\n"; if (log.Length > 6000) log = log.Substring(log.Length - 6000); }
                        }
                    }
                    else line.Append(c);
                }
                p.WaitForExit();
                return p.ExitCode;
            }
        }
        static void Run()
        {
            try
            {
                Encoding oem = Encoding.GetEncoding(CultureInfo.CurrentCulture.TextInfo.OEMCodePage);
                int d = Exec("dism.exe", "/Online /Cleanup-Image /RestoreHealth", oem);
                lock (lk) { step = "sfc"; pct = 0; }
                int s = Exec("sfc.exe", "/scannow", Encoding.Unicode);
                lock (lk)
                {
                    string l = log.ToLowerInvariant();
                    if (l.Contains("did not find any integrity") || l.Contains("não encontrou quaisquer viola") || l.Contains("não encontrou nenhuma viola")) verdict = "ok";
                    else if (l.Contains("successfully repaired") || l.Contains("repar") && l.Contains("com êxito")) verdict = "repaired";
                    else if (l.Contains("unable to fix") || l.Contains("não conseguiu corrigir") || l.Contains("não foi possível")) verdict = "failed";
                    else verdict = d == 0 && s == 0 ? "ok" : "unknown";
                    state = "done"; step = ""; pct = 100;
                }
                Program.Notify("NEXUS · " + Lang.L("Reparar o Windows"), Lang.L(verdict == "ok" ? "Sem problemas nos ficheiros do Windows." : verdict == "repaired" ? "Ficheiros do Windows reparados. Reinicia o PC." : "Acabou. Vê o resultado no NEXUS."));
            }
            catch (Exception ex) { lock (lk) { state = "error"; lastLine = ex.Message; } }
        }
    }

    // ------------------------------------------------------------ programas a correr (ou marcados para correr) como administrador
    static class AdminApps
    {
        [DllImport("advapi32.dll", SetLastError = true)] static extern bool OpenProcessToken(IntPtr h, uint access, out IntPtr tok);
        [DllImport("advapi32.dll", SetLastError = true)] static extern bool GetTokenInformation(IntPtr tok, int cls, out int info, int len, out int ret);
        [DllImport("kernel32.dll", SetLastError = true)] static extern IntPtr OpenProcess(uint access, bool inherit, int pid);
        [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)] static extern bool QueryFullProcessImageName(IntPtr h, int flags, StringBuilder name, ref int size);
        const string LAYERS = @"Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers";

        static bool Elevated(int pid, out string path)
        {
            path = "";
            IntPtr h = OpenProcess(0x1000, false, pid);   // PROCESS_QUERY_LIMITED_INFORMATION
            if (h == IntPtr.Zero) return false;
            try
            {
                StringBuilder sb = new StringBuilder(1024); int sz = sb.Capacity;
                if (QueryFullProcessImageName(h, 0, sb, ref sz)) path = sb.ToString();
                IntPtr tok;
                if (!OpenProcessToken(h, 0x0008, out tok)) return false;
                try { int e, r; return GetTokenInformation(tok, 20, out e, 4, out r) && e != 0; }
                finally { CloseHandle(tok); }
            }
            finally { CloseHandle(h); }
        }
        public static string Json()
        {
            StringBuilder run = new StringBuilder("["), flagged = new StringBuilder("[");
            string win = Environment.GetFolderPath(Environment.SpecialFolder.Windows).ToLowerInvariant();
            int me = Process.GetCurrentProcess().Id, mySession = Process.GetCurrentProcess().SessionId;
            HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            bool first = true;
            foreach (Process p in Process.GetProcesses())
            {
                try
                {
                    if (p.Id == me || p.SessionId != mySession || p.SessionId == 0) continue;
                    string path;
                    if (!Elevated(p.Id, out path) || path == "" || path.ToLowerInvariant().StartsWith(win) || !seen.Add(path)) continue;
                    string desc = "", comp = "";
                    try { FileVersionInfo fv = FileVersionInfo.GetVersionInfo(path); desc = fv.FileDescription ?? ""; comp = fv.CompanyName ?? ""; } catch { }
                    if (!first) run.Append(','); first = false;
                    run.Append("{\"name\":").Append(Js.S(p.ProcessName)).Append(",\"path\":").Append(Js.S(path)).Append(",\"desc\":").Append(Js.S(desc.Trim())).Append(",\"company\":").Append(Js.S(comp.Trim())).Append('}');
                }
                catch { }
                finally { p.Dispose(); }
            }
            first = true;
            foreach (RegistryKey hive in new[] { Registry.CurrentUser, Registry.LocalMachine })
                try
                {
                    using (RegistryKey k = hive.OpenSubKey(LAYERS))
                        if (k != null)
                            foreach (string n in k.GetValueNames())
                            {
                                string v = Convert.ToString(k.GetValue(n)) ?? "";
                                if (v.IndexOf("RUNASADMIN", StringComparison.OrdinalIgnoreCase) < 0) continue;
                                if (!first) flagged.Append(','); first = false;
                                flagged.Append("{\"path\":").Append(Js.S(n)).Append(",\"machine\":").Append(hive == Registry.LocalMachine ? "true" : "false").Append('}');
                            }
                }
                catch { }
            return "{\"ok\":true,\"running\":" + run.Append(']') + ",\"flagged\":" + flagged.Append(']') + "}";
        }
        // tira só a marca "Executar como administrador" (as outras opções de compatibilidade ficam)
        public static string Unflag(string path, bool machine)
        {
            try
            {
                using (RegistryKey k = (machine ? Registry.LocalMachine : Registry.CurrentUser).OpenSubKey(LAYERS, true))
                {
                    if (k == null) return Json();
                    string v = Convert.ToString(k.GetValue(path));
                    if (v == null) return Json();
                    string nv = string.Join(" ", v.Split(' ').Where(x => x != "" && !x.Equals("RUNASADMIN", StringComparison.OrdinalIgnoreCase)).ToArray()).Trim();
                    if (nv == "" || nv == "~") k.DeleteValue(path, false); else k.SetValue(path, nv);
                }
            }
            catch (Exception ex) { return "{\"ok\":false,\"error\":" + Js.S(ex.Message) + "}"; }
            return Json();
        }
    }

    // ------------------------------------------------------------ vigiar uma transferência: avisa / suspende / desliga quando a rede fica parada
    static class Vigia
    {
        static readonly object lk = new object();
        static string action = "", state = "off"; static DateTime armedAt, quietSince = DateTime.MinValue; static double peak; static Timer timer;
        static long downloaded, lastRx = -1; static int countdown = -1; static double rate; static DateTime lastAt;
        static long Rx()
        {
            long t = 0;
            foreach (System.Net.NetworkInformation.NetworkInterface ni in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
                try
                {
                    if (ni.OperationalStatus != System.Net.NetworkInformation.OperationalStatus.Up) continue;
                    if (ni.NetworkInterfaceType == System.Net.NetworkInformation.NetworkInterfaceType.Loopback || ni.NetworkInterfaceType == System.Net.NetworkInformation.NetworkInterfaceType.Tunnel) continue;
                    t += ni.GetIPv4Statistics().BytesReceived;
                }
                catch { }
            return t;
        }
        public static string Json()
        {
            lock (lk) return "{\"ok\":true,\"state\":" + Js.S(state) + ",\"action\":" + Js.S(action) + ",\"now\":" + Js.N(rate) + ",\"peak\":" + Js.N(peak) +
                             ",\"total\":" + downloaded + ",\"quiet\":" + (quietSince == DateTime.MinValue ? 0 : (int)(DateTime.Now - quietSince).TotalSeconds) + ",\"countdown\":" + countdown + "}";
        }
        public static string Arm(string act)
        {
            lock (lk)
            {
                action = act == "sleep" || act == "shutdown" ? act : "notify";
                state = "armed"; armedAt = DateTime.Now; quietSince = DateTime.MinValue; peak = 0; downloaded = 0; countdown = -1; lastRx = Rx(); lastAt = DateTime.Now; rate = 0;
                if (timer == null) timer = new Timer(delegate { try { Tick(); } catch { } }, null, 2000, 2000);
            }
            return Json();
        }
        public static string Cancel()
        {
            lock (lk) { state = "off"; countdown = -1; }
            return Json();
        }
        static void Tick()
        {
            string doIt = null;
            lock (lk)
            {
                if (state == "off" || state == "done") return;
                long rx = Rx(); double dt = Math.Max(0.5, (DateTime.Now - lastAt).TotalSeconds);
                double d = lastRx < 0 || rx < lastRx ? 0 : (rx - lastRx) / dt;
                lastRx = rx; lastAt = DateTime.Now; rate = d;
                downloaded += (long)(d * dt);
                if (d > peak) peak = d;
                if (state == "countdown")
                {
                    countdown -= 2;
                    if (countdown <= 0) { state = "done"; doIt = action; countdown = -1; }
                }
                else
                {
                    // só conta como "acabou" depois de ter havido uma transferência a sério (> 1 MB/s) e 60 s quase sem nada (< 150 KB/s)
                    if (peak < 1048576) return;
                    if (d < 153600) { if (quietSince == DateTime.MinValue) quietSince = DateTime.Now; }
                    else quietSince = DateTime.MinValue;
                    if (quietSince != DateTime.MinValue && (DateTime.Now - quietSince).TotalSeconds >= 60)
                    {
                        if (action == "notify") { state = "done"; doIt = "notify"; }
                        else { state = "countdown"; countdown = 60; doIt = "warn"; }
                    }
                }
            }
            if (doIt == null) return;
            string gb = (downloaded / 1073741824.0).ToString("0.0", CultureInfo.InvariantCulture) + " GB";
            if (doIt == "notify") Program.Notify("NEXUS · " + Lang.L("Transferência acabou"), Lang.L("A rede está parada há 1 minuto.") + " ~" + gb);
            else if (doIt == "warn") Program.Notify("NEXUS · " + Lang.L("Transferência acabou"), Lang.L(action == "shutdown" ? "O PC desliga-se daqui a 60 segundos. Abre o NEXUS para cancelar." : "O PC suspende daqui a 60 segundos. Abre o NEXUS para cancelar."));
            else if (doIt == "shutdown") { try { Process.Start(new ProcessStartInfo("shutdown", "/s /t 0") { UseShellExecute = false, CreateNoWindow = true }); } catch { } }
            else if (doIt == "sleep") Program.Ui(delegate { try { System.Windows.Forms.Application.SetSuspendState(System.Windows.Forms.PowerState.Suspend, false, false); } catch { } });
        }
    }

    // ------------------------------------------------------------ não incomodar enquanto jogas (desliga as notificações do Windows e volta a ligar)
    static class NaoIncomodar
    {
        const string KEY = @"Software\Microsoft\Windows\CurrentVersion\Notifications\Settings";
        static string FileS { get { return Path.Combine(AppSettings.Dir, "nao_incomodar.txt"); } }
        public static void OnGame(bool on)
        {
            try
            {
                if (on && AppSettings.Dnd)
                {
                    if (File.Exists(FileS)) return;
                    object prev;
                    using (RegistryKey k = Registry.CurrentUser.CreateSubKey(KEY)) { prev = k.GetValue("NOC_GLOBAL_SETTING_TOASTS_ENABLED"); k.SetValue("NOC_GLOBAL_SETTING_TOASTS_ENABLED", 0, RegistryValueKind.DWord); }
                    File.WriteAllText(FileS, prev == null ? "none" : Convert.ToString(prev));
                }
                else if (!on) Restore();
            }
            catch { }
        }
        // volta a pôr como estava (também ao abrir o NEXUS, se ficou ligado por um crash)
        public static void Restore()
        {
            try
            {
                if (!File.Exists(FileS)) return;
                string prev = File.ReadAllText(FileS).Trim();
                using (RegistryKey k = Registry.CurrentUser.CreateSubKey(KEY))
                {
                    if (prev == "none") k.DeleteValue("NOC_GLOBAL_SETTING_TOASTS_ENABLED", false);
                    else { int v; if (int.TryParse(prev, out v)) k.SetValue("NOC_GLOBAL_SETTING_TOASTS_ENABLED", v, RegistryValueKind.DWord); }
                }
                File.Delete(FileS);
            }
            catch { }
        }
    }

    // ------------------------------------------------------------ limite de FPS automático: Hz do monitor - 3 (perfil global do RivaTuner). Opcional.
    static class FpsAutoLim
    {
        public static string Apply()
        {
            int hz = HwCheck.PrimaryHz();
            if (!AppSettings.FpsAuto) { return FpsLimite.SetGlobal(0); }
            if (hz < 50) return Lang.L("não consegui ler os Hz do monitor");
            return FpsLimite.SetGlobal(hz - 3);
        }
    }

    // ------------------------------------------------------------ outros PCs da casa com o NEXUS (opcional): cada um anuncia o nome e o estado na rede local
    static class Vizinhos
    {
        const int PORT = 8766;
        static readonly object lk = new object();
        static readonly Dictionary<string, string[]> peers = new Dictionary<string, string[]>();   // ip -> { nome, json estado, hora }
        static Thread rx; static Timer tx;
        public static void Start()
        {
            rx = new Thread(Listen) { IsBackground = true }; rx.Start();
            tx = new Timer(delegate { try { Announce(); } catch { } }, null, 5000, 20000);
        }
        static void Announce()
        {
            if (!AppSettings.LanShare) return;
            double cpu, ram, rg; double? ct, g, gt;
            Stats.OverlaySnap(out cpu, out ct, out g, out gt, out ram, out rg, false);
            string st = "{\"nexus\":1,\"name\":" + Js.S(Environment.MachineName) + ",\"port\":8765,\"cpu\":" + Js.N(cpu) + ",\"cput\":" + Js.N(ct ?? double.NaN) +
                        ",\"gput\":" + Js.N(gt ?? double.NaN) + ",\"ram\":" + Js.N(ram) + ",\"game\":" + Js.S(Optimizer.GameName) + "}";
            byte[] b = Encoding.UTF8.GetBytes(st);
            using (UdpClient u = new UdpClient()) { u.EnableBroadcast = true; u.Send(b, b.Length, new IPEndPoint(IPAddress.Broadcast, PORT)); }
        }
        static void Listen()
        {
            while (true)
            {
                try
                {
                    using (UdpClient u = new UdpClient())
                    {
                        u.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
                        u.Client.Bind(new IPEndPoint(IPAddress.Any, PORT));
                        while (true)
                        {
                            IPEndPoint from = new IPEndPoint(IPAddress.Any, 0);
                            byte[] b = u.Receive(ref from);
                            if (!AppSettings.LanShare || b.Length > 2048) continue;
                            string s = Encoding.UTF8.GetString(b);
                            if (!s.StartsWith("{\"nexus\":1")) continue;
                            Match m = Regex.Match(s, "\"name\":\"((?:[^\"\\\\]|\\\\.)*)\"");
                            if (!m.Success || m.Groups[1].Value == Environment.MachineName) continue;
                            lock (lk)
                            {
                                peers[from.Address.ToString()] = new[] { m.Groups[1].Value, s, DateTime.Now.ToString("o") };
                                // pacotes falsos de muitos endereços não enchem a memória: ficam no máximo 32 (sai o mais antigo)
                                if (peers.Count > 32) peers.Remove(peers.OrderBy(x => x.Value[2], StringComparer.Ordinal).First().Key);
                            }
                        }
                    }
                }
                catch { Thread.Sleep(10000); }
            }
        }
        // o que outro PC da rede mandou é refeito campo a campo (nunca se passa à página tal como chegou:
        // um pacote feito à mão podia meter código na página do NEXUS)
        static string PeerSafe(string s)
        {
            Func<string, string> num = k => { Match m = Regex.Match(s, "\"" + k + "\":(-?[0-9]{1,6}(?:\\.[0-9]{1,4})?)[,}]"); return m.Success ? m.Groups[1].Value : "null"; };
            Func<string, string> str = k =>
            {
                Match m = Regex.Match(s, "\"" + k + "\":\"((?:[^\"\\\\]|\\\\.){0,120})\"");
                string v = null; if (m.Success) try { v = Regex.Unescape(m.Groups[1].Value); } catch { }
                return Js.S(v);
            };
            int port; Match pm = Regex.Match(s, "\"port\":([0-9]{1,5})[,}]");
            if (!pm.Success || !int.TryParse(pm.Groups[1].Value, out port) || port < 1 || port > 65535) port = 8765;
            return "{\"name\":" + str("name") + ",\"port\":" + port + ",\"cpu\":" + num("cpu") + ",\"cput\":" + num("cput") + ",\"gput\":" + num("gput") +
                   ",\"ram\":" + num("ram") + ",\"game\":" + str("game") + "}";
        }
        public static string Json()
        {
            lock (lk)
            {
                DateTime lim = DateTime.Now.AddMinutes(-2);
                List<string> l = new List<string>();
                foreach (KeyValuePair<string, string[]> kv in peers)
                {
                    DateTime t; if (!DateTime.TryParse(kv.Value[2], null, DateTimeStyles.RoundtripKind, out t) || t < lim) continue;
                    l.Add("{\"ip\":" + Js.S(kv.Key) + ",\"status\":" + PeerSafe(kv.Value[1]) + "}");
                }
                return "{\"ok\":true,\"on\":" + (AppSettings.LanShare ? "true" : "false") + ",\"me\":" + Js.S(Environment.MachineName) + ",\"peers\":[" + string.Join(",", l.ToArray()) + "]}";
            }
        }
    }
}
