﻿// NEXUS // MONITOR 2.4 - ROTA PARA JOGOS (tipo ExitLag, opcional)
// Desligada por defeito. Só funciona depois de o utilizador aceitar uma janela que diz, às claras, que o tráfego do jogo
// passa pelos servidores da Cloudflare (WARP, grátis). Fora disso, nada sai do PC.
//
// Como funciona:
//  1. Quando um jogo abre, um registo de eventos de rede do próprio Windows (ETW, Microsoft-Windows-Kernel-Network) vê
//     para onde o processo do jogo manda pacotes UDP/TCP. O destino com mais pacotes é o servidor do jogo.
//  2. Mede o ping, o jitter e as perdas até lá pela ligação normal e pela Cloudflare. Só liga a rota se ganhar.
//  3. A rota é só para esse servidor: o WARP fica em modo "excluir" com tudo o resto da internet excluído
//     (o complemento em blocos CIDR do /24 do servidor). O browser, o Discord e os downloads não passam pela Cloudflare.
//  4. Quando o jogo fecha, a rota desliga-se e as regras do WARP voltam ao normal.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

namespace Nexus
{
    static class Rota
    {
        static readonly object lk = new object();
        public const string WarpUrl = "https://downloads.cloudflareclient.com/v1/download/windows/ga";   // página oficial de transferência da Cloudflare

        // ---- estado
        static string game, busy = "", lastErr = "";
        static int pid;
        static uint server; static int serverPort; static int serverPkts;
        static bool active;                 // a rota está ligada agora
        static string activeKey = "";      // redes que estão a passar pela Cloudflare
        static DateTime gameSince, lastCheck = DateTime.MinValue;
        static Meas mNormal, mWarp; static DateTime measWhen = DateTime.MinValue; static bool measApprox; static string verdict = "";
        static Meas live; static DateTime liveWhen = DateTime.MinValue;

        public class Meas { public double ms = -1, jit = -1, loss = 100; public int n; }

        public static bool Consent { get { return Cfg23.On("rt_consent", false); } }
        public static bool Enabled { get { return Consent && Cfg23.On("rt_on", false); } }
        public static bool Active { get { lock (lk) return active; } }

        // ================================================================ JSON para o painel
        public static string Json()
        {
            StringBuilder b = new StringBuilder("{\"ok\":true");
            string w = WarpExe();
            lock (lk)
            {
                b.Append(",\"consent\":").Append(Consent ? "true" : "false")
                 .Append(",\"on\":").Append(Cfg23.On("rt_on", false) ? "true" : "false")
                 .Append(",\"warp\":").Append(w != null ? "true" : "false")
                 .Append(",\"admin\":").Append(EtwNet.CanRun ? "true" : "false")
                 .Append(",\"busy\":").Append(Js.S(busy))
                 .Append(",\"err\":").Append(Js.S(lastErr))
                 .Append(",\"active\":").Append(active ? "true" : "false")
                 .Append(",\"game\":").Append(Js.S(game))
                 .Append(",\"mins\":").Append(game != null ? Js.N((DateTime.UtcNow - gameSince).TotalMinutes) : "null")
                 .Append(",\"server\":").Append(server != 0 ? Js.S(Ip(server) + (serverPort > 0 ? ":" + serverPort : "")) : "null")
                 .Append(",\"pkts\":").Append(serverPkts)
                 .Append(",\"normal\":").Append(MJ(mNormal))
                 .Append(",\"cf\":").Append(MJ(mWarp))
                 .Append(",\"approx\":").Append(measApprox ? "true" : "false")
                 .Append(",\"verdict\":").Append(Js.S(verdict))
                 .Append(",\"measAgo\":").Append(measWhen == DateTime.MinValue ? "null" : Js.N((DateTime.UtcNow - measWhen).TotalSeconds))
                 .Append(",\"live\":").Append(MJ(live));
            }
            // decisões guardadas por jogo
            b.Append(",\"games\":[");
            bool first = true;
            foreach (KeyValuePair<string, string> kv in Cfg23.Prefix("rt_g_"))
            {
                string[] f = kv.Value.Split('|');   // modo|ms normal|ms cloudflare|quando
                if (!first) b.Append(','); first = false;
                b.Append("{\"game\":").Append(Js.S(kv.Key)).Append(",\"mode\":").Append(Js.S(f[0]))
                 .Append(",\"n\":").Append(f.Length > 1 && f[1] != "" ? f[1] : "null").Append(",\"w\":").Append(f.Length > 2 && f[2] != "" ? f[2] : "null")
                 .Append(",\"when\":").Append(Js.S(f.Length > 3 ? f[3] : "")).Append('}');
            }
            b.Append("]}");
            return b.ToString();
        }
        static string MJ(Meas m)
        {
            if (m == null) return "null";
            return "{\"ms\":" + (m.ms < 0 ? "null" : Js.N(m.ms)) + ",\"jit\":" + (m.jit < 0 ? "null" : Js.N(m.jit)) + ",\"loss\":" + Js.N(m.loss) + "}";
        }

        // ================================================================ ações do painel
        public static string SetConsent(bool yes)
        {
            Cfg23.Set("rt_consent", yes ? "1" : "0");
            if (!yes) { Cfg23.Set("rt_on", "0"); ThreadPool.QueueUserWorkItem(delegate { try { lock (routeLk) Off("consentimento retirado"); } catch { } }); }
            return Json();
        }
        public static string SetOn(bool on)
        {
            if (on && !Consent) return Ps23.Ok(false, "consent");
            Cfg23.Set("rt_on", on ? "1" : "0");
            if (!on) ThreadPool.QueueUserWorkItem(delegate { try { lock (routeLk) Off("desligada pelo utilizador"); } catch { } });
            else if (WarpExe() == null) ThreadPool.QueueUserWorkItem(delegate { Install(); });
            else lock (lk) if (game != null && pid > 0) EtwNet.Watch(pid);   // a rota só se liga no início do próximo jogo
            return Json();
        }
        public static string SetGame(string g, string mode)
        {
            if (string.IsNullOrEmpty(g)) return Ps23.Ok(false, "game");
            if (mode != "on" && mode != "off" && mode != "auto") mode = "auto";
            string[] f = Cfg23.Get("rt_g_" + g, "auto||||").Split('|');
            f[0] = mode;
            Cfg23.Set("rt_g_" + g, string.Join("|", f));
            // não se mexe no caminho a meio de uma partida: vale a partir do próximo jogo
            return Json();
        }
        public static string Forget(string g) { Cfg23.Set("rt_g_" + g, null); return Json(); }

        // testar já: com jogo aberto usa o servidor dele; sem jogo, aceita um IP ou nome escrito pelo utilizador
        public static string TestNow(string host)
        {
            if (!Consent) return Ps23.Ok(false, "consent");
            uint ip = 0;
            if (!string.IsNullOrEmpty(host)) ip = Resolve(host);
            if (ip == 0) lock (lk) ip = server;
            if (ip == 0) return Ps23.Ok(false, Lang.L("Abre um jogo (ou escreve o servidor) para testar."));
            uint t = ip;
            ThreadPool.QueueUserWorkItem(delegate { try { Compare(t, true); } catch (Exception e) { lock (lk) { lastErr = e.Message; busy = ""; } } });
            return Json();
        }

        public static string UninstallWarp()
        {
            Off("WARP desinstalado");
            Cfg23.Set("rt_on", "0");
            ThreadPool.QueueUserWorkItem(delegate
            {
                lock (lk) busy = Lang.L("A desinstalar o Cloudflare WARP…");
                try
                {
                    string cmd = null;
                    foreach (string root in new[] { @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall", @"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall" })
                        using (Microsoft.Win32.RegistryKey k = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(root))
                            if (k != null)
                                foreach (string sub in k.GetSubKeyNames())
                                    using (Microsoft.Win32.RegistryKey s = k.OpenSubKey(sub))
                                    {
                                        string n = s == null ? null : s.GetValue("DisplayName") as string;
                                        if (n != null && n.IndexOf("Cloudflare WARP", StringComparison.OrdinalIgnoreCase) >= 0 && sub.StartsWith("{")) cmd = "/x " + sub + " /qn /norestart";
                                    }
                    if (cmd != null) Ps23.Cmd("msiexec.exe", cmd, 300000);
                }
                catch (Exception e) { lock (lk) lastErr = e.Message; }
                lock (lk) busy = "";
            });
            return Json();
        }

        // ao arrancar: se a rota ficou ligada (o NEXUS fechou à força), desliga-a
        public static void OnStart()
        {
            if (Cfg23.On("rt_live", false)) ThreadPool.QueueUserWorkItem(delegate { try { Off("arranque"); } catch { } });
            else if (Consent && WarpExe() != null) ThreadPool.QueueUserWorkItem(delegate { try { Thread.Sleep(15000); Tame(); if (!Active) SvcStop(); } catch { } });
        }

        // ================================================================ ligação ao ciclo do NEXUS (Vigias23)
        // REGRA: o caminho até ao servidor nunca muda a meio de uma partida (o servidor via outro endereço e desligava o jogador).
        // A rota liga-se quando o jogo abre (antes de entrar num servidor), para os servidores que esse jogo já usou,
        // e os testes durante o jogo medem através do ponto da rede mesmo antes do servidor, sem tocar na ligação do jogo.
        static bool routedAtStart;
        static readonly object routeLk = new object();   // uma mudança de rota de cada vez (ligar no arranque, testar, desligar)
        public static void GameStart(string g, int p)
        {
            lock (lk) { game = g; pid = p; gameSince = DateTime.UtcNow; server = 0; serverPort = 0; serverPkts = 0; mNormal = mWarp = live = null; verdict = ""; measWhen = DateTime.MinValue; lastCheck = DateTime.UtcNow; routedAtStart = false; }
            if (!Enabled || WarpExe() == null || p <= 0) return;
            EtwNet.Watch(p);
            string[] f = Cfg23.Get("rt_g_" + g, "auto||||").Split('|');
            bool better = f.Length > 4 && f[4] == "1";
            List<uint> nets = Nets(g);
            if (nets.Count > 0 && (f[0] == "on" || (f[0] == "auto" && better)))
                ThreadPool.QueueUserWorkItem(delegate
                {
                    try
                    {
                        bool ok;
                        lock (routeLk)
                        {
                            bool still; lock (lk) still = game == g;
                            if (!still) return;
                            ok = RouteOn(nets.Select(n => new KeyValuePair<uint, int>(n, 24)).ToList(), false);
                            bool gone; lock (lk) gone = game != g;
                            if (ok && gone) { Off("o jogo fechou"); return; }   // o jogo fechou enquanto a rota ligava
                        }
                        if (ok)
                        {
                            lock (lk) { routedAtStart = true; verdict = Lang.L("Rota da Cloudflare ligada desde o início do jogo (para os servidores que este jogo já usou)."); }
                            Vigias23.Alert(Lang.L("🌐 Rota Cloudflare ligada"), string.Format(Lang.L("{0}: o tráfego deste jogo passa pela Cloudflare até o fechares."), g));
                        }
                    }
                    catch (Exception e) { lock (lk) lastErr = e.Message; }
                });
        }
        public static void GameEnd(string g)
        {
            EtwNet.Stop();
            lock (lk) { game = null; pid = 0; server = 0; routedAtStart = false; }
            // espera que acabe qualquer mudança em curso (ex.: a rota ainda a ligar) e só depois desliga
            ThreadPool.QueueUserWorkItem(delegate { try { lock (routeLk) if (Active) Off("o jogo fechou"); } catch { } });
        }
        // chamado a cada segundo pelo Vigias23.Tick
        public static void Tick()
        {
            string g; int p; DateTime since, lc;
            lock (lk) { g = game; p = pid; since = gameSince; lc = lastCheck; }
            if (g == null || p <= 0 || !Enabled || WarpExe() == null) return;
            if (!EtwNet.Running) EtwNet.Watch(p);
            double secs = (DateTime.UtcNow - since).TotalSeconds, sinceCheck = (DateTime.UtcNow - lc).TotalSeconds;
            if (secs < 40 || sinceCheck < (server == 0 ? 15 : 60)) return;
            lock (lk) lastCheck = DateTime.UtcNow;
            ThreadPool.QueueUserWorkItem(delegate { try { Decide(false); } catch (Exception e) { lock (lk) lastErr = e.Message; } });
        }

        // redes (/24) dos servidores que cada jogo usou, a mais recente primeiro (no máximo 8)
        static List<uint> Nets(string g)
        {
            List<uint> l = new List<uint>();
            foreach (string x in Cfg23.Get("rt_n_" + g, "").Split(','))
            {
                IPAddress a; if (IPAddress.TryParse(x.Trim(), out a)) { uint u = ToU(a); if (u != 0) l.Add(u & 0xFFFFFF00u); }
            }
            return l.Distinct().ToList();
        }
        static void AddNet(string g, uint ip)
        {
            List<uint> l = Nets(g); uint n = ip & 0xFFFFFF00u;
            l.Remove(n); l.Insert(0, n);
            Cfg23.Set("rt_n_" + g, string.Join(",", l.Take(6).Select(Ip).ToArray()));
        }

        static int deciding;
        static void Decide(bool force)
        {
            if (Interlocked.Exchange(ref deciding, 1) == 1) return;
            try
            {
                string g; int p; lock (lk) { g = game; p = pid; }
                if (g == null) return;
                int port, pk;
                uint top = EtwNet.Top(p, out port, out pk);
                if (top == 0) return;
                bool changed;
                lock (lk) { changed = server == 0 || (server & 0xFFFFFF00u) != (top & 0xFFFFFF00u); server = top; serverPort = port; serverPkts = pk; }
                bool known = Nets(g).Contains(top & 0xFFFFFF00u);
                AddNet(g, top);
                string mode = Cfg23.Get("rt_g_" + g, "auto||||").Split('|')[0];
                bool on; lock (lk) on = active;
                if (on)
                {
                    // a rota já está ligada: não se mexe em nada até o jogo fechar; só se mede a ligação
                    Meas m = Measure(top, 6, 120); lock (lk) { live = m; liveWhen = DateTime.UtcNow; }
                    if (changed && !known) lock (lk) verdict = Lang.L("Este servidor é novo: a rota passa a incluí-lo a partir do próximo jogo.");
                    return;
                }
                if (mode == "off") return;
                if (!changed && !force)
                {
                    Meas m = Measure(top, 6, 120); lock (lk) { live = m; liveWhen = DateTime.UtcNow; }
                    return;
                }
                Compare(top, false);
            }
            finally { Interlocked.Exchange(ref deciding, 0); }
        }

        // último salto que responde antes do servidor (para testar a rota sem tocar na ligação do jogo)
        static uint HopBefore(uint ip)
        {
            uint last = 0;
            using (Ping p = new Ping())
                for (int ttl = 1; ttl <= 30; ttl++)
                {
                    try
                    {
                        PingReply r = p.Send(new IPAddress(BitConverter.GetBytes(ip).Reverse().ToArray()), 900, new byte[16], new PingOptions(ttl, true));
                        if (r == null) continue;
                        if (r.Status == IPStatus.Success) break;   // chegou ao servidor: fica o salto anterior
                        if (r.Status == IPStatus.TtlExpired) { uint a = ToU(r.Address); if (a != 0 && a != ip && !Private(a)) last = a; }
                    }
                    catch { }
                }
            return last;
        }

        // ================================================================ comparar a ligação normal com a Cloudflare
        static void Compare(uint ip, bool manual)
        {
            string g; bool on; lock (lk) { g = game; on = active; }
            if (on) { lock (lk) verdict = Lang.L("A rota já está ligada neste jogo. Os testes ficam para quando não estiver (mexer agora desligava-te do servidor)."); return; }
            lock (lk) { busy = Lang.L("A medir a ligação normal…"); lastErr = ""; }
            // com um jogo aberto, nunca se desvia o servidor dele: mede-se até ao salto mesmo antes
            uint target = ip; bool approx = false;
            if (g != null)
            {
                uint hop = HopBefore(ip);
                if (hop == 0) { lock (lk) { busy = ""; verdict = Lang.L("Não dá para testar a meio do jogo sem te desligar do servidor. Testa sem o jogo aberto (escreve o servidor) ou escolhe \"Sempre\" para este jogo."); } return; }
                target = hop; approx = true;
            }
            Meas n = Measure(target, 20, 100);
            if (n.n == 0 && g == null) { uint hop = HopBefore(ip); if (hop != 0) { target = hop; approx = true; n = Measure(target, 20, 100); } }
            if (n.n == 0) { lock (lk) { busy = ""; verdict = Lang.L("O servidor não responde a medições. Não dá para comparar."); } return; }
            lock (lk) busy = Lang.L("A ligar a rota da Cloudflare para comparar…");
            Meas w;
            lock (routeLk)
            {
                // entretanto a rota pode ter sido ligada para o jogo: nesse caso não se mexe
                if (Active) { lock (lk) { busy = ""; verdict = Lang.L("A rota já está ligada neste jogo. Os testes ficam para quando não estiver (mexer agora desligava-te do servidor)."); } return; }
                if (!RouteOn(new List<KeyValuePair<uint, int>> { new KeyValuePair<uint, int>(target, 32) }, true)) { lock (lk) busy = ""; return; }
                Thread.Sleep(1500);
                lock (lk) busy = Lang.L("A medir pela Cloudflare…");
                w = Measure(target, 20, 100);
                Off(null);   // o teste acaba sempre com a rota desligada
            }
            bool better = w.n > 0 && (w.ms + 3 < n.ms || (w.loss + 2 < n.loss && w.ms <= n.ms + 5));
            lock (lk)
            {
                mNormal = n; mWarp = w; measWhen = DateTime.UtcNow; measApprox = approx;
                verdict = w.n == 0 ? Lang.L("Pela Cloudflare não houve resposta: fica a ligação normal.")
                        : better ? (g != null ? string.Format(Lang.L("A Cloudflare é melhor: {0} ms → {1} ms. Liga-se sozinha no início do próximo jogo (ligar a meio desligava-te do servidor)."), Math.Round(n.ms), Math.Round(w.ms))
                                              : string.Format(Lang.L("A Cloudflare é melhor para este servidor: {0} ms → {1} ms."), Math.Round(n.ms), Math.Round(w.ms)))
                        : string.Format(Lang.L("A ligação normal já é melhor ({0} ms contra {1} ms). Fica como está."), Math.Round(n.ms), Math.Round(w.ms));
                busy = "";
            }
            if (g != null)
            {
                string[] f = Cfg23.Get("rt_g_" + g, "auto||||").Split('|');
                Cfg23.Set("rt_g_" + g, f[0] + "|" + Math.Round(n.ms) + "|" + (w.n > 0 ? Math.Round(w.ms).ToString(CultureInfo.InvariantCulture) : "") + "|" + DateTime.Now.ToString("yyyy-MM-dd") + "|" + (better ? "1" : "0"));
                if (better && !manual)
                    Vigias23.Alert(Lang.L("🌐 A Cloudflare é mais rápida"), string.Format(Lang.L("{0}: {1} ms → {2} ms. Da próxima vez que abrires o jogo, a rota liga-se logo no início."), g, Math.Round(n.ms), Math.Round(w.ms)));
            }
        }

        // ================================================================ WARP
        public static string WarpExe()
        {
            foreach (string d in new[] { Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), @"C:\Program Files" })
            {
                try { string f = Path.Combine(d, @"Cloudflare\Cloudflare WARP\warp-cli.exe"); if (File.Exists(f)) return f; } catch { }
            }
            return null;
        }
        static string Cli(string args, int ms)
        {
            string w = WarpExe();
            if (w == null) return "";
            SvcStart();   // o serviço do WARP só corre quando o NEXUS precisa dele
            return Ps23.Cmd(w, "--accept-tos " + args, ms) ?? "";
        }

        // ---- o WARP só existe quando é preciso: sem janela, sem arrancar com o Windows, serviço manual
        const string WarpSvc = "CloudflareWARP";
        static readonly string[] WarpGui = { "Cloudflare WARP" };
        static void SvcStart()
        {
            try
            {
                using (System.ServiceProcess.ServiceController sc = new System.ServiceProcess.ServiceController(WarpSvc))
                    if (sc.Status != System.ServiceProcess.ServiceControllerStatus.Running)
                    {
                        if (sc.Status == System.ServiceProcess.ServiceControllerStatus.Stopped) sc.Start();
                        sc.WaitForStatus(System.ServiceProcess.ServiceControllerStatus.Running, TimeSpan.FromSeconds(20));
                        Thread.Sleep(1500);   // o serviço ainda está a acordar
                    }
            }
            catch { }
        }
        static void SvcStop()
        {
            try
            {
                using (System.ServiceProcess.ServiceController sc = new System.ServiceProcess.ServiceController(WarpSvc))
                    if (sc.Status == System.ServiceProcess.ServiceControllerStatus.Running) { sc.Stop(); sc.WaitForStatus(System.ServiceProcess.ServiceControllerStatus.Stopped, TimeSpan.FromSeconds(15)); }
            }
            catch { }
        }
        static void KillGui() { foreach (string n in WarpGui) try { foreach (Process p in Process.GetProcessesByName(n)) try { p.Kill(); } catch { } } catch { } }
        // depois de instalar: tira o WARP do arranque do Windows, fecha a janela dele e põe o serviço em manual
        static void Tame()
        {
            KillGui();
            try { foreach (string[] it in Arranque.Items()) if ((it[1] + " " + it[2]).IndexOf("Cloudflare WARP", StringComparison.OrdinalIgnoreCase) >= 0 && it[3] == "1") Arranque.Set(it[0], false); } catch { }
            try { using (Microsoft.Win32.RegistryKey k = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services\" + WarpSvc, true)) if (k != null) k.SetValue("Start", 3, Microsoft.Win32.RegistryValueKind.DWord); } catch { }
        }
        static bool Ok(string o) { return o.IndexOf("Success", StringComparison.OrdinalIgnoreCase) >= 0 && o.IndexOf("Error", StringComparison.OrdinalIgnoreCase) < 0; }

        static int installing;
        public static void Install()
        {
            if (Interlocked.Exchange(ref installing, 1) == 1) return;
            try
            {
                lock (lk) { busy = Lang.L("A transferir o Cloudflare WARP (site oficial)…"); lastErr = ""; }
                string f = Path.Combine(Path.GetTempPath(), "NEXUS_Cloudflare_WARP.msi");
                using (WebClient wc = new WebClient()) { wc.Headers.Add("User-Agent", "NEXUS-Monitor"); wc.DownloadFile(WarpUrl, f); }
                // só instala se o ficheiro estiver assinado pela Cloudflare
                string sig = PsFile.Run("rt_sig", "$s = Get-AuthenticodeSignature -LiteralPath '" + f.Replace("'", "''") + "'; \"$($s.Status)|$($s.SignerCertificate.Subject)\"", 30000) ?? "";
                // estado exatamente "Valid" e a empresa (O=) tem de ser a Cloudflare, Inc. — não basta "Cloudflare" algures no nome
                sig = sig.Trim();
                bool sigOk = sig.StartsWith("Valid|", StringComparison.Ordinal) &&
                             (sig.IndexOf("O=\"Cloudflare, Inc.\"", StringComparison.OrdinalIgnoreCase) >= 0 || sig.IndexOf("O=Cloudflare, Inc.", StringComparison.OrdinalIgnoreCase) >= 0 || sig.IndexOf("O=Cloudflare Inc", StringComparison.OrdinalIgnoreCase) >= 0);
                if (!sigOk)
                {
                    try { File.Delete(f); } catch { }
                    lock (lk) { lastErr = Lang.L("O ficheiro transferido não está assinado pela Cloudflare: não foi instalado."); busy = ""; }
                    return;
                }
                lock (lk) busy = Lang.L("A instalar o Cloudflare WARP…");
                Ps23.Cmd("msiexec.exe", "/i \"" + f + "\" /qn /norestart", 600000);
                try { File.Delete(f); } catch { }
                for (int i = 0; i < 30 && WarpExe() == null; i++) Thread.Sleep(1000);
                if (WarpExe() == null) { lock (lk) { lastErr = Lang.L("Não consegui instalar o Cloudflare WARP."); busy = ""; } return; }
                Thread.Sleep(3000);   // o serviço do WARP arranca
                lock (lk) busy = Lang.L("A preparar o WARP…");
                Prepare();
                Cli("disconnect", 15000);
                Tame();
                SvcStop();
                lock (lk) busy = "";
                string g; int p; lock (lk) { g = game; p = pid; }
                if (g != null && p > 0) EtwNet.Watch(p);
            }
            catch (Exception e) { lock (lk) { lastErr = e.Message; busy = ""; } }
            finally { Interlocked.Exchange(ref installing, 0); }
        }

        // registo (aceitar os termos foi feito pelo utilizador na janela do NEXUS) e modo "só tráfego" (o DNS continua o do PC)
        static void Prepare()
        {
            string reg = Cli("registration show", 15000);
            if (reg.IndexOf("Account", StringComparison.OrdinalIgnoreCase) < 0 && reg.IndexOf("Conta", StringComparison.OrdinalIgnoreCase) < 0) Cli("registration new", 30000);
            if (!Ok(Cli("mode tunnel_only", 15000))) Cli("mode warp", 15000);
        }

        static bool RouteOn(List<KeyValuePair<uint, int>> inc, bool forTest)
        {
            if (WarpExe() == null) { lock (lk) lastErr = Lang.L("O Cloudflare WARP não está instalado."); return false; }
            string key = string.Join(",", inc.Select(x => Ip(x.Key) + "/" + x.Value).ToArray());
            lock (lk) if (active && activeKey == key) return true;
            if (!forTest) lock (lk) busy = Lang.L("A ligar a rota da Cloudflare…");
            Prepare();
            Cli("disconnect", 15000);
            // modo excluir: tudo o que NÃO são estas redes fica fora do WARP. O WARP guarda esta lista, por isso só se
            // reescreve quando muda (assim, no início de um jogo já configurado, ligar demora 1-2 s e não meio minuto)
            if (Cfg23.Get("rt_cfgkey", "") != key)
            {
                Cfg23.Set("rt_cfgkey", null);
                Cli("tunnel ip reset", 15000);
                bool newSyntax = true;
                foreach (string c in Complement(inc))
                {
                    string o = newSyntax ? Cli("tunnel ip add " + c, 10000) : "";
                    if (newSyntax && !Ok(o) && o.IndexOf("unrecognized", StringComparison.OrdinalIgnoreCase) >= 0) newSyntax = false;
                    if (!newSyntax) Cli("add-excluded-route " + c, 10000);
                }
                foreach (string c in new[] { "::/1", "8000::/1" }) { if (!Ok(Cli("tunnel ip add " + c, 10000))) Cli("add-excluded-route " + c, 10000); }
                Cfg23.Set("rt_cfgkey", key);
            }
            Cli("connect", 15000);
            KillGui();
            bool up = false;
            for (int i = 0; i < 20 && !up; i++) { Thread.Sleep(750); up = Cli("status", 8000).IndexOf("Connected", StringComparison.OrdinalIgnoreCase) >= 0; }
            lock (lk)
            {
                if (!forTest) busy = "";
                if (!up) { lastErr = Lang.L("O WARP não ligou (sem internet ou bloqueado pela rede)."); active = false; activeKey = ""; }
                else { active = !forTest; activeKey = forTest ? "" : key; }
            }
            if (!forTest) Cfg23.Set("rt_live", up ? "1" : null);   // se o NEXUS fechar à força, ao arrancar desliga o que ficou
            if (!up) { Cli("disconnect", 15000); KillGui(); SvcStop(); }
            return up;
        }

        // blocos CIDR que cobrem toda a internet IPv4 menos as redes pedidas
        public static List<string> Complement(List<KeyValuePair<uint, int>> inc)
        {
            List<string> r = new List<string>();
            Comp(0, 0, inc, r);
            return r;
        }
        static void Comp(uint net, int len, List<KeyValuePair<uint, int>> inc, List<string> r)
        {
            uint mask = len == 0 ? 0u : 0xFFFFFFFFu << (32 - len);
            bool overlaps = false;
            foreach (KeyValuePair<uint, int> x in inc)
            {
                uint xm = x.Value == 0 ? 0u : 0xFFFFFFFFu << (32 - x.Value);
                if (x.Value <= len) { if ((net & xm) == (x.Key & xm)) return; }        // este bloco está todo dentro de uma rede pedida
                else if ((x.Key & mask) == net) overlaps = true;                         // uma rede pedida está dentro deste bloco
            }
            if (!overlaps) { r.Add(Ip(net) + "/" + len); return; }
            uint half = 1u << (31 - len);
            Comp(net, len + 1, inc, r);
            Comp(net | half, len + 1, inc, r);
        }

        public static void Off(string why)
        {
            bool was; lock (lk) { was = active; active = false; activeKey = ""; }
            Cfg23.Set("rt_live", null);
            if (WarpExe() == null) return;
            if (was || why != null) Cli("disconnect", 15000);   // a lista de redes fica guardada no WARP (desligado não faz nada)
            KillGui(); SvcStop();   // nada da Cloudflare fica a correr quando a rota não está ligada
        }

        // ================================================================ medições
        public static Meas Measure(uint ip, int count, int gapMs)
        {
            Meas m = new Meas();
            List<double> v = new List<double>(); int lost = 0;
            using (Ping p = new Ping())
            {
                for (int i = 0; i < count; i++)
                {
                    try
                    {
                        PingReply r = p.Send(new IPAddress(BitConverter.GetBytes(ip).Reverse().ToArray()), 1000);
                        if (r != null && r.Status == IPStatus.Success) v.Add(r.RoundtripTime); else lost++;
                    }
                    catch { lost++; }
                    if (gapMs > 0) Thread.Sleep(gapMs);
                }
            }
            m.n = v.Count;
            m.loss = count == 0 ? 100 : 100.0 * lost / count;
            if (v.Count > 0)
            {
                List<double> s = v.OrderBy(x => x).ToList();
                m.ms = s[s.Count / 2];
                double j = 0; for (int i = 1; i < v.Count; i++) j += Math.Abs(v[i] - v[i - 1]);
                m.jit = v.Count > 1 ? j / (v.Count - 1) : 0;
            }
            return m;
        }

        // "onde está o lag": salto a salto até ao servidor (corre em segundo plano; o painel vai buscando o resultado)
        static string traceRes = "null"; static int tracing;
        public static string TraceStart(string host)
        {
            uint ip = string.IsNullOrEmpty(host) ? 0 : Resolve(host);
            if (ip == 0) lock (lk) ip = server;
            if (ip == 0) return Ps23.Ok(false, Lang.L("Abre um jogo (ou escreve o servidor) para testar."));
            if (Interlocked.Exchange(ref tracing, 1) == 1) return TraceJson();
            uint t = ip;
            ThreadPool.QueueUserWorkItem(delegate { try { string r = Trace(t); lock (lk) traceRes = r; } catch { } finally { Interlocked.Exchange(ref tracing, 0); } });
            return TraceJson();
        }
        public static string TraceJson() { lock (lk) return "{\"ok\":true,\"running\":" + (tracing == 1 ? "true" : "false") + ",\"res\":" + traceRes + "}"; }

        static string Trace(uint ip)
        {
            StringBuilder b = new StringBuilder("{\"target\":" + Js.S(Ip(ip)) + ",\"hops\":[");
            List<double> times = new List<double>();
            using (Ping p = new Ping())
            {
                bool first = true;
                for (int ttl = 1; ttl <= 20; ttl++)
                {
                    double best = -1; string addr = null; bool done = false; int lost = 0;
                    for (int k = 0; k < 2; k++)
                    {
                        try
                        {
                            Stopwatch sw = Stopwatch.StartNew();
                            PingReply r = p.Send(new IPAddress(BitConverter.GetBytes(ip).Reverse().ToArray()), 800, new byte[16], new PingOptions(ttl, true));
                            double el = sw.Elapsed.TotalMilliseconds;
                            if (r != null && (r.Status == IPStatus.TtlExpired || r.Status == IPStatus.Success))
                            {
                                addr = r.Address.ToString();
                                double t = r.RoundtripTime > 0 ? r.RoundtripTime : el;   // no TtlExpired o Windows às vezes dá 0
                                if (best < 0 || t < best) best = t;
                                if (r.Status == IPStatus.Success) done = true;
                            }
                            else lost++;
                        }
                        catch { lost++; }
                    }
                    if (!first) b.Append(','); first = false;
                    b.Append("{\"ttl\":").Append(ttl).Append(",\"ip\":").Append(Js.S(addr)).Append(",\"ms\":").Append(best < 0 ? "null" : Js.N(best)).Append(",\"lost\":").Append(lost).Append('}');
                    times.Add(best);
                    if (done) break;
                }
            }
            b.Append("]");
            // onde está o maior salto de tempo: em casa (1.º salto lento), na operadora (saltos 2-4) ou longe
            string where;
            double home = times.Count > 0 ? times[0] : -1;
            if (home > 10) where = "home";
            else
            {
                double prev = Math.Max(0, home), maxJump = 0; int at = -1;
                for (int i = 1; i < times.Count; i++) { if (times[i] < 0) continue; double jd = times[i] - prev; if (jd > maxJump) { maxJump = jd; at = i; } prev = times[i]; }
                where = at >= 0 && maxJump >= 15 ? (at <= 3 ? "isp" : "far") : "ok";
            }
            b.Append(",\"where\":").Append(Js.S(where)).Append('}');
            return b.ToString();
        }

        // ================================================================ utilitários
        public static string Ip(uint a) { return ((a >> 24) & 255) + "." + ((a >> 16) & 255) + "." + ((a >> 8) & 255) + "." + (a & 255); }
        static uint ToU(IPAddress a)
        {
            if (a == null || a.AddressFamily != System.Net.Sockets.AddressFamily.InterNetwork) return 0;
            byte[] b = a.GetAddressBytes();
            return ((uint)b[0] << 24) | ((uint)b[1] << 16) | ((uint)b[2] << 8) | b[3];
        }
        static uint Resolve(string host)
        {
            host = (host ?? "").Trim();
            int c = host.LastIndexOf(':'); if (c > 0 && host.IndexOf('.') > 0) host = host.Substring(0, c);
            IPAddress a;
            if (IPAddress.TryParse(host, out a)) return ToU(a);
            try { foreach (IPAddress x in Dns.GetHostAddresses(host)) { uint u = ToU(x); if (u != 0) return u; } } catch { }
            return 0;
        }
        public static bool Private(uint a)
        {
            byte b0 = (byte)(a >> 24), b1 = (byte)(a >> 16);
            return b0 == 10 || b0 == 127 || b0 == 0 || b0 >= 224 || (b0 == 172 && b1 >= 16 && b1 <= 31) || (b0 == 192 && b1 == 168) || (b0 == 169 && b1 == 254) || (b0 == 100 && b1 >= 64 && b1 <= 127);
        }
    }

    // ==================================================================== ETW: para onde é que o jogo manda pacotes
    // Sessão em tempo real do fornecedor Microsoft-Windows-Kernel-Network, só enquanto há um jogo aberto e a rota ligada.
    // Lê apenas: processo, IP e porta de destino. Nada é guardado em disco.
    static class EtwNet
    {
        static readonly Guid KernelNetwork = new Guid("7DD42A49-5329-4832-8DFD-43D979153A88");
        const string SessionName = "NEXUS-Rota";
        static readonly object lk = new object();
        static ulong session, trace;
        static IntPtr propsBuf = IntPtr.Zero, logBuf = IntPtr.Zero;
        static Thread th;
        static int watchPid;
        // pacotes por destino (ip << 16 | porta) na janela atual e na anterior
        static Dictionary<ulong, int> cur = new Dictionary<ulong, int>(), prev = new Dictionary<ulong, int>();
        static DateTime winStart = DateTime.UtcNow;
        static CallbackDelegate cb;   // guardado para o GC não o apagar

        public static bool CanRun { get { return IntPtr.Size == 8 && IsAdmin(); } }
        public static bool Running { get { lock (lk) return th != null && th.IsAlive; } }

        public static void Watch(int pid)
        {
            lock (lk)
            {
                watchPid = pid;
                if (th != null && th.IsAlive) return;
            }
            if (!CanRun) return;
            Thread t = new Thread(Run) { IsBackground = true, Name = "NEXUS-Rota-ETW" };
            lock (lk) th = t;
            t.Start();
        }

        public static void Stop()
        {
            lock (lk) { watchPid = 0; cur.Clear(); prev.Clear(); }
            StopSession();
        }

        // destino com mais pacotes nos últimos ~60 s (exclui rede local, DNS, multicast e QUIC/HTTPS)
        public static uint Top(int pid, out int port, out int pkts)
        {
            port = 0; pkts = 0;
            Dictionary<ulong, int> all = new Dictionary<ulong, int>();
            lock (lk)
            {
                Roll();
                foreach (KeyValuePair<ulong, int> kv in prev) all[kv.Key] = kv.Value;
                foreach (KeyValuePair<ulong, int> kv in cur) { int v; all.TryGetValue(kv.Key, out v); all[kv.Key] = v + kv.Value; }
            }
            // somar por IP (várias portas do mesmo servidor contam juntas)
            Dictionary<uint, int> byIp = new Dictionary<uint, int>(); Dictionary<uint, int> bestPort = new Dictionary<uint, int>(); Dictionary<uint, int> bestPortN = new Dictionary<uint, int>();
            foreach (KeyValuePair<ulong, int> kv in all)
            {
                uint ip = (uint)(kv.Key >> 16); int pt = (int)(kv.Key & 0xFFFF);
                if (Rota.Private(ip) || pt == 53 || pt == 443 || pt == 80 || pt == 123 || pt == 5353 || pt == 1900) continue;
                int v; byIp.TryGetValue(ip, out v); byIp[ip] = v + kv.Value;
                int bn; bestPortN.TryGetValue(ip, out bn); if (kv.Value > bn) { bestPortN[ip] = kv.Value; bestPort[ip] = pt; }
            }
            if (byIp.Count == 0) return 0;
            KeyValuePair<uint, int> top = byIp.OrderByDescending(x => x.Value).First();
            if (top.Value < 20) return 0;   // pouco tráfego: ainda não é a partida
            port = bestPort[top.Key]; pkts = top.Value;
            return top.Key;
        }

        static void Roll()
        {
            if ((DateTime.UtcNow - winStart).TotalSeconds < 30) return;
            prev = cur; cur = new Dictionary<ulong, int>(); winStart = DateTime.UtcNow;
        }

        // ---------------------------------------------------------------- P/Invoke (só x64)
        [DllImport("advapi32.dll", CharSet = CharSet.Unicode)] static extern uint StartTrace(out ulong handle, string name, IntPtr props);
        [DllImport("advapi32.dll", CharSet = CharSet.Unicode)] static extern uint ControlTrace(ulong handle, string name, IntPtr props, uint code);
        [DllImport("advapi32.dll")] static extern uint EnableTraceEx2(ulong handle, ref Guid provider, uint control, byte level, ulong any, ulong all, uint timeout, IntPtr param);
        [DllImport("advapi32.dll", CharSet = CharSet.Unicode)] static extern ulong OpenTrace(IntPtr logfile);
        [DllImport("advapi32.dll")] static extern uint ProcessTrace(ulong[] handles, uint count, IntPtr start, IntPtr end);
        [DllImport("advapi32.dll")] static extern uint CloseTrace(ulong handle);
        [UnmanagedFunctionPointer(CallingConvention.Winapi)] delegate void CallbackDelegate(IntPtr rec);

        const int PropsSize = 120;          // EVENT_TRACE_PROPERTIES em x64
        const int LogfileSize = 448;        // EVENT_TRACE_LOGFILEW em x64

        static IntPtr NewProps()
        {
            int total = PropsSize + 2 * 1024;
            IntPtr p = Marshal.AllocHGlobal(total);
            for (int i = 0; i < total; i++) Marshal.WriteByte(p, i, 0);
            Marshal.WriteInt32(p, 0, total);                  // Wnode.BufferSize
            Marshal.WriteInt32(p, 40, 1);                     // Wnode.ClientContext = QPC
            Marshal.WriteInt32(p, 44, 0x00020000);            // Wnode.Flags = WNODE_FLAG_TRACED_GUID
            Marshal.WriteInt32(p, 48, 64);                    // BufferSize (KB)
            Marshal.WriteInt32(p, 52, 4);                     // MinimumBuffers
            Marshal.WriteInt32(p, 56, 16);                    // MaximumBuffers
            Marshal.WriteInt32(p, 64, 0x00000100);            // LogFileMode = EVENT_TRACE_REAL_TIME_MODE
            Marshal.WriteInt32(p, 68, 1);                     // FlushTimer (s)
            Marshal.WriteInt32(p, 116, PropsSize);            // LoggerNameOffset
            return p;
        }

        static void StopSession()
        {
            ulong t; IntPtr pb;
            lock (lk) { t = trace; trace = 0; pb = propsBuf; }
            if (t != 0 && t != ulong.MaxValue) try { CloseTrace(t); } catch { }
            IntPtr p = NewProps();
            try { ControlTrace(0, SessionName, p, 1); } catch { }   // EVENT_TRACE_CONTROL_STOP
            Marshal.FreeHGlobal(p);
        }

        static void Run()
        {
            try
            {
                StopSession();   // uma sessão antiga com o mesmo nome (o NEXUS fechou à pressa) sai primeiro
                IntPtr props = NewProps();
                ulong h;
                uint err = StartTrace(out h, SessionName, props);
                if (err != 0) { Marshal.FreeHGlobal(props); return; }
                Guid g = KernelNetwork;
                // palavras-chave: IPv4 (0x10) e IPv6 (0x20); nível informativo
                EnableTraceEx2(h, ref g, 1, 4, 0x30, 0, 0, IntPtr.Zero);
                lock (lk) { session = h; propsBuf = props; }

                IntPtr log = Marshal.AllocHGlobal(LogfileSize);
                for (int i = 0; i < LogfileSize; i++) Marshal.WriteByte(log, i, 0);
                IntPtr name = Marshal.StringToHGlobalUni(SessionName);
                cb = OnEvent;
                Marshal.WriteIntPtr(log, 8, name);                                         // LoggerName
                Marshal.WriteInt32(log, 28, 0x00000100 | 0x10000000);                      // ProcessTraceMode = REAL_TIME | EVENT_RECORD
                Marshal.WriteIntPtr(log, 424, Marshal.GetFunctionPointerForDelegate(cb));  // EventRecordCallback
                ulong t = OpenTrace(log);
                if (t == ulong.MaxValue) { StopSession(); Marshal.FreeHGlobal(log); Marshal.FreeHGlobal(name); return; }
                lock (lk) trace = t;
                ProcessTrace(new[] { t }, 1, IntPtr.Zero, IntPtr.Zero);   // fica aqui até a sessão parar
                Marshal.FreeHGlobal(log); Marshal.FreeHGlobal(name);
            }
            catch { }
            finally { lock (lk) th = null; }
        }

        // EVENT_RECORD (x64): EventHeader.ProcessId @12, EventDescriptor.Id @40, UserDataLength @86, UserData @96
        static void OnEvent(IntPtr rec)
        {
            try
            {
                int id = Marshal.ReadInt16(rec, 40) & 0xFFFF;
                // envios: TCP IPv4 = 10, UDP IPv4 = 42 (o destino é o servidor)
                if (id != 42 && id != 10) return;
                int len = Marshal.ReadInt16(rec, 86) & 0xFFFF;
                if (len < 20) return;
                IntPtr d = Marshal.ReadIntPtr(rec, 96);
                int pid = Marshal.ReadInt32(d, 0);
                int want; lock (lk) want = watchPid;
                if (want == 0 || pid != want) return;
                // daddr (ordem da rede) @8, dport (ordem da rede) @16
                uint ip = ((uint)Marshal.ReadByte(d, 8) << 24) | ((uint)Marshal.ReadByte(d, 9) << 16) | ((uint)Marshal.ReadByte(d, 10) << 8) | Marshal.ReadByte(d, 11);
                int port = (Marshal.ReadByte(d, 16) << 8) | Marshal.ReadByte(d, 17);
                ulong key = ((ulong)ip << 16) | (uint)port;
                lock (lk) { Roll(); int v; cur.TryGetValue(key, out v); cur[key] = v + 1; }
            }
            catch { }
        }

        static bool IsAdmin()
        {
            try { return new System.Security.Principal.WindowsPrincipal(System.Security.Principal.WindowsIdentity.GetCurrent()).IsInRole(System.Security.Principal.WindowsBuiltInRole.Administrator); }
            catch { return false; }
        }
    }
}
