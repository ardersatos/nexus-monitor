﻿// NEXUS // MONITOR 2.3 - ainda mais: atraso do clique do rato, tempo de ecrã por app, pasta térmica da placa (núcleo vs ponto
// mais quente), driver da placa antigo, o que não deixa o PC dormir, teste da RAM, espaço da Steam, explicar um processo e o
// zip de suporte (sem dados pessoais).
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Eventing.Reader;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Management;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using Microsoft.Win32;

namespace Nexus
{
    static partial class Vigias23
    {
        // ============================================================ ATRASO DO CLIQUE (PresentMon: do clique do rato até aparecer no ecrã)
        static readonly object clk = new object();
        static readonly List<KeyValuePair<DateTime, double>> clicks = new List<KeyValuePair<DateTime, double>>();
        static string clickApp;
        public static void Click(string app, double ms)
        {
            lock (clk)
            {
                // o PresentMon repete o mesmo valor em vários frames seguidos: só conta um por clique
                if (clicks.Count > 0 && (DateTime.UtcNow - clicks[clicks.Count - 1].Key).TotalMilliseconds < 120) return;
                clicks.Add(new KeyValuePair<DateTime, double>(DateTime.UtcNow, ms)); clickApp = app;
                if (clicks.Count > 200) clicks.RemoveAt(0);
            }
        }
        public static string ClickJson()
        {
            lock (clk)
            {
                List<double> l = clicks.Where(x => (DateTime.UtcNow - x.Key).TotalMinutes < 30).Select(x => x.Value).ToList();
                List<double> last = l.Skip(Math.Max(0, l.Count - 40)).ToList();
                Func<List<double>, double, double> pct = (v, p) => { if (v.Count == 0) return double.NaN; List<double> o = v.OrderBy(x => x).ToList(); return o[Math.Min(o.Count - 1, (int)(p * o.Count))]; };
                return "{\"ok\":true,\"pm\":" + Js.S(PresentMonReader.Status) + ",\"app\":" + Js.S(clickApp) + ",\"n\":" + last.Count + ",\"avg\":" + Js.N(last.Count > 0 ? last.Average() : double.NaN) +
                       ",\"min\":" + Js.N(last.Count > 0 ? last.Min() : double.NaN) + ",\"p90\":" + Js.N(pct(last, 0.9)) + ",\"last\":[" + string.Join(",", last.Skip(Math.Max(0, last.Count - 20)).Select(x => Js.N(x)).ToArray()) + "]}";
            }
        }
        public static void ClickReset() { lock (clk) clicks.Clear(); }

        // ============================================================ TEMPO DE ECRÃ (que programa está à frente; só conta quando mexes no PC)
        [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
        [StructLayout(LayoutKind.Sequential)] struct LASTINPUTINFO { public uint cbSize; public uint dwTime; }
        [DllImport("user32.dll")] static extern bool GetLastInputInfo(ref LASTINPUTINFO l);
        static readonly Dictionary<string, double> today = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
        static readonly Dictionary<string, string> names = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        static string todayKey = DateTime.Now.ToString("yyyy-MM-dd");
        static int t2;
        static string StFile { get { return Path.Combine(AppSettings.Dir, "tempo_ecra.txt"); } }
        static double IdleSecs() { LASTINPUTINFO l = new LASTINPUTINFO(); l.cbSize = (uint)Marshal.SizeOf(l); if (!GetLastInputInfo(ref l)) return 0; return ((uint)Environment.TickCount - l.dwTime) / 1000.0; }

        static void Tick2(string game, double? gpu)
        {
            t2++;
            // tempo de ecrã (2 s por volta; com jogo aberto conta sempre, mesmo sem mexer)
            if (Cfg23.On("screentime", true) && (game != null || IdleSecs() < 300))
            {
                uint pid; GetWindowThreadProcessId(GetForegroundWindow(), out pid);
                if (pid > 4)
                    try
                    {
                        using (Process p = Process.GetProcessById((int)pid))
                        {
                            string n = p.ProcessName;
                            {
                                lock (today)
                                {
                                    string k = DateTime.Now.ToString("yyyy-MM-dd");
                                    if (k != todayKey) { FlushScreen(); today.Clear(); todayKey = k; }
                                    double v; today.TryGetValue(n, out v); today[n] = v + 2;
                                    if (!names.ContainsKey(n)) { string d = ""; try { string ep = Optimizer.ExePath(p.Id); if (ep != "") d = FileVersionInfo.GetVersionInfo(ep).FileDescription ?? ""; } catch { } names[n] = d.Trim(); }
                                }
                            }
                        }
                    }
                    catch { }
            }
            if (t2 % 60 == 0) FlushScreen();
            // pasta térmica da placa
            try { Hotspot(gpu); } catch { }
            // driver da placa muito antigo (uma vez por semana)
            if (t2 % 1800 == 120 && Cfg23.On("al_driver", true)) ThreadPool.QueueUserWorkItem(delegate { try { Ferr.DriverCheck(); } catch { } });
        }
        public static void FlushScreen()
        {
            lock (today)
            {
                try
                {
                    Dictionary<string, double> all = new Dictionary<string, double>();
                    if (File.Exists(StFile))
                        foreach (string l in File.ReadAllLines(StFile, Encoding.UTF8))
                        {
                            string[] c = l.Split('|'); double v;
                            if (c.Length >= 3 && double.TryParse(c[2], NumberStyles.Float, CultureInfo.InvariantCulture, out v)) all[c[0] + "|" + c[1]] = v;
                        }
                    foreach (KeyValuePair<string, double> kv in today) all[todayKey + "|" + kv.Key] = kv.Value;
                    string cut = DateTime.Now.AddDays(-30).ToString("yyyy-MM-dd");
                    File.WriteAllLines(StFile, all.Where(x => string.CompareOrdinal(x.Key, cut) >= 0).OrderBy(x => x.Key)
                        .Select(x => x.Key + "|" + Math.Round(x.Value).ToString(CultureInfo.InvariantCulture)).ToArray(), new UTF8Encoding(false));
                    StringBuilder nm = new StringBuilder();
                    foreach (KeyValuePair<string, string> kv in names) if (kv.Value != "") nm.Append(kv.Key).Append('|').Append(kv.Value.Replace("|", "/")).Append("\r\n");
                    File.WriteAllText(Path.Combine(AppSettings.Dir, "tempo_ecra_nomes.txt"), nm.ToString(), new UTF8Encoding(false));
                }
                catch { }
            }
        }
        public static string ScreenJson()
        {
            FlushScreen();
            Dictionary<string, string> nm = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            try { foreach (string l in File.ReadAllLines(Path.Combine(AppSettings.Dir, "tempo_ecra_nomes.txt"), Encoding.UTF8)) { int i = l.IndexOf('|'); if (i > 0) nm[l.Substring(0, i)] = l.Substring(i + 1); } } catch { }
            StringBuilder sb = new StringBuilder("{\"ok\":true,\"on\":" + (Cfg23.On("screentime", true) ? "true" : "false") + ",\"days\":[");
            bool first = true;
            try
            {
                if (File.Exists(StFile))
                    foreach (string l in File.ReadAllLines(StFile, Encoding.UTF8))
                    {
                        string[] c = l.Split('|'); if (c.Length < 3) continue;
                        if (!first) sb.Append(','); first = false;
                        string d; nm.TryGetValue(c[1], out d);
                        sb.Append("[").Append(Js.S(c[0])).Append(',').Append(Js.S(c[1])).Append(',').Append(Js.S(d ?? "")).Append(',').Append(c[2]).Append(']');
                    }
            }
            catch { }
            return sb.Append("]}").ToString();
        }

        // ============================================================ PASTA TÉRMICA DA PLACA (diferença entre o núcleo e o ponto mais quente)
        static readonly List<double> hsRecent = new List<double>();
        static double hsCore = double.NaN, hsHot = double.NaN;
        static void Hotspot(double? gpu)
        {
            if (t2 % 5 != 0) return;
            List<object[]> rows = Embedded.LastRows; if (rows == null) return;
            double core = double.NaN, hot = double.NaN;
            foreach (object[] r in rows)
            {
                if (Convert.ToString(r[0]).IndexOf("Gpu", StringComparison.OrdinalIgnoreCase) < 0 || Convert.ToString(r[2]) != "Temperature") continue;
                string n = Convert.ToString(r[3]).ToLowerInvariant(); double v = Convert.ToDouble(r[4]);
                if (n.Contains("hot spot") || n.Contains("hotspot")) hot = v; else if (n == "gpu core" || n == "gpu") core = v;
            }
            hsCore = core; hsHot = hot;
            if (double.IsNaN(core) || double.IsNaN(hot) || !gpu.HasValue || gpu.Value < 80) return;
            double d = hot - core; if (d < 0 || d > 60) return;
            lock (hsRecent) { hsRecent.Add(d); if (hsRecent.Count > 300) hsRecent.RemoveAt(0); }
            // referência: as primeiras 2 horas de carga que o NEXUS viu (guardada)
            // (conta em memória e grava de 30 em 30: antes reescrevia o ficheiro de definições 3 vezes a cada 10 s durante o jogo)
            lock (hsRecent)
            {
                if (hsN < 0) { hsN = Cfg23.Int("hs_n", 0); double.TryParse(Cfg23.Get("hs_sum", "0"), NumberStyles.Float, CultureInfo.InvariantCulture, out hsSum); }
                if (hsN >= 1440) return;
                if (hsN == 0) Cfg23.Set("hs_since", DateTime.Now.ToString("yyyy-MM-dd"));
                hsSum += d; hsN++;
                if (hsN % 30 == 0 || hsN == 60 || hsN >= 1440) { Cfg23.Set("hs_sum", hsSum.ToString("0.##", CultureInfo.InvariantCulture)); Cfg23.Set("hs_n", hsN.ToString()); }
            }
        }
        static int hsN = -1; static double hsSum;
        public static string HotspotJson()
        {
            double avg; int avgN; lock (hsRecent) { avg = hsRecent.Count > 0 ? hsRecent.Average() : double.NaN; avgN = hsRecent.Count; }
            int n0; double s0;
            lock (hsRecent) { if (hsN >= 0) { n0 = hsN; s0 = hsSum; } else { n0 = Cfg23.Int("hs_n", 0); double.TryParse(Cfg23.Get("hs_sum", "0"), NumberStyles.Float, CultureInfo.InvariantCulture, out s0); } }
            return "{\"ok\":true,\"core\":" + Js.N(hsCore) + ",\"hot\":" + Js.N(hsHot) + ",\"loadDelta\":" + Js.N(avg) + ",\"samples\":" + avgN +
                   ",\"base\":" + Js.N(n0 >= 60 ? s0 / n0 : double.NaN) + ",\"baseN\":" + n0 + ",\"since\":" + Js.S(Cfg23.Get("hs_since", "")) + "}";
        }
    }

    static partial class Ferr
    {
        // ============================================================ DRIVER DA PLACA ANTIGO (sem internet: avisa pela idade e abre a página oficial)
        public static string DriverInfo(out int days, out string vendor)
        {
            days = -1; vendor = ""; string ver = "";
            try
            {
                using (ManagementObjectSearcher q = new ManagementObjectSearcher("SELECT Name, DriverVersion, DriverDate, PNPDeviceID FROM Win32_VideoController"))
                    foreach (ManagementObject m in q.Get())
                    {
                        if ((Convert.ToString(m["PNPDeviceID"]) ?? "").IndexOf("PCI", StringComparison.OrdinalIgnoreCase) < 0) continue;
                        string n = Convert.ToString(m["Name"]) ?? "", dd = Convert.ToString(m["DriverDate"]) ?? "";
                        vendor = n.IndexOf("NVIDIA", StringComparison.OrdinalIgnoreCase) >= 0 ? "nvidia" : n.IndexOf("AMD", StringComparison.OrdinalIgnoreCase) >= 0 || n.IndexOf("Radeon", StringComparison.OrdinalIgnoreCase) >= 0 ? "amd" : "intel";
                        ver = Convert.ToString(m["DriverVersion"]) ?? "";
                        if (dd.Length >= 8) { DateTime d; if (DateTime.TryParseExact(dd.Substring(0, 8), "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out d)) days = (int)(DateTime.Now - d).TotalDays; }
                        break;
                    }
            }
            catch { }
            return ver;
        }
        public static void DriverCheck()
        {
            int days; string v; DriverInfo(out days, out v);
            int lim = Cfg23.Int("driver_days", 60);
            if (days < lim) return;
            string last = Cfg23.Get("driver_warned", "");
            if (last == DateTime.Now.ToString("yyyy-ww")) return;
            Cfg23.Set("driver_warned", DateTime.Now.ToString("yyyy-ww"));
            Vigias23.Alert(Lang.L("NEXUS · Driver da placa antigo"), Lang.L("O driver da placa gráfica tem") + " " + days + " " + Lang.L("dias. Normalmente já há uma versão mais recente: vê em Hardware → Placa gráfica."));
        }

        // ============================================================ DESINSTALAR UM DRIVER ANTIGO (tira o dispositivo e o pacote do driver; sem /force)
        public static string DriverRemove(string dev, string inf)
        {
            if (string.IsNullOrEmpty(dev) || dev.Contains("\"") || dev.Length > 400) return Ps23.Ok(false, "?");   // uma aspa fechava o argumento e deixava juntar outras opções ao pnputil
            string o = Ps23.Cmd("pnputil.exe", "/remove-device \"" + dev + "\"", 60000);
            string o2 = "";
            if (Regex.IsMatch(inf ?? "", @"^oem\d+\.inf$", RegexOptions.IgnoreCase)) o2 = Ps23.Cmd("pnputil.exe", "/delete-driver " + inf, 60000);
            Bios.Reset();
            return "{\"ok\":true,\"out\":" + Js.S((o + "\n" + o2).Trim()) + "}";
        }

        // ============================================================ O QUE NÃO DEIXA O PC DORMIR (e o que o acorda)
        public static string SleepJson()
        {
            string req = Ps23.Cmd("powercfg.exe", "/requests", 10000);
            List<string> items = new List<string>();
            string sec = "";
            foreach (string raw in req.Replace("\r", "").Split('\n'))
            {
                string l = raw.TrimEnd();
                Match h = Regex.Match(l, @"^([A-Z]+):\s*$");
                if (h.Success) { sec = h.Groups[1].Value; continue; }
                if (l.Trim() == "" || Regex.IsMatch(l.Trim(), @"^(None\.|Nenhum\.?|Nenhuma\.?|Ninguno\.?|Aucun\.?|Keine\.?)$", RegexOptions.IgnoreCase)) continue;
                if (sec != "" && sec != "PERFBOOST" && sec != "ACTIVELOCKSCREEN") items.Add("{\"type\":" + Js.S(sec) + ",\"what\":" + Js.S(l.Trim()) + "}");
            }
            string wake = Ps23.Cmd("powercfg.exe", "/lastwake", 10000);
            string timers = Ps23.Cmd("powercfg.exe", "/waketimers", 10000);
            string armed = Ps23.Cmd("powercfg.exe", "/devicequery wake_armed", 10000);
            List<string> dev = armed.Replace("\r", "").Split('\n').Select(x => x.Trim()).Where(x => x != "" && !Regex.IsMatch(x, @"^(NONE|NENHUM)", RegexOptions.IgnoreCase)).ToList();
            List<string> off = Cfg23.Get("wake_off", "").Split('\t').Where(x => x != "").ToList();
            return "{\"ok\":true,\"requests\":[" + string.Join(",", items.ToArray()) + "],\"lastwake\":" + Js.S(wake) + ",\"timers\":" + Js.S(timers) +
                   ",\"armed\":[" + string.Join(",", dev.Select(x => Js.S(x)).ToArray()) + "],\"disarmed\":[" + string.Join(",", off.Select(x => Js.S(x)).ToArray()) + "]}";
        }
        public static string WakeSet(string dev, bool on)
        {
            if (string.IsNullOrEmpty(dev) || dev.Contains("\"")) return Ps23.Ok(false, "?");
            Ps23.Cmd("powercfg.exe", (on ? "/deviceenablewake \"" : "/devicedisablewake \"") + dev + "\"", 10000);
            List<string> off = Cfg23.Get("wake_off", "").Split('\t').Where(x => x != "").ToList();
            if (on) off.Remove(dev); else if (!off.Contains(dev)) off.Add(dev);
            Cfg23.Set("wake_off", string.Join("\t", off.ToArray()));
            return SleepJson();
        }

        // ============================================================ TESTE DA RAM (Diagnóstico de Memória do Windows; o resultado aparece aqui depois de reiniciar)
        public static string RamTestJson()
        {
            List<string> res = new List<string>();
            try
            {
                EventLogQuery q = new EventLogQuery("System", PathType.LogName, "*[System[Provider[@Name='Microsoft-Windows-MemoryDiagnostics-Results']]]") { ReverseDirection = true };
                using (EventLogReader r = new EventLogReader(q))
                    for (EventRecord e = r.ReadEvent(); e != null && res.Count < 5; e = r.ReadEvent())
                        using (e) res.Add("{\"when\":" + Js.S(e.TimeCreated.HasValue ? e.TimeCreated.Value.ToString("yyyy-MM-dd HH:mm") : "") + ",\"id\":" + e.Id + ",\"ok\":" + (e.Id == 1201 ? "true" : "false") + "}");
            }
            catch { }
            return "{\"ok\":true,\"results\":[" + string.Join(",", res.ToArray()) + "]}";
        }
        public static string RamTestStart()
        {
            try { Process.Start(new ProcessStartInfo("mdsched.exe") { UseShellExecute = true }); } catch (Exception ex) { return Ps23.Ok(false, ex.Message); }
            return Ps23.Ok(true, Lang.L("Abriu a janela do Windows: escolhe reiniciar agora ou da próxima vez que ligares o PC."));
        }

        // ============================================================ ESPAÇO DA STEAM (jogos repetidos, shaders, downloads a meio)
        static long DirSize(string d) { try { return new DirectoryInfo(d).EnumerateFiles("*", SearchOption.AllDirectories).Sum(f => { try { return f.Length; } catch { return 0L; } }); } catch { return 0; } }
        static List<string> SteamLibs()
        {
            List<string> libs = new List<string>();
            try
            {
                string steam = null;
                using (RegistryKey k = Registry.CurrentUser.OpenSubKey(@"Software\Valve\Steam")) if (k != null) steam = Convert.ToString(k.GetValue("SteamPath"));
                if (string.IsNullOrEmpty(steam)) return libs;
                libs.Add(Path.Combine(steam.Replace('/', '\\'), "steamapps"));
                string vdf = Path.Combine(libs[0], "libraryfolders.vdf");
                if (File.Exists(vdf)) foreach (Match m in Regex.Matches(File.ReadAllText(vdf), "\"path\"\\s+\"([^\"]+)\"")) libs.Add(Path.Combine(m.Groups[1].Value.Replace("\\\\", "\\"), "steamapps"));
            }
            catch { }
            return libs.Distinct(StringComparer.OrdinalIgnoreCase).Where(Directory.Exists).ToList();
        }
        public static string SteamJson()
        {
            List<string> libs = SteamLibs();
            if (libs.Count == 0) return "{\"ok\":true,\"steam\":false}";
            Dictionary<string, string> nameOf = new Dictionary<string, string>();
            Dictionary<string, List<string>> where = new Dictionary<string, List<string>>();
            List<string> partial = new List<string>(), shader = new List<string>(), down = new List<string>(), games = new List<string>();
            foreach (string lib in libs)
            {
                foreach (string f in Directory.GetFiles(lib, "appmanifest_*.acf"))
                {
                    string t; try { t = File.ReadAllText(f); } catch { continue; }
                    Func<string, string> g = k => { Match m = Regex.Match(t, "\"" + k + "\"\\s+\"([^\"]*)\""); return m.Success ? m.Groups[1].Value : ""; };
                    string id = g("appid"), n = g("name"), st = g("StateFlags"), dir = g("installdir");
                    long size; long.TryParse(g("SizeOnDisk"), out size); long todo; long.TryParse(g("BytesToDownload"), out todo); long done; long.TryParse(g("BytesDownloaded"), out done);
                    if (id == "") continue;
                    nameOf[id] = n;
                    if (!where.ContainsKey(id)) where[id] = new List<string>();
                    where[id].Add(lib);
                    games.Add("{\"id\":" + Js.S(id) + ",\"name\":" + Js.S(n) + ",\"lib\":" + Js.S(lib) + ",\"size\":" + size + "}");
                    if (st != "4" && st != "" && todo > 0 && done < todo) partial.Add("{\"id\":" + Js.S(id) + ",\"name\":" + Js.S(n) + ",\"lib\":" + Js.S(lib) + ",\"done\":" + done + ",\"todo\":" + todo + "}");
                }
                string sc = Path.Combine(lib, "shadercache");
                if (Directory.Exists(sc)) foreach (string d in Directory.GetDirectories(sc)) { long s = DirSize(d); string id = Path.GetFileName(d); if (s > 50L << 20) shader.Add("{\"id\":" + Js.S(id) + ",\"lib\":" + Js.S(lib) + ",\"size\":" + s + "}"); }
                string dl = Path.Combine(lib, "downloading");
                if (Directory.Exists(dl)) foreach (string d in Directory.GetDirectories(dl)) { long s = DirSize(d); string id = Path.GetFileName(d); if (s > 0) down.Add("{\"id\":" + Js.S(id) + ",\"lib\":" + Js.S(lib) + ",\"size\":" + s + "}"); }
            }
            Func<string, string> named = j => { Match m = Regex.Match(j, "\"id\":\"(\\d+)\""); string n; return m.Success && nameOf.TryGetValue(m.Groups[1].Value, out n) ? j.TrimEnd('}') + ",\"name\":" + Js.S(n) + "}" : j; };
            string dup = string.Join(",", where.Where(x => x.Value.Count > 1).Select(x => "{\"id\":" + Js.S(x.Key) + ",\"name\":" + Js.S(nameOf[x.Key]) + ",\"libs\":[" + string.Join(",", x.Value.Select(v => Js.S(v)).ToArray()) + "]}").ToArray());
            bool running = false; try { running = Process.GetProcessesByName("steam").Length > 0; } catch { }
            return "{\"ok\":true,\"steam\":true,\"running\":" + (running ? "true" : "false") + ",\"libs\":[" + string.Join(",", libs.Select(x => Js.S(x)).ToArray()) + "],\"dups\":[" + dup + "],\"partial\":[" + string.Join(",", partial.ToArray()) +
                   "],\"shader\":[" + string.Join(",", shader.Select(named).ToArray()) + "],\"downloading\":[" + string.Join(",", down.Select(named).ToArray()) + "],\"games\":" + games.Count + "}";
        }
        public static string SteamClean(string kind, string lib, string id)
        {
            try { if (Process.GetProcessesByName("steam").Length > 0) return Ps23.Ok(false, Lang.L("Fecha a Steam primeiro (também no tabuleiro do relógio).")); } catch { }
            if (!Regex.IsMatch(id ?? "", @"^\d+$") || (kind != "shadercache" && kind != "downloading")) return Ps23.Ok(false, "?");
            if (!SteamLibs().Contains(lib ?? "", StringComparer.OrdinalIgnoreCase)) return Ps23.Ok(false, "?");
            string d = Path.Combine(lib, kind, id);
            if (!Directory.Exists(d)) return SteamJson();
            // cache de shaders: volta a criar-se ao jogar; download a meio: a Steam volta a descarregar se precisar
            try { Directory.Delete(d, true); } catch (Exception ex) { return Ps23.Ok(false, ex.Message); }
            return SteamJson();
        }

        // ============================================================ EXPLICAR UM PROCESSO
        static readonly string[][] PROCS = {
            new[] { "System", "Núcleo do Windows", "O próprio Windows (drivers, discos, rede). Não se fecha.", "no" },
            new[] { "Registry", "Registo do Windows", "Guarda as definições do Windows na memória. Não se fecha.", "no" },
            new[] { "smss", "Gestor de sessões", "Arranca o Windows. Não se fecha.", "no" },
            new[] { "csrss", "Subsistema do Windows", "Peça essencial do Windows. Fechar dá ecrã azul.", "no" },
            new[] { "wininit", "Arranque do Windows", "Peça essencial do Windows. Não se fecha.", "no" },
            new[] { "winlogon", "Início de sessão", "Trata do início de sessão e do Ctrl+Alt+Del. Não se fecha.", "no" },
            new[] { "services", "Gestor de serviços", "Arranca e para os serviços. Não se fecha.", "no" },
            new[] { "lsass", "Segurança local", "Palavras-passe e permissões. Fechar reinicia o PC.", "no" },
            new[] { "svchost", "Anfitrião de serviços", "Corre vários serviços do Windows ao mesmo tempo. É normal haver dezenas.", "no" },
            new[] { "dwm", "Gestor de janelas", "Desenha as janelas e os efeitos. Se fechar, volta sozinho com um piscar de ecrã.", "no" },
            new[] { "explorer", "Explorador do Windows", "A barra de tarefas, o ambiente de trabalho e as pastas. Pode reiniciar-se sem problema.", "restart" },
            new[] { "MsMpEng", "Microsoft Defender", "O antivírus. Não se fecha (e não convém).", "no" },
            new[] { "NisSrv", "Defender (rede)", "Proteção de rede do antivírus.", "no" },
            new[] { "SearchHost", "Pesquisa do Windows", "A caixa de pesquisa do Menu Iniciar. Fecha-se e volta quando precisares.", "yes" },
            new[] { "SearchIndexer", "Indexação da pesquisa", "Indexa ficheiros para a pesquisa ser rápida. Pode gastar disco.", "yes" },
            new[] { "StartMenuExperienceHost", "Menu Iniciar", "O Menu Iniciar. Fecha-se e volta sozinho.", "yes" },
            new[] { "ShellExperienceHost", "Partes do Windows", "Centro de notificações, calendário da barra de tarefas. Volta sozinho.", "yes" },
            new[] { "RuntimeBroker", "Permissões das apps", "Controla as permissões das apps da Store. Seguro de fechar, mas volta.", "yes" },
            new[] { "TextInputHost", "Teclado e emojis", "Teclado tátil e painel de emojis (Win+.).", "yes" },
            new[] { "ctfmon", "Idiomas e escrita", "Teclados e idiomas. Se fechar, a escrita em algumas apps falha.", "no" },
            new[] { "audiodg", "Áudio do Windows", "Processa o som. Fechar corta o som por um instante.", "no" },
            new[] { "spoolsv", "Impressão", "Fila de impressão. Só é preciso se imprimes.", "yes" },
            new[] { "WmiPrvSE", "Informação do sistema (WMI)", "Responde a programas que pedem dados do PC (o NEXUS também usa). Normal aparecer e desaparecer.", "no" },
            new[] { "fontdrvhost", "Letras do Windows", "Desenha os tipos de letra. Não se fecha.", "no" },
            new[] { "sihost", "Anfitrião do ambiente", "Parte da interface do Windows. Não se fecha.", "no" },
            new[] { "taskhostw", "Tarefas do Windows", "Corre tarefas em segundo plano do Windows.", "no" },
            new[] { "SecurityHealthService", "Segurança do Windows", "Mostra o estado da segurança. Não se fecha.", "no" },
            new[] { "conhost", "Janela de consola", "Acompanha programas de linha de comandos.", "no" },
            new[] { "NVDisplay.Container", "Driver NVIDIA", "Painel de Controlo e funções do driver NVIDIA. Não fechar.", "no" },
            new[] { "nvcontainer", "Contentor NVIDIA", "Funções da NVIDIA App (overlay, gravação). Desliga em Otimizar → NVIDIA App.", "yes" },
            new[] { "steamwebhelper", "Steam (páginas)", "As páginas da Steam (loja, biblioteca). Gasta RAM; fechar a Steam fecha-os.", "yes" },
            new[] { "Discord", "Discord", "Chat de voz e texto. Usa vários processos.", "yes" },
            new[] { "NEXUS Monitor", "NEXUS Monitor", "Este programa :)", "no" },
            new[] { "PresentMon", "PresentMon (NEXUS)", "Mede os FPS para o NEXUS. Só corre com jogos abertos.", "no" },
            new[] { "MemCompression", "Compressão de memória", "O Windows comprime RAM em vez de usar o disco. É bom.", "no" },
            new[] { "Idle", "Processador parado", "Não é um programa: é o tempo em que o processador não tem nada para fazer.", "no" },
        };
        public static string ProcJson(string name)
        {
            name = (name ?? "").Trim(); if (name.EndsWith(".exe", StringComparison.OrdinalIgnoreCase)) name = name.Substring(0, name.Length - 4);
            if (name == "" || name.Length > 120) return Ps23.Ok(false, "?");
            string path = "", desc = "", company = "", product = ""; int count = 0; long mem = 0;
            try
            {
                foreach (Process p in Process.GetProcessesByName(name))
                {
                    count++; try { mem += p.WorkingSet64; } catch { }
                    if (path == "") try { path = Optimizer.ExePath(p.Id); if (path == "") continue; FileVersionInfo v = FileVersionInfo.GetVersionInfo(path); desc = (v.FileDescription ?? "").Trim(); company = (v.CompanyName ?? "").Trim(); product = (v.ProductName ?? "").Trim(); } catch { }
                }
            }
            catch { }
            string[] k = PROCS.FirstOrDefault(x => x[0].Equals(name, StringComparison.OrdinalIgnoreCase));
            string win = Environment.GetFolderPath(Environment.SpecialFolder.Windows).ToLowerInvariant();
            string lp = path.ToLowerInvariant();
            string kind, safe, text;
            if (k != null) { kind = Lang.L(k[1]); text = Lang.L(k[2]); safe = k[3]; }
            else if (lp.StartsWith(win + "\\")) { kind = Lang.L("Parte do Windows"); text = Lang.L("Está na pasta do Windows. Normalmente não se fecha; se gastar muito, vê se uma atualização está a correr."); safe = "careful"; }
            else if (lp.Contains("\\appdata\\local\\temp\\") || lp.Contains("\\temp\\")) { kind = Lang.L("Programa a correr de uma pasta temporária"); text = Lang.L("Instaladores fazem isto, mas programas que ficam sempre a correr daqui merecem uma vista de olhos com o antivírus."); safe = "check"; }
            else if (path == "") { kind = Lang.L("Processo protegido ou do sistema"); text = Lang.L("O Windows não deixa ver de onde vem. Costuma ser do sistema, de um antivírus ou de um anti-cheat."); safe = "careful"; }
            else { kind = (product != "" ? product : desc != "" ? desc : name); text = Lang.L("Programa instalado") + (company != "" ? " " + Lang.L("de") + " " + company : "") + ". " + Lang.L("Fechar é seguro, mas perdes o que não estiver guardado nele."); safe = "yes"; }
            return "{\"ok\":true,\"name\":" + Js.S(name) + ",\"kind\":" + Js.S(kind) + ",\"text\":" + Js.S(text) + ",\"safe\":" + Js.S(safe) + ",\"path\":" + Js.S(path) + ",\"desc\":" + Js.S(desc) +
                   ",\"company\":" + Js.S(company) + ",\"count\":" + count + ",\"mem\":" + mem + "}";
        }

        // ============================================================ ZIP DE SUPORTE (para mandar a quem te ajuda; sem nomes, IPs, MACs nem códigos)
        static string Anon(string s)
        {
            if (s == null) return "";
            string user = Environment.UserName, pc = Environment.MachineName, home = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            if (home != "") s = s.Replace(home, "C:\\Users\\<utilizador>").Replace(home.Replace("\\", "\\\\"), "C:\\\\Users\\\\<utilizador>");
            if (user.Length >= 2) s = Regex.Replace(s, Regex.Escape(user), "<utilizador>", RegexOptions.IgnoreCase);
            if (pc.Length >= 2) s = Regex.Replace(s, Regex.Escape(pc), "<PC>", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\b(\d{1,3}\.){3}\d{1,3}\b", "<IP>");
            s = Regex.Replace(s, @"\b([0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}\b", "<MAC>");
            s = Regex.Replace(s, @"\b[0-9a-fA-F]{1,4}(:[0-9a-fA-F]{0,4}){4,7}\b", "<IPv6>");
            s = Regex.Replace(s, "(\"(?:token|viewtok|ntfy_topic|discord_id|remotectl_ips)\"\\s*:\\s*)\"[^\"]*\"", "$1\"<oculto>\"");
            s = Regex.Replace(s, "(?m)^(token|viewtok|ntfy_topic|discord_id|remotectl_ips)=.*$", "$1=<oculto>");
            return s;
        }
        public static string SupportZip()
        {
            string tmp = Path.Combine(Path.GetTempPath(), "NEXUS-suporte-" + DateTime.Now.ToString("yyyyMMdd-HHmmss"));
            try
            {
                Directory.CreateDirectory(tmp);
                Action<string, Func<string>> put = (f, get) => { string t; try { t = get(); } catch (Exception ex) { t = "erro: " + ex.Message; } File.WriteAllText(Path.Combine(tmp, f), Anon(t), new UTF8Encoding(false)); };
                put("00-LEIA.txt", () => "NEXUS Monitor - ficheiro de suporte\r\nCriado: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm") + "\r\nVersao: " + System.Reflection.Assembly.GetExecutingAssembly().GetName().Version + "\r\n\r\nNomes, IPs, MACs e codigos foram trocados por <...>.\r\nNao tem ficheiros pessoais.\r\n");
                put("pc.json", () => MyPcJson());
                put("discos.json", () => Saude.DisksJson());
                put("drivers.json", () => Saude.DriversJson());
                put("crashes.json", () => Crashes.Json());
                put("arranque.json", () => Boot.Json());
                put("sessoes.json", () => Vigias23.SessJson());
                put("seguranca.json", () => SecurityJson(false));
                put("windows.json", () => WinverJson());
                put("sensores.txt", () => { List<object[]> r = Embedded.LastRows; return r == null ? "" : string.Join("\r\n", r.Select(x => string.Join(" | ", x.Select(y => Convert.ToString(y, CultureInfo.InvariantCulture)).ToArray())).ToArray()); });
                foreach (string f in new[] { "settings.ini", "nexus23.ini", "performance_backup.txt", "ventoinhas.txt", "cenarios.txt", "nexus_crash.txt" })
                { string p = Path.Combine(AppSettings.Dir, f); if (File.Exists(p)) put("def-" + f, () => File.ReadAllText(p, Encoding.UTF8)); }
                string downloads = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
                if (!Directory.Exists(downloads)) downloads = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                string zip = Path.Combine(downloads, "NEXUS suporte " + DateTime.Now.ToString("yyyy-MM-dd HHmm") + ".zip");
                PsFile.Run("suporte", "Compress-Archive -Path " + PsQ(Path.Combine(tmp, "*")) + " -DestinationPath " + PsQ(zip) + " -Force", 60000);
                try { Directory.Delete(tmp, true); } catch { }
                if (!File.Exists(zip)) return Ps23.Ok(false, Lang.L("Não consegui criar o zip."));
                try { Process.Start(new ProcessStartInfo("explorer.exe", "/select,\"" + zip + "\"") { UseShellExecute = false }); } catch { }
                return "{\"ok\":true,\"file\":" + Js.S(zip) + "}";
            }
            catch (Exception ex) { return Ps23.Ok(false, ex.Message); }
        }
    }
}
