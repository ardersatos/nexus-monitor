﻿// NEXUS // MONITOR - deteção de jogo, limpeza da RAM e as otimizações da página Performance
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Linq;
using System.Management;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Reflection;
using System.Security.Principal;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Win32;

namespace Nexus
{


    // ---------------------------------------------------------------- otimização: limpar RAM e modo jogo
    static class Optimizer
    {
        [DllImport("psapi.dll")] static extern bool EmptyWorkingSet(IntPtr h);
        [DllImport("kernel32.dll")] static extern IntPtr OpenProcess(uint access, bool inherit, int pid);
        [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);
        [DllImport("ntdll.dll")] static extern int NtSuspendProcess(IntPtr h);
        [DllImport("ntdll.dll")] static extern int NtResumeProcess(IntPtr h);
        [DllImport("shell32.dll")] static extern int SHQueryUserNotificationState(out int state);
        [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
        [StructLayout(LayoutKind.Sequential)] struct RECT { public int L, T, R, B; }
        [StructLayout(LayoutKind.Sequential)] struct MONINFO { public int cbSize; public RECT rcMonitor, rcWork; public uint dwFlags; }
        [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out RECT r);
        [DllImport("user32.dll")] static extern IntPtr MonitorFromWindow(IntPtr h, uint flags);
        [DllImport("user32.dll")] static extern bool GetMonitorInfo(IntPtr m, ref MONINFO mi);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(IntPtr h, StringBuilder sb, int max);
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] static extern bool QueryFullProcessImageName(IntPtr h, int flags, StringBuilder sb, ref int size);
        [StructLayout(LayoutKind.Sequential)]
        class MEMSTAT
        {
            public uint dwLength = (uint)Marshal.SizeOf(typeof(MEMSTAT));
            public uint dwMemoryLoad; public ulong ullTotalPhys, ullAvailPhys, ullTotalPageFile, ullAvailPageFile, ullTotalVirtual, ullAvailVirtual, ullAvailExtendedVirtual;
        }
        [DllImport("kernel32.dll")] static extern bool GlobalMemoryStatusEx([In, Out] MEMSTAT m);

        const uint SET_QUOTA = 0x0100, QUERY_LIMITED = 0x1000, SUSPEND_RESUME = 0x0800;

        // nunca mexer nestes (sistema, NEXUS e ferramentas de que o NEXUS precisa)
        static readonly HashSet<string> Protected = new HashSet<string>(new[] {
            "system", "idle", "registry", "smss", "csrss", "wininit", "winlogon", "services", "lsass", "lsaiso", "svchost",
            "fontdrvhost", "dwm", "explorer", "sihost", "ctfmon", "taskhostw", "runtimebroker", "audiodg", "conhost",
            "searchhost", "searchindexer", "startmenuexperiencehost", "shellexperiencehost", "textinputhost", "securityhealthservice",
            "securityhealthsystray", "msmpeng", "nissrv", "mpdefendercoreservice", "memory compression", "spoolsv", "wudfhost",
            "dllhost", "applicationframehost", "lockapp", "logonui", "userinit", "taskmgr", "nexus monitor", "nexusdeck",
            "presentmon", "cmd", "powershell", "windowsterminal", "openconsole", "smartscreen", "consent", "wmiprvse",
            "nvcontainer", "nvdisplay.container", "amdrsserv", "atiesrxx", "atieclxx", "igfxem" }, StringComparer.OrdinalIgnoreCase);

        public static bool IsProtected(string name) { return Protected.Contains(name ?? "") || IsAntiCheat(name); }

        // anti-cheats: mexer neles (ou no jogo que protegem) faz o jogo dar erro, fechar ou nem abrir
        static readonly string[] AC = { "easyanticheat", "eac_", "eaclauncher", "beservice", "battleye", "bedaisy", "vgc", "vgtray", "vanguard", "faceit", "ace-", "sguard",
            "ricochet", "randgrid", "mhyprot", "xigncode", "gameguard", "npgg", "nprotect", "pnkbstr", "punkbuster", "eosoverlay", "equ8", "mrac", "atvi-", "acsvc", "tpsvc", "tenprotect", "wellbia" };
        public static bool IsAntiCheat(string name) { string n = (name ?? "").ToLowerInvariant(); return n != "" && AC.Any(a => n.StartsWith(a) || n.Contains(a)); }
        public static bool AntiCheatRunning()
        {
            foreach (Process p in Process.GetProcesses()) { try { if (IsAntiCheat(p.ProcessName)) return true; } catch { } finally { p.Dispose(); } }
            return false;
        }
        // o jogo e tudo o que corre da pasta dele (lançador, ajudantes, anti-cheat próprio) nunca se toca
        static string gameDir;
        static string GameRoot(string exe)
        {
            string d = Path.GetDirectoryName(exe);
            string[] sub = { "win64", "x64", "bin", "binaries", "win32", "x86", "bin64", "retail", "shipping" };
            for (int i = 0; i < 3 && d != null && sub.Contains(Path.GetFileName(d).ToLowerInvariant()); i++) d = Path.GetDirectoryName(d);
            return d != null && d.Length > 3 ? d + "\\" : null;   // nunca a raiz de um disco
        }
        static bool InGameDir(Process p)
        {
            if (string.IsNullOrEmpty(gameDir)) return false;
            // só com "consulta limitada": abrir o jogo para ler a memória (MainModule) é o que os anti-cheats castigam
            try { string f = ExeOf(p.Id); return f != "" && f.StartsWith(gameDir, StringComparison.OrdinalIgnoreCase); } catch { return false; }
        }

        // software em segundo plano que não faz falta durante um jogo (pausado automaticamente no modo jogo)
        static readonly string[] AutoPause = {
            // (OneDrive, Dropbox, Google Drive e iCloud Drive NÃO: se a pasta Documentos estiver na nuvem, um jogo que lá guarda
            //  as definições fica parado à espera deles - travava jogos ou nem os deixava abrir)
            "OneDriveStandaloneUpdater", "DropboxUpdate", "iCloudServices", "iCloudPhotos", "iCloudCKKS", "APSDaemon", "SoftwareUpdate",
            "GoogleUpdate", "GoogleCrashHandler", "GoogleCrashHandler64", "MicrosoftEdgeUpdate",
            "AdobeARM", "AdobeCollabSync", "CCXProcess", "CCLibrary", "AdobeIPCBroker", "Adobe Desktop Service", "CoreSync", "AdobeNotificationClient",
            "jusched", "jucheck", "PhoneExperienceHost", "YourPhone", "CrossDeviceService", "CrossDeviceResume", "Widgets", "WidgetService",
            "HxTsr", "HxOutlook", "HxCalendarAppImm", "SkypeBackgroundHost", "Cortana", "MoUsoCoreWorker", "CompatTelRunner",
            "OfficeC2RClient", "MSOSYNC", "msoia" };

        // apps que o utilizador usa (mesmo só no tabuleiro junto ao relógio): nunca pausar
        static readonly HashSet<string> NeverPause = new HashSet<string>(new[] {
            "steam", "steamwebhelper", "steamservice", "epicgameslauncher", "epicwebhelper", "eadesktop", "eabackgroundservice", "origin",
            "battle.net", "agent", "ubisoftconnect", "upc", "uplaywebcore", "galaxyclient", "riotclientservices", "riotclientux", "vanguard", "vgtray",
            "xboxapp", "xboxpcapp", "gamingservices", "gamebar", "gamebarftserver", "discord", "spotify", "streamdeck", "elgato.streamdeck",
            "obs64", "obs32", "obs", "streamlabs obs", "nvidia share", "nvidia overlay", "nvidia app", "nvcontainer", "radeonsoftware", "amdrsserv",
            "msiafterburner", "rtss", "rtsshooksloader64", "hwinfo64", "librehardwaremonitor", "signalrgb", "icue", "lghub", "lghub_agent", "lghub_updater",
            "razer synapse", "razer synapse 3", "razercentralservice", "armourycrate.service", "openrgb", "wallpaper32", "wallpaper64", "lively", "rainmeter",
            "chrome", "msedge", "firefox", "opera", "opera_gx", "brave", "vivaldi", "msedgewebview2", "teams", "ms-teams", "slack", "whatsapp", "telegram",
            "zoom", "skype", "teamspeak", "ts3client_win64", "mumble", "claude", "code", "devenv", "explorer", "voicemeeter", "voicemeeterpro",
            "voicemeeter8", "nahimic", "sonar", "steelseriesgg", "steelseriesengine", "presentmon", "nexus monitor", "nexusdeck" }, StringComparer.OrdinalIgnoreCase);

        [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc cb, IntPtr lp);
        delegate bool EnumProc(IntPtr h, IntPtr lp);
        [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
        [DllImport("user32.dll")] static extern int GetWindowTextLength(IntPtr h);

        // processos com uma janela visível = apps abertas pelo utilizador
        static HashSet<int> WindowPids()
        {
            HashSet<int> set = new HashSet<int>();
            EnumWindows((h, lp) =>
            {
                if (IsWindowVisible(h) && GetWindowTextLength(h) > 0) { uint pid; GetWindowThreadProcessId(h, out pid); set.Add((int)pid); }
                return true;
            }, IntPtr.Zero);
            return set;
        }

        static HashSet<string> Effective()
        {
            HashSet<string> e = new HashSet<string>(AutoPause, StringComparer.OrdinalIgnoreCase);
            e.UnionWith(AppSettings.GameApps);
            e.ExceptWith(AppSettings.GameSkip);
            return e;
        }

        static readonly object lk = new object();
        static bool gameOn;
        static string gameName;
        static DateTime gameFirstSeen = DateTime.MinValue, gameLastSeen = DateTime.MinValue, lastClean = DateTime.MinValue;
        static long lastFreedMb = -1;
        static DateTime lastRetry = DateTime.MinValue;
        static string lastCleanTxt;
        static readonly List<KeyValuePair<int, DateTime>> paused = new List<KeyValuePair<int, DateTime>>();
        static readonly List<string> pausedNames = new List<string>();
        static string StateFile { get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "NEXUS", "em_pausa.txt"); } }

        public static void Start()
        {
            ResumeLeftovers();
            Thread t = new Thread(() =>
            {
                while (!Program.Quitting)
                {
                    try { Tick(); } catch { }
                    Thread.Sleep(5000);
                }
            });
            t.IsBackground = true;
            t.Start();
        }

        public static double RamPercent(out ulong total, out ulong avail)
        {
            MEMSTAT m = new MEMSTAT();
            if (!GlobalMemoryStatusEx(m)) { total = avail = 0; return 0; }
            total = m.ullTotalPhys; avail = m.ullAvailPhys;
            return total == 0 ? 0 : 100.0 * (total - avail) / total;
        }

        static string NameFromJson(string j)
        {
            if (j == null || j == "null") return null;
            System.Text.RegularExpressions.Match mt = System.Text.RegularExpressions.Regex.Match(j, "\"name\":\"((?:[^\"\\\\]|\\\\.)*)\"");
            return mt.Success ? mt.Groups[1].Value.Replace("\\\\", "\\").Replace("\\\"", "\"") : "jogo";
        }

        // jogo aberto? (PresentMon / RivaTuner, ou uma app em ecrã inteiro)
        public static string DetectGame()
        {
            string n = NameFromJson(PresentMonReader.Json());
            if (n == null) n = NameFromJson(Rtss.Json());
            if (n != null) return n;
            int st;
            if (SHQueryUserNotificationState(out st) == 0 && st == 3) return ForegroundName() ?? "ecrã inteiro";
            return null;
        }

        // pastas onde ficam os jogos (Steam, Epic, GOG, Xbox, EA, Ubisoft, Riot, Battle.net…)
        static readonly string[] GameDirs = { "\\steamapps\\common\\", "\\epic games\\", "\\gog galaxy\\games\\", "\\gog games\\",
            "\\xboxgames\\", "\\ea games\\", "\\ubisoft game launcher\\games\\", "\\riot games\\",
            "\\battle.net\\", "\\rockstar games\\", "\\games\\" };
        static readonly Dictionary<int, KeyValuePair<string, DateTime>> exeCache = new Dictionary<int, KeyValuePair<string, DateTime>>();
        static readonly int myPid = Process.GetCurrentProcess().Id;
        // caminho do .exe sem cache e só com "consulta limitada" (nunca lê a memória do processo: os anti-cheats castigam isso)
        public static string ExePath(int pid)
        {
            IntPtr h = OpenProcess(QUERY_LIMITED, false, pid); if (h == IntPtr.Zero) return "";
            try { StringBuilder sb = new StringBuilder(1024); int n = sb.Capacity; return QueryFullProcessImageName(h, 0, sb, ref n) ? sb.ToString() : ""; }
            finally { CloseHandle(h); }
        }
        static string ExeOf(int pid)
        {
            // o Windows reaproveita números de processo: a cache só vale 2 minutos (senão um programa novo herdava o nome de outro)
            KeyValuePair<string, DateTime> c;
            lock (exeCache) if (exeCache.TryGetValue(pid, out c) && DateTime.UtcNow - c.Value < TimeSpan.FromMinutes(2)) return c.Key;
            string path = "";
            IntPtr h = OpenProcess(QUERY_LIMITED, false, pid);
            if (h != IntPtr.Zero)
            {
                StringBuilder sb = new StringBuilder(1024); int n = sb.Capacity;
                if (QueryFullProcessImageName(h, 0, sb, ref n)) path = sb.ToString();
                CloseHandle(h);
            }
            lock (exeCache) { if (exeCache.Count > 300) exeCache.Clear(); exeCache[pid] = new KeyValuePair<string, DateTime>(path, DateTime.UtcNow); }
            return path;
        }

        // há sinais de um jogo? (barato: não precisa do PresentMon)
        static string GameCandidate()
        {
            string n = NameFromJson(Rtss.Json());
            if (n != null) return n;
            int st;
            if (SHQueryUserNotificationState(out st) == 0 && st == 3) return ForegroundName() ?? "ecrã inteiro";
            IntPtr fg = GetForegroundWindow();
            if (fg == IntPtr.Zero) return null;
            uint upid; GetWindowThreadProcessId(fg, out upid);
            int pid = (int)upid;
            if (pid == 0 || pid == myPid) return null;
            string exe = ExeOf(pid);
            string name = Path.GetFileNameWithoutExtension(exe);
            if (string.IsNullOrEmpty(exe) || Rtss.NotAGame(name)) return null;
            string low = exe.ToLowerInvariant();
            if (low.StartsWith(Environment.GetFolderPath(Environment.SpecialFolder.Windows).ToLowerInvariant() + "\\")) return null;
            foreach (string d in GameDirs) if (low.Contains(d)) return name;
            // janela sem bordas a ocupar o ecrã todo (jogos em "borderless")
            StringBuilder cls = new StringBuilder(64); GetClassName(fg, cls, 64);
            string c = cls.ToString();
            if (c == "Progman" || c == "WorkerW" || c == "Shell_TrayWnd") return null;
            RECT r; MONINFO mi = new MONINFO(); mi.cbSize = Marshal.SizeOf(typeof(MONINFO));
            if (GetWindowRect(fg, out r) && GetMonitorInfo(MonitorFromWindow(fg, 2), ref mi) &&
                r.L <= mi.rcMonitor.L && r.T <= mi.rcMonitor.T && r.R >= mi.rcMonitor.R && r.B >= mi.rcMonitor.B) return name;
            return null;
        }
        static DateTime lastCandidate = DateTime.MinValue;
        // há um jogo aberto agora? (independente da opção "Deteção de jogo"; usado pelos alertas)
        static DateTime lastAnyGame = DateTime.MinValue;
        public static bool Playing { get { return DateTime.Now - lastAnyGame < TimeSpan.FromSeconds(12); } }
        // o jogo detetado agora (null se não há jogo aberto)
        public static string GameName { get { return gameOn ? gameName : null; } }

        static int ForegroundPid()
        {
            uint pid; GetWindowThreadProcessId(GetForegroundWindow(), out pid);
            return (int)pid;
        }

        static string ForegroundName()
        {
            try { using (Process p = Process.GetProcessById(ForegroundPid())) return p.ProcessName; } catch { return null; }
        }

        static void Tick()
        {
            try { DiskScan.Housekeeping(); } catch { }
            DateTime now = DateTime.Now;
            // PresentMon (FPS/latência) só corre com um jogo aberto; desliga 30 s depois de o jogo fechar
            string cand = null;
            try { cand = GameCandidate(); } catch { }
            if (cand != null) lastCandidate = now;
            PresentMonReader.SetActive(now - lastCandidate < TimeSpan.FromSeconds(30));
            string g = DetectGame() ?? cand;
            if (g != null) lastAnyGame = now;
            if (g != null)
            {
                if (gameLastSeen == DateTime.MinValue || now - gameLastSeen > TimeSpan.FromSeconds(20)) gameFirstSeen = now;
                gameLastSeen = now;
                gameName = g;
                if (!gameOn && now - gameFirstSeen >= TimeSpan.FromSeconds(8))
                {
                    gameOn = true; gameDir = null;
                    try { foreach (Process gp in Process.GetProcessesByName(g.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) ? g.Substring(0, g.Length - 4) : g)) { try { string ge = ExeOf(gp.Id); if (ge != "") gameDir = GameRoot(ge); } catch { } finally { gp.Dispose(); } if (gameDir != null) break; } } catch { }
                    OnGameStart(); Tweaks.OnGame(true, g);
                }
            }
            else if (gameOn && now - gameLastSeen > TimeSpan.FromSeconds(15)) { gameOn = false; OnGameEnd(); Tweaks.OnGame(false, null); }

            // ligaram a deteção a meio de um jogo (ou nada para pausar ainda): tenta de novo, no máximo a cada 30 s
            if (gameOn && AppSettings.GameMode && paused.Count == 0 && now - lastRetry > TimeSpan.FromSeconds(30)) { lastRetry = now; OnGameStart(); }
            if (!AppSettings.GameMode && paused.Count > 0) ResumeAll(false);

            if (AppSettings.RamClean && g == null && !gameOn && now - lastClean > TimeSpan.FromMinutes(AppSettings.RamCleanMin))
            {
                ulong t, a;
                if (RamPercent(out t, out a) >= AppSettings.RamCleanPct) Clean(true);
            }
        }

        // ---------------- limpar RAM
        public static string Clean(bool auto)
        {
            lock (lk)
            {
                ulong t, a0, a1;
                double before = RamPercent(out t, out a0);
                int fg = ForegroundPid(), self = Process.GetCurrentProcess().Id, n = 0;
                foreach (Process p in Process.GetProcesses())
                {
                    try
                    {
                        if (p.Id == fg || p.Id == self || p.Id <= 4 || IsProtected(p.ProcessName)) continue;
                        if (gameName != null && (string.Equals(p.ProcessName, gameName, StringComparison.OrdinalIgnoreCase) || InGameDir(p))) continue;
                        IntPtr h = OpenProcess(SET_QUOTA | QUERY_LIMITED, false, p.Id);
                        if (h == IntPtr.Zero) continue;
                        if (EmptyWorkingSet(h)) n++;
                        CloseHandle(h);
                    }
                    catch { }
                    finally { p.Dispose(); }
                }
                Thread.Sleep(1500);
                double after = RamPercent(out t, out a1);
                long freed = ((long)a1 - (long)a0) / 1048576;
                lastClean = DateTime.Now;
                lastFreedMb = Math.Max(0, freed);
                lastCleanTxt = lastClean.ToString("HH:mm");
                string msg = "Libertados " + FmtMb(lastFreedMb) + " (" + Math.Round(before) + "% → " + Math.Round(after) + "%).";
                if (auto) Program.Notify("NEXUS · RAM limpa", msg);
                return "{\"freed_mb\":" + lastFreedMb + ",\"before\":" + Math.Round(before) + ",\"after\":" + Math.Round(after) + ",\"apps\":" + n +
                       ",\"message\":\"" + msg + "\"}";
            }
        }

        static string FmtMb(long mb) { return mb >= 1024 ? (mb / 1024.0).ToString("0.0", CultureInfo.InvariantCulture) + " GB" : mb + " MB"; }

        // ---------------- modo jogo
        static void OnGameStart()
        {
            if (!AppSettings.GameMode) return;
            HashSet<string> want = Effective();
            if (want.Count == 0) return;
            int fg = ForegroundPid();
            HashSet<int> win = WindowPids();
            HashSet<string> winNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (int wp in win) { try { using (Process wpp = Process.GetProcessById(wp)) winNames.Add(wpp.ProcessName); } catch { } }
            string game = gameName ?? "";
            lock (lk)
            {
                foreach (Process p in Process.GetProcesses())
                {
                    try
                    {
                        string n = p.ProcessName;
                        if (!want.Contains(n) || IsProtected(n) || NeverPause.Contains(n) || winNames.Contains(n) || p.Id == fg || InGameDir(p) ||
                            string.Equals(n, game, StringComparison.OrdinalIgnoreCase)) continue;
                        if (paused.Any(x => x.Key == p.Id)) continue;
                        IntPtr h = OpenProcess(SUSPEND_RESUME | QUERY_LIMITED, false, p.Id);
                        if (h == IntPtr.Zero) continue;
                        if (NtSuspendProcess(h) == 0)
                        {
                            paused.Add(new KeyValuePair<int, DateTime>(p.Id, p.StartTime));
                            if (!pausedNames.Contains(n, StringComparer.OrdinalIgnoreCase)) pausedNames.Add(n);
                        }
                        CloseHandle(h);
                    }
                    catch { }
                    finally { p.Dispose(); }
                }
                SaveState();
            }
            if (pausedNames.Count > 0)
                Program.Notify(Lang.L("NEXUS · Jogo detetado:") + " " + gameName, Lang.L("Em pausa até saíres:") + " " + string.Join(", ", pausedNames.ToArray()));
        }

        static void OnGameEnd() { ResumeAll(true); }

        public static void ResumeAll(bool notify)
        {
            int n;
            lock (lk)
            {
                n = pausedNames.Count;
                foreach (KeyValuePair<int, DateTime> kv in paused) Resume(kv.Key, kv.Value);
                paused.Clear(); pausedNames.Clear();
                try { File.Delete(StateFile); } catch { }
            }
            if (notify && n > 0) Program.Notify("NEXUS · Jogo fechado", "Processos em segundo plano retomados.");
        }

        static void Resume(int pid, DateTime start)
        {
            try
            {
                using (Process p = Process.GetProcessById(pid))
                {
                    if (Math.Abs((p.StartTime - start).TotalSeconds) > 2) return;   // outro processo com o mesmo PID
                    IntPtr h = OpenProcess(SUSPEND_RESUME | QUERY_LIMITED, false, pid);
                    if (h == IntPtr.Zero) return;
                    NtResumeProcess(h);
                    CloseHandle(h);
                }
            }
            catch { }
        }

        static void SaveState()
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(StateFile));
                File.WriteAllLines(StateFile, paused.Select(kv => kv.Key + "|" + kv.Value.ToBinary()).ToArray());
            }
            catch { }
        }

        // se o NEXUS fechou de repente com apps em pausa, retoma-as ao arrancar
        static void ResumeLeftovers()
        {
            try
            {
                if (!File.Exists(StateFile)) return;
                foreach (string l in File.ReadAllLines(StateFile))
                {
                    string[] p = l.Split('|'); int pid; long bin;
                    if (p.Length == 2 && int.TryParse(p[0], out pid) && long.TryParse(p[1], out bin)) Resume(pid, DateTime.FromBinary(bin));
                }
                File.Delete(StateFile);
            }
            catch { }
        }

        // processos em segundo plano (sem janela) que podem ser pausados no modo jogo
        public static string ProcsJson()
        {
            Dictionary<string, long[]> m = new Dictionary<string, long[]>(StringComparer.OrdinalIgnoreCase);
            HashSet<int> win = WindowPids();
            HashSet<string> winNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            int mySession = Process.GetCurrentProcess().SessionId;
            List<Process> all = Process.GetProcesses().ToList();
            foreach (Process p in all) { try { if (win.Contains(p.Id)) winNames.Add(p.ProcessName); } catch { } }
            HashSet<string> auto = new HashSet<string>(AutoPause, StringComparer.OrdinalIgnoreCase);
            HashSet<string> eff = Effective();
            foreach (Process p in all)
            {
                try
                {
                    string n = p.ProcessName;
                    if (p.Id <= 4 || IsProtected(n) || NeverPause.Contains(n) || winNames.Contains(n)) continue;
                    if (p.SessionId != mySession && !auto.Contains(n)) continue;
                    long[] v;
                    if (!m.TryGetValue(n, out v)) m[n] = v = new long[2];
                    v[0] += p.WorkingSet64; v[1]++;
                }
                catch { }
                finally { p.Dispose(); }
            }
            return "[" + string.Join(",", m.OrderByDescending(kv => eff.Contains(kv.Key)).ThenByDescending(kv => kv.Value[0]).Take(80).Select(kv =>
                "{\"name\":\"" + kv.Key.Replace("\\", "\\\\").Replace("\"", "\\\"") + "\",\"mem\":" + kv.Value[0] + ",\"count\":" + kv.Value[1] +
                ",\"auto\":" + (auto.Contains(kv.Key) ? "true" : "false") + ",\"on\":" + (eff.Contains(kv.Key) ? "true" : "false") + "}").ToArray()) + "]";
        }

        public static string Json()
        {
            Func<string, string> q = x => x == null ? "null" : "\"" + x.Replace("\\", "\\\\").Replace("\"", "\\\"") + "\"";
            string[] pn; try { pn = pausedNames.ToArray(); } catch { pn = new string[0]; }
            return "{\"game_active\":" + (gameOn ? "true" : "false") + ",\"game\":" + q(gameOn ? gameName : null) +
                   ",\"paused\":[" + string.Join(",", pn.Select(q).ToArray()) + "]" +
                   ",\"last_clean\":" + q(lastCleanTxt) + ",\"next_clean\":" + q(lastCleanTxt == null ? null : lastClean.AddMinutes(AppSettings.RamCleanMin).ToString("HH:mm")) + ",\"last_freed\":" + q(lastFreedMb < 0 ? null : FmtMb(lastFreedMb)) + "}";
        }
    }
    // ---------------------------------------------------------------- página Performance: otimizações e debloat
    // Cada otimização guarda o valor original (Documentos\NEXUS Monitor\performance_backup.txt) antes de mudar
    // e "Repor" volta exatamente ao que estava. Tudo feito pelo próprio NEXUS (registo, serviços, powercfg):
    // nada é descarregado da internet.
    static class Tweaks
    {
        class RV
        {
            public string Path, Name, Val;     // Val: "d:123" (DWORD) ou "s:texto"
            public RV(string p, string n, string v) { Path = p; Name = n; Val = v; }
        }
        class Tw
        {
            public string Id, Cat, Name, Desc, Risk;   // risco: safe | mod | adv
            public bool Reboot, Rec;
            public List<RV> Regs = new List<RV>();
            public List<string> Svcs = new List<string>();
            public Func<string> State;                 // personalizado: "on" | "off" | "partial"
            public Func<bool, string> Apply;           // personalizado: true = aplicar, false = repor
            public string Key;                         // personalizado: chave da cópia de segurança
            public double Lo, Hi; public string Eff = "";
            public List<string> Extra = new List<string>();   // notas deste PC (separadas para se poderem traduzir)   // ganho estimado (% FPS) e tipo de efeito
        }

        static readonly object lk = new object();
        static Dictionary<string, string> backup;
        static bool rebootPending;
        static string BackupFile { get { return Path.Combine(AppSettings.Dir, "performance_backup.txt"); } }

        static void LoadBackup()
        {
            if (backup != null) return;
            backup = new Dictionary<string, string>();
            try
            {
                if (File.Exists(BackupFile))
                    foreach (string line in File.ReadAllLines(BackupFile, Encoding.UTF8))
                    {
                        int t = line.IndexOf('\t');
                        if (t > 0) backup[line.Substring(0, t)] = line.Substring(t + 1);
                    }
            }
            catch { }
        }
        static void SaveBackup()
        {
            try
            {
                Directory.CreateDirectory(AppSettings.Dir);
                File.WriteAllLines(BackupFile, backup.Select(kv => kv.Key + "\t" + kv.Value).ToArray(), new UTF8Encoding(false));
            }
            catch { }
        }

        // ---------------- registo
        static RegistryKey Root(string path, out string sub)
        {
            int i = path.IndexOf('\\');
            string r = path.Substring(0, i); sub = path.Substring(i + 1);
            return RegistryKey.OpenBaseKey(r == "HKLM" ? RegistryHive.LocalMachine : RegistryHive.CurrentUser, RegistryView.Registry64);
        }
        static string Read(string path, string name)
        {
            try
            {
                string sub;
                using (RegistryKey b = Root(path, out sub))
                using (RegistryKey k = b.OpenSubKey(sub))
                {
                    if (k == null) return "-";
                    object v = k.GetValue(name, null, RegistryValueOptions.DoNotExpandEnvironmentNames);
                    if (v == null) return "-";
                    if (v is int) return "d:" + unchecked((uint)(int)v);
                    if (v is string) return "s:" + ((string)v).Replace("\r", "").Replace("\n", " ").Replace("\t", " ");
                    return "?";
                }
            }
            catch { return "-"; }
        }
        static void Write(string path, string name, string val)
        {
            string sub;
            using (RegistryKey b = Root(path, out sub))
            {
                if (val == "-")
                {
                    using (RegistryKey k = b.OpenSubKey(sub, true)) if (k != null) k.DeleteValue(name, false);
                    return;
                }
                if (val == "?") return;
                using (RegistryKey k = b.CreateSubKey(sub))
                {
                    if (val.StartsWith("d:")) k.SetValue(name, unchecked((int)uint.Parse(val.Substring(2))), RegistryValueKind.DWord);
                    else k.SetValue(name, val.Substring(2), RegistryValueKind.String);
                }
            }
        }

        // ---------------- serviços
        const string SVC = @"HKLM\SYSTEM\CurrentControlSet\Services\";
        static bool SvcExists(string n) { return Read(SVC + n, "Start") != "-"; }

        // ---------------- comandos
        // as leituras do powercfg/bcdedit repetiam-se dezenas de vezes por cada vez que a página abria (cada uma é um programa
        // novo): guardam-se 4 s; qualquer mudança apaga a cópia
        static readonly Dictionary<string, KeyValuePair<DateTime, string>> runCache = new Dictionary<string, KeyValuePair<DateTime, string>>();
        static string RunOut(string exe, string args, int ms)
        {
            bool query = (exe == "powercfg" && (args.StartsWith("/q ") || args == "/getactivescheme" || args == "/list")) || (exe == "bcdedit" && args.StartsWith("/enum"));
            string ck = exe + " " + args;
            lock (runCache)
            {
                KeyValuePair<DateTime, string> c;
                if (!query) runCache.Clear();
                else if (runCache.TryGetValue(ck, out c) && (DateTime.UtcNow - c.Key).TotalSeconds < 4) return c.Value;
            }
            try
            {
                string o = ProcOut.Run(exe, args, ms);
                if (query) lock (runCache) runCache[ck] = new KeyValuePair<DateTime, string>(DateTime.UtcNow, o);
                if (!query) lock (runCache) runCache.Clear();
                return o;
            }
            catch (Exception ex) { return "ERRO " + ex.Message; }
        }
        static string Guid1(string s)
        {
            System.Text.RegularExpressions.Match m = System.Text.RegularExpressions.Regex.Match(s ?? "", @"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}");
            return m.Success ? m.Value.ToLowerInvariant() : null;
        }

        // ---------------- plano de energia
        const string ULTIMATE = "e9a42b02-d5df-448d-aa00-03f14749eb61", HIGHPERF = "8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c";
        public static string ActiveScheme() { return Guid1(RunOut("powercfg", "/getactivescheme", 8000)); }
        public static string ActiveSchemeName()
        {
            string o = RunOut("powercfg", "/getactivescheme", 8000);
            int a = o.IndexOf('('), b = o.LastIndexOf(')');
            return a >= 0 && b > a ? o.Substring(a + 1, b - a - 1) : null;
        }
        static List<string> Schemes() { return System.Text.RegularExpressions.Regex.Matches(RunOut("powercfg", "/list", 8000), @"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}").Cast<System.Text.RegularExpressions.Match>().Select(m => m.Value.ToLowerInvariant()).ToList(); }
        // o plano "Desempenho Máximo": usa o que o NEXUS criou antes, ou cria-o; se o Windows não deixar, "Alto desempenho"
        public static string FastScheme(bool create)
        {
            LoadBackup();
            List<string> all = Schemes();
            string mine;
            if (backup.TryGetValue("power|ultimate", out mine) && all.Contains(mine)) return mine;
            if (all.Contains(ULTIMATE)) return ULTIMATE;
            if (create)
            {
                string g = Guid1(RunOut("powercfg", "-duplicatescheme " + ULTIMATE, 15000));
                if (g != null && g != ULTIMATE && Schemes().Contains(g)) { backup["power|ultimate"] = g; SaveBackup(); return g; }
            }
            return all.Contains(HIGHPERF) ? HIGHPERF : null;
        }
        static string PowerState()
        {
            string act = ActiveScheme();
            if (act == null) return "off";
            string mine; LoadBackup();
            return act == ULTIMATE || act == HIGHPERF || (backup.TryGetValue("power|ultimate", out mine) && act == mine) ? "on" : "off";
        }
        static string PowerApply(bool on)
        {
            LoadBackup();
            if (on)
            {
                string act = ActiveScheme();
                string fast = FastScheme(true);
                if (fast == null) return "O Windows não deixa usar um plano de desempenho neste PC.";
                if (!backup.ContainsKey("power|orig") && act != null && act != fast) backup["power|orig"] = act;
                SaveBackup();
                RunOut("powercfg", "/setactive " + fast, 8000);
                return null;
            }
            string orig;
            if (backup.TryGetValue("power|orig", out orig)) { RunOut("powercfg", "/setactive " + orig, 8000); backup.Remove("power|orig"); SaveBackup(); }
            else RunOut("powercfg", "/setactive 381b4222-f694-41f0-9685-ff5bb260df2e", 8000);   // Equilibrado
            return null;
        }

        // ---------------- hibernação
        static string HiberState() { return Read(@"HKLM\SYSTEM\CurrentControlSet\Control\Power", "HibernateEnabled") == "d:0" ? "on" : "off"; }
        static string HiberApply(bool on)
        {
            LoadBackup();
            if (on)
            {
                if (!backup.ContainsKey("hiber")) { backup["hiber"] = HiberState() == "on" ? "0" : "1"; SaveBackup(); }
                RunOut("powercfg", "-h off", 15000);
            }
            else
            {
                string o; bool was = !backup.TryGetValue("hiber", out o) || o == "1";
                if (was) RunOut("powercfg", "-h on", 15000);
                backup.Remove("hiber"); SaveBackup();
            }
            return null;
        }

        // ---------------- otimizações para jogos em janela (texto partilhado com outras definições do DirectX)
        const string DXP = @"HKCU\Software\Microsoft\DirectX\UserGpuPreferences", DXN = "DirectXUserGlobalSettings";
        static string DxState() { string v = Read(DXP, DXN); return v.StartsWith("s:") && v.Contains("SwapEffectUpgradeEnable=1;") ? "on" : "off"; }
        static string DxApply(bool on)
        {
            LoadBackup();
            string cur = Read(DXP, DXN);
            string key = "reg|" + DXP + "|" + DXN;
            if (on)
            {
                if (!backup.ContainsKey(key)) { backup[key] = cur; SaveBackup(); }
                string txt = cur.StartsWith("s:") ? cur.Substring(2) : "";
                txt = System.Text.RegularExpressions.Regex.Replace(txt, @"SwapEffectUpgradeEnable=\d;", "");
                Write(DXP, DXN, "s:" + txt + "SwapEffectUpgradeEnable=1;");
            }
            else
            {
                string orig;
                if (backup.TryGetValue(key, out orig)) { Write(DXP, DXN, orig); backup.Remove(key); SaveBackup(); }
                else if (cur.StartsWith("s:")) Write(DXP, DXN, "s:" + cur.Substring(2).Replace("SwapEffectUpgradeEnable=1;", ""));
            }
            return null;
        }

        // ---------------- lista
        static List<Tw> list;
        static Tw T(string id, string cat, string name, string desc, string risk, bool rec, bool reboot)
        {
            Tw t = new Tw { Id = id, Cat = cat, Name = name, Desc = desc, Risk = risk, Rec = rec, Reboot = reboot };
            list.Add(t);
            return t;
        }

        static List<Tw> Build()
        {
            list = new List<Tw>();
            Tw t;
            const string MM = @"HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile";
            const string GCS = @"HKCU\System\GameConfigStore";
            const string CDM = @"HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager";
            const string ADV = @"HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced";

            // ENERGIA
            t = T("power_plan", "ENERGIA", "Plano de energia Desempenho Máximo", "O processador não poupa energia nem desliga núcleos a meio do jogo. Gasta um pouco mais de energia e aquece um pouco mais.", "safe", true, false);
            t.State = PowerState; t.Apply = PowerApply; t.Key = "power|orig";
            t = T("power_throttle", "ENERGIA", "Sem limitação de energia em segundo plano", "O Windows deixa de abrandar programas que acha que estão em segundo plano (alguns jogos e launchers eram afetados).", "safe", true, true);
            t.Regs.Add(new RV(@"HKLM\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling", "PowerThrottlingOff", "d:1"));
            t = T("hibernate", "ENERGIA", "Desligar a hibernação", "Apaga o hiberfil.sys (liberta vários GB no disco C:) e desliga o Arranque Rápido. O PC deixa de poder hibernar.", "mod", false, false);
            t.State = HiberState; t.Apply = HiberApply; t.Key = "hiber";

            // JOGOS
            t = T("game_mode", "JOGOS", "Modo de Jogo do Windows", "Dá prioridade ao jogo e impede o Windows Update de instalar coisas enquanto jogas.", "safe", true, false);
            t.Regs.Add(new RV(@"HKCU\Software\Microsoft\GameBar", "AutoGameModeEnabled", "d:1"));
            t.Regs.Add(new RV(@"HKCU\Software\Microsoft\GameBar", "AllowAutoGameMode", "d:1"));
            t = T("hags", "JOGOS", "Agendamento de GPU acelerado por hardware", "A placa gráfica gere a própria memória: menos latência e é preciso para o DLSS Frame Generation.", "safe", true, true);
            t.Regs.Add(new RV(@"HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers", "HwSchMode", "d:2"));
            t = T("game_dvr", "JOGOS", "Sem gravação em segundo plano (Xbox Game DVR)", "Desliga a gravação contínua dos últimos minutos de jogo, que gasta GPU e disco. A Xbox Game Bar continua a abrir.", "safe", true, false);
            t.Regs.Add(new RV(GCS, "GameDVR_Enabled", "d:0"));
            t.Regs.Add(new RV(@"HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR", "AppCaptureEnabled", "d:0"));
            t.Regs.Add(new RV(@"HKLM\SOFTWARE\Policies\Microsoft\Windows\GameDVR", "AllowGameDVR", "d:0"));
            t = T("windowed_opt", "JOGOS", "Otimizações para jogos em janela", "Jogos em janela/sem bordas passam a ter a mesma latência do ecrã inteiro e suportam Auto HDR e VRR.", "safe", true, false);
            t.State = DxState; t.Apply = DxApply; t.Key = "reg|" + DXP + "|" + DXN;
            t = T("mmcss", "JOGOS", "Prioridade máxima para jogos (agendador multimédia)", "O Windows dá mais tempo de CPU e de GPU às tarefas marcadas como jogo.", "safe", true, false);
            t.Regs.Add(new RV(MM + @"\Tasks\Games", "GPU Priority", "d:8"));
            t.Regs.Add(new RV(MM + @"\Tasks\Games", "Priority", "d:6"));
            t.Regs.Add(new RV(MM + @"\Tasks\Games", "Scheduling Category", "s:High"));
            t.Regs.Add(new RV(MM + @"\Tasks\Games", "SFIO Priority", "s:High"));
            t = T("sys_resp", "JOGOS", "Menos CPU reservado para segundo plano", "O Windows reserva 20% do CPU para tarefas em segundo plano; passa a reservar 10% e deixa de limitar a rede durante áudio/vídeo.", "safe", true, true);
            t.Regs.Add(new RV(MM, "SystemResponsiveness", "d:10"));
            t.Regs.Add(new RV(MM, "NetworkThrottlingIndex", "d:4294967295"));
            t = T("mouse_accel", "JOGOS", "Sem aceleração do rato", "O cursor mexe-se sempre a mesma distância para o mesmo movimento: mira mais consistente.", "safe", true, true);
            t.Regs.Add(new RV(@"HKCU\Control Panel\Mouse", "MouseSpeed", "s:0"));
            t.Regs.Add(new RV(@"HKCU\Control Panel\Mouse", "MouseThreshold1", "s:0"));
            t.Regs.Add(new RV(@"HKCU\Control Panel\Mouse", "MouseThreshold2", "s:0"));
            t = T("prio_sep", "JOGOS", "Mais CPU para a janela da frente", "A janela que estás a usar (o jogo) recebe fatias de CPU maiores do que os programas em segundo plano.", "mod", false, false);
            t.Regs.Add(new RV(@"HKLM\SYSTEM\CurrentControlSet\Control\PriorityControl", "Win32PrioritySeparation", "d:38"));
            t = T("fso_off", "JOGOS", "Desligar as otimizações de ecrã inteiro", "Força o ecrã inteiro exclusivo nos jogos antigos (DirectX 9-11). Pode ajudar em alguns, mas tira o Auto HDR e alt-tab rápido.", "mod", false, false);
            t.Regs.Add(new RV(GCS, "GameDVR_FSEBehaviorMode", "d:2"));
            t.Regs.Add(new RV(GCS, "GameDVR_HonorUserFSEBehaviorMode", "d:1"));
            t.Regs.Add(new RV(GCS, "GameDVR_FSEBehavior", "d:2"));
            t.Regs.Add(new RV(GCS, "GameDVR_DXGIHonorFSEWindowsCompatible", "d:1"));
            t = T("bg_apps", "JOGOS", "Apps da Loja sem correr em segundo plano", "As apps da Microsoft Store deixam de correr escondidas. Podem deixar de dar notificações até as abrires.", "mod", false, false);
            t.Regs.Add(new RV(@"HKCU\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications", "GlobalUserDisabled", "d:1"));
            t.Regs.Add(new RV(@"HKCU\Software\Microsoft\Windows\CurrentVersion\Search", "BackgroundAppGlobalToggle", "d:0"));

            // SISTEMA
            t = T("startup_delay", "SISTEMA", "Arranque dos programas sem atraso", "O Windows espera uns segundos antes de abrir os programas do arranque; deixa de esperar.", "safe", true, false);
            t.Regs.Add(new RV(@"HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize", "StartupDelayInMSec", "d:0"));
            t.Regs.Add(new RV(@"HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize", "WaitForIdleState", "d:0"));
            t = T("visual_fx", "SISTEMA", "Menos animações e transparência", "Tira as animações das janelas e da barra de tarefas e a transparência. O Windows fica mais seco, mas mais rápido.", "mod", false, true);
            t.Regs.Add(new RV(@"HKCU\Control Panel\Desktop\WindowMetrics", "MinAnimate", "s:0"));
            t.Regs.Add(new RV(ADV, "TaskbarAnimations", "d:0"));
            t.Regs.Add(new RV(@"HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize", "EnableTransparency", "d:0"));
            t = T("sysmain", "SISTEMA", "Desligar o SysMain (Superfetch)", "Deixa de carregar programas para a RAM antes de os abrires. Num SSD quase não se nota diferença; poupa disco e RAM.", "mod", false, false);
            t.Svcs.Add("SysMain");
            t = T("search_idx", "SISTEMA", "Desligar a indexação da pesquisa", "Para de ler os discos em segundo plano para a pesquisa do Windows. A pesquisa de ficheiros no Iniciar fica mais lenta.", "mod", false, false);
            t.Svcs.Add("WSearch");
            t = T("vbs_off", "SISTEMA", "Desligar a Integridade da Memória (VBS)", "É a otimização com mais impacto nos FPS de muitos jogos, mas tira uma proteção de segurança do Windows contra drivers maliciosos. Alguns anti-batota (ex.: Valorant, FACEIT) podem exigi-la ligada.", "adv", false, true);
            t.Regs.Add(new RV(@"HKLM\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity", "Enabled", "d:0"));
            t.Regs.Add(new RV(@"HKLM\SYSTEM\CurrentControlSet\Control\DeviceGuard", "EnableVirtualizationBasedSecurity", "d:0"));

            // REDE
            t = T("nagle", "REDE", "Sem atraso de Nagle (TCP)", "Os pacotes pequenos saem logo em vez de serem juntados: menos latência nos jogos que usam TCP. Não muda nada nos que usam UDP.", "mod", false, true);
            try
            {
                const string IFS = @"SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces";
                using (RegistryKey b = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64))
                using (RegistryKey ifs = b.OpenSubKey(IFS))
                    if (ifs != null)
                        foreach (string g in ifs.GetSubKeyNames())
                            using (RegistryKey k = ifs.OpenSubKey(g))
                            {
                                if (k == null) continue;
                                string ip = Convert.ToString(k.GetValue("DhcpIPAddress")) + " " + string.Join(" ", (k.GetValue("IPAddress") as string[]) ?? new string[0]);
                                if (!System.Text.RegularExpressions.Regex.IsMatch(ip, @"\b(?!0\.0\.0\.0)\d+\.\d+\.\d+\.\d+")) continue;
                                t.Regs.Add(new RV(@"HKLM\" + IFS + "\\" + g, "TcpAckFrequency", "d:1"));
                                t.Regs.Add(new RV(@"HKLM\" + IFS + "\\" + g, "TCPNoDelay", "d:1"));
                            }
            }
            catch { }
            if (t.Regs.Count == 0) list.Remove(t);

            // PRIVACIDADE E ANÚNCIOS (debloat do Windows)
            t = T("telemetry", "PRIVACIDADE", "Telemetria no mínimo", "O Windows envia à Microsoft o mínimo possível de dados de utilização e desliga o serviço de telemetria.", "safe", true, false);
            t.Regs.Add(new RV(@"HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection", "AllowTelemetry", "d:0"));
            t.Svcs.Add("DiagTrack");
            t = T("ad_id", "PRIVACIDADE", "Sem ID de publicidade", "As apps deixam de usar um identificador teu para mostrar anúncios personalizados.", "safe", true, false);
            t.Regs.Add(new RV(@"HKCU\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo", "Enabled", "d:0"));
            t.Regs.Add(new RV(@"HKCU\Software\Microsoft\Windows\CurrentVersion\Privacy", "TailoredExperiencesWithDiagnosticDataEnabled", "d:0"));
            t = T("start_ads", "PRIVACIDADE", "Sem anúncios nem sugestões", "Tira as apps sugeridas no Iniciar, as dicas, os anúncios no ecrã de bloqueio e a instalação automática de apps patrocinadas.", "safe", true, false);
            foreach (string n in new[] { "SubscribedContent-338388Enabled", "SubscribedContent-338389Enabled", "SubscribedContent-353694Enabled", "SubscribedContent-353696Enabled",
                                         "SubscribedContent-310093Enabled", "SubscribedContent-338387Enabled", "SystemPaneSuggestionsEnabled", "SilentInstalledAppsEnabled",
                                         "SoftLandingEnabled", "RotatingLockScreenOverlayEnabled", "PreInstalledAppsEnabled", "OemPreInstalledAppsEnabled" })
                t.Regs.Add(new RV(CDM, n, "d:0"));
            t.Regs.Add(new RV(ADV, "Start_IrisRecommendations", "d:0"));
            t.Regs.Add(new RV(ADV, "ShowSyncProviderNotifications", "d:0"));
            t.Regs.Add(new RV(@"HKCU\Software\Microsoft\Windows\CurrentVersion\UserProfileEngagement", "ScoobeSystemSettingEnabled", "d:0"));
            t.Regs.Add(new RV(@"HKLM\SOFTWARE\Policies\Microsoft\Windows\CloudContent", "DisableWindowsConsumerFeatures", "d:1"));
            t = T("bing", "PRIVACIDADE", "Pesquisa do Iniciar sem Bing", "A pesquisa do Iniciar procura só no PC: deixa de mandar o que escreves para a Bing e de mostrar resultados da web.", "safe", true, false);
            t.Regs.Add(new RV(@"HKCU\Software\Policies\Microsoft\Windows\Explorer", "DisableSearchBoxSuggestions", "d:1"));
            t.Regs.Add(new RV(@"HKCU\Software\Microsoft\Windows\CurrentVersion\Search", "BingSearchEnabled", "d:0"));
            t = T("copilot", "PRIVACIDADE", "Desligar o Copilot do Windows", "Tira o Copilot da barra de tarefas e do Windows.", "safe", true, false);
            t.Regs.Add(new RV(@"HKCU\Software\Policies\Microsoft\Windows\WindowsCopilot", "TurnOffWindowsCopilot", "d:1"));
            t.Regs.Add(new RV(@"HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsCopilot", "TurnOffWindowsCopilot", "d:1"));
            t.Regs.Add(new RV(ADV, "ShowCopilotButton", "d:0"));
            t = T("recall", "PRIVACIDADE", "Desligar o Recall", "O Windows deixa de tirar capturas de ecrã contínuas para a pesquisa com IA (PCs Copilot+).", "safe", true, false);
            t.Regs.Add(new RV(@"HKCU\Software\Policies\Microsoft\Windows\WindowsAI", "DisableAIDataAnalysis", "d:1"));
            t.Regs.Add(new RV(@"HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsAI", "DisableAIDataAnalysis", "d:1"));
            t = T("widgets", "PRIVACIDADE", "Desligar os Widgets (notícias)", "Tira o painel de notícias e meteorologia da barra de tarefas, que fica sempre a correr.", "safe", true, true);
            t.Regs.Add(new RV(@"HKLM\SOFTWARE\Policies\Microsoft\Dsh", "AllowNewsAndInterests", "d:0"));
            t = T("activity", "PRIVACIDADE", "Sem histórico de atividade", "O Windows deixa de guardar e enviar a lista do que abres (Linha Cronológica).", "safe", true, false);
            t.Regs.Add(new RV(@"HKLM\SOFTWARE\Policies\Microsoft\Windows\System", "PublishUserActivities", "d:0"));
            t.Regs.Add(new RV(@"HKLM\SOFTWARE\Policies\Microsoft\Windows\System", "UploadUserActivities", "d:0"));
            t = T("edge_bg", "PRIVACIDADE", "Edge sem correr em segundo plano", "O Microsoft Edge deixa de arrancar com o Windows e de ficar aberto escondido depois de o fechares.", "safe", true, false);
            t.Regs.Add(new RV(@"HKLM\SOFTWARE\Policies\Microsoft\Edge", "StartupBoostEnabled", "d:0"));
            t.Regs.Add(new RV(@"HKLM\SOFTWARE\Policies\Microsoft\Edge", "BackgroundModeEnabled", "d:0"));

            // ---------- mais otimizações
            const string PROC = "54533251-82be-4824-96c1-47b60b740d00";
            P("core_park", "ENERGIA", "Sem estacionamento de núcleos", "O Windows deixa de \"adormecer\" núcleos do processador: menos quebras de FPS quando o jogo pede mais de repente. No plano de energia ativo, ligado à corrente.", "mod", false, PROC, "0cc5b647-c1df-4637-891a-dec35c318583", 100);
            P("proc_min", "ENERGIA", "Processador sempre a 100%", "O estado mínimo do processador passa a 100%: responde logo, sem tempo a acelerar. Gasta mais energia e aquece mais em repouso. Só ligado à corrente.", "mod", false, PROC, "893dee8e-2bef-41e0-89c6-b55d0929964c", 100);
            P("boost_aggr", "ENERGIA", "Turbo do processador agressivo", "O processador sobe para a frequência máxima de turbo mais depressa e fica lá mais tempo. Só ligado à corrente.", "mod", false, PROC, "be337238-0d82-4146-a960-4f3749d470c7", 2);
            P("usb_suspend", "ENERGIA", "USB sem poupança de energia", "O Windows deixa de pôr portas USB a dormir: evita o rato, o teclado ou o headset falharem ou terem atraso por um instante.", "safe", true, "2a737441-1930-4402-8d77-b2bebba308a3", "48e6b7a6-50f5-4782-a5d4-53bb8f07e226", 0);
            P("pcie_aspm", "ENERGIA", "PCI Express sem poupança de energia", "A placa gráfica e o SSD NVMe deixam de entrar em modo de poupança entre pedidos: menos micro-atrasos.", "safe", true, "501a4d13-42af-4429-9fd1-a8218c268e20", "ee12f906-d277-404b-b6da-e5fa1a576df5", 0);
            P("disk_idle", "ENERGIA", "Discos nunca se desligam", "Os discos deixam de parar quando não estão a ser usados: acaba a espera de um disco rígido a voltar a rodar a meio do jogo.", "safe", true, "0012ee47-9041-4b5d-9b77-535fba8b1442", "6738e2c4-e8a5-4a42-b16a-e040e769756e", 0);
            t = T("fast_startup", "ENERGIA", "Desligar o Arranque Rápido", "O PC desliga-se a sério: os drivers começam do zero a cada arranque e evitam-se problemas que só um reinício resolvia. Arranca uns segundos mais devagar.", "mod", false, false);
            t.Regs.Add(new RV(@"HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Power", "HiberbootEnabled", "d:0"));

            t = T("gamebar_off", "JOGOS", "Desligar a Xbox Game Bar", "A Game Bar (Win+G) deixa de abrir e de carregar em segundo plano. Os jogos da Xbox/Game Pass continuam a funcionar.", "mod", false, false);
            t.Regs.Add(new RV(@"HKCU\Software\Microsoft\GameBar", "UseNexusForGameBarEnabled", "d:0"));
            t.Regs.Add(new RV(@"HKCU\Software\Microsoft\GameBar", "ShowStartupPanel", "d:0"));
            t.Regs.Add(new RV(@"HKCU\Software\Microsoft\GameBar", "GamePanelStartupTipIndex", "d:3"));
            t = T("sticky_keys", "JOGOS", "Sem teclas aderentes a meio do jogo", "Carregar 5 vezes no Shift (ou segurar outras teclas) deixa de abrir avisos que tiram o jogo de ecrã inteiro.", "safe", true, false);
            t.Regs.Add(new RV(@"HKCU\Control Panel\Accessibility\StickyKeys", "Flags", "s:506"));
            t.Regs.Add(new RV(@"HKCU\Control Panel\Accessibility\ToggleKeys", "Flags", "s:58"));
            t.Regs.Add(new RV(@"HKCU\Control Panel\Accessibility\Keyboard Response", "Flags", "s:122"));
            t = T("kbd_fast", "JOGOS", "Teclado com resposta máxima", "A repetição de teclas começa mais cedo e é mais rápida (o mesmo que pôr os controlos do Painel de Controlo no máximo).", "safe", false, false);
            t.Regs.Add(new RV(@"HKCU\Control Panel\Keyboard", "KeyboardDelay", "s:0"));
            t.Regs.Add(new RV(@"HKCU\Control Panel\Keyboard", "KeyboardSpeed", "s:31"));
            t = T("timer_res", "JOGOS", "Temporizador preciso para jogos", "No Windows 11, quando um jogo pede um relógio do sistema mais preciso, o pedido volta a valer para todo o PC. Ajuda o ritmo de frames em alguns jogos.", "mod", false, true);
            t.Regs.Add(new RV(@"HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel", "GlobalTimerResolutionRequests", "d:1"));
            t = T("dyn_tick", "JOGOS", "Desligar o tick dinâmico", "O relógio interno do Windows deixa de abrandar em repouso: latência mais constante. Gasta um pouco mais de energia. Muda a configuração de arranque (BCD).", "adv", false, true);
            t.State = DynTickState; t.Apply = DynTickApply; t.Key = "bcd|dyntick";

            t = T("menu_delay", "SISTEMA", "Menus sem atraso", "Os menus e submenus do Windows abrem logo, sem a pausa de 0,4 s.", "safe", true, false);
            t.Regs.Add(new RV(@"HKCU\Control Panel\Desktop", "MenuShowDelay", "s:0"));
            t = T("last_access", "SISTEMA", "Não registar a hora de cada leitura", "O Windows deixa de escrever no disco a data de último acesso de cada ficheiro que lê: menos escritas quando os jogos carregam milhares de ficheiros.", "safe", true, false);
            t.Regs.Add(new RV(@"HKLM\SYSTEM\CurrentControlSet\Control\FileSystem", "NtfsDisableLastAccessUpdate", "d:2147483649"));
            t = T("short_names", "SISTEMA", "Sem nomes curtos 8.3", "Deixa de criar um segundo nome antigo (tipo PROGRA~1) para cada ficheiro novo: escrever pastas grandes fica mais rápido.", "mod", false, false);
            t.Regs.Add(new RV(@"HKLM\SYSTEM\CurrentControlSet\Control\FileSystem", "NtfsDisable8dot3NameCreation", "d:1"));
            t = T("maint_off", "SISTEMA", "Sem manutenção automática", "O Windows deixa de correr tarefas de manutenção (otimizar discos, verificações) sozinho quando o PC está parado, o que às vezes acontecia a meio de um jogo pausado.", "mod", false, false);
            t.Regs.Add(new RV(@"HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance", "MaintenanceDisabled", "d:1"));
            if (GetSpecs().RamGb >= 15)
            {
                t = T("paging_exec", "SISTEMA", "Núcleo do Windows sempre na RAM", "Com 16 GB ou mais, o núcleo e os drivers deixam de poder ir para o ficheiro de paginação: menos esperas pelo disco.", "mod", false, true);
                t.Regs.Add(new RV(@"HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management", "DisablePagingExecutive", "d:1"));
            }
            t = T("wer_off", "SISTEMA", "Desligar o relatório de erros", "Quando um programa falha, o Windows deixa de juntar e enviar relatórios à Microsoft (que podem pesar no disco).", "safe", true, false);
            t.Regs.Add(new RV(@"HKLM\SOFTWARE\Microsoft\Windows\Windows Error Reporting", "Disabled", "d:1"));
            t.Svcs.Add("WerSvc");
            t = T("svc_extra", "SISTEMA", "Desligar serviços que quase ninguém usa", "Fax, Mapas offline, Modo de demonstração das lojas e Telefonia de dados móveis.", "safe", true, false);
            foreach (string sv in new[] { "Fax", "MapsBroker", "RetailDemo", "lfsvc", "dmwappushservice" }) t.Svcs.Add(sv);
            t = T("svc_more", "SISTEMA", "Desligar mais serviços dispensáveis", "Registo remoto (deixa outro PC mexer no registo deste), Windows Insider, Controlo parental, Pagamentos NFC e Rastreio de atalhos na rede.", "safe", true, false);
            foreach (string sv in new[] { "RemoteRegistry", "wisvc", "WpcMonSvc", "SEMgrSvc", "TrkWks" }) t.Svcs.Add(sv);
            t = T("spooler", "SISTEMA", "Desligar o serviço de impressão", "Só se não tens impressora: o Spooler fica sempre a correr e já teve várias falhas de segurança. Para imprimir, volta a ligar.", "mod", false, false);
            t.Svcs.Add("Spooler");

            t = T("delivery_p2p", "REDE", "Atualizações do Windows sem partilha P2P", "O Windows deixa de usar a tua internet para enviar atualizações a outros PCs: mais largura de banda para os jogos.", "safe", true, false);
            t.Regs.Add(new RV(@"HKLM\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization", "DODownloadMode", "d:0"));

            t = T("feedback", "PRIVACIDADE", "Sem pedidos de opinião", "O Windows deixa de aparecer a perguntar o que achas.", "safe", true, false);
            t.Regs.Add(new RV(@"HKCU\Software\Microsoft\Siuf\Rules", "NumberOfSIUFInPeriod", "d:0"));
            t.Regs.Add(new RV(@"HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection", "DoNotShowFeedbackNotifications", "d:1"));
            t = T("typing", "PRIVACIDADE", "Não enviar o que escreves", "Deixa de recolher dados de escrita e caneta para \"melhorar\" o teclado e o reconhecimento.", "safe", true, false);
            t.Regs.Add(new RV(@"HKCU\Software\Microsoft\InputPersonalization", "RestrictImplicitTextCollection", "d:1"));
            t.Regs.Add(new RV(@"HKCU\Software\Microsoft\InputPersonalization", "RestrictImplicitInkCollection", "d:1"));
            t.Regs.Add(new RV(@"HKCU\Software\Microsoft\Input\TIPC", "Enabled", "d:0"));
            t = T("cloud_search", "PRIVACIDADE", "Pesquisa sem conteúdo da nuvem", "A pesquisa do Windows deixa de procurar no teu OneDrive, Outlook e conta Microsoft.", "safe", true, false);
            t.Regs.Add(new RV(@"HKCU\Software\Microsoft\Windows\CurrentVersion\SearchSettings", "IsMSACloudSearchEnabled", "d:0"));
            t.Regs.Add(new RV(@"HKCU\Software\Microsoft\Windows\CurrentVersion\SearchSettings", "IsAADCloudSearchEnabled", "d:0"));
            t = T("app_track", "PRIVACIDADE", "Não seguir as apps que abres", "O Windows deixa de registar quais programas abres para te sugerir no Iniciar.", "safe", false, false);
            t.Regs.Add(new RV(ADV, "Start_TrackProgs", "d:0"));
            t = T("speech", "PRIVACIDADE", "Reconhecimento de voz só no PC", "A voz deixa de ser enviada para os servidores da Microsoft.", "safe", true, false);
            t.Regs.Add(new RV(@"HKCU\Software\Microsoft\Speech_OneCore\Settings\OnlineSpeechPrivacy", "HasAccepted", "d:0"));

            // tira o que não existe neste PC (serviços inexistentes, definições de energia que o PC não tem)
            list.RemoveAll(x => x.State == null && x.Regs.Count == 0 && x.Svcs.Count > 0 && !x.Svcs.Any(v => SvcExists(v)));
            list.RemoveAll(x => x.Id == "pcfg_missing");
            Adapt(list);
            Gains(list);
            return list;
        }

        // ---------------- definições escondidas do plano de energia (ligado à corrente, no plano ativo)
        static int? PcfgGet(string sub, string set)
        {
            System.Text.RegularExpressions.MatchCollection m = System.Text.RegularExpressions.Regex.Matches(RunOut("powercfg", "/q scheme_current " + sub + " " + set, 8000), @"0x([0-9a-fA-F]{8})");
            if (m.Count < 2) return null;
            return Convert.ToInt32(m[m.Count - 2].Groups[1].Value, 16);
        }
        static string PcfgSet(string sub, string set, int val, bool on)
        {
            LoadBackup();
            string key = "pcfg|" + sub + "|" + set;
            if (on)
            {
                int? cur = PcfgGet(sub, set);
                if (!cur.HasValue) return "O Windows não tem esta definição neste PC.";
                if (!backup.ContainsKey(key)) { backup[key] = cur.Value.ToString(); SaveBackup(); }
                RunOut("powercfg", "/setacvalueindex scheme_current " + sub + " " + set + " " + val, 8000);
            }
            else
            {
                string orig;
                if (!backup.TryGetValue(key, out orig)) return null;
                RunOut("powercfg", "/setacvalueindex scheme_current " + sub + " " + set + " " + orig, 8000);
                backup.Remove(key); SaveBackup();
            }
            RunOut("powercfg", "/setactive scheme_current", 8000);
            return null;
        }
        static Tw P(string id, string cat, string name, string desc, string risk, bool rec, string sub, string set, int val)
        {
            Tw t = T(id, cat, name, desc, risk, rec, false);
            int? cur = PcfgGet(sub, set);
            if (!cur.HasValue) { t.Id = "pcfg_missing"; return t; }
            t.State = delegate { int? v = PcfgGet(sub, set); return v.HasValue && v.Value == val ? "on" : "off"; };
            t.Apply = delegate (bool on) { return PcfgSet(sub, set, val, on); };
            t.Key = "pcfg|" + sub + "|" + set;
            return t;
        }

        // ---------------- tick dinâmico (bcdedit)
        static string DynTickLine()
        {
            foreach (string l in RunOut("bcdedit", "/enum {current}", 10000).Split('\n'))
                if (l.TrimStart().StartsWith("disabledynamictick", StringComparison.OrdinalIgnoreCase)) return l.Trim();
            return null;
        }
        static string DynTickState()
        {
            string l = DynTickLine();
            if (l == null) return "off";
            string v = l.Substring("disabledynamictick".Length).Trim().ToLowerInvariant();
            return v == "no" || v.StartsWith("n") ? "off" : "on";     // No / Não / Nein / Non
        }
        static string DynTickApply(bool on)
        {
            LoadBackup();
            if (on)
            {
                if (!backup.ContainsKey("bcd|dyntick")) { backup["bcd|dyntick"] = DynTickLine() == null ? "-" : "no"; SaveBackup(); }
                string o = RunOut("bcdedit", "/set disabledynamictick yes", 10000);
                return DynTickState() == "on" ? null : o.Trim();
            }
            string orig;
            if (!backup.TryGetValue("bcd|dyntick", out orig)) orig = "-";
            RunOut("bcdedit", orig == "-" ? "/deletevalue disabledynamictick" : "/set disabledynamictick no", 10000);
            backup.Remove("bcd|dyntick"); SaveBackup();
            return null;
        }

        // ---------------- o hardware deste PC (para a estimativa de ganho)
        public class Specs { public string Cpu = "", Gpu = "", Disk = "", CpuVendor = "", GpuVendor = ""; public int Cores, Threads; public double RamGb; public bool Laptop, Hdd, IGpu, X3dDual, Hybrid; }
        static Specs specs;
        public static Specs GetSpecs()
        {
            if (specs != null) return specs;
            Specs s = new Specs();
            s.Threads = Environment.ProcessorCount; s.Cores = s.Threads;
            try { s.Cpu = (Convert.ToString(Registry.GetValue(@"HKEY_LOCAL_MACHINE\HARDWARE\DESCRIPTION\System\CentralProcessor\0", "ProcessorNameString", "")) ?? "").Trim(); } catch { }
            try
            {
                using (ManagementObjectSearcher q = new ManagementObjectSearcher("SELECT NumberOfCores FROM Win32_Processor"))
                {
                    int c = 0; foreach (ManagementObject o in q.Get()) c += Convert.ToInt32(o["NumberOfCores"]);
                    if (c > 0) s.Cores = c;
                }
            }
            catch { }
            try { s.RamGb = Math.Round(new Microsoft.VisualBasic.Devices.ComputerInfo().TotalPhysicalMemory / 1073741824.0, 1); } catch { }
            try
            {
                using (ManagementObjectSearcher q = new ManagementObjectSearcher("SELECT Name FROM Win32_VideoController"))
                {
                    string best = "";
                    foreach (ManagementObject o in q.Get())
                    {
                        string n = Convert.ToString(o["Name"]) ?? "";
                        string l = n.ToLowerInvariant();
                        if (l.Contains("basic") || l.Contains("remote") || l.Contains("virtual") || l.Contains("parsec") || l.Contains("mirror")) continue;
                        bool dedicated = l.Contains("nvidia") || l.Contains("rtx") || l.Contains("gtx") || l.Contains("radeon rx") || l.Contains(" rx ") || l.Contains("arc");
                        if (best == "" || dedicated) best = n;
                        if (dedicated) break;
                    }
                    s.Gpu = best.Trim();
                }
            }
            catch { }
            string gl = s.Gpu.ToLowerInvariant(), cl = s.Cpu.ToLowerInvariant();
            s.CpuVendor = cl.Contains("amd") || cl.Contains("ryzen") ? "AMD" : cl.Contains("intel") ? "Intel" : "";
            s.GpuVendor = gl.Contains("nvidia") || gl.Contains("geforce") ? "NVIDIA" : gl.Contains("amd") || gl.Contains("radeon") ? "AMD" : gl.Contains("intel") ? "Intel" : "";
            // Ryzen X3D com dois CCDs: o driver da AMD usa o estacionamento de núcleos e a Game Bar para pôr o jogo nos núcleos com cache 3D
            s.X3dDual = cl.Contains("x3d") && System.Text.RegularExpressions.Regex.IsMatch(cl, @"\b(79[05]0|99[05]0)x3d");
            // Intel com núcleos P e E (12.ª geração ou mais recente, Core Ultra)
            // (os núcleos E não têm hyper-threading: há menos threads do que o dobro dos núcleos; ex.: o i5-12400F tem 6/12 e não é híbrido)
            s.Hybrid = s.CpuVendor == "Intel" && (cl.Contains("core ultra") || System.Text.RegularExpressions.Regex.IsMatch(cl, @"i[3579]-1[2-4]\d{3}")) && s.Threads < s.Cores * 2;
            s.IGpu = gl == "" || ((gl.Contains("intel") && !gl.Contains("arc")) || gl == "amd radeon(tm) graphics" || gl.Contains("vega") || gl.Contains("radeon graphics"));
            try
            {
                ManagementScope sc = new ManagementScope(@"\\.\root\Microsoft\Windows\Storage");
                string disk = null;
                using (ManagementObjectSearcher q = new ManagementObjectSearcher(sc, new ObjectQuery("SELECT DiskNumber, DriveLetter FROM MSFT_Partition")))
                    foreach (ManagementObject o in q.Get())
                        if (Convert.ToString(o["DriveLetter"]) == Path.GetPathRoot(Environment.SystemDirectory).Substring(0, 1)) disk = Convert.ToString(o["DiskNumber"]);
                using (ManagementObjectSearcher q = new ManagementObjectSearcher(sc, new ObjectQuery("SELECT DeviceId, MediaType, BusType FROM MSFT_PhysicalDisk")))
                    foreach (ManagementObject o in q.Get())
                        if (Convert.ToString(o["DeviceId"]) == disk)
                        {
                            int mt = Convert.ToInt32(o["MediaType"]), bt = Convert.ToInt32(o["BusType"]);
                            s.Hdd = mt == 3; s.Disk = mt == 3 ? "HDD" : bt == 17 ? "SSD NVMe" : mt == 4 ? "SSD" : "";
                        }
            }
            catch { }
            try { s.Laptop = (SystemInformation.PowerStatus.BatteryChargeStatus & BatteryChargeStatus.NoSystemBattery) == 0 && SystemInformation.PowerStatus.BatteryChargeStatus != BatteryChargeStatus.Unknown; } catch { }
            specs = s;
            return s;
        }

        // ajusta a lista ao hardware: portátil/desktop, Intel/AMD, NVIDIA/AMD/Intel. Notas mostradas na página.
        static List<string> notes = new List<string>();
        static void Adapt(List<Tw> l)
        {
            Specs s = GetSpecs();
            List<string> n = new List<string>();
            Func<string, Tw> F = k => l.FirstOrDefault(x => x.Id == k);
            Tw t;
            if (s.X3dDual)
            {
                l.RemoveAll(x => x.Id == "core_park" || x.Id == "gamebar_off" || x.Id == "proc_min");
                if ((t = F("power_plan")) != null) { t.Rec = false; t.Extra.Add("Num Ryzen X3D com dois CCDs a AMD recomenda o plano Equilibrado: o Desempenho Máximo pode tirar o jogo dos núcleos com cache 3D."); }
                n.Add("Ryzen X3D com dois CCDs: escondidas as otimizações que estragam a escolha dos núcleos com cache 3D (estacionamento de núcleos, Game Bar, processador a 100%).");
            }
            else if (s.CpuVendor == "AMD")
            {
                if ((t = F("core_park")) != null) t.Extra.Add("Nos Ryzen ajuda sobretudo os mínimos de FPS.");
            }
            if (s.Hybrid)
            {
                if ((t = F("core_park")) != null) { t.Risk = "mod"; t.Extra.Add("Num Intel com núcleos P e E, os núcleos E também ficam acordados: mais consumo e calor."); }
                if ((t = F("game_mode")) != null) t.Extra.Add("Num Intel com núcleos P e E ajuda o Thread Director a pôr o jogo nos núcleos P.");
                n.Add("Intel com núcleos P e E: o Modo de Jogo fica recomendado para o jogo ir para os núcleos de desempenho.");
            }
            if (s.Laptop)
            {
                if ((t = F("hibernate")) != null) { t.Risk = "adv"; t.Extra.Add("Num portátil não é aconselhado: se a bateria acabar com o PC suspenso, perdes o que estava aberto."); }
                if ((t = F("power_plan")) != null) t.Extra.Add("Num portátil só vale ligado à corrente; na bateria gasta-a mais depressa.");
                foreach (string id in new[] { "proc_min", "core_park", "boost_aggr" })
                    if ((t = F(id)) != null) { t.Rec = false; t.Extra.Add("Num portátil aquece mais e as ventoinhas trabalham mais."); }
                if ((t = F("dyn_tick")) != null) t.Extra.Add("Num portátil gasta mais bateria.");
                n.Add("Portátil: as definições de energia só mudam o que acontece ligado à corrente; as que aquecem mais deixaram de ser recomendadas.");
            }
            else
            {
                foreach (string id in new[] { "usb_suspend", "pcie_aspm" }) if ((t = F(id)) != null) t.Rec = true;
            }
            t = F("hags");
            if (t != null)
            {
                if (s.GpuVendor == "NVIDIA") { t.Rec = true; t.Extra.Add("Numa NVIDIA RTX é preciso para o DLSS Frame Generation."); }
                else if (s.GpuVendor == "AMD") { t.Rec = false; t.Extra.Add("Nas Radeon os resultados variam de jogo para jogo: experimenta."); }
                else if (s.IGpu) { l.Remove(t); n.Add("Gráfica integrada: escondido o agendamento de GPU por hardware (não ajuda nestas gráficas)."); }
                else if (s.GpuVendor == "Intel") t.Extra.Add("Nas Intel Arc ajuda a latência.");
            }
            if (s.GpuVendor == "NVIDIA" || s.GpuVendor == "AMD")
            {
                t = T("mpo_off", "JOGOS", "Desligar o Multiplane Overlay (MPO)", "Resolve ecrãs a piscar, cortes na imagem e pequenas paragens com mais de um monitor ou ao fazer alt-tab, que acontecem com algumas versões dos drivers da placa gráfica. Só liga se tens esse problema.", "mod", false, true);
                t.Regs.Add(new RV(@"HKLM\SOFTWARE\Microsoft\Windows\Dwm", "OverlayTestMode", "d:5"));
            }
            if (s.IGpu)
            {
                if ((t = F("visual_fx")) != null) t.Rec = true;
                if ((t = F("game_dvr")) != null) t.Extra.Add("Com gráfica integrada é das que mais se notam.");
                n.Add("Gráfica integrada: menos animações e sem gravação de fundo passam a recomendadas, porque a gráfica partilha a memória do PC.");
            }
            if (s.Hdd)
            {
                if ((t = F("search_idx")) != null) t.Rec = true;
                if ((t = F("disk_idle")) != null) t.Extra.Add("Neste PC o Windows está num disco rígido: é das mais úteis.");
                n.Add("Windows num disco rígido: desligar a indexação passou a recomendada.");
            }
            notes = n;
        }
        // ganho estimado de cada otimização neste PC (% de FPS médio, intervalo) e o tipo de efeito principal.
        // Valores conservadores, de medições públicas; dependem muito do jogo.
        static void Gains(List<Tw> l)
        {
            Specs s = GetSpecs();
            bool weak = s.Cores <= 4 || s.RamGb < 12 || s.IGpu, lowRam = s.RamGb < 12;
            foreach (Tw t in l)
            {
                double lo = 0, hi = 0; string e = "fps";
                switch (t.Id)
                {
                    case "power_plan": if (s.Laptop) { lo = 2; hi = 8; } else { lo = 0; hi = 3; } break;
                    case "power_throttle": hi = 2; e = "stab"; break;
                    case "hibernate": e = "disk"; break;
                    case "fast_startup": e = "boot"; break;
                    case "core_park": hi = 4; e = "stab"; break;
                    case "proc_min": hi = 3; e = "stab"; break;
                    case "boost_aggr": hi = 3; break;
                    case "usb_suspend": e = "lat"; break;
                    case "pcie_aspm": hi = 1; e = "lat"; break;
                    case "disk_idle": e = s.Hdd ? "stab" : "disk"; break;
                    case "game_mode": hi = 2; e = "stab"; break;
                    case "hags": hi = s.IGpu ? 1 : 3; e = "lat"; break;
                    case "game_dvr": if (s.IGpu) { lo = 2; hi = 6; } else hi = 3; break;
                    case "gamebar_off": hi = 1; e = "ram"; break;
                    case "windowed_opt": hi = 2; e = "lat"; break;
                    case "mmcss": hi = 2; e = "stab"; break;
                    case "sys_resp": hi = 2; e = "stab"; break;
                    case "mouse_accel": case "sticky_keys": case "kbd_fast": e = "aim"; break;
                    case "prio_sep": if (s.Cores <= 4) { lo = 1; hi = 4; } else hi = 2; break;
                    case "fso_off": hi = 3; e = "lat"; break;
                    case "timer_res": hi = 1; e = "stab"; break;
                    case "dyn_tick": hi = 1; e = "lat"; break;
                    case "bg_apps": if (lowRam) { lo = 1; hi = 4; } else hi = 1; e = "ram"; break;
                    case "startup_delay": e = "boot"; break;
                    case "visual_fx": if (weak) { lo = 1; hi = 3; } else hi = 1; break;
                    case "menu_delay": e = "ui"; break;
                    case "sysmain": hi = lowRam ? 2 : 1; e = "ram"; break;
                    case "search_idx": if (s.Hdd) { lo = 1; hi = 4; } else hi = 1; e = "stab"; break;
                    case "last_access": case "short_names": hi = s.Hdd ? 1 : 0; e = "disk"; break;
                    case "maint_off": hi = 1; e = "stab"; break;
                    case "paging_exec": hi = 1; e = "stab"; break;
                    case "vbs_off": if (s.Cores <= 6) { lo = 4; hi = 12; } else { lo = 2; hi = 8; } break;
                    case "nagle": e = "lat"; break;
                    case "mpo_off": e = "stab"; break;
                    case "delivery_p2p": e = "net"; break;
                    case "telemetry": hi = 1; e = "stab"; break;
                    case "widgets": case "edge_bg": hi = lowRam ? 1 : 0; e = "ram"; break;
                    case "svc_extra": case "spooler": case "wer_off": e = "ram"; break;
                    default: e = "priv"; break;
                }
                t.Lo = lo; t.Hi = hi; t.Eff = e;
            }
        }
        // o que pode correr mal em cada otimização com risco (aparece ao pôr o rato por cima da etiqueta)
        static string RiskTip(Tw t)
        {
            switch (t.Id)
            {
                case "hibernate": return "O PC deixa de poder hibernar e o Arranque Rápido fica desligado: o arranque demora uns segundos mais. Num portátil, se a bateria acabar com o PC suspenso, perdes o que estava aberto.";
                case "prio_sep": return "Os programas em segundo plano (downloads, Discord, gravação com o OBS) ficam com menos CPU enquanto usas outra janela.";
                case "fso_off": return "Perdes o Auto HDR e o alt-tab rápido. Em alguns jogos modernos pode dar menos FPS ou ecrã preto ao trocar de janela.";
                case "bg_apps": return "Apps da Loja (Correio, Calendário, WhatsApp, Teams…) deixam de dar notificações e de sincronizar até as abrires.";
                case "visual_fx": return "O Windows fica com um aspeto mais simples, sem animações nem transparência. Nada deixa de funcionar.";
                case "sysmain": return "Programas e jogos podem demorar um pouco mais a abrir da primeira vez, sobretudo num disco rígido.";
                case "search_idx": return "A pesquisa de ficheiros no Iniciar e no Explorador fica mais lenta e deixa de encontrar texto dentro dos ficheiros e emails do Outlook.";
                case "vbs_off": return "Tira uma proteção do Windows contra drivers e malware ao nível do núcleo. Alguns anti-batota (Valorant, FACEIT) podem exigir que esteja ligada e não deixar jogar.";
                case "nagle": return "Saem mais pacotes pequenos na rede (um pouco mais de tráfego). Raramente, algumas apps de rede antigas ficam menos eficientes.";
                case "core_park": return "O processador gasta mais energia e aquece um pouco mais quando o PC está parado.";
                case "proc_min": return "Mais consumo e temperatura com o PC parado; as ventoinhas podem rodar mais.";
                case "boost_aggr": return "Mais calor e consumo. Com um cooler fraco, o processador pode chegar ao limite de temperatura e baixar a velocidade sozinho.";
                case "fast_startup": return "O PC demora uns segundos mais a arrancar.";
                case "gamebar_off": return "O Win+G deixa de abrir: perdes as capturas e gravações da Game Bar e os widgets dela.";
                case "timer_res": return "Gasta um pouco mais de energia enquanto um jogo pede o relógio preciso (num portátil, mais bateria).";
                case "dyn_tick": return "Mais consumo com o PC parado. Muda a configuração de arranque do Windows: se usas BitLocker, tem a chave de recuperação à mão.";
                case "short_names": return "Programas muito antigos que dependem dos nomes curtos (tipo PROGRA~1) podem falhar em pastas criadas a partir de agora.";
                case "maint_off": return "O Windows deixa de otimizar os discos e de fazer verificações sozinho; convém fazê-lo à mão de vez em quando.";
                case "paging_exec": return "Usa um pouco mais de RAM. Por isso só aparece em PCs com 16 GB ou mais.";
                case "spooler": return "Deixas de conseguir imprimir (incluindo \"Imprimir para PDF\") até voltares a ligar.";
                case "mpo_off": return "Em alguns PCs aumenta um pouco o uso da placa gráfica no ambiente de trabalho e nos vídeos. Não ajuda se não tens estes problemas.";
            }
            return t.Risk == "safe" ? "Sem riscos conhecidos. Podes repor quando quiseres." : "Pode ter efeitos secundários. Podes repor quando quiseres.";
        }
        static string StateOf(Tw t)
        {
            if (t.State != null) return t.State();
            int on = 0, n = 0;
            foreach (RV r in t.Regs) { n++; if (Read(r.Path, r.Name) == r.Val) on++; }
            foreach (string s in t.Svcs) { if (!SvcExists(s)) continue; n++; if (Read(SVC + s, "Start") == "d:4") on++; }
            return n == 0 ? "on" : on == n ? "on" : on == 0 ? "off" : "partial";
        }
        static bool Changed(Tw t)
        {
            LoadBackup();
            if (t.Key != null) return backup.ContainsKey(t.Key);
            return t.Regs.Any(r => backup.ContainsKey("reg|" + r.Path + "|" + r.Name)) || t.Svcs.Any(s => backup.ContainsKey("svc|" + s));
        }

        static string Set(Tw t, bool on)
        {
            LoadBackup();
            if (t.Apply != null) return t.Apply(on);
            foreach (RV r in t.Regs)
            {
                string key = "reg|" + r.Path + "|" + r.Name;
                if (on)
                {
                    if (!backup.ContainsKey(key)) backup[key] = Read(r.Path, r.Name);
                    Write(r.Path, r.Name, r.Val);
                }
                else
                {
                    string orig;
                    Write(r.Path, r.Name, backup.TryGetValue(key, out orig) ? orig : "-");
                    backup.Remove(key);
                }
            }
            foreach (string s in t.Svcs)
            {
                if (!SvcExists(s)) continue;
                string key = "svc|" + s;
                if (on)
                {
                    if (!backup.ContainsKey(key)) backup[key] = Read(SVC + s, "Start");
                    Write(SVC + s, "Start", "d:4");
                    RunOut("sc.exe", "stop \"" + s + "\"", 15000);
                }
                else
                {
                    string orig;
                    string v = backup.TryGetValue(key, out orig) ? orig : "d:3";
                    Write(SVC + s, "Start", v);
                    if (v == "d:2") RunOut("sc.exe", "start \"" + s + "\"", 15000);
                    backup.Remove(key);
                }
            }
            SaveBackup();
            return null;
        }

        static string Q(string v) { return v == null ? "null" : "\"" + v.Replace("\\", "\\\\").Replace("\"", "\\\"") + "\""; }

        public static string Json()
        {
            lock (lk)
            {
                List<Tw> l = Build();
                StringBuilder sb = new StringBuilder("{\"ok\":true,\"admin\":" + (Program.IsAdmin() ? "true" : "false") + ",\"reboot\":" + (rebootPending ? "true" : "false") +
                    ",\"power\":" + Q(ActiveSchemeName()) + ",\"tweaks\":[");
                bool first = true;
                foreach (Tw t in l)
                {
                    if (!first) sb.Append(','); first = false;
                    sb.Append("{\"id\":").Append(Q(t.Id)).Append(",\"cat\":").Append(Q(t.Cat)).Append(",\"name\":").Append(Q(t.Name)).Append(",\"desc\":").Append(Q(t.Desc))
                      .Append(",\"risk\":").Append(Q(t.Risk)).Append(",\"rec\":").Append(t.Rec ? "true" : "false").Append(",\"reboot\":").Append(t.Reboot ? "true" : "false")
                      .Append(",\"state\":").Append(Q(StateOf(t))).Append(",\"changed\":").Append(Changed(t) ? "true" : "false")
                      .Append(",\"lo\":").Append(t.Lo.ToString(CultureInfo.InvariantCulture)).Append(",\"hi\":").Append(t.Hi.ToString(CultureInfo.InvariantCulture)).Append(",\"eff\":").Append(Q(t.Eff)).Append(",\"rtip\":").Append(Q(RiskTip(t)))
                      .Append(",\"extra\":[").Append(string.Join(",", t.Extra.Select(x => Q(x)).ToArray())).Append("]}");
                }
                Specs p = GetSpecs();
                sb.Append("],\"specs\":{\"cpu\":").Append(Q(p.Cpu)).Append(",\"gpu\":").Append(Q(p.Gpu)).Append(",\"disk\":").Append(Q(p.Disk))
                  .Append(",\"cores\":").Append(p.Cores).Append(",\"threads\":").Append(p.Threads).Append(",\"ram\":").Append(p.RamGb.ToString(CultureInfo.InvariantCulture))
                  .Append(",\"laptop\":").Append(p.Laptop ? "true" : "false").Append(",\"igpu\":").Append(p.IGpu ? "true" : "false")
                  .Append(",\"cpuv\":").Append(Q(p.CpuVendor)).Append(",\"gpuv\":").Append(Q(p.GpuVendor)).Append("},\"notes\":[").Append(string.Join(",", notes.Select(x => Q(x)).ToArray())).Append("]}");
                return sb.ToString();
            }
        }

        public static string SetJson(string id, bool on)
        {
            lock (lk)
            {
                Tw t = Build().FirstOrDefault(x => x.Id == id);
                if (t == null) return "{\"ok\":false,\"error\":\"not_found\"}";
                string err = null;
                try { err = Set(t, on); } catch (Exception ex) { err = ex.Message; }
                if (err == null && t.Reboot) rebootPending = true;
                return "{\"ok\":" + (err == null ? "true" : "false") + ",\"error\":" + Q(err) + ",\"reboot\":" + (t.Reboot && err == null ? "true" : "false") + "}";
            }
        }

        // aplica as recomendadas que ainda não estão (ou repõe tudo o que o NEXUS mudou)
        public static string Bulk(bool recommended, string ids)
        {
            lock (lk)
            {
                int ok = 0; List<string> fail = new List<string>(); bool reboot = false;
                HashSet<string> only = string.IsNullOrEmpty(ids) ? null : new HashSet<string>(ids.Split(','));
                foreach (Tw t in Build())
                {
                    if (only != null && !only.Contains(t.Id)) continue;
                    try
                    {
                        if (recommended)
                        {
                            if ((only == null && !t.Rec) || StateOf(t) == "on") continue;
                            string e = Set(t, true);
                            if (e != null) fail.Add(t.Name + " (" + e + ")"); else { ok++; reboot |= t.Reboot; }
                        }
                        else
                        {
                            if (!Changed(t)) continue;
                            string e = Set(t, false);
                            if (e != null) fail.Add(t.Name + " (" + e + ")"); else { ok++; reboot |= t.Reboot; }
                        }
                    }
                    catch (Exception ex) { fail.Add(t.Name + " (" + ex.Message + ")"); }
                }
                if (reboot) rebootPending = true;
                return "{\"ok\":true,\"done\":" + ok + ",\"reboot\":" + (reboot ? "true" : "false") + ",\"failed\":[" + string.Join(",", fail.Select(x => Q(x)).ToArray()) + "]}";
            }
        }

        // ponto de restauro automático antes de mudanças grandes (no máximo um por dia, como o Windows deixa)
        public static void AutoRestorePoint()
        {
            if (!AppSettings.AutoRp) return;
            DateTime last;
            if (DateTime.TryParse(AppSettings.RpLast, CultureInfo.InvariantCulture, DateTimeStyles.None, out last) && (DateTime.Now - last).TotalHours < 24) return;
            string r = RestorePoint();
            if (r.Contains("\"ok\":true")) { AppSettings.RpLast = DateTime.Now.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture); try { AppSettings.Save(); } catch { } }
        }
        public static string RestorePoint()
        {
            string o = RunOut("powershell.exe", "-NoProfile -ExecutionPolicy Bypass -Command \"try { Checkpoint-Computer -Description 'NEXUS - antes de otimizar' -RestorePointType MODIFY_SETTINGS -ErrorAction Stop; 'NXOK' } catch { 'NXERR ' + $_.Exception.Message }\"", 180000);
            if (o.Contains("NXOK"))
            {
                if (o.IndexOf("1440", StringComparison.Ordinal) >= 0 || o.IndexOf("WARNING", StringComparison.OrdinalIgnoreCase) >= 0 || o.IndexOf("AVISO", StringComparison.OrdinalIgnoreCase) >= 0)
                    return "{\"ok\":true,\"msg\":\"recent\"}";
                return "{\"ok\":true,\"msg\":\"created\"}";
            }
            string low = o.ToLowerInvariant();
            if (low.Contains("disabled") || low.Contains("desativad") || low.Contains("desligad") || low.Contains("service cannot be started")) return "{\"ok\":false,\"msg\":\"off\"}";
            return "{\"ok\":false,\"msg\":" + Q(o.Replace("NXERR", "").Trim()) + "}";
        }

        // ---------------- otimizações dos perfis por jogo: ligadas só enquanto o jogo está aberto
        // (só as que não precisam de reiniciar; as que já estavam ligadas não se tocam)
        public static void SetScheme(string guid) { if (!string.IsNullOrEmpty(guid) && System.Text.RegularExpressions.Regex.IsMatch(guid, "^[0-9a-fA-F-]{36}$")) RunOut("powercfg", "/setactive " + guid, 8000); }
        public static List<string> ChangedIds()
        {
            lock (lk) return Build().Where(t => Changed(t)).Select(t => t.Id).ToList();
        }
        // quantas otimizações o NEXUS tem ligadas agora (para as medições de FPS dizerem "com N otimizações")
        public static int ChangedCount()
        {
            lock (lk) return Build().Count(t => Changed(t));
        }
        public static HashSet<string> TempIds()
        {
            lock (lk) return new HashSet<string>(Build().Where(t => !t.Reboot).Select(t => t.Id));
        }
        public static List<string> ApplyTemp(IEnumerable<string> ids)
        {
            HashSet<string> want = new HashSet<string>(ids);
            List<string> done = new List<string>();
            lock (lk)
            {
                foreach (Tw t in Build())
                {
                    if (!want.Contains(t.Id) || t.Reboot || StateOf(t) == "on") continue;
                    string e;
                    try { e = Set(t, true); } catch (Exception ex) { e = ex.Message; }
                    if (e == null) done.Add(t.Id);
                }
            }
            return done;
        }
        public static void RevertTemp(IEnumerable<string> ids)
        {
            HashSet<string> want = new HashSet<string>(ids);
            lock (lk)
                foreach (Tw t in Build())
                    if (want.Contains(t.Id)) { try { Set(t, false); } catch { } }
        }

        // ---------------- turbo ao jogar (só enquanto o jogo está aberto; ao sair tudo volta)
        static readonly Dictionary<int, ProcessPriorityClass> prio = new Dictionary<int, ProcessPriorityClass>();
        static string turboPlanOrig;
        public static void OnGame(bool on, string game)
        {
            ThreadPool.QueueUserWorkItem(delegate
            {
                lock (prio)
                {
                    try
                    {
                        if (on)
                        {
                            try { Perfis.Start(game); } catch { }       // o perfil deste jogo (se houver) manda no boost e no overlay
                            try { NaoIncomodar.OnGame(true); } catch { }
                            bool ac = Optimizer.AntiCheatRunning();   // o anti-cheat vê qualquer programa que abra o jogo e pode dar erro
                            if (Perfis.Want("ram", AppSettings.TurboRam) && !ac) { try { Optimizer.Clean(false); } catch { } }
                            if (Perfis.Want("prio", AppSettings.TurboPrio) && !string.IsNullOrEmpty(game) && !ac)
                            {
                                string n = game.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) ? game.Substring(0, game.Length - 4) : game;
                                foreach (Process p in Process.GetProcessesByName(n))
                                    try { if (!prio.ContainsKey(p.Id)) { prio[p.Id] = p.PriorityClass; p.PriorityClass = ProcessPriorityClass.High; } } catch { } finally { p.Dispose(); }
                            }
                            if (Perfis.Want("power", AppSettings.TurboPower) && turboPlanOrig == null)
                            {
                                string act = ActiveScheme(), fast = FastScheme(true);
                                if (act != null && fast != null && act != fast) { turboPlanOrig = act; RunOut("powercfg", "/setactive " + fast, 8000); }
                            }
                        }
                        else
                        {
                            foreach (KeyValuePair<int, ProcessPriorityClass> kv in prio)
                                try { using (Process p = Process.GetProcessById(kv.Key)) p.PriorityClass = kv.Value; } catch { }
                            prio.Clear();
                            if (turboPlanOrig != null) { RunOut("powercfg", "/setactive " + turboPlanOrig, 8000); turboPlanOrig = null; }
                            try { Perfis.Stop(); } catch { }
                            try { NaoIncomodar.OnGame(false); } catch { }
                        }
                    }
                    catch { }
                }
            });
        }

        // ---------------- debloat: apps que vêm com o Windows
        class Bloat { public string Pkg, Name, Desc; public Bloat(string p, string n, string d) { Pkg = p; Name = n; Desc = d; } }
        static readonly Bloat[] Bloats = {
            new Bloat("Microsoft.BingNews", "Notícias (Microsoft News)", "Notícias da MSN."),
            new Bloat("Microsoft.BingWeather", "Meteorologia", "App da meteorologia da MSN."),
            new Bloat("Microsoft.BingSearch", "Pesquisa Bing", "Pesquisa da Bing fora do browser."),
            new Bloat("Microsoft.GetHelp", "Obter Ajuda", "Ajuda online da Microsoft."),
            new Bloat("Microsoft.Getstarted", "Sugestões (Dicas)", "Dicas e tutoriais do Windows."),
            new Bloat("Microsoft.MicrosoftSolitaireCollection", "Solitaire Collection", "Jogos de cartas com anúncios."),
            new Bloat("Microsoft.People", "Pessoas", "Contactos (já não é usada)."),
            new Bloat("Microsoft.PowerAutomateDesktop", "Power Automate", "Automatização de tarefas para empresas."),
            new Bloat("Microsoft.Todos", "Microsoft To Do", "Listas de tarefas."),
            new Bloat("Microsoft.WindowsFeedbackHub", "Hub de Comentários", "Enviar sugestões à Microsoft."),
            new Bloat("Microsoft.WindowsMaps", "Mapas", "Mapas da Microsoft."),
            new Bloat("Microsoft.ZuneVideo", "Filmes e TV", "Loja de filmes da Microsoft."),
            new Bloat("Microsoft.MicrosoftOfficeHub", "Microsoft 365 (Office)", "Atalho para comprar/abrir o Office online."),
            new Bloat("Microsoft.SkypeApp", "Skype", "Já foi descontinuado pela Microsoft."),
            new Bloat("MicrosoftTeams", "Microsoft Teams (pessoal)", "Chat do Teams que vem com o Windows."),
            new Bloat("MSTeams", "Microsoft Teams", "Chat do Teams que vem com o Windows."),
            new Bloat("Microsoft.OutlookForWindows", "Outlook (novo)", "Substituto do Correio do Windows."),
            new Bloat("Microsoft.Copilot", "Copilot", "Assistente de IA da Microsoft."),
            new Bloat("Microsoft.549981C3F5F10", "Cortana", "Assistente antigo, já descontinuado."),
            new Bloat("Microsoft.Microsoft3DViewer", "Visualizador 3D", "Ver modelos 3D."),
            new Bloat("Microsoft.MixedReality.Portal", "Portal de Realidade Mista", "Para óculos Windows Mixed Reality."),
            new Bloat("Microsoft.MSPaint", "Paint 3D", "Já descontinuado (o Paint normal fica)."),
            new Bloat("Microsoft.Wallet", "Microsoft Pay", "Carteira, já descontinuada."),
            new Bloat("Microsoft.YourPhone", "Ligação ao Telemóvel", "Ligar o telemóvel ao PC. Remove se não usas."),
            new Bloat("Clipchamp.Clipchamp", "Clipchamp", "Editor de vídeo online."),
            new Bloat("Microsoft.Windows.DevHome", "Dev Home", "Painel para programadores."),
            new Bloat("Microsoft.News", "Notícias", "Notícias da MSN."),
            new Bloat("Disney.37853FC22B2CE", "Disney+ (atalho)", "Atalho pré-instalado."),
            new Bloat("5A894077.McAfeeSecurity", "McAfee (teste)", "Antivírus de teste pré-instalado."),
            new Bloat("king.com.", "Jogos da King (Candy Crush…)", "Jogos com anúncios instalados sozinhos."),
            new Bloat("Facebook.", "Facebook / Instagram (atalhos)", "Atalhos pré-instalados."),
            new Bloat("7EE7776C.LinkedInforWindows", "LinkedIn", "Atalho pré-instalado."),
            new Bloat("AmazonVideo.PrimeVideo", "Prime Video (atalho)", "Atalho pré-instalado."),
            new Bloat("BytedancePte.Ltd.TikTok", "TikTok (atalho)", "Atalho pré-instalado."),
            new Bloat("4DF9E0F8.Netflix", "Netflix (atalho)", "Atalho pré-instalado."),
        };
        static List<string[]> appsCache; static DateTime appsAt;

        static List<string[]> InstalledApps()
        {
            if (appsCache != null && (DateTime.Now - appsAt).TotalSeconds < 60) return appsCache;
            string o = RunOut("powershell.exe", "-NoProfile -ExecutionPolicy Bypass -Command \"[Console]::OutputEncoding=[Text.Encoding]::UTF8; Get-AppxPackage | ForEach-Object { $_.Name + '|' + $_.PackageFullName }\"", 60000);
            List<string[]> l = new List<string[]>();
            foreach (string line in o.Split('\n'))
            {
                string[] c = line.Trim().Split('|');
                if (c.Length == 2 && c[0] != "") l.Add(c);
            }
            appsCache = l; appsAt = DateTime.Now;
            return l;
        }
        static Bloat Match(string name)
        {
            return Bloats.FirstOrDefault(b => b.Pkg.EndsWith(".") ? name.StartsWith(b.Pkg, StringComparison.OrdinalIgnoreCase) : name.Equals(b.Pkg, StringComparison.OrdinalIgnoreCase));
        }
        public static string AppsJson()
        {
            StringBuilder sb = new StringBuilder("{\"ok\":true,\"apps\":[");
            bool first = true;
            HashSet<string> seen = new HashSet<string>();
            foreach (string[] a in InstalledApps())
            {
                Bloat b = Match(a[0]);
                if (b == null || !seen.Add(a[1])) continue;
                if (!first) sb.Append(','); first = false;
                sb.Append("{\"pkg\":").Append(Q(a[0])).Append(",\"full\":").Append(Q(a[1])).Append(",\"name\":").Append(Q(b.Name)).Append(",\"desc\":").Append(Q(b.Desc)).Append('}');
            }
            return sb.Append("]}").ToString();
        }
        public static string RemoveApps(string fulls)
        {
            int ok = 0; List<string> fail = new List<string>();
            HashSet<string> allowed = new HashSet<string>(InstalledApps().Where(a => Match(a[0]) != null).Select(a => a[1]));
            foreach (string f in (fulls ?? "").Split(','))
            {
                string full = f.Trim();
                if (full == "" || !allowed.Contains(full)) continue;        // só apps da lista (nunca outras)
                string o = RunOut("powershell.exe", "-NoProfile -ExecutionPolicy Bypass -Command \"try { Remove-AppxPackage -Package '" + full.Replace("'", "''") + "' -ErrorAction Stop; 'NXOK' } catch { 'NXERR ' + $_.Exception.Message }\"", 120000);
                if (o.Contains("NXOK")) ok++; else fail.Add(full);
            }
            appsCache = null;
            return "{\"ok\":true,\"done\":" + ok + ",\"failed\":[" + string.Join(",", fail.Select(x => Q(x)).ToArray()) + "]}";
        }
    }
}
