﻿// NEXUS // MONITOR 2.3 - ferramentas: serviços, menu do botão direito, tarefas agendadas, segurança, otimizar discos,
// vida dos SSD, fonte de alimentação, limites de boost, prioridade de rede, fechar programas ao jogar, ligações à internet,
// Wi-Fi, inventário, periféricos com bateria, espaço escondido, programas esquecidos, apps padrão, versão do Windows,
// drivers gráficos antigos, Modo de Jogo / HAGS, overlays, poupar SSD, atualizações do Windows.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.ServiceProcess;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using Microsoft.Win32;

namespace Nexus
{
    static partial class Ferr
    {
        static string Clean(string s, int max) { s = Regex.Replace(s ?? "", @"[^\w .\-+()#&']", ""); return s.Length > max ? s.Substring(0, max) : s; }
        static string PsQ(string s) { return "'" + (s ?? "").Replace("'", "''") + "'"; }
        public static double RestW() { return 60; }
        // número da build verdadeiro (o Environment.OSVersion mente sem manifesto e diz 9200)
        public static int WinBuild()
        {
            try { using (RegistryKey k = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion")) { int b; if (int.TryParse(Convert.ToString(k.GetValue("CurrentBuildNumber")), out b)) return b; } } catch { }
            return Environment.OSVersion.Version.Build;
        }   // placa-mãe, RAM, discos, ventoinhas, USB (estimativa)

        // ============================================================ MENU DO BOTÃO DIREITO
        static readonly string[] CtxRoots = { @"*", @"Directory", @"Directory\Background", @"Folder", @"AllFilesystemObjects", @"Drive" };
        const string BLOCKED = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked";
        const string CLASSIC = @"Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\InprocServer32";
        static bool IsWindowsPath(string p)
        {
            p = (p ?? "").ToLowerInvariant();
            string win = Environment.GetFolderPath(Environment.SpecialFolder.Windows).ToLowerInvariant();
            return p.Contains(win + "\\") || p.StartsWith("%systemroot%") || p.StartsWith("%windir%") || p.Contains("windowsapps\\microsoft.windows");
        }
        static string ClsidDll(string clsid)
        {
            try { using (RegistryKey k = Registry.ClassesRoot.OpenSubKey(@"CLSID\" + clsid + @"\InprocServer32")) return k == null ? "" : Environment.ExpandEnvironmentVariables(Convert.ToString(k.GetValue("")) ?? ""); } catch { return ""; }
        }
        static string ClsidName(string clsid)
        {
            try { using (RegistryKey k = Registry.ClassesRoot.OpenSubKey(@"CLSID\" + clsid)) return k == null ? "" : Convert.ToString(k.GetValue("")) ?? ""; } catch { return ""; }
        }
        static string Company(string path)
        {
            try { path = path.Trim('"'); if (File.Exists(path)) return (FileVersionInfo.GetVersionInfo(path).CompanyName ?? "").Trim(); } catch { }
            return "";
        }
        static bool Blocked(string clsid) { try { using (RegistryKey k = Registry.LocalMachine.OpenSubKey(BLOCKED)) return k != null && k.GetValue(clsid) != null; } catch { return false; } }
        public static string CtxJson()
        {
            List<string> items = new List<string>();
            HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (string root in CtxRoots)
            {
                // extensões (shellex)
                try
                {
                    using (RegistryKey k = Registry.ClassesRoot.OpenSubKey(root + @"\shellex\ContextMenuHandlers"))
                        if (k != null)
                            foreach (string n in k.GetSubKeyNames())
                            {
                                string clsid = n.StartsWith("{") ? n : "";
                                using (RegistryKey s = k.OpenSubKey(n)) if (clsid == "" && s != null) clsid = Convert.ToString(s.GetValue("")) ?? "";
                                if (!clsid.StartsWith("{") || !seen.Add("x" + clsid)) continue;
                                string dll = ClsidDll(clsid);
                                if (dll == "" || IsWindowsPath(dll)) continue;
                                string nm = n.StartsWith("{") ? ClsidName(clsid) : n;
                                items.Add("{\"id\":" + Js.S("x|" + clsid) + ",\"name\":" + Js.S(nm.Trim() == "" ? Path.GetFileNameWithoutExtension(dll) : nm) + ",\"where\":" + Js.S(root) +
                                          ",\"path\":" + Js.S(dll) + ",\"company\":" + Js.S(Company(dll)) + ",\"off\":" + (Blocked(clsid) ? "true" : "false") + "}");
                            }
                }
                catch { }
                // comandos (shell\verbo\command)
                try
                {
                    using (RegistryKey k = Registry.ClassesRoot.OpenSubKey(root + @"\shell"))
                        if (k != null)
                            foreach (string n in k.GetSubKeyNames())
                            {
                                using (RegistryKey v = k.OpenSubKey(n))
                                {
                                    if (v == null) continue;
                                    string cmd = "";
                                    using (RegistryKey c = v.OpenSubKey("command")) if (c != null) cmd = Convert.ToString(c.GetValue("")) ?? "";
                                    if (cmd == "" || IsWindowsPath(Environment.ExpandEnvironmentVariables(cmd)) || cmd.StartsWith("explorer", StringComparison.OrdinalIgnoreCase)) continue;
                                    if (v.GetValue("ProgrammaticAccessOnly") != null) continue;
                                    string id = "v|" + root + "|" + n;
                                    if (!seen.Add(id)) continue;
                                    string label = Convert.ToString(v.GetValue("MUIVerb") ?? v.GetValue("")) ?? "";
                                    if (label == "" || label.StartsWith("@")) label = n;
                                    string exe = cmd.StartsWith("\"") ? cmd.Substring(1, Math.Max(0, cmd.IndexOf('"', 1) - 1)) : cmd.Split(' ')[0];
                                    items.Add("{\"id\":" + Js.S(id) + ",\"name\":" + Js.S(label.Replace("&", "")) + ",\"where\":" + Js.S(root) + ",\"path\":" + Js.S(cmd) +
                                              ",\"company\":" + Js.S(Company(exe)) + ",\"off\":" + (v.GetValue("LegacyDisable") != null ? "true" : "false") + "}");
                                }
                            }
                }
                catch { }
            }
            bool w11 = WinBuild() >= 22000;
            bool classic = false;
            try { using (RegistryKey k = Registry.CurrentUser.OpenSubKey(CLASSIC)) classic = k != null; } catch { }
            return "{\"ok\":true,\"w11\":" + (w11 ? "true" : "false") + ",\"classic\":" + (classic ? "true" : "false") + ",\"items\":[" + string.Join(",", items.ToArray()) + "]}";
        }
        public static string CtxSet(string id, bool off)
        {
            try
            {
                string[] p = (id ?? "").Split('|');
                if (p[0] == "x" && p.Length == 2 && p[1].StartsWith("{"))
                {
                    using (RegistryKey k = Registry.LocalMachine.CreateSubKey(BLOCKED))
                        if (off) k.SetValue(p[1], "NEXUS"); else k.DeleteValue(p[1], false);
                }
                else if (p[0] == "v" && p.Length == 3 && CtxRoots.Contains(p[1]))
                {
                    using (RegistryKey k = Registry.ClassesRoot.OpenSubKey(p[1] + @"\shell\" + p[2], true))
                        if (k != null) { if (off) k.SetValue("LegacyDisable", ""); else k.DeleteValue("LegacyDisable", false); }
                }
                else return Ps23.Ok(false, "?");
            }
            catch (Exception ex) { return Ps23.Ok(false, ex.Message); }
            return CtxJson();
        }
        public static string CtxClassic(bool on)
        {
            try
            {
                if (on) using (RegistryKey k = Registry.CurrentUser.CreateSubKey(CLASSIC)) k.SetValue("", "");
                else Registry.CurrentUser.DeleteSubKeyTree(@"Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}", false);
            }
            catch (Exception ex) { return Ps23.Ok(false, ex.Message); }
            return CtxJson();
        }
        // o Windows volta a abrir o Explorador sozinho, já sem administrador
        public static string RestartExplorer()
        {
            try { foreach (Process p in Process.GetProcessesByName("explorer")) try { p.Kill(); } catch { } } catch { }
            return Ps23.Ok(true, null);
        }

        // ============================================================ TAREFAS AGENDADAS (as que não são do Windows)
        public static string TasksJson(bool fresh)
        {
            if (fresh) Ps23.Drop("tarefas");
            return Ps23.Run("tarefas", @"
$r = @(Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object { $_.TaskPath -notlike '\Microsoft\*' } | ForEach-Object {
  $a = $_.Actions | Where-Object { $_.Execute } | Select-Object -First 1
  $i = $null; try { $i = Get-ScheduledTaskInfo -TaskPath $_.TaskPath -TaskName $_.TaskName -ErrorAction Stop } catch {}
  $tr = @($_.Triggers | ForEach-Object { ($_.CimClass.CimClassName -replace 'MSFT_Task','' -replace 'Trigger','') }) -join ', '
  [pscustomobject]@{ p = $_.TaskPath + $_.TaskName; n = $_.TaskName; s = [string]$_.State; a = [string]$_.Author
    x = if ($a) { ([string]$a.Execute + ' ' + [string]$a.Arguments).Trim() } else { '' }; t = $tr
    l = if ($i -and $i.LastRunTime -and $i.LastRunTime.Year -gt 2000) { $i.LastRunTime.ToString('yyyy-MM-dd HH:mm') } else { '' } }
})
ConvertTo-Json -InputObject $r -Compress -Depth 3", 60000, 120);
        }
        public static string TaskSet(string path, bool on)
        {
            if (string.IsNullOrEmpty(path) || path.Contains("\"") || path.StartsWith(@"\Microsoft\", StringComparison.OrdinalIgnoreCase)) return Ps23.Ok(false, "?");
            string o = Ps23.Cmd("schtasks.exe", "/Change /TN \"" + path + "\" " + (on ? "/ENABLE" : "/DISABLE"), 15000);
            Ps23.Drop("tarefas");
            return o.IndexOf("SUCCESS", StringComparison.OrdinalIgnoreCase) >= 0 || o.IndexOf("XITO", StringComparison.OrdinalIgnoreCase) >= 0 || o.IndexOf("êxito", StringComparison.OrdinalIgnoreCase) >= 0
                ? Ps23.Ok(true, null) : Ps23.Ok(false, o);
        }

        // ============================================================ SEGURANÇA
        public static string SecurityJson(bool fresh)
        {
            if (fresh) Ps23.Drop("seguranca");
            return Ps23.Run("seguranca", @"
$o = [ordered]@{}
try { $l = Get-CimInstance SoftwareLicensingProduct -Filter ""PartialProductKey IS NOT NULL AND Name LIKE 'Windows%'"" -ErrorAction Stop | Select-Object -First 1; $o.act = [int]$l.LicenseStatus } catch { $o.act = $null }
try { $m = Get-MpComputerStatus -ErrorAction Stop; $o.av = [bool]$m.AntivirusEnabled; $o.rt = [bool]$m.RealTimeProtectionEnabled
  $o.sig = [int]((Get-Date) - $m.AntivirusSignatureLastUpdated).TotalDays; $o.tamper = [bool]$m.IsTamperProtected
  $o.scan = if ($m.QuickScanEndTime) { [int]((Get-Date) - $m.QuickScanEndTime).TotalDays } else { $null } } catch { $o.av = $null }
try { $o.other = @(Get-CimInstance -Namespace root/SecurityCenter2 -ClassName AntiVirusProduct -ErrorAction Stop | ForEach-Object { [string]$_.displayName }) } catch { $o.other = @() }
try { $o.fwoff = @(Get-NetFirewallProfile -ErrorAction Stop | Where-Object { -not $_.Enabled } | ForEach-Object { [string]$_.Name }) } catch { $o.fwoff = $null }
try { $h = Get-HotFix -ErrorAction Stop | Where-Object { $_.InstalledOn } | Sort-Object InstalledOn -Descending | Select-Object -First 1; $o.upd = if ($h) { [int]((Get-Date) - $h.InstalledOn).TotalDays } else { $null } } catch { $o.upd = $null }
$o.uac = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -ErrorAction SilentlyContinue).EnableLUA
try { $o.sb = [bool](Confirm-SecureBootUEFI -ErrorAction Stop) } catch { $o.sb = $null }
try { $t = Get-Tpm -ErrorAction Stop; $o.tpm = [bool]($t.TpmPresent -and $t.TpmReady) } catch { $o.tpm = $null }
try { $b = Get-BitLockerVolume -MountPoint $env:SystemDrive -ErrorAction Stop; $o.bl = [string]$b.ProtectionStatus } catch { $o.bl = $null }
ConvertTo-Json -InputObject $o -Compress", 60000, 300);
        }

        // ============================================================ OTIMIZAR DISCOS (desfragmentar HDD / TRIM no SSD)
        static readonly object optLk = new object();
        static string optDrive = "", optLog = "", optState = "idle";
        public static string DrivesJson()
        {
            string vols = Ps23.Run("volumes", @"
$r = @(Get-Volume -ErrorAction SilentlyContinue | Where-Object { $_.DriveLetter -and $_.DriveType -eq 'Fixed' -and $_.FileSystem } | Sort-Object DriveLetter | ForEach-Object {
  $m = ''; $b = ''; $n = ''
  try { $pt = Get-Partition -DriveLetter $_.DriveLetter -ErrorAction Stop; $pd = Get-PhysicalDisk -ErrorAction Stop | Where-Object { $_.DeviceId -eq [string]$pt.DiskNumber } | Select-Object -First 1; if ($pd) { $m = [string]$pd.MediaType; $b = [string]$pd.BusType; $n = [string]$pd.FriendlyName } } catch {}
  [pscustomobject]@{ d = [string]$_.DriveLetter; l = [string]$_.FileSystemLabel; m = $m; b = $b; n = $n; size = [int64]$_.Size; free = [int64]$_.SizeRemaining }
})
$t = $null; try { $t = [string](Get-ScheduledTask -TaskPath '\Microsoft\Windows\Defrag\' -TaskName 'ScheduledDefrag' -ErrorAction Stop).State } catch {}
ConvertTo-Json -InputObject ([ordered]@{ vols = $r; sched = $t }) -Compress -Depth 3", 30000, 60);
            lock (optLk) return "{\"ok\":true,\"info\":" + vols + ",\"run\":{\"state\":" + Js.S(optState) + ",\"drive\":" + Js.S(optDrive) + ",\"log\":" + Js.S(optLog) + "}}";
        }
        public static string DriveOptimize(string d)
        {
            d = (d ?? "").Trim(':').ToUpperInvariant();
            if (d.Length != 1 || d[0] < 'A' || d[0] > 'Z') return Ps23.Ok(false, "?");
            lock (optLk) { if (optState == "running") return Ps23.Ok(false, Lang.L("Já está a otimizar um disco.")); optState = "running"; optDrive = d; optLog = ""; }
            new Thread(delegate ()
            {
                string o = Ps23.Cmd("defrag.exe", d + ": /O /U /V", 6 * 3600 * 1000);
                string[] lines = o.Replace("\r", "").Split('\n').Where(x => x.Trim() != "").ToArray();
                lock (optLk) { optState = "done"; optLog = string.Join("\n", lines.Skip(Math.Max(0, lines.Length - 14)).ToArray()); }
            }) { IsBackground = true }.Start();
            return DrivesJson();
        }

        // ============================================================ VIDA DOS SSD (TB escritos, vida restante, ritmo por dia) - do LibreHardwareMonitor
        public static string SsdJson()
        {
            List<object[]> rows = Embedded.LastRows;
            if (rows == null) return "{\"ok\":false,\"error\":" + Js.S(Lang.L("Precisa dos sensores incluídos no NEXUS (modo de sensores normal).")) + "}";
            Dictionary<string, Dictionary<string, double>> by = new Dictionary<string, Dictionary<string, double>>();
            foreach (object[] r in rows)
            {
                if (Convert.ToString(r[0]) != "Storage") continue;
                string hw = Convert.ToString(r[1]), st = Convert.ToString(r[2]), nm = Convert.ToString(r[3]);
                if (!by.ContainsKey(hw)) by[hw] = new Dictionary<string, double>();
                by[hw][st + ":" + nm] = Convert.ToDouble(r[4]);
            }
            StringBuilder sb = new StringBuilder("{\"ok\":true,\"items\":[");
            bool first = true;
            foreach (KeyValuePair<string, Dictionary<string, double>> kv in by)
            {
                Dictionary<string, double> v = kv.Value;
                double w = double.NaN, rd = double.NaN, life = double.NaN, used = double.NaN, temp = double.NaN, hours = double.NaN;
                foreach (KeyValuePair<string, double> s in v)
                {
                    string k = s.Key.ToLowerInvariant();
                    if (k.StartsWith("data:") && (k.Contains("written") || k.Contains("writes"))) w = s.Value;
                    else if (k.StartsWith("data:") && k.Contains("read")) rd = s.Value;
                    else if (k.StartsWith("level:") && k.Contains("remaining life")) life = s.Value;
                    else if (k.StartsWith("level:") && k.Contains("percentage used")) used = s.Value;
                    else if (k.StartsWith("temperature:") && double.IsNaN(temp)) temp = s.Value;
                    else if (k.Contains("power on") && k.Contains("hour")) hours = s.Value;
                }
                if (double.IsNaN(life) && !double.IsNaN(used)) life = Math.Max(0, 100 - used);
                // ritmo: guarda a primeira vez que se viu e quanto tinha escrito
                double perDay = double.NaN;
                if (!double.IsNaN(w))
                {
                    string key = "ssdw_" + Regex.Replace(kv.Key, @"[^\w]", "");
                    string prev = Cfg23.Get(key, "");
                    string[] p = prev.Split('|');
                    DateTime d0; double w0;
                    if (p.Length == 2 && DateTime.TryParse(p[0], CultureInfo.InvariantCulture, DateTimeStyles.None, out d0) && double.TryParse(p[1], NumberStyles.Float, CultureInfo.InvariantCulture, out w0))
                    { double days = (DateTime.Now - d0).TotalDays; if (days >= 1 && w >= w0) perDay = (w - w0) / days; }
                    else Cfg23.Set(key, DateTime.Now.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture) + "|" + w.ToString(CultureInfo.InvariantCulture));
                }
                if (double.IsNaN(w) && double.IsNaN(life)) continue;
                if (!first) sb.Append(','); first = false;
                sb.Append("{\"name\":").Append(Js.S(kv.Key)).Append(",\"writtenGB\":").Append(Js.N(w)).Append(",\"readGB\":").Append(Js.N(rd)).Append(",\"life\":").Append(Js.N(life))
                  .Append(",\"temp\":").Append(Js.N(temp)).Append(",\"hours\":").Append(Js.N(hours)).Append(",\"perDayGB\":").Append(Js.N(perDay)).Append('}');
            }
            return sb.Append("]}").ToString();
        }

        // ============================================================ FONTE DE ALIMENTAÇÃO
        public static string PsuJson()
        {
            string lim = Ps23.Cmd(GpuCtl.Smi() ?? "nvidia-smi.exe", "--query-gpu=power.limit,power.max_limit,power.default_limit --format=csv,noheader,nounits", 6000);
            double gl = double.NaN, gmax = double.NaN;
            string[] f = lim.Split(',');
            if (f.Length >= 3) { double.TryParse(f[0].Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out gl); double.TryParse(f[1].Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out gmax); }
            double? c = Stats.CpuPowerNow, g = Stats.GpuPowerNow;
            double cpuPeak = Cfg23.Int("cpu_wmax", 0);
            if (c.HasValue && c.Value > cpuPeak && c.Value < 500) { cpuPeak = Math.Round(c.Value); Cfg23.Set("cpu_wmax", cpuPeak.ToString(CultureInfo.InvariantCulture)); }
            double gpuW = !double.IsNaN(gmax) && gmax > 0 ? gmax : !double.IsNaN(gl) ? gl : 250;
            double cpuW = Math.Max(cpuPeak, 125);
            double need = gpuW + cpuW + RestW();
            return "{\"ok\":true,\"psu\":" + Cfg23.Int("psu_w", 0) + ",\"cpuNow\":" + Js.N(c ?? double.NaN) + ",\"gpuNow\":" + Js.N(g ?? double.NaN) + ",\"rest\":" + RestW() +
                   ",\"cpuPeak\":" + Js.N(cpuPeak) + ",\"gpuLimit\":" + Js.N(gl) + ",\"gpuMax\":" + Js.N(gmax) + ",\"need\":" + Js.N(need) + ",\"rec\":" + Js.N(Math.Ceiling(need * 1.3 / 50) * 50) +
                   ",\"peak\":" + Js.N(Vigias23.PeakW) + ",\"peakWhen\":" + Js.S(Vigias23.PeakW > 0 ? Vigias23.PeakWhen.ToString("HH:mm") : "") + ",\"alert\":" + (Cfg23.On("al_power", true) ? "true" : "false") + "}";
        }

        // ============================================================ LIMITES DE BOOST (o que trava o processador e a placa)
        public static string BoostJson()
        {
            // placa: razões de abrandamento do driver
            string q = Ps23.Cmd(GpuCtl.Smi() ?? "nvidia-smi.exe", "--query-gpu=clocks.sm,clocks.max.sm,clocks_event_reasons.active,clocks_event_reasons.sw_power_cap,clocks_event_reasons.hw_slowdown,clocks_event_reasons.sw_thermal_slowdown,clocks_event_reasons.hw_thermal_slowdown,clocks_event_reasons.hw_power_brake_slowdown,power.limit,power.default_limit --format=csv,noheader,nounits", 6000);
            if (q.IndexOf("Field", StringComparison.OrdinalIgnoreCase) >= 0 || q.IndexOf("Invalid", StringComparison.OrdinalIgnoreCase) >= 0)
                q = Ps23.Cmd(GpuCtl.Smi() ?? "nvidia-smi.exe", "--query-gpu=clocks.sm,clocks.max.sm,clocks_throttle_reasons.active,clocks_throttle_reasons.sw_power_cap,clocks_throttle_reasons.hw_slowdown,clocks_throttle_reasons.sw_thermal_slowdown,clocks_throttle_reasons.hw_thermal_slowdown,clocks_throttle_reasons.hw_power_brake_slowdown,power.limit,power.default_limit --format=csv,noheader,nounits", 6000);
            string[] g = q.Split(',').Select(x => x.Trim()).ToArray();
            // processador: o que o plano de energia do Windows deixa (estado máximo e modo de boost)
            string pc = Ps23.Cmd("powercfg.exe", "/qh SCHEME_CURRENT SUB_PROCESSOR PROCTHROTTLEMAX", 6000);
            string pb = Ps23.Cmd("powercfg.exe", "/qh SCHEME_CURRENT SUB_PROCESSOR PERFBOOSTMODE", 6000);
            Func<string, int> ac = s => { MatchCollection m = Regex.Matches(s, @"0x([0-9a-fA-F]{8})"); return m.Count >= 1 ? Convert.ToInt32(m[m.Count >= 2 ? m.Count - 2 : 0].Groups[1].Value, 16) : -1; };
            int maxState = ac(pc), boost = ac(pb);
            double? clk = Stats.CpuClockNow;
            double clkMax = Cfg23.Int("cpu_clkmax", 0);
            if (clk.HasValue && clk.Value > clkMax && clk.Value < 8000) { clkMax = Math.Round(clk.Value); Cfg23.Set("cpu_clkmax", clkMax.ToString(CultureInfo.InvariantCulture)); }
            int baseMhz = 0;
            try { using (RegistryKey k = Registry.LocalMachine.OpenSubKey(@"HARDWARE\DESCRIPTION\System\CentralProcessor\0")) baseMhz = Convert.ToInt32(k.GetValue("~MHz", 0)); } catch { }
            StringBuilder sb = new StringBuilder("{\"ok\":true");
            sb.Append(",\"cpu\":{\"maxState\":").Append(maxState).Append(",\"boostMode\":").Append(boost).Append(",\"clk\":").Append(Js.N(clk ?? double.NaN))
              .Append(",\"clkMax\":").Append(Js.N(clkMax)).Append(",\"base\":").Append(baseMhz).Append(",\"pkgW\":").Append(Js.N(Stats.CpuPowerNow ?? double.NaN)).Append(",\"wMax\":").Append(Cfg23.Int("cpu_wmax", 0)).Append('}');
            if (g.Length >= 10)
            {
                Func<int, string> yes = i => g[i].IndexOf("Active", StringComparison.OrdinalIgnoreCase) >= 0 && g[i].IndexOf("Not", StringComparison.OrdinalIgnoreCase) < 0 ? "true" : "false";
                sb.Append(",\"gpu\":{\"clk\":").Append(Js.S(g[0])).Append(",\"clkMax\":").Append(Js.S(g[1])).Append(",\"power\":").Append(yes(3)).Append(",\"hw\":").Append(yes(4))
                  .Append(",\"thermal\":").Append(g[5].Contains("Active") && !g[5].Contains("Not") || g[6].Contains("Active") && !g[6].Contains("Not") ? "true" : "false")
                  .Append(",\"brake\":").Append(yes(7)).Append(",\"limit\":").Append(Js.S(g[8])).Append(",\"deflimit\":").Append(Js.S(g[9])).Append('}');
            }
            else sb.Append(",\"gpu\":null");
            return sb.Append('}').ToString();
        }
        public static string BoostFix()
        {
            // repõe o máximo do processador a 100 % e o boost ligado (agressivo) no plano atual, na tomada e na bateria
            Ps23.Cmd("powercfg.exe", "/setacvalueindex SCHEME_CURRENT SUB_PROCESSOR PROCTHROTTLEMAX 100", 6000);
            Ps23.Cmd("powercfg.exe", "/setdcvalueindex SCHEME_CURRENT SUB_PROCESSOR PROCTHROTTLEMAX 100", 6000);
            Ps23.Cmd("powercfg.exe", "/setacvalueindex SCHEME_CURRENT SUB_PROCESSOR PERFBOOSTMODE 2", 6000);
            Ps23.Cmd("powercfg.exe", "/setactive SCHEME_CURRENT", 6000);
            return BoostJson();
        }

        // ============================================================ PRIORIDADE DE REDE PARA O JOGO (QoS / DSCP 46)
        public static void QosEnsure(string exe)
        {
            exe = Clean(exe, 80);
            if (!exe.EndsWith(".exe", StringComparison.OrdinalIgnoreCase)) return;
            PsFile.Run("qos_" + Regex.Replace(exe.ToLowerInvariant(), @"[^a-z0-9]", ""), @"
New-Item 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\QoS' -Force -ErrorAction SilentlyContinue | Out-Null
Set-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\QoS' -Name 'Do not use NLA' -Value '1' -Type String -ErrorAction SilentlyContinue
$n = " + PsQ("NEXUS " + exe) + @"
if (-not (Get-NetQosPolicy -Name $n -ErrorAction SilentlyContinue)) { New-NetQosPolicy -Name $n -AppPathNameMatchCondition " + PsQ(exe) + @" -DSCPAction 46 -NetworkProfile All -ErrorAction SilentlyContinue | Out-Null }", 20000);
            Ps23.Drop("qos");
        }
        public static string QosJson()
        {
            string l = Ps23.Run("qos", "$r = @(Get-NetQosPolicy -ErrorAction SilentlyContinue | Where-Object { $_.Name -like 'NEXUS *' } | ForEach-Object { [pscustomobject]@{ n = $_.Name; app = [string]$_.AppPathNameMatchCondition; dscp = [int]$_.DSCPValue } })\r\nConvertTo-Json -InputObject $r -Compress", 20000, 30);
            return "{\"ok\":true,\"on\":" + (Cfg23.On("qos", false) ? "true" : "false") + ",\"items\":" + l + "}";
        }
        public static string QosSet(bool on) { Cfg23.Set("qos", on ? "1" : "0"); string g = Optimizer.GameName; if (on && g != null) { string exe = Cfg23.Get("gexe_" + g.ToLowerInvariant(), ""); if (exe != "") QosEnsure(Path.GetFileName(exe)); } return QosJson(); }
        public static string QosRemove(string name)
        {
            name = name ?? "";
            if (name == "*") PsFile.Run("qos_del", "Get-NetQosPolicy -ErrorAction SilentlyContinue | Where-Object { $_.Name -like 'NEXUS *' } | Remove-NetQosPolicy -Confirm:$false -ErrorAction SilentlyContinue", 20000);
            else if (name.StartsWith("NEXUS ")) PsFile.Run("qos_del1", "Remove-NetQosPolicy -Name " + PsQ(Clean(name, 90)) + " -Confirm:$false -ErrorAction SilentlyContinue", 20000);
            Ps23.Drop("qos");
            return QosJson();
        }

        // ============================================================ FECHAR PROGRAMAS AO JOGAR (e voltar a abri-los no fim)
        static string[] CloseList() { return Cfg23.Get("closelist", "").Split(';').Select(x => x.Trim()).Where(x => x != "").ToArray(); }
        public static string CloseJson()
        {
            StringBuilder sb = new StringBuilder("{\"ok\":true,\"on\":" + (Cfg23.On("closeon", false) ? "true" : "false") + ",\"list\":[");
            sb.Append(string.Join(",", CloseList().Select(n => { bool run = false; try { run = Process.GetProcessesByName(n).Length > 0; } catch { } return "{\"name\":" + Js.S(n) + ",\"running\":" + (run ? "true" : "false") + "}"; }).ToArray()));
            sb.Append("],\"closed\":").Append(Js.S(Cfg23.Get("reopen", ""))).Append(",\"suggest\":[");
            // sugestões: programas abertos com janela que costumam ser pesados
            string[] known = { "Discord", "Spotify", "chrome", "msedge", "firefox", "opera", "vivaldi", "brave", "Teams", "ms-teams", "Slack", "OneDrive", "Dropbox", "iCUE", "SignalRgb", "LGHUB", "Razer Synapse", "EpicGamesLauncher", "steamwebhelper", "Overwolf", "WhatsApp", "Telegram" };
            HashSet<string> have = new HashSet<string>(CloseList(), StringComparer.OrdinalIgnoreCase);
            List<string> sug = new List<string>();
            try { foreach (Process p in Process.GetProcesses()) { string n = p.ProcessName; if (known.Contains(n, StringComparer.OrdinalIgnoreCase) && !have.Contains(n) && !sug.Contains(n, StringComparer.OrdinalIgnoreCase)) sug.Add(n); } } catch { }
            sb.Append(string.Join(",", sug.Select(x => Js.S(x)).ToArray()));
            return sb.Append("]}").ToString();
        }
        public static string CloseSet(string list, string on)
        {
            if (list != null) Cfg23.Set("closelist", string.Join(";", list.Split(';', ',').Select(x => Clean(x.Trim().Replace(".exe", ""), 60)).Where(x => x != "" && !x.Equals("explorer", StringComparison.OrdinalIgnoreCase) && x.IndexOf("NEXUS", StringComparison.OrdinalIgnoreCase) < 0).Distinct(StringComparer.OrdinalIgnoreCase).ToArray()));
            if (on != null) Cfg23.Set("closeon", on == "1" ? "1" : "0");
            return CloseJson();
        }
        public static void CloseApps()
        {
            List<string> paths = new List<string>();
            foreach (string n in CloseList())
            {
                Process[] ps; try { ps = Process.GetProcessesByName(n); } catch { continue; }
                string path = null;
                foreach (Process p in ps) { try { if (path == null) { string ep = Optimizer.ExePath(p.Id); if (ep != "") path = ep; } } catch { } try { p.CloseMainWindow(); } catch { } }
                if (path != null && !paths.Contains(path)) paths.Add(path);
                Thread.Sleep(3000);
                foreach (Process p in ps) { try { if (!p.HasExited) p.Kill(); } catch { } }
            }
            if (paths.Count > 0)
            {
                Cfg23.Set("reopen", string.Join("|", paths.ToArray()));
                Program.Notify("NEXUS · " + Lang.L("Jogo aberto"), Lang.L("Programas fechados até acabares de jogar:") + " " + string.Join(", ", paths.Select(Path.GetFileNameWithoutExtension).ToArray()));
            }
        }
        public static void ReopenApps()
        {
            string r = Cfg23.Get("reopen", ""); if (r == "") return;
            Cfg23.Set("reopen", null);
            foreach (string p in r.Split('|'))
                if (File.Exists(p)) try { Process.Start(new ProcessStartInfo("explorer.exe", "\"" + p + "\"") { UseShellExecute = false }); Thread.Sleep(800); } catch { }   // pelo Explorador: abre sem administrador
        }
    }
}
