﻿// NEXUS // MONITOR 2.3 - NVIDIA App (desligar e manter desligada), jogos para abrir do telemóvel, música e volume
// (também para a Stream Deck, com capa), tema a partir do papel de parede, painel no 2.º monitor / por cima do jogo,
// copiar definições de outro PC da casa, modo só de leitura, e o encaminhamento de /api/x/...
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Management;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.ServiceProcess;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

namespace Nexus
{
    // ------------------------------------------------------------ NVIDIA App: desligar o que corre sempre (overlay, contentor, arranque, tarefas)
    // O Painel de Controlo NVIDIA e o driver não são tocados (o serviço NVDisplay.ContainerLocalSystem fica como está).
    static class NvApp
    {
        const string SVC = "NvContainerLocalSystem";
        static readonly string[] Procs = { "NVIDIA App", "NVIDIA Overlay", "NVIDIA Share", "NVIDIA Web Helper", "NVIDIA GeForce Experience" };
        static string AppDir { get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), @"NVIDIA Corporation\NVIDIA App"); } }
        static string GfeDir { get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), @"NVIDIA Corporation\NVIDIA GeForce Experience"); } }
        static bool IsNvStartup(string[] it)
        {
            string c = (it[1] + " " + it[2]).ToLowerInvariant();
            return c.Contains("nvidia app") || c.Contains("nvbackend") || c.Contains("nvidia geforce experience") || c.Contains("nvidia overlay");
        }
        static string TasksPs { get { return "Get-ScheduledTask -TaskPath '\\' -ErrorAction SilentlyContinue | Where-Object { $_.TaskName -match '^(NvTmRep|NvDriverUpdateCheck|NVIDIA App|NvNodeLauncher|NvBatteryBoostCheck|NvTmMon)' }"; } }
        public static string Json()
        {
            bool installed = Directory.Exists(AppDir) || Directory.Exists(GfeDir);
            List<string> run = new List<string>();
            foreach (string p in Procs) try { if (Process.GetProcessesByName(p).Length > 0) run.Add(p); } catch { }
            int st = -1; string state = "";
            try { using (RegistryKey k = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services\" + SVC)) st = k == null ? -1 : Convert.ToInt32(k.GetValue("Start", 3)); } catch { }
            try { using (ServiceController sc = new ServiceController(SVC)) state = sc.Status.ToString(); } catch { }
            List<string[]> su = new List<string[]>(); try { su = Arranque.Items().Where(IsNvStartup).ToList(); } catch { }
            string tasks = Ps23.Run("nv_tarefas", "$r = @(" + TasksPs + " | ForEach-Object { [pscustomobject]@{ n = $_.TaskName; s = [string]$_.State } })\r\nConvertTo-Json -InputObject $r -Compress", 30000, 60);
            bool cpl = File.Exists(Path.Combine(Environment.SystemDirectory, "nvcplui.exe")) || Directory.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "WindowsApps")) && Directory.GetDirectories(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "WindowsApps"), "NVIDIACorp.NVIDIAControlPanel*").Length > 0;
            bool cplRun = false; try { cplRun = Process.GetProcessesByName("nvcplui").Length > 0; } catch { }
            return "{\"ok\":true,\"installed\":" + (installed ? "true" : "false") + ",\"running\":[" + string.Join(",", run.Select(x => Js.S(x)).ToArray()) + "]" +
                   ",\"svc\":" + st + ",\"svcState\":" + Js.S(state) + ",\"startup\":[" + string.Join(",", su.Select(x => "{\"name\":" + Js.S(x[1]) + ",\"on\":" + (x[3] == "1" ? "true" : "false") + "}").ToArray()) + "]" +
                   ",\"tasks\":" + tasks + ",\"keep\":" + (Cfg23.On("nvkeep", false) ? "true" : "false") + ",\"off\":" + (Cfg23.On("nvoff", false) ? "true" : "false") +
                   ",\"cpl\":" + (cpl ? "true" : "false") + ",\"cplRunning\":" + (cplRun ? "true" : "false") + ",\"last\":" + Js.S(Cfg23.Get("nv_last", "")) + "}";
        }
        public static string Off(bool quiet)
        {
            // serviço do contentor (overlay, gravação, otimização automática)
            try
            {
                using (RegistryKey k = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services\" + SVC, true))
                    if (k != null)
                    {
                        int cur = Convert.ToInt32(k.GetValue("Start", 2));
                        if (cur != 4) { if (Cfg23.Get("nv_svc", "") == "") Cfg23.Set("nv_svc", cur.ToString()); k.SetValue("Start", 4, RegistryValueKind.DWord); }
                    }
                using (ServiceController sc = new ServiceController(SVC)) if (sc.Status != ServiceControllerStatus.Stopped) { sc.Stop(); sc.WaitForStatus(ServiceControllerStatus.Stopped, TimeSpan.FromSeconds(15)); }
            }
            catch { }
            // arranque com o Windows
            try
            {
                List<string> ids = Cfg23.Get("nv_run", "").Split('\t').Where(x => x != "").ToList();
                foreach (string[] it in Arranque.Items().Where(IsNvStartup))
                    if (it[3] == "1") { Arranque.Set(it[0], false); if (!ids.Contains(it[0])) ids.Add(it[0]); }
                Cfg23.Set("nv_run", string.Join("\t", ids.ToArray()));
            }
            catch { }
            // tarefas agendadas (telemetria, procurar atualizações)
            PsFile.Run("nv_off", TasksPs + " | Where-Object { $_.State -ne 'Disabled' } | ForEach-Object { Disable-ScheduledTask -TaskName $_.TaskName -TaskPath '\\' -ErrorAction SilentlyContinue | Out-Null; $_.TaskName }", 30000);
            Ps23.Drop("nv_tarefas");
            // fecha o que está aberto
            foreach (string p in Procs) try { foreach (Process x in Process.GetProcessesByName(p)) try { x.Kill(); } catch { } } catch { }
            Cfg23.Set("nvoff", "1");
            return quiet ? "" : Json();
        }
        public static string On()
        {
            try
            {
                int back = Cfg23.Int("nv_svc", 2);
                using (RegistryKey k = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services\" + SVC, true)) if (k != null) k.SetValue("Start", back, RegistryValueKind.DWord);
                Cfg23.Set("nv_svc", null);
                if (back == 2) using (ServiceController sc = new ServiceController(SVC)) if (sc.Status == ServiceControllerStatus.Stopped) sc.Start();
            }
            catch { }
            try { foreach (string id in Cfg23.Get("nv_run", "").Split('\t').Where(x => x != "")) Arranque.Set(id, true); Cfg23.Set("nv_run", null); } catch { }
            PsFile.Run("nv_on", TasksPs + " | Where-Object { $_.State -eq 'Disabled' } | ForEach-Object { Enable-ScheduledTask -TaskName $_.TaskName -TaskPath '\\' -ErrorAction SilentlyContinue | Out-Null }", 30000);
            Ps23.Drop("nv_tarefas");
            Cfg23.Set("nvoff", "0"); Cfg23.Set("nvkeep", "0");
            return Json();
        }
        public static string Keep(bool on) { Cfg23.Set("nvkeep", on ? "1" : "0"); if (on) Off(true); return Json(); }
        // "manter desligada": a NVIDIA App também é aberta por coisas fora do arranque (o contentor do driver, atualizações...).
        // Com isto ligado, o NEXUS fecha-a assim que aparece (vê a cada 3 s) e guarda quem a abriu, para se saber de onde veio.
        public static void Watch()
        {
            if (!Cfg23.On("nvkeep", false)) return;
            List<string> dirs = Dirs();
            HashSet<string> names = Names(dirs);
            foreach (Process x in Process.GetProcesses())
            {
                try
                {
                    if (!names.Contains(x.ProcessName)) continue;
                    // só o que vem das pastas da NVIDIA App / GeForce Experience (o driver e o Painel de Controlo nunca são tocados)
                    string path = ImagePath(x.Id);
                    bool fromApp = path != "" ? dirs.Any(d => path.StartsWith(d + "\\", StringComparison.OrdinalIgnoreCase)) : Procs.Contains(x.ProcessName, StringComparer.OrdinalIgnoreCase);
                    if (!fromApp) continue;
                    string parent = "";
                    try
                    {
                        using (System.Management.ManagementObjectSearcher q = new System.Management.ManagementObjectSearcher("SELECT ParentProcessId FROM Win32_Process WHERE ProcessId=" + x.Id))
                            foreach (System.Management.ManagementObject o in q.Get())
                            {
                                int pp = Convert.ToInt32(o["ParentProcessId"]);
                                try { parent = Process.GetProcessById(pp).ProcessName; } catch { parent = "#" + pp; }
                            }
                    }
                    catch { }
                    x.Kill();
                    Cfg23.Set("nv_last", DateTime.Now.ToString("dd/MM HH:mm") + "|" + x.ProcessName + "|" + parent);
                }
                catch { }
                finally { x.Dispose(); }
            }
        }
        static List<string> Dirs()
        {
            string pf = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), pd = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);
            return new[] { AppDir, GfeDir, Path.Combine(pd, @"NVIDIA Corporation\NVIDIA app"), Path.Combine(pd, @"NVIDIA Corporation\NVIDIA App\UpdateFramework"), Path.Combine(pf, @"NVIDIA Corporation\NvNode") }
                .Where(Directory.Exists).Select(d => d.TrimEnd('\\')).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        }
        // os programas que existem nessas pastas. A lista faz-se ao arrancar e só se refaz quando o Windows avisa que
        // apareceu ou mudou um programa lá dentro (uma atualização da NVIDIA App) — não fica a ver de x em x tempo.
        static HashSet<string> nameCache; static readonly List<FileSystemWatcher> watchers = new List<FileSystemWatcher>();
        static HashSet<string> Names(List<string> dirs)
        {
            if (nameCache != null) return nameCache;
            lock (watchers)
                if (watchers.Count == 0)
                    foreach (string d in dirs)
                        try
                        {
                            FileSystemWatcher w = new FileSystemWatcher(d, "*.exe") { IncludeSubdirectories = true, NotifyFilter = NotifyFilters.FileName };
                            FileSystemEventHandler reset = delegate { nameCache = null; };
                            w.Created += reset; w.Deleted += reset; w.Renamed += delegate { nameCache = null; };
                            w.EnableRaisingEvents = true; watchers.Add(w);
                        }
                        catch { }
            var h = new HashSet<string>(Procs, StringComparer.OrdinalIgnoreCase);
            foreach (string d in dirs)
                try { foreach (string f in Directory.GetFiles(d, "*.exe", SearchOption.AllDirectories)) h.Add(Path.GetFileNameWithoutExtension(f)); } catch { }
            h.Remove("nvcontainer"); h.Remove("nvdisplay.container"); h.Remove("nvcplui");   // nunca: são do driver / Painel de Controlo
            nameCache = h;
            return h;
        }
        [System.Runtime.InteropServices.DllImport("kernel32.dll", SetLastError = true)] static extern IntPtr OpenProcess(uint acc, bool inherit, int pid);
        [System.Runtime.InteropServices.DllImport("kernel32.dll", SetLastError = true, CharSet = System.Runtime.InteropServices.CharSet.Unicode)] static extern bool QueryFullProcessImageName(IntPtr h, int flags, StringBuilder name, ref int size);
        [System.Runtime.InteropServices.DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);
        static string ImagePath(int pid)
        {
            IntPtr h = OpenProcess(0x1000, false, pid); if (h == IntPtr.Zero) return "";
            try { StringBuilder b = new StringBuilder(1024); int n = b.Capacity; return QueryFullProcessImageName(h, 0, b, ref n) ? b.ToString() : ""; }
            finally { CloseHandle(h); }
        }
        // ao abrir o NEXUS: se "manter desligada" estiver ligado, volta a desligar o que uma atualização do driver tenha ligado
        public static void OnStart() { if (Cfg23.On("nvkeep", false)) ThreadPool.QueueUserWorkItem(delegate { try { Watch(); } catch { } Thread.Sleep(20000); try { Off(true); } catch { } }); }
    }

    static partial class Ferr
    {
        // ============================================================ JOGOS (para abrir a partir do telemóvel)
        static List<string[]> Games()
        {
            List<string[]> l = new List<string[]>();   // {id, nome, origem}
            foreach (string k in Cfg23.Keys("gexe_"))
            {
                string exe = Cfg23.Get(k, "");
                if (File.Exists(exe)) l.Add(new[] { "x:" + k.Substring(5), FileVersionInfo.GetVersionInfo(exe).ProductName ?? Path.GetFileNameWithoutExtension(exe), "PC" });
            }
            try
            {
                string steam = null;
                using (RegistryKey k = Registry.CurrentUser.OpenSubKey(@"Software\Valve\Steam")) if (k != null) steam = Convert.ToString(k.GetValue("SteamPath"));
                if (!string.IsNullOrEmpty(steam))
                {
                    List<string> libs = new List<string> { Path.Combine(steam.Replace('/', '\\'), "steamapps") };
                    string vdf = Path.Combine(libs[0], "libraryfolders.vdf");
                    if (File.Exists(vdf)) foreach (Match m in Regex.Matches(File.ReadAllText(vdf), "\"path\"\\s+\"([^\"]+)\"")) libs.Add(Path.Combine(m.Groups[1].Value.Replace("\\\\", "\\"), "steamapps"));
                    foreach (string lib in libs.Distinct(StringComparer.OrdinalIgnoreCase))
                        if (Directory.Exists(lib))
                            foreach (string f in Directory.GetFiles(lib, "appmanifest_*.acf"))
                            {
                                string t = File.ReadAllText(f);
                                Match id = Regex.Match(t, "\"appid\"\\s+\"(\\d+)\""), nm = Regex.Match(t, "\"name\"\\s+\"([^\"]+)\"");
                                if (!id.Success || !nm.Success) continue;
                                string n = nm.Groups[1].Value;
                                if (Regex.IsMatch(n, @"(?i)redistributable|steamworks|proton|runtime|dedicated server|soundtrack")) continue;
                                l.Add(new[] { "s:" + id.Groups[1].Value, n, "Steam" });
                            }
                }
            }
            catch { }
            return l.GroupBy(x => x[1].ToLowerInvariant()).Select(g => g.First()).OrderBy(x => x[1]).ToList();
        }
        public static string GamesJson()
        {
            return "{\"ok\":true,\"items\":[" + string.Join(",", Games().Select(g => "{\"id\":" + Js.S(g[0]) + ",\"name\":" + Js.S(g[1]) + ",\"src\":" + Js.S(g[2]) + "}").ToArray()) + "]}";
        }
        public static string GameLaunch(string id)
        {
            string[] g = Games().FirstOrDefault(x => x[0] == id);
            if (g == null) return Ps23.Ok(false, Lang.L("Jogo não encontrado."));
            try
            {
                // pelo Explorador: o jogo abre como utilizador normal, não como administrador
                string target = id.StartsWith("s:") ? "steam://rungameid/" + id.Substring(2) : Cfg23.Get("gexe_" + id.Substring(2), "");
                Process.Start(new ProcessStartInfo("explorer.exe", "\"" + target + "\"") { UseShellExecute = false });
            }
            catch (Exception ex) { return Ps23.Ok(false, ex.Message); }
            return Ps23.Ok(true, Lang.L("A abrir") + " " + g[1] + "…");
        }

        // ============================================================ MÚSICA (o que está a tocar, com capa) e VOLUME
        // A música vem dos controlos de multimédia do Windows (Spotify, browsers, apps…) através de um PowerShell que fica
        // a correr só enquanto alguém está a ver (página ou Stream Deck) e fecha sozinho 60 s depois.
        static readonly object medLk = new object();
        static DateTime medAsk = DateTime.MinValue;
        static Process medProc;
        static string MedDir { get { return Path.Combine(AppSettings.Dir, "musica"); } }
        const string MEDIA_PS = @"
$ErrorActionPreference = 'SilentlyContinue'
$dir = $args[0]
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
function Await($op, $type) { $t = $asTask.MakeGenericMethod($type).Invoke($null, @($op)); [void]$t.Wait(5000); $t.Result }
[void][Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType = WindowsRuntime]
[void][Windows.Storage.Streams.IRandomAccessStreamWithContentType, Windows.Storage.Streams, ContentType = WindowsRuntime]
$mgr = Await ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])
$last = ''; $n = 0
while ($true) {
  $alive = Join-Path $dir 'vivo.txt'
  if (-not (Test-Path $alive) -or ((Get-Date) - (Get-Item $alive).LastWriteTime).TotalSeconds -gt 60) { break }
  $s = $mgr.GetCurrentSession()
  $cmdf = Join-Path $dir 'comando.txt'
  if ($s -and (Test-Path $cmdf)) {
    $c = (Get-Content $cmdf -Raw).Trim(); Remove-Item $cmdf -Force
    if ($c -eq 'play') { [void](Await ($s.TryTogglePlayPauseAsync()) ([bool])) }
    elseif ($c -eq 'next') { [void](Await ($s.TrySkipNextAsync()) ([bool])) }
    elseif ($c -eq 'prev') { [void](Await ($s.TrySkipPreviousAsync()) ([bool])) }
  }
  $o = [ordered]@{ title = ''; artist = ''; album = ''; app = ''; status = 0; cover = '' }
  if ($s) {
    $p = Await ($s.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties])
    $o.title = [string]$p.Title; $o.artist = [string]$p.Artist; $o.album = [string]$p.AlbumTitle; $o.app = [string]$s.SourceAppUserModelId
    $o.status = [int]$s.GetPlaybackInfo().PlaybackStatus
    $key = $o.title + '|' + $o.artist
    if ($key -ne $last -and $p.Thumbnail) {
      $last = $key; $n++
      $st = Await ($p.Thumbnail.OpenReadAsync()) ([Windows.Storage.Streams.IRandomAccessStreamWithContentType])
      if ($st) { $src = [System.IO.WindowsRuntimeStreamExtensions]::AsStreamForRead($st); $f = [System.IO.File]::Create((Join-Path $dir 'capa.tmp')); $src.CopyTo($f); $f.Close(); $src.Close()
        Move-Item (Join-Path $dir 'capa.tmp') (Join-Path $dir 'capa.img') -Force }
    } elseif ($key -ne $last) { $last = $key; Remove-Item (Join-Path $dir 'capa.img') -Force }
    if (Test-Path (Join-Path $dir 'capa.img')) { $o.cover = [string]$n }
  }
  $j = ConvertTo-Json -InputObject $o -Compress
  [System.IO.File]::WriteAllText((Join-Path $dir 'agora.tmp'), $j, [System.Text.Encoding]::UTF8)
  Move-Item (Join-Path $dir 'agora.tmp') (Join-Path $dir 'agora.json') -Force
  Start-Sleep -Milliseconds 700
}";
        static void MediaWake()
        {
            lock (medLk)
            {
                medAsk = DateTime.Now;
                try { Directory.CreateDirectory(MedDir); File.WriteAllText(Path.Combine(MedDir, "vivo.txt"), DateTime.Now.ToString("o")); } catch { }
                if (medProc != null) { try { if (!medProc.HasExited) return; } catch { } }
                try
                {
                    string dir = Path.Combine(AppSettings.Dir, "scripts"); Directory.CreateDirectory(dir);
                    string f = Path.Combine(dir, "nexus_musica.ps1");
                    string body = "# NEXUS Monitor - musica (criado pelo NEXUS; pode ser apagado)\r\n" + MEDIA_PS.Replace("\r\n", "\n").Replace("\n", "\r\n") + "\r\n";
                    if (!File.Exists(f) || File.ReadAllText(f, Encoding.UTF8) != body) File.WriteAllText(f, body, new UTF8Encoding(true));
                    medProc = Process.Start(new ProcessStartInfo("powershell.exe", "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File \"" + f + "\" \"" + MedDir + "\"") { UseShellExecute = false, CreateNoWindow = true });
                }
                catch { }
            }
        }
        // volume do Windows (Core Audio): só para mostrar; mudar usa as teclas de volume (o Windows mostra o indicador)
        [ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")] class MMDeviceEnumeratorCom { }
        [ComImport, Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        interface IMMDeviceEnumerator { [PreserveSig] int EnumAudioEndpoints(int dataFlow, int mask, out IntPtr devices); [PreserveSig] int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice dev); }
        [ComImport, Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        interface IMMDevice { [PreserveSig] int Activate(ref Guid iid, int ctx, IntPtr p, [MarshalAs(UnmanagedType.IUnknown)] out object o); }
        [ComImport, Guid("5CDF2C82-841E-4546-9722-0CF74078229A"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        interface IAudioEndpointVolume
        {
            [PreserveSig] int RegisterControlChangeNotify(IntPtr p); [PreserveSig] int UnregisterControlChangeNotify(IntPtr p); [PreserveSig] int GetChannelCount(out int n);
            [PreserveSig] int SetMasterVolumeLevel(float db, ref Guid ctx); [PreserveSig] int SetMasterVolumeLevelScalar(float v, ref Guid ctx);
            [PreserveSig] int GetMasterVolumeLevel(out float db); [PreserveSig] int GetMasterVolumeLevelScalar(out float v);
            [PreserveSig] int SetChannelVolumeLevel(uint ch, float db, ref Guid ctx); [PreserveSig] int SetChannelVolumeLevelScalar(uint ch, float v, ref Guid ctx);
            [PreserveSig] int GetChannelVolumeLevel(uint ch, out float db); [PreserveSig] int GetChannelVolumeLevelScalar(uint ch, out float v);
            [PreserveSig] int SetMute([MarshalAs(UnmanagedType.Bool)] bool mute, ref Guid ctx); [PreserveSig] int GetMute([MarshalAs(UnmanagedType.Bool)] out bool mute);
        }
        static IAudioEndpointVolume Vol()
        {
            IMMDeviceEnumerator en = (IMMDeviceEnumerator)new MMDeviceEnumeratorCom();
            IMMDevice dev; if (en.GetDefaultAudioEndpoint(0, 1, out dev) != 0 || dev == null) return null;
            Guid iid = typeof(IAudioEndpointVolume).GUID; object o;
            if (dev.Activate(ref iid, 23, IntPtr.Zero, out o) != 0) return null;
            return o as IAudioEndpointVolume;
        }
        public static void VolumeNow(out double pct, out bool mute)
        {
            pct = double.NaN; mute = false;
            try { IAudioEndpointVolume v = Vol(); if (v == null) return; float f; v.GetMasterVolumeLevelScalar(out f); pct = Math.Round(f * 100); bool m; v.GetMute(out m); mute = m; } catch { }
        }
        public static string MediaJson()
        {
            MediaWake();
            string now = "null";
            try { string f = Path.Combine(MedDir, "agora.json"); if (File.Exists(f) && (DateTime.Now - File.GetLastWriteTime(f)).TotalSeconds < 10) now = File.ReadAllText(f, Encoding.UTF8).Trim(); } catch { }
            if (now == "" || !(now.StartsWith("{"))) now = "null";
            double v; bool m; VolumeNow(out v, out m);
            return "{\"ok\":true,\"now\":" + now + ",\"volume\":" + Js.N(v) + ",\"mute\":" + (m ? "true" : "false") + "}";
        }
        public static byte[] MediaCover() { try { string f = Path.Combine(MedDir, "capa.img"); return File.Exists(f) ? File.ReadAllBytes(f) : null; } catch { return null; } }
        [DllImport("user32.dll")] static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);
        static void Key(byte vk) { keybd_event(vk, 0, 0, UIntPtr.Zero); keybd_event(vk, 0, 2, UIntPtr.Zero); }
        public static string MediaDo(string a)
        {
            MediaWake();
            if (a == "play" || a == "next" || a == "prev")
            {
                // pelos controlos do Windows (vai à app certa); se o PowerShell ainda não arrancou, usa as teclas multimédia
                bool viaPs = false;
                lock (medLk) { try { viaPs = medProc != null && !medProc.HasExited && (DateTime.Now - medAsk).TotalSeconds < 60 && File.Exists(Path.Combine(MedDir, "agora.json")); } catch { } }
                if (viaPs) try { File.WriteAllText(Path.Combine(MedDir, "comando.txt"), a); } catch { viaPs = false; }
                if (!viaPs) Key(a == "play" ? (byte)0xB3 : a == "next" ? (byte)0xB0 : (byte)0xB1);
            }
            else if (a == "volup") { Key(0xAF); Key(0xAF); }
            else if (a == "voldown") { Key(0xAE); Key(0xAE); }
            else if (a == "mute") Key(0xAD);
            else return Ps23.Ok(false, "?");
            Thread.Sleep(250);
            return MediaJson();
        }

        // ============================================================ TEMA A PARTIR DO PAPEL DE PAREDE
        public static string WallTheme()
        {
            string p = "";
            try { using (RegistryKey k = Registry.CurrentUser.OpenSubKey(@"Control Panel\Desktop")) p = Convert.ToString(k.GetValue("WallPaper")) ?? ""; } catch { }
            if (p == "" || !File.Exists(p)) p = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), @"Microsoft\Windows\Themes\TranscodedWallpaper");
            if (!File.Exists(p)) return Ps23.Ok(false, Lang.L("Não encontrei o papel de parede (cor sólida ou apresentação?)."));
            // 24 tons (15° cada): soma o peso e a cor real dos píxeis com cor (sem cinzentos, pretos nem brancos)
            double[] w = new double[24], sr = new double[24], sg = new double[24], sb = new double[24];
            try
            {
                using (Image src = Image.FromFile(p))
                using (Bitmap b = new Bitmap(96, 54))
                {
                    using (Graphics g = Graphics.FromImage(b)) { g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBilinear; g.DrawImage(src, 0, 0, 96, 54); }
                    for (int y = 0; y < b.Height; y++)
                        for (int x = 0; x < b.Width; x++)
                        {
                            Color c = b.GetPixel(x, y);
                            float sat = c.GetSaturation(), lum = c.GetBrightness();
                            if (sat < 0.2f || lum < 0.12f || lum > 0.92f) continue;
                            int k = (int)(c.GetHue() / 15) % 24;
                            double wt = sat * (1 - Math.Abs(lum - 0.5f));
                            w[k] += wt; sr[k] += c.R * wt; sg[k] += c.G * wt; sb[k] += c.B * wt;
                        }
                }
            }
            catch (Exception ex) { return Ps23.Ok(false, ex.Message); }
            // junta cada tom com os vizinhos (um degradê não se parte em dois)
            double[] ws = new double[24]; for (int k = 0; k < 24; k++) ws[k] = w[k] + 0.5 * (w[(k + 23) % 24] + w[(k + 1) % 24]);
            if (w.Sum() < 3) return Ps23.Ok(false, Lang.L("O papel de parede quase não tem cor. Escolhe as cores à mão."));
            int k1 = Enumerable.Range(0, 24).OrderByDescending(k => ws[k]).First();
            int k2 = Enumerable.Range(0, 24).Where(k => { int d = Math.Abs(k - k1); return Math.Min(d, 24 - d) >= 3 && w[k] > w.Sum() * 0.04; }).OrderByDescending(k => ws[k]).DefaultIfEmpty(-1).First();
            // cor real média do tom, ajustada para se ler bem num fundo escuro
            Func<int, Color> real = k =>
            {
                Color m = Color.FromArgb((int)(sr[k] / w[k]), (int)(sg[k] / w[k]), (int)(sb[k] / w[k]));
                return FromHsl(m.GetHue(), Math.Max(0.55f, Math.Min(0.95f, m.GetSaturation() * 1.15f)), Math.Max(0.55f, Math.Min(0.70f, m.GetBrightness())));
            };
            Color c1 = real(k1);
            Color c2 = k2 >= 0 ? real(k2) : FromHsl((c1.GetHue() + 40) % 360, Math.Max(0.55f, c1.GetSaturation()), 0.62f);   // um tom ao lado quando só há uma cor
            Func<Color, string> hex = c => (c.R.ToString("x2") + c.G.ToString("x2") + c.B.ToString("x2"));
            AppSettings.SetTheme("/x?c1=" + hex(c1) + "&c2=" + hex(c2));
            return "{\"ok\":true,\"c1\":\"#" + hex(c1) + "\",\"c2\":\"#" + hex(c2) + "\"}";
        }
        static Color FromHsl(float h, float s, float l)
        {
            float c = (1 - Math.Abs(2 * l - 1)) * s, x = c * (1 - Math.Abs((h / 60) % 2 - 1)), m = l - c / 2, r = 0, g = 0, b = 0;
            if (h < 60) { r = c; g = x; } else if (h < 120) { r = x; g = c; } else if (h < 180) { g = c; b = x; } else if (h < 240) { g = x; b = c; } else if (h < 300) { r = x; b = c; } else { r = c; b = x; }
            return Color.FromArgb((int)Math.Round((r + m) * 255), (int)Math.Round((g + m) * 255), (int)Math.Round((b + m) * 255));
        }

        // ============================================================ COPIAR DEFINIÇÕES DE OUTRO PC DA CASA (código de 6 números, 5 minutos, só na rede local)
        static string syncCode; static DateTime syncUntil; static int syncFails;
        public static string SyncCode()
        {
            byte[] b = new byte[4]; using (RNGCryptoServiceProvider r = new RNGCryptoServiceProvider()) r.GetBytes(b);
            syncCode = (BitConverter.ToUInt32(b, 0) % 1000000).ToString("000000"); syncUntil = DateTime.Now.AddMinutes(5); syncFails = 0;
            return "{\"ok\":true,\"code\":" + Js.S(syncCode) + ",\"until\":" + Js.S(syncUntil.ToString("HH:mm")) + ",\"name\":" + Js.S(Environment.MachineName) + "}";
        }
        // pedido vindo do outro PC (sem o código de acesso do telemóvel: vale o código de 6 números)
        public static string SyncGet(string code, string ip)
        {
            if (!IsLan(ip) || syncCode == null || DateTime.Now > syncUntil) return Ps23.Ok(false, "expired");
            if (code != syncCode) { if (++syncFails >= 5) syncCode = null; return Ps23.Ok(false, "wrong"); }
            syncCode = null;   // só serve uma vez
            Program.Notify("NEXUS", Lang.L("As definições foram copiadas para outro PC da rede:") + " " + ip);
            return Copia.ExportJson();
        }
        public static string SyncPull(string ip, string code)
        {
            IPAddress a; if (!IPAddress.TryParse(ip ?? "", out a) || !IsLan(ip)) return Ps23.Ok(false, Lang.L("Endereço inválido."));
            if (!Regex.IsMatch(code ?? "", @"^\d{6}$")) return Ps23.Ok(false, Lang.L("O código tem 6 números."));
            try
            {
                using (WebClient wc = new WebClient())
                {
                    wc.Encoding = Encoding.UTF8; wc.Proxy = null;
                    string j = wc.DownloadString("http://" + a + ":8765/api/x/sync/get?code=" + code);
                    if (!j.Contains("\"files\"")) return Ps23.Ok(false, j.Contains("wrong") ? Lang.L("Código errado.") : Lang.L("O código expirou. Gera outro no outro PC."));
                    // só as definições e os perfis de jogo; o que é deste PC (acesso pela rede, telemóveis aceites, código) fica como está
                    string[] keepLocal = { "remote=", "remotectl=", "remotectl_ips=", "lanshare=", "token=" };
                    StringBuilder body = new StringBuilder();
                    foreach (string name in new[] { "settings.ini", "perfis.txt" })
                    {
                        Match m = Regex.Match(j, "\"" + Regex.Escape(name) + "\":\"((?:[^\"\\\\]|\\\\.)*)\"");
                        if (!m.Success) continue;
                        string text = Regex.Unescape(m.Groups[1].Value);
                        if (name == "settings.ini")
                        {
                            string mine = Path.Combine(AppSettings.Dir, "settings.ini");
                            List<string> lines = text.Replace("\r", "").Split('\n').Where(l => l.Trim() != "" && !keepLocal.Any(k => l.StartsWith(k))).ToList();
                            if (File.Exists(mine)) lines.AddRange(File.ReadAllLines(mine).Where(l => keepLocal.Any(k => l.StartsWith(k))));
                            text = string.Join("\n", lines.ToArray());
                        }
                        body.Append(name).Append('\t').Append(Convert.ToBase64String(Encoding.UTF8.GetBytes(text))).Append('\n');
                    }
                    return Copia.Import(body.ToString());
                }
            }
            catch (Exception ex) { return Ps23.Ok(false, Lang.L("Não consegui falar com esse PC:") + " " + ex.Message); }
        }
        static bool IsLan(string ip)
        {
            IPAddress a; if (!IPAddress.TryParse(ip ?? "", out a)) return false;
            if (IPAddress.IsLoopback(a)) return true;
            byte[] b = a.GetAddressBytes(); if (b.Length != 4) return a.IsIPv6LinkLocal;
            return b[0] == 10 || (b[0] == 192 && b[1] == 168) || (b[0] == 172 && b[1] >= 16 && b[1] <= 31) || (b[0] == 169 && b[1] == 254);
        }

        // ============================================================ MODO SÓ DE LEITURA (alguém vê o teu PC pela rede, sem mexer em nada)
        public static string ViewToken { get { return Cfg23.Get("viewtok", ""); } }
        public static bool ViewMatches(string t) { string v = ViewToken; return v.Length >= 16 && t != null && t.Length == v.Length && CryptographicEquals(t, v); }
        static bool CryptographicEquals(string a, string b) { int d = 0; for (int i = 0; i < a.Length; i++) d |= a[i] ^ b[i]; return d == 0; }
        public static string ViewJson()
        {
            string t = ViewToken, ip = "";
            try { foreach (IPAddress a in Dns.GetHostAddresses(Dns.GetHostName())) if (a.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork && IsLan(a.ToString()) && !IPAddress.IsLoopback(a)) { ip = a.ToString(); break; } } catch { }
            return "{\"ok\":true,\"on\":" + (t != "" ? "true" : "false") + ",\"remote\":" + (AppSettings.Remote ? "true" : "false") + ",\"url\":" + Js.S(t != "" && ip != "" ? "http://" + ip + ":8765/?v=" + t : "") + "}";
        }
        public static string ViewSet(bool on)
        {
            if (on) { byte[] b = new byte[12]; using (RNGCryptoServiceProvider r = new RNGCryptoServiceProvider()) r.GetBytes(b); Cfg23.Set("viewtok", BitConverter.ToString(b).Replace("-", "").ToLowerInvariant()); }
            else Cfg23.Set("viewtok", null);
            return ViewJson();
        }
        // o que o modo só de leitura pode pedir: a página principal e os números ao vivo
        public static bool ViewAllowed(string method, string path)
        {
            if (method != "GET") return false;
            string p = path.Split('?')[0];
            return p == "/" || p == "/index.html" || p == "/i18n.js" || p == "/tour.js" || p == "/shell.js" || p == "/api/stats" || p == "/api/history" || p == "/manifest.webmanifest" || p.StartsWith("/nexus-icon-") || p == "/favicon.ico" || p == "/api/ui";
        }
    }

    // ------------------------------------------------------------ painel do NEXUS numa janela própria: 2.º monitor (modo apresentação) ou pequeno por cima do jogo (Alt+Shift+N)
    static class Painel
    {
        // browser com "modo app" (janela sem barras): Edge, Chrome, Brave ou Vivaldi
        static string Edge()
        {
            List<string> c = new List<string>();
            foreach (string exe in new[] { "msedge.exe", "chrome.exe", "brave.exe", "vivaldi.exe" })
                foreach (RegistryKey h in new[] { Registry.LocalMachine, Registry.CurrentUser })
                    try { using (RegistryKey k = h.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\" + exe)) if (k != null) c.Add(Convert.ToString(k.GetValue("")) ?? ""); } catch { }
            string pf86 = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), pf = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), la = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            c.AddRange(new[] { Path.Combine(pf86, @"Microsoft\Edge\Application\msedge.exe"), Path.Combine(pf, @"Microsoft\Edge\Application\msedge.exe"), Path.Combine(pf, @"Google\Chrome\Application\chrome.exe"),
                               Path.Combine(la, @"Google\Chrome\Application\chrome.exe"), Path.Combine(pf, @"BraveSoftware\Brave-Browser\Application\brave.exe"), Path.Combine(la, @"Vivaldi\Application\vivaldi.exe") });
            foreach (string p in c) { string q = (p ?? "").Trim('"'); if (q != "" && File.Exists(q)) return q; }
            return null;
        }
        static string Profile(string kind) { return Path.Combine(AppSettings.Dir, "painel-" + kind); }
        static List<int> Pids(string kind)
        {
            List<int> l = new List<int>();
            try
            {
                using (ManagementObjectSearcher s = new ManagementObjectSearcher("SELECT ProcessId, CommandLine FROM Win32_Process WHERE Name='msedge.exe' OR Name='chrome.exe' OR Name='brave.exe' OR Name='vivaldi.exe'"))
                    foreach (ManagementObject o in s.Get()) { string c = Convert.ToString(o["CommandLine"]) ?? ""; if (c.IndexOf(Profile(kind), StringComparison.OrdinalIgnoreCase) >= 0) l.Add(Convert.ToInt32(o["ProcessId"])); }
            }
            catch { }
            return l;
        }
        public static bool Running(string kind) { return Pids(kind).Count > 0; }
        public static string Stop(string kind) { foreach (int p in Pids(kind)) try { Process.GetProcessById(p).Kill(); } catch { } return Json(); }
        public static string Toggle(string kind) { return Running(kind) ? Stop(kind) : Start(kind); }

        // teste do monitor pedido pelo telemóvel: abre no PC em ecrã inteiro e o telemóvel serve de comando
        static readonly object monLk = new object();
        static bool monOn; static int monStep; static DateTime monAt;
        public static string MonJson() { lock (monLk) { if (monOn && (DateTime.UtcNow - monAt).TotalMinutes > 10) monOn = false; return "{\"ok\":true,\"on\":" + (monOn ? "true" : "false") + ",\"step\":" + monStep + "}"; } }
        public static string MonStep(string act)
        {
            lock (monLk)
            {
                monAt = DateTime.UtcNow;
                if (act == "close") monOn = false;
                else if (act == "back") monStep = Math.Max(0, monStep - 1);
                else monStep++;
            }
            return MonJson();
        }
        public static string MonTest()
        {
            lock (monLk) { monOn = true; monStep = 0; monAt = DateTime.UtcNow; }
            string url = "http://localhost:8765/perf?montest=1";
            string edge = Edge();
            try
            {
                if (edge == null) { Process.Start(new ProcessStartInfo("explorer.exe", "\"" + url + "\"") { UseShellExecute = false }); return MonJson(); }
                Rectangle r = Screen.PrimaryScreen.Bounds;
                string args = "--app=" + url + " --user-data-dir=\"" + Profile("monitor") + "\" --no-first-run --no-default-browser-check --start-fullscreen --window-position=" + r.X + "," + r.Y + " --window-size=" + r.Width + "," + r.Height;
                // pelo Explorador (atalho .lnk): o browser abre como utilizador normal, não como administrador
                string lnk = Path.Combine(AppSettings.Dir, "scripts", "teste-monitor.lnk");
                Directory.CreateDirectory(Path.GetDirectoryName(lnk));
                object sh = Activator.CreateInstance(Type.GetTypeFromProgID("WScript.Shell"));
                object sc = sh.GetType().InvokeMember("CreateShortcut", BindingFlags.InvokeMethod, null, sh, new object[] { lnk });
                sc.GetType().InvokeMember("TargetPath", BindingFlags.SetProperty, null, sc, new object[] { edge });
                sc.GetType().InvokeMember("Arguments", BindingFlags.SetProperty, null, sc, new object[] { args });
                sc.GetType().InvokeMember("Save", BindingFlags.InvokeMethod, null, sc, null);
                Marshal.FinalReleaseComObject(sc); Marshal.FinalReleaseComObject(sh);
                Process.Start(new ProcessStartInfo("explorer.exe", "\"" + lnk + "\"") { UseShellExecute = false });
            }
            catch (Exception ex) { return Ps23.Ok(false, ex.Message); }
            return MonJson();
        }
        public static string Json()
        {
            int n = 1; try { n = Screen.AllScreens.Length; } catch { }
            return "{\"ok\":true,\"edge\":" + (Edge() != null ? "true" : "false") + ",\"screens\":" + n + ",\"present\":" + (Running("apresentacao") ? "true" : "false") + ",\"mini\":" + (Running("mini") ? "true" : "false") + "}";
        }
        public static string Start(string kind)
        {
            string edge = Edge();
            string url0 = "http://localhost:8765/?kiosk=" + (kind == "mini" ? "mini" : "1");
            if (edge == null)
            {
                // nenhum browser com "modo app": abre no browser padrão (Firefox, Opera…) numa janela normal
                try { Process.Start(new ProcessStartInfo("explorer.exe", "\"" + url0 + "\"") { UseShellExecute = false }); } catch (Exception ex) { return Ps23.Ok(false, ex.Message); }
                return "{\"ok\":true,\"edge\":false,\"msg\":" + Js.S(Lang.L("Abriu no teu browser normal. Para uma janela sem barras e no sítio certo, é preciso o Edge, Chrome, Brave ou Vivaldi (o Edge vem com o Windows).")) + "}";
            }
            Rectangle r;
            Screen[] all = Screen.AllScreens;
            if (kind == "apresentacao")
            {
                Screen s = all.FirstOrDefault(x => !x.Primary);
                if (s == null) return Ps23.Ok(false, Lang.L("Só há um monitor ligado."));
                r = s.Bounds;
            }
            else { Rectangle w = Screen.PrimaryScreen.WorkingArea; r = new Rectangle(w.Right - 560, w.Top + 40, 540, Math.Min(760, w.Height - 80)); }
            string url = "http://localhost:8765/?kiosk=" + (kind == "mini" ? "mini" : "1");
            string args = "--app=" + url + " --user-data-dir=\"" + Profile(kind) + "\" --no-first-run --no-default-browser-check --window-position=" + r.X + "," + r.Y + " --window-size=" + r.Width + "," + r.Height + (kind == "apresentacao" ? " --start-fullscreen" : "");
            try
            {
                // atalho .lnk aberto pelo Explorador: o Edge abre como utilizador normal (o NEXUS corre como administrador)
                string lnk = Path.Combine(AppSettings.Dir, "scripts", "painel-" + kind + ".lnk");
                Directory.CreateDirectory(Path.GetDirectoryName(lnk));
                object sh = Activator.CreateInstance(Type.GetTypeFromProgID("WScript.Shell"));
                object sc = sh.GetType().InvokeMember("CreateShortcut", BindingFlags.InvokeMethod, null, sh, new object[] { lnk });
                sc.GetType().InvokeMember("TargetPath", BindingFlags.SetProperty, null, sc, new object[] { edge });
                sc.GetType().InvokeMember("Arguments", BindingFlags.SetProperty, null, sc, new object[] { args });
                sc.GetType().InvokeMember("Save", BindingFlags.InvokeMethod, null, sc, null);
                Marshal.FinalReleaseComObject(sc); Marshal.FinalReleaseComObject(sh);
                Process.Start(new ProcessStartInfo("explorer.exe", "\"" + lnk + "\"") { UseShellExecute = false });
            }
            catch (Exception ex) { return Ps23.Ok(false, ex.Message); }
            Thread.Sleep(1500);
            return Json();
        }
    }
}
