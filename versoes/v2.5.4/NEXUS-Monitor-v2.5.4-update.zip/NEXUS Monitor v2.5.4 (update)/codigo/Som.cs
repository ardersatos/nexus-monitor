﻿// NEXUS // MONITOR - auscultadores e microfone (qualquer marca, pelo som do Windows): aparelho de saída/entrada,
// volume, silenciar, trocar o aparelho predefinido. Os Logitech com HID++ têm ainda bateria e "sidetone" (em Dispositivos.cs).
using System;
using System.Threading;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using Microsoft.Win32;
using System.Runtime.InteropServices;
using System.Text;

namespace Nexus
{
    static class Som
    {
        [ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")] class MMDeviceEnumeratorCom { }
        [ComImport, Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        interface IMMDeviceEnumerator
        {
            [PreserveSig] int EnumAudioEndpoints(int flow, int mask, out IMMDeviceCollection devs);
            [PreserveSig] int GetDefaultAudioEndpoint(int flow, int role, out IMMDevice dev);
            [PreserveSig] int GetDevice([MarshalAs(UnmanagedType.LPWStr)] string id, out IMMDevice dev);
        }
        [ComImport, Guid("0BD7A1BE-7A1A-44DB-8397-CC5392387B5E"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        interface IMMDeviceCollection { [PreserveSig] int GetCount(out int n); [PreserveSig] int Item(int i, out IMMDevice dev); }
        [ComImport, Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        interface IMMDevice
        {
            [PreserveSig] int Activate(ref Guid iid, int ctx, IntPtr p, [MarshalAs(UnmanagedType.IUnknown)] out object o);
            [PreserveSig] int OpenPropertyStore(int access, out IPropertyStore ps);
            [PreserveSig] int GetId([MarshalAs(UnmanagedType.LPWStr)] out string id);
        }
        [StructLayout(LayoutKind.Sequential)] struct PROPKEY { public Guid fmt; public int pid; }
        [StructLayout(LayoutKind.Sequential)] struct PROPVAR { public ushort vt, r1, r2, r3; public IntPtr p; public IntPtr p2; }
        [ComImport, Guid("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        interface IPropertyStore { [PreserveSig] int GetCount(out int n); [PreserveSig] int GetAt(int i, out PROPKEY k); [PreserveSig] int GetValue(ref PROPKEY k, out PROPVAR v); }
        [ComImport, Guid("5CDF2C82-841E-4546-9722-0CF74078229A"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        interface IAudioEndpointVolume
        {
            [PreserveSig] int RegisterControlChangeNotify(IntPtr p); [PreserveSig] int UnregisterControlChangeNotify(IntPtr p); [PreserveSig] int GetChannelCount(out int n);
            [PreserveSig] int SetMasterVolumeLevel(float db, ref Guid ctx); [PreserveSig] int SetMasterVolumeLevelScalar(float v, ref Guid ctx);
            [PreserveSig] int GetMasterVolumeLevel(out float db); [PreserveSig] int GetMasterVolumeLevelScalar(out float v);
            [PreserveSig] int SetChannelVolumeLevel(uint ch, float db, ref Guid ctx); [PreserveSig] int SetChannelVolumeLevelScalar(uint ch, float v, ref Guid ctx);
            [PreserveSig] int GetChannelVolumeLevel(uint ch, out float db); [PreserveSig] int GetChannelVolumeLevelScalar(uint ch, out float v);
            [PreserveSig] int SetMute([MarshalAs(UnmanagedType.Bool)] bool mute, ref Guid ctx); [PreserveSig] int GetMute([MarshalAs(UnmanagedType.Bool)] out bool mute);
        }
        // trocar o aparelho predefinido (interface usada pelo próprio painel de som do Windows)
        [ComImport, Guid("870AF99C-171D-4F9E-AF0D-E63DF40C2BC9")] class PolicyConfigCom { }
        [ComImport, Guid("F8679F50-850A-41CF-9C72-430F290290C8"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        interface IPolicyConfig
        {
            [PreserveSig] int GetMixFormat(IntPtr a, IntPtr b); [PreserveSig] int GetDeviceFormat(IntPtr a, int b, IntPtr c); [PreserveSig] int ResetDeviceFormat(IntPtr a);
            [PreserveSig] int SetDeviceFormat(IntPtr a, IntPtr b, IntPtr c); [PreserveSig] int GetProcessingPeriod(IntPtr a, int b, IntPtr c, IntPtr d); [PreserveSig] int SetProcessingPeriod(IntPtr a, IntPtr b);
            [PreserveSig] int GetShareMode(IntPtr a, IntPtr b); [PreserveSig] int SetShareMode(IntPtr a, IntPtr b); [PreserveSig] int GetPropertyValue(IntPtr a, IntPtr b, IntPtr c);
            [PreserveSig] int SetPropertyValue(IntPtr a, IntPtr b, IntPtr c);
            [PreserveSig] int SetDefaultEndpoint([MarshalAs(UnmanagedType.LPWStr)] string id, int role);
            [PreserveSig] int SetEndpointVisibility([MarshalAs(UnmanagedType.LPWStr)] string id, int visible);
        }
        [DllImport("ole32.dll")] static extern int PropVariantClear(ref PROPVAR v);

        static string Name(IMMDevice d)
        {
            try
            {
                IPropertyStore ps; if (d.OpenPropertyStore(0, out ps) != 0 || ps == null) return "";
                PROPKEY k = new PROPKEY { fmt = new Guid("A45C254E-DF1C-4EFD-8020-67D146A850E0"), pid = 14 };   // nome completo
                PROPVAR v; if (ps.GetValue(ref k, out v) != 0) return "";
                string s = v.vt == 31 ? Marshal.PtrToStringUni(v.p) : "";
                PropVariantClear(ref v);
                return s ?? "";
            }
            catch { return ""; }
        }
        static IAudioEndpointVolume Vol(IMMDevice d)
        {
            Guid iid = typeof(IAudioEndpointVolume).GUID; object o;
            return d.Activate(ref iid, 23, IntPtr.Zero, out o) == 0 ? o as IAudioEndpointVolume : null;
        }

        class Dev { public string Id, Name; public bool Def; }
        static List<Dev> Devices(int flow, out string defId)
        {
            List<Dev> r = new List<Dev>(); defId = "";
            IMMDeviceEnumerator en = (IMMDeviceEnumerator)new MMDeviceEnumeratorCom();
            IMMDevice def; if (en.GetDefaultAudioEndpoint(flow, 1, out def) == 0 && def != null) def.GetId(out defId);
            IMMDeviceCollection c; if (en.EnumAudioEndpoints(flow, 1, out c) != 0 || c == null) return r;
            int n; c.GetCount(out n);
            for (int i = 0; i < n && i < 32; i++) { IMMDevice d; if (c.Item(i, out d) != 0 || d == null) continue; string id; d.GetId(out id); r.Add(new Dev { Id = id, Name = Name(d), Def = id == defId }); }
            return r;
        }
        static string Side(int flow)
        {
            try
            {
                string defId; List<Dev> l = Devices(flow, out defId);
                double vol = -1; bool mute = false;
                IMMDeviceEnumerator en = (IMMDeviceEnumerator)new MMDeviceEnumeratorCom();
                IMMDevice d; if (en.GetDefaultAudioEndpoint(flow, 1, out d) == 0 && d != null) { IAudioEndpointVolume v = Vol(d); if (v != null) { float f; v.GetMasterVolumeLevelScalar(out f); vol = Math.Round(f * 100); v.GetMute(out mute); } }
                return "{\"vol\":" + (vol < 0 ? "null" : vol.ToString(System.Globalization.CultureInfo.InvariantCulture)) + ",\"mute\":" + (mute ? "true" : "false") +
                       ",\"devs\":[" + string.Join(",", l.Select(x => "{\"id\":" + Js.S(x.Id) + ",\"name\":" + Js.S(x.Name) + ",\"def\":" + (x.Def ? "true" : "false") + "}").ToArray()) + "]}";
            }
            catch (Exception e) { lastErr = e.GetType().Name + ": " + e.Message; return "null"; }
        }
        public static string lastErr = "";
        public static string Json()
        {
            string o = Side(0), i = Side(1);
            // depois de o som do Windows reiniciar, a ligação desta thread pode ficar inválida: tenta numa thread nova (STA e depois MTA)
            foreach (ApartmentState ap in new[] { ApartmentState.STA, ApartmentState.MTA })
            {
                if (o != "null" && i != "null") break;
                string o2 = null, i2 = null;
                Thread t = new Thread(() => { try { o2 = Side(0); i2 = Side(1); } catch { } }) { IsBackground = true };
                t.SetApartmentState(ap); t.Start(); t.Join(5000);
                if (o2 != null && o2 != "null") o = o2;
                if (i2 != null && i2 != "null") i = i2;
            }
            return "{\"ok\":true,\"out\":" + o + ",\"in\":" + i + (o == "null" || i == "null" ? ",\"err\":" + Js.S(lastErr) : "") + "}";
        }

        // flow 0 = saída (auscultadores/colunas), 1 = entrada (microfone)
        public static string Set(int flow, string what, string v)
        {
            try
            {
                IMMDeviceEnumerator en = (IMMDeviceEnumerator)new MMDeviceEnumeratorCom();
                if (what == "def")
                {
                    IPolicyConfig pc = (IPolicyConfig)new PolicyConfigCom();
                    for (int role = 0; role < 3; role++) pc.SetDefaultEndpoint(v, role);
                    return Json();
                }
                IMMDevice d; if (en.GetDefaultAudioEndpoint(flow, 1, out d) != 0 || d == null) return Ps23.Ok(false, Lang.L("Sem aparelho de som."));
                IAudioEndpointVolume vol = Vol(d); if (vol == null) return Ps23.Ok(false, "?");
                Guid ctx = Guid.Empty; double n;
                if (what == "vol" && double.TryParse(v, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out n)) vol.SetMasterVolumeLevelScalar((float)Math.Max(0, Math.Min(1, n / 100)), ref ctx);
                else if (what == "mute") vol.SetMute(v == "1", ref ctx);
                else if (what == "togglemute") { bool m; vol.GetMute(out m); vol.SetMute(!m, ref ctx); }
                return Json();
            }
            catch (Exception e) { return Ps23.Ok(false, e.Message); }
        }
        public static bool MicMuted() { try { IMMDeviceEnumerator en = (IMMDeviceEnumerator)new MMDeviceEnumeratorCom(); IMMDevice d; if (en.GetDefaultAudioEndpoint(1, 1, out d) != 0 || d == null) return false; IAudioEndpointVolume v = Vol(d); bool m = false; if (v != null) v.GetMute(out m); return m; } catch { return false; } }

    }

    // ================================================================ equalizador (pelo Equalizer APO, gratuito e de código aberto)
    // O NEXUS não mexe no som sozinho: escreve um ficheiro de configuração que o Equalizer APO aplica a todo o som do Windows,
    // só no aparelho escolhido. Sem o Equalizer APO instalado, o cartão explica como o instalar.
    static class Equalizador
    {
        static string ApoDir()
        {
            foreach (RegistryView v in new[] { RegistryView.Registry64, RegistryView.Registry32 })
                try
                {
                    using (RegistryKey b = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, v))
                    using (RegistryKey k = b.OpenSubKey(@"SOFTWARE\EqualizerAPO"))
                        if (k != null) { string p = k.GetValue("InstallPath") as string; if (!string.IsNullOrEmpty(p) && Directory.Exists(p)) return p; string c = k.GetValue("ConfigPath") as string; if (!string.IsNullOrEmpty(c) && Directory.Exists(c)) return Path.GetDirectoryName(c.TrimEnd('\\')); }
                }
                catch { }
            string d = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "EqualizerAPO");
            return Directory.Exists(d) ? d : null;
        }
        static string ConfDir() { string a = ApoDir(); return a == null ? null : Path.Combine(a, "config"); }
        public static string ApoDirPublic() { return ApoDir(); }
        public static void Rewrite() { Write(); }
        public static string DevGuid(string id) { if (string.IsNullOrEmpty(id)) return ""; int i = id.LastIndexOf('{'); return i >= 0 ? id.Substring(i) : id; }

        public static string Json()
        {
            string a = ApoDir(), c = ConfDir();
            bool cfgOk = c != null && File.Exists(Path.Combine(c, "config.txt"));
            var l = Cfg23.Prefix("eq_d_");
            bool eng = EqMotor.EngineOk();
            return "{\"ok\":true,\"apo\":" + (eng && cfgOk ? "true" : "false") + ",\"cfg\":" + (cfgOk ? "true" : "false") + ",\"setup\":" + Js.S(EqMotor.State) +
                   ",\"inst\":[" + string.Join(",", (eng ? EqMotor.Installed() : new List<string>()).Select(x => Js.S(x)).ToArray()) + "]" +
                   ",\"saved\":{" + string.Join(",", l.Select(kv => Js.S(kv.Key) + ":" + Js.S(kv.Value)).ToArray()) + "},\"sound\":" + Som.Json() + "}";
        }

        // cfg (vindo da página): "on|preamp|b1,b2,...,b10|tipo,f,g,q;..." e o nome do aparelho para mostrar
        public static string Set(string guid, string cfg)
        {
            if (string.IsNullOrEmpty(guid) || guid.IndexOf('{') != 0 || guid.Length > 60) return Ps23.Ok(false, "?");
            if (cfg != null && cfg.Length > 4000) return Ps23.Ok(false, "?");
            Cfg23.Set("eq_d_" + guid, string.IsNullOrEmpty(cfg) ? null : cfg);
            string err = Write();
            return err == null ? Json() : Ps23.Ok(false, err);
        }
        static string Num(double v) { return v.ToString("0.##", CultureInfo.InvariantCulture); }
        static double D(string s, double def) { double v; return double.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out v) && !double.IsNaN(v) && !double.IsInfinity(v) ? v : def; }
        static readonly int[] BANDS = { 31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000 };

        static string Write()
        {
            string c = ConfDir();
            if (c == null) return Lang.L("O Equalizer APO não está instalado.");
            try
            {
                StringBuilder b = new StringBuilder("# NEXUS Monitor - equalizador (criado pelo NEXUS; muda-se no NEXUS em Dispositivos > Equalizador)\r\n");
                foreach (var kv in Cfg23.Prefix("eq_d_"))
                {
                    string[] p = kv.Value.Split('|');
                    if (p.Length < 4 || p[0] != "1") continue;
                    b.Append("Device: ").Append(kv.Key).Append("\r\n");
                    b.Append("Preamp: ").Append(Num(Math.Max(-30, Math.Min(10, D(p[1], 0))))).Append(" dB\r\n");
                    foreach (string f in p[3].Split(';'))
                    {
                        string[] q = f.Split(','); if (q.Length != 4) continue;
                        string t = q[0] == "ls" ? "LSC" : q[0] == "hs" ? "HSC" : "PK";
                        double fc = Math.Max(10, Math.Min(22000, D(q[1], 1000))), g = Math.Max(-24, Math.Min(24, D(q[2], 0))), qq = Math.Max(0.1, Math.Min(20, D(q[3], 0.7)));
                        b.Append("Filter: ON ").Append(t).Append(" Fc ").Append(Num(fc)).Append(" Hz Gain ").Append(Num(g)).Append(" dB Q ").Append(Num(qq)).Append("\r\n");
                    }
                    string[] g10 = p[2].Split(',');
                    if (g10.Length == 10 && g10.Any(x => D(x, 0) != 0))
                        b.Append("GraphicEQ: ").Append(string.Join("; ", BANDS.Select((hz, i) => hz + " " + Num(Math.Max(-15, Math.Min(15, D(g10[i], 0))))).ToArray())).Append("\r\n");
                    b.Append("Device: all\r\n");
                }
                File.WriteAllText(Path.Combine(c, "nexus_eq.txt"), b.ToString(), new UTF8Encoding(false));
                // o config.txt principal passa a incluir o do NEXUS (uma vez; guarda uma cópia antes)
                string main = Path.Combine(c, "config.txt");
                string txt = File.Exists(main) ? File.ReadAllText(main) : "";
                if (File.Exists(Path.Combine(c, "nexus_owner.txt")))
                {
                    const string only = "# NEXUS Monitor\r\nInclude: nexus_eq.txt\r\n";
                    if (txt != only)
                    {
                        if (File.Exists(main) && !File.Exists(Path.Combine(c, "config.antes-do-nexus.txt"))) File.Copy(main, Path.Combine(c, "config.antes-do-nexus.txt"));
                        File.WriteAllText(main, only, new UTF8Encoding(false));
                    }
                }
                else if (txt.IndexOf("nexus_eq.txt", StringComparison.OrdinalIgnoreCase) < 0)
                {
                    if (File.Exists(main) && !File.Exists(Path.Combine(c, "config.antes-do-nexus.txt"))) File.Copy(main, Path.Combine(c, "config.antes-do-nexus.txt"));
                    File.WriteAllText(main, txt.TrimEnd() + (txt.Trim() == "" ? "" : "\r\n") + "Include: nexus_eq.txt\r\n", new UTF8Encoding(false));
                }
                return null;
            }
            catch (UnauthorizedAccessException) { return Lang.L("Sem permissão para escrever na pasta do Equalizer APO. Abre o NEXUS como administrador uma vez."); }
            catch (Exception e) { return e.Message; }
        }
    }
}
