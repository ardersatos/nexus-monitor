﻿// NEXUS // MONITOR - histórico de temperaturas e uso, resumo das sessões de jogo, saúde dos discos, drivers,
// modo de poupança automático e cópia de segurança das definições. Tudo fica neste PC (Documentos\NEXUS Monitor).
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Management;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using Microsoft.Win32;

namespace Nexus
{
    static class Js
    {
        // texto JSON seguro (com quebras de linha e caracteres de controlo)
        public static string S(string v)
        {
            if (v == null) return "null";
            StringBuilder sb = new StringBuilder(v.Length + 8).Append('"');
            foreach (char c in v)
            {
                if (c == '"') sb.Append("\\\""); else if (c == '\\') sb.Append("\\\\");
                else if (c == '\n') sb.Append("\\n"); else if (c == '\r') sb.Append("\\r"); else if (c == '\t') sb.Append("\\t");
                else if (c < 32) sb.Append("\\u").Append(((int)c).ToString("x4"));
                else sb.Append(c);
            }
            return sb.Append('"').ToString();
        }
        public static string N(double v) { return double.IsNaN(v) || double.IsInfinity(v) ? "null" : v.ToString("0.#", CultureInfo.InvariantCulture); }
    }

    // ------------------------------------------------------------ histórico + sessões de jogo + modo poupança (um temporizador de 2 s)
    static class Historico
    {
        class S { public long T; public float Cpu, CpuT, Gpu, GpuT, Ram, Fps; }
        class Sess
        {
            public string Game; public DateTime Start;
            public List<float> Fps = new List<float>();
            public double CpuTMax = double.NaN, GpuTMax = double.NaN, CpuSum, GpuSum; public int N, GpuN;
        }
        public class Res
        {
            public string Game, When, Bott = "", Thieves = ""; public double Mins, Avg, Low, CpuT, GpuT, Cpu, Gpu;
        }

        static readonly object lk = new object();
        static readonly List<S> mem = new List<S>();          // últimas 24 h, um ponto a cada 10 s
        static readonly StringBuilder pend = new StringBuilder();
        static Timer timer; static int busy;
        static int tick;
        static Sess sess;
        static List<Res> sessions;
        static string Folder { get { return Path.Combine(AppSettings.Dir, "historico"); } }
        static string FileSess { get { return Path.Combine(AppSettings.Dir, "sessoes.txt"); } }
        static long Now { get { return (long)(DateTime.UtcNow - new DateTime(1970, 1, 1)).TotalSeconds; } }

        public static void Start()
        {
            try
            {
                Directory.CreateDirectory(Folder);
                foreach (string f in Directory.GetFiles(Folder, "*.csv"))
                    if (File.GetLastWriteTime(f) < DateTime.Now.AddDays(-8)) File.Delete(f);
                // volta a pôr na memória as últimas 24 h (se o NEXUS foi reiniciado)
                long from = Now - 86400;
                foreach (S s in ReadDays(2)) if (s.T >= from) mem.Add(s);
            }
            catch { }
            // uma volta de cada vez: se uma demorar mais de 2 s, a seguinte salta (antes podiam correr duas ao mesmo tempo e
            // o início de um jogo era tratado duas vezes: rota, perfis do rato, macros…)
            timer = new Timer(delegate { if (Interlocked.Exchange(ref busy, 1) == 1) return; try { Tick(); } catch { } finally { Interlocked.Exchange(ref busy, 0); } }, null, 4000, 2000);
        }
        public static void Shutdown()
        {
            try { Flush(); } catch { }
            try { Vigias3.Save(); } catch { }
            try { Eco.Off(); } catch { }
            try { if (sess != null) FinishSession(); } catch { }
        }

        static double Fps()
        {
            string g = PresentMonReader.Json();
            if (g == "null") g = Rtss.Json();
            if (g == "null") return double.NaN;
            System.Text.RegularExpressions.Match m = System.Text.RegularExpressions.Regex.Match(g, "\"fps\":([0-9.]+)");
            double v;
            return m.Success && double.TryParse(m.Groups[1].Value, NumberStyles.Float, CultureInfo.InvariantCulture, out v) ? v : double.NaN;
        }

        static void Tick()
        {
            tick++;
            double cpu, ram, ramGb; double? cpuT, gpu, gpuT;
            string game = Optimizer.GameName;
            // o histórico de fundo não mantém a leitura da placa ligada (antes ficava a correr sempre): só durante um jogo
            Stats.OverlaySnap(out cpu, out cpuT, out gpu, out gpuT, out ram, out ramGb, game != null);
            double fps = game != null ? Fps() : double.NaN;
            try { Vigias3.Tick(cpu, cpuT, gpu, gpuT, game); } catch { }   // estatísticas, pó, fugas, mineradores, jogos atualizados…

            // ---- sessão de jogo
            lock (lk)
            {
                if (game != null && (sess == null || sess.Game != game)) { if (sess != null) FinishSession(); sess = new Sess { Game = game, Start = DateTime.Now }; Analise.TakeSession(); Ladroes.TakeSession(); }
                if (sess != null && game != null)
                {
                    if (!double.IsNaN(fps) && fps > 0 && sess.Fps.Count < 50000) sess.Fps.Add((float)fps);
                    if (cpuT.HasValue && (double.IsNaN(sess.CpuTMax) || cpuT.Value > sess.CpuTMax)) sess.CpuTMax = cpuT.Value;
                    if (gpuT.HasValue && (double.IsNaN(sess.GpuTMax) || gpuT.Value > sess.GpuTMax)) sess.GpuTMax = gpuT.Value;
                    sess.CpuSum += cpu; sess.N++;
                    if (gpu.HasValue) { sess.GpuSum += gpu.Value; sess.GpuN++; }
                }
                else if (sess != null && game == null) FinishSession();
            }

            // ---- gargalo e alertas em jogo
            try { Analise.Feed(game, cpu, cpuT, gpu, gpuT, ram, fps); } catch { }
            try { Vigias23.Tick(game, cpu, cpuT, gpu, gpuT, fps); } catch { }

            // ---- modo poupança
            try { Eco.Check(game != null || Optimizer.Playing); } catch { }

            // ---- histórico: um ponto a cada 10 s
            if (tick % 5 != 0) return;
            S p = new S { T = Now, Cpu = (float)cpu, CpuT = cpuT.HasValue ? (float)cpuT.Value : float.NaN, Gpu = gpu.HasValue ? (float)gpu.Value : float.NaN,
                          GpuT = gpuT.HasValue ? (float)gpuT.Value : float.NaN, Ram = (float)ram, Fps = (float)fps };
            lock (lk)
            {
                mem.Add(p);
                long from = Now - 86400; int cut = 0;
                while (cut < mem.Count && mem[cut].T < from) cut++;
                if (cut > 0) mem.RemoveRange(0, cut);
                CultureInfo ci = CultureInfo.InvariantCulture;
                pend.Append(p.T).Append(';').Append(F(p.Cpu)).Append(';').Append(F(p.CpuT)).Append(';').Append(F(p.Gpu)).Append(';').Append(F(p.GpuT))
                    .Append(';').Append(F(p.Ram)).Append(';').Append(F(p.Fps)).Append("\r\n");
            }
            if (tick % 30 == 0) Flush();   // grava no disco a cada minuto
        }
        static string F(float v) { return float.IsNaN(v) ? "" : v.ToString("0.#", CultureInfo.InvariantCulture); }
        static void Flush()
        {
            string t;
            lock (lk) { t = pend.ToString(); pend.Clear(); }
            if (t.Length == 0) return;
            try { Directory.CreateDirectory(Folder); File.AppendAllText(Path.Combine(Folder, DateTime.Now.ToString("yyyy-MM-dd") + ".csv"), t); } catch { }
        }
        static IEnumerable<S> ReadDays(int days)
        {
            List<S> l = new List<S>();
            for (int d = days - 1; d >= 0; d--)
            {
                string f = Path.Combine(Folder, DateTime.Now.AddDays(-d).ToString("yyyy-MM-dd") + ".csv");
                if (!File.Exists(f)) continue;
                foreach (string line in File.ReadAllLines(f))
                {
                    string[] c = line.Split(';');
                    if (c.Length < 7) continue;
                    long t; if (!long.TryParse(c[0], out t)) continue;
                    l.Add(new S { T = t, Cpu = P(c[1]), CpuT = P(c[2]), Gpu = P(c[3]), GpuT = P(c[4]), Ram = P(c[5]), Fps = P(c[6]) });
                }
            }
            return l;
        }
        static float P(string s) { float v; return float.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out v) ? v : float.NaN; }

        // pontos de um intervalo (1h, 6h, 24h, 7d), reduzidos a ~600 (média por bloco)
        public static string HistoryJson(string range)
        {
            long secs = range == "1h" ? 3600 : range == "6h" ? 21600 : range == "7d" ? 7 * 86400 : 86400;
            List<S> src;
            if (secs <= 86400) { lock (lk) src = mem.Where(x => x.T >= Now - secs).ToList(); }
            else { Flush(); src = ReadDays(8).Where(x => x.T >= Now - secs).ToList(); }
            int buckets = 600; long step = Math.Max(10, secs / buckets);
            StringBuilder t = new StringBuilder(), a = new StringBuilder(), b = new StringBuilder(), c = new StringBuilder(), d = new StringBuilder(), e = new StringBuilder(), f = new StringBuilder();
            long start = Now - secs; bool first = true;
            int i = 0;
            for (long bt = start; bt < Now; bt += step)
            {
                List<S> blk = new List<S>();
                while (i < src.Count && src[i].T < bt + step) { if (src[i].T >= bt) blk.Add(src[i]); i++; }
                if (blk.Count == 0) continue;
                if (!first) { t.Append(','); a.Append(','); b.Append(','); c.Append(','); d.Append(','); e.Append(','); f.Append(','); }
                first = false;
                t.Append(bt + step / 2);
                a.Append(Avg(blk, x => x.Cpu)); b.Append(Avg(blk, x => x.CpuT)); c.Append(Avg(blk, x => x.Gpu));
                d.Append(Avg(blk, x => x.GpuT)); e.Append(Avg(blk, x => x.Ram)); f.Append(Avg(blk, x => x.Fps));
            }
            return "{\"ok\":true,\"range\":" + Js.S(range) + ",\"step\":" + step + ",\"t\":[" + t + "],\"cpu\":[" + a + "],\"cput\":[" + b + "],\"gpu\":[" + c +
                   "],\"gput\":[" + d + "],\"ram\":[" + e + "],\"fps\":[" + f + "]}";
        }
        // uma janela de tempo (para o gráfico de uma sessão de jogo): de 'from' a 'to' em segundos Unix, até 400 pontos
        public static string WindowJson(long from, long to)
        {
            if (to <= from) return "{\"ok\":false}";
            List<S> src;
            if (from >= Now - 86400) { lock (lk) src = mem.Where(x => x.T >= from && x.T <= to).ToList(); }
            else { Flush(); src = ReadDays(8).Where(x => x.T >= from && x.T <= to).ToList(); }
            long step = Math.Max(2, (to - from) / 400);
            StringBuilder t = new StringBuilder(), a = new StringBuilder(), b = new StringBuilder(), c = new StringBuilder(), d = new StringBuilder(), f = new StringBuilder();
            bool first = true; int i = 0;
            for (long bt = from; bt < to; bt += step)
            {
                List<S> blk = new List<S>();
                while (i < src.Count && src[i].T < bt + step) { if (src[i].T >= bt) blk.Add(src[i]); i++; }
                if (blk.Count == 0) continue;
                if (!first) { t.Append(','); a.Append(','); b.Append(','); c.Append(','); d.Append(','); f.Append(','); }
                first = false;
                t.Append(bt + step / 2); a.Append(Avg(blk, x => x.Cpu)); b.Append(Avg(blk, x => x.CpuT)); c.Append(Avg(blk, x => x.Gpu)); d.Append(Avg(blk, x => x.GpuT)); f.Append(Avg(blk, x => x.Fps));
            }
            return "{\"ok\":true,\"t\":[" + t + "],\"cpu\":[" + a + "],\"cput\":[" + b + "],\"gpu\":[" + c + "],\"gput\":[" + d + "],\"fps\":[" + f + "]}";
        }
        static string Avg(List<S> l, Func<S, float> g)
        {
            double s = 0; int n = 0;
            foreach (S x in l) { float v = g(x); if (!float.IsNaN(v)) { s += v; n++; } }
            return n == 0 ? "null" : Js.N(s / n);
        }

        // ---------------- sessões de jogo
        static void FinishSession()
        {
            Sess s = sess; sess = null;
            if (s == null) return;
            double mins = (DateTime.Now - s.Start).TotalMinutes;
            if (mins < 1) return;
            Res r = new Res { Game = s.Game, When = s.Start.ToString("dd/MM HH:mm", CultureInfo.InvariantCulture), Mins = mins,
                              CpuT = s.CpuTMax, GpuT = s.GpuTMax, Cpu = s.N > 0 ? s.CpuSum / s.N : double.NaN, Gpu = s.GpuN > 0 ? s.GpuSum / s.GpuN : double.NaN,
                              Avg = double.NaN, Low = double.NaN, Bott = Analise.TakeSession(), Thieves = Ladroes.TakeSession() };
            if (s.Fps.Count > 0)
            {
                r.Avg = s.Fps.Average(x => (double)x);
                float[] o = s.Fps.ToArray(); Array.Sort(o);
                r.Low = o[(int)Math.Floor(0.01 * (o.Length - 1))];     // o pior 1% dos segundos de jogo
            }
            LoadSessions();
            sessions.Insert(0, r);
            while (sessions.Count > 100) sessions.RemoveAt(sessions.Count - 1);
            SaveSessions();
            string txt = (mins >= 60 ? Math.Floor(mins / 60) + " h " + Math.Round(mins % 60) + " min" : Math.Round(mins) + " min") +
                         (double.IsNaN(r.Avg) ? "" : " · " + Math.Round(r.Avg) + " FPS") +
                         (double.IsNaN(r.GpuT) ? "" : " · GPU " + Math.Round(r.GpuT) + "°") + (double.IsNaN(r.CpuT) ? "" : " · CPU " + Math.Round(r.CpuT) + "°");
            ThreadPool.QueueUserWorkItem(delegate { try { Program.Notify("NEXUS · " + r.Game, txt); } catch { } });
        }
        static void LoadSessions()
        {
            if (sessions != null) return;
            sessions = new List<Res>();
            try
            {
                if (File.Exists(FileSess))
                    foreach (string line in File.ReadAllLines(FileSess, Encoding.UTF8))
                    {
                        string[] c = line.Split('|');
                        if (c.Length < 9) continue;
                        sessions.Add(new Res { Game = c[0], When = c[1], Mins = D(c[2]), Avg = D(c[3]), Low = D(c[4]), CpuT = D(c[5]), GpuT = D(c[6]), Cpu = D(c[7]), Gpu = D(c[8]), Bott = c.Length > 9 ? c[9] : "", Thieves = c.Length > 10 ? c[10] : "" });
                    }
            }
            catch { }
        }
        static double D(string s) { double v; return double.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out v) ? v : double.NaN; }
        static string W(double v) { return double.IsNaN(v) ? "" : v.ToString("0.#", CultureInfo.InvariantCulture); }
        static void SaveSessions()
        {
            try
            {
                Directory.CreateDirectory(AppSettings.Dir);
                File.WriteAllLines(FileSess, sessions.Select(r => string.Join("|", new[] { r.Game.Replace("|", "/"), r.When, W(r.Mins), W(r.Avg), W(r.Low), W(r.CpuT), W(r.GpuT), W(r.Cpu), W(r.Gpu), r.Bott ?? "", (r.Thieves ?? "").Replace("|", "/") })).ToArray(), new UTF8Encoding(false));
            }
            catch { }
        }
        // minutos da sessão de jogo atual (NaN se não há jogo)
        public static double SessionMins { get { lock (lk) return sess == null ? double.NaN : (DateTime.Now - sess.Start).TotalMinutes; } }
        public static void ReloadSessions() { lock (lk) sessions = null; }
        public static List<Res> Sessions() { lock (lk) { LoadSessions(); return sessions.ToList(); } }
        public static string SessionsJson()
        {
            lock (lk)
            {
                LoadSessions();
                StringBuilder sb = new StringBuilder("{\"ok\":true,\"current\":");
                if (sess != null) sb.Append("{\"game\":").Append(Js.S(sess.Game)).Append(",\"mins\":").Append(Js.N((DateTime.Now - sess.Start).TotalMinutes)).Append(",\"bott\":").Append(Js.S(Analise.Bottleneck)).Append('}');
                else sb.Append("null");
                sb.Append(",\"sessions\":[");
                bool first = true;
                foreach (Res r in sessions)
                {
                    if (!first) sb.Append(','); first = false;
                    sb.Append("{\"game\":").Append(Js.S(r.Game)).Append(",\"when\":").Append(Js.S(r.When)).Append(",\"mins\":").Append(Js.N(r.Mins))
                      .Append(",\"avg\":").Append(Js.N(r.Avg)).Append(",\"low\":").Append(Js.N(r.Low)).Append(",\"cput\":").Append(Js.N(r.CpuT))
                      .Append(",\"gput\":").Append(Js.N(r.GpuT)).Append(",\"cpu\":").Append(Js.N(r.Cpu)).Append(",\"gpu\":").Append(Js.N(r.Gpu)).Append(",\"bott\":").Append(Js.S(r.Bott)).Append(",\"thieves\":").Append(Js.S(r.Thieves)).Append('}');
                }
                return sb.Append("]}").ToString();
            }
        }
        public static string ClearSessions()
        {
            lock (lk) { LoadSessions(); sessions.Clear(); SaveSessions(); }
            return SessionsJson();
        }
    }

    // ------------------------------------------------------------ modo poupança: PC parado e sem jogo -> plano Equilibrado; volta ao mexer
    static class Eco
    {
        [StructLayout(LayoutKind.Sequential)] struct LASTINPUTINFO { public uint cbSize; public uint dwTime; }
        [DllImport("user32.dll")] static extern bool GetLastInputInfo(ref LASTINPUTINFO plii);
        const string BALANCED = "381b4222-f694-41f0-9685-ff5bb260df2e";
        static string prev;
        static bool active;
        public static bool Active { get { return active; } }

        static double IdleSeconds()
        {
            LASTINPUTINFO li = new LASTINPUTINFO(); li.cbSize = (uint)Marshal.SizeOf(typeof(LASTINPUTINFO));
            if (!GetLastInputInfo(ref li)) return 0;
            return unchecked((uint)Environment.TickCount - li.dwTime) / 1000.0;
        }
        static bool settled;     // já se viu que não havia nada a mudar (o plano já era o Equilibrado)
        public static void Check(bool gaming)
        {
            bool want = AppSettings.EcoOn && !gaming && IdleSeconds() >= AppSettings.EcoMin * 60;
            if (!want) { settled = false; if (active) Off(); return; }
            if (active || settled) return;
            string cur = Tweaks.ActiveScheme();
            if (cur == null || cur == BALANCED) { settled = true; return; }
            prev = cur; active = true;
            Tweaks.SetScheme(BALANCED);
        }
        public static void Off()
        {
            if (!active) return;
            active = false;
            if (prev != null) Tweaks.SetScheme(prev);
            prev = null;
        }
    }

    // ------------------------------------------------------------ saúde dos discos (SMART pelo Windows) e drivers
    static class Saude
    {
        static string disks; static DateTime disksAt = DateTime.MinValue, warnedAt = DateTime.MinValue;
        static readonly object lk = new object();

        static string Ps(string script, int ms) { return PsFile.Run("discos", script, ms); }

        // estado SMART de cada disco (cache de 10 min): saúde, temperatura, desgaste, horas ligado, erros
        public static string DisksJson()
        {
            lock (lk)
            {
                if (disks != null && (DateTime.Now - disksAt).TotalMinutes < 10) return disks;
                // NVMe: o desgaste vem do Windows (Percentage Used). SATA: o Windows quase nunca o dá, por isso lê-se o SMART do disco
                // (atributos de vida útil 231/169/202/233/173/177). Discos de pratos (HDD) não têm desgaste.
                string o = Ps(@"$sm = @(); try { $sm = @(Get-CimInstance -Namespace root\wmi -ClassName MSStorageDriver_FailurePredictData -ErrorAction Stop) } catch {}
$pf = @(); try { $pf = @(Get-CimInstance -Namespace root\wmi -ClassName MSStorageDriver_FailurePredictStatus -ErrorAction Stop) } catch {}
function Pf($n) { $k = ($n -replace '[^A-Za-z0-9]', '').ToUpper(); if ($k.Length -gt 12) { $k = $k.Substring(0, 12) }; if ($k.Length -lt 6) { return $null }
  foreach ($s in $pf) { if ((($s.InstanceName -replace '[^A-Za-z0-9]', '').ToUpper()).Contains($k)) { return [bool]$s.PredictFailure } }; return $null }
function Vs($n) { $k = ($n -replace '[^A-Za-z0-9]', '').ToUpper(); if ($k.Length -gt 12) { $k = $k.Substring(0, 12) }; if ($k.Length -lt 6) { return $null }
  foreach ($s in $sm) { if ((($s.InstanceName -replace '[^A-Za-z0-9]', '').ToUpper()).Contains($k)) { return [byte[]]$s.VendorSpecific } }; return $null }
function At($v, $id) { if (-not $v) { return $null }; for ($o = 2; $o + 12 -le $v.Length; $o += 12) { if ($v[$o] -eq $id) {
  return @{ cur = [int]$v[$o + 3]; raw = [uint64]$v[$o + 5] + ([uint64]$v[$o + 6] -shl 8) + ([uint64]$v[$o + 7] -shl 16) + ([uint64]$v[$o + 8] -shl 24) } } }; return $null }
$r = foreach ($d in Get-PhysicalDisk) { $c = $d | Get-StorageReliabilityCounter -ErrorAction SilentlyContinue
  $media = [string]$d.MediaType; $bus = [string]$d.BusType; $wear = $null; $hours = $c.PowerOnHours; $src = ''
  $v = Vs $d.FriendlyName
  if ($media -eq 'SSD' -and $bus -eq 'NVMe') { $wear = $c.Wear; $src = 'nvme' } elseif ($media -ne 'HDD') { foreach ($id in 231, 169, 202, 233, 177, 173) { $a = At $v $id; if ($a -and $a.cur -ge 1 -and $a.cur -le 100) { $wear = 100 - $a.cur; $src = 'smart'; break } } }
  if ($hours -eq $null) { $a = At $v 9; if ($a) { $hours = $a.raw } }
  [pscustomobject]@{ name = $d.FriendlyName; media = $media; bus = $bus; health = [string]$d.HealthStatus; size = $d.Size;
    temp = $c.Temperature; tempmax = $c.TemperatureMax; wear = $wear; wsrc = $src; hours = $hours; rerr = $c.ReadErrorsUncorrected; werr = $c.WriteErrorsUncorrected
    # porquê do aviso: estado do Windows e contadores SMART que mostram setores estragados ou problemas de ligação
    op = @($d.OperationalStatus | ForEach-Object { [string]$_ }); predict = (Pf $d.FriendlyName)
    realloc = (At $v 5).raw; pending = (At $v 197).raw; uncorr = (At $v 198).raw; crc = (At $v 199).raw; reported = (At $v 187).raw; spin = (At $v 10).raw } }
ConvertTo-Json -Compress -InputObject @($r)", 60000);
                if (!o.StartsWith("[")) o = "[]";
                disks = "{\"ok\":true,\"disks\":" + o + "}";
                disksAt = DateTime.Now;
                // aviso (uma vez por dia) se um disco não está saudável ou está quase gasto
                bool bad = System.Text.RegularExpressions.Regex.IsMatch(o, "\"health\":\"(Warning|Unhealthy)\"") ||
                           System.Text.RegularExpressions.Regex.Matches(o, "\"wear\":(\\d+)").Cast<System.Text.RegularExpressions.Match>().Any(m => int.Parse(m.Groups[1].Value) >= 90);
                if (bad && (DateTime.Now - warnedAt).TotalHours > 20)
                {
                    warnedAt = DateTime.Now;
                    ThreadPool.QueueUserWorkItem(delegate { try { Program.Notify("NEXUS · " + Lang.L("Disco"), Lang.L("Um disco precisa de atenção: vê a Saúde dos discos no Deep Scan.")); } catch { } });
                }
                return disks;
            }
        }
        public static void CheckLater() { ThreadPool.QueueUserWorkItem(delegate { Thread.Sleep(90000); try { DisksJson(); } catch { } }); }

        // placa gráfica: versão e data do driver, e a página oficial para ver se há mais recente
        public static string DriversJson()
        {
            StringBuilder sb = new StringBuilder("{\"ok\":true,\"gpus\":[");
            bool first = true;
            try
            {
                using (ManagementObjectSearcher q = new ManagementObjectSearcher("SELECT Name, DriverVersion, DriverDate FROM Win32_VideoController"))
                    foreach (ManagementObject m in q.Get())
                    {
                        string name = Convert.ToString(m["Name"]) ?? "", ver = Convert.ToString(m["DriverVersion"]) ?? "", dd = Convert.ToString(m["DriverDate"]) ?? "";
                        string l = name.ToLowerInvariant();
                        if (l.Contains("basic") || l.Contains("remote") || l.Contains("virtual") || l.Contains("parsec")) continue;
                        string vendor = l.Contains("nvidia") ? "NVIDIA" : (l.Contains("amd") || l.Contains("radeon")) ? "AMD" : l.Contains("intel") ? "Intel" : "";
                        string friendly = ver;
                        if (vendor == "NVIDIA") { string dg = ver.Replace(".", ""); if (dg.Length >= 5) { dg = dg.Substring(dg.Length - 5); friendly = dg.Substring(0, 3) + "." + dg.Substring(3); } }
                        int days = -1; string date = "";
                        if (dd.Length >= 8) { DateTime dt; if (DateTime.TryParseExact(dd.Substring(0, 8), "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out dt)) { days = (int)(DateTime.Now - dt).TotalDays; date = dt.ToString("dd/MM/yyyy"); } }
                        string url = vendor == "NVIDIA" ? "https://www.nvidia.com/drivers" : vendor == "AMD" ? "https://www.amd.com/support/download/drivers.html"
                                   : vendor == "Intel" ? "https://www.intel.com/content/www/us/en/support/detect.html" : "";
                        if (!first) sb.Append(','); first = false;
                        sb.Append("{\"name\":").Append(Js.S(name.Trim())).Append(",\"vendor\":").Append(Js.S(vendor)).Append(",\"version\":").Append(Js.S(ver))
                          .Append(",\"friendly\":").Append(Js.S(friendly)).Append(",\"date\":").Append(Js.S(date)).Append(",\"days\":").Append(days).Append(",\"url\":").Append(Js.S(url)).Append('}');
                    }
            }
            catch { }
            string os = "";
            try
            {
                using (RegistryKey k = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion"))
                {
                    string prod = Convert.ToString(k.GetValue("ProductName")), disp = Convert.ToString(k.GetValue("DisplayVersion")), build = Convert.ToString(k.GetValue("CurrentBuild"));
                    int b; if (int.TryParse(build, out b) && b >= 22000) prod = (prod ?? "").Replace("Windows 10", "Windows 11");
                    os = (prod + " " + disp + " (build " + build + "." + Convert.ToString(k.GetValue("UBR")) + ")").Trim();
                }
            }
            catch { }
            return sb.Append("],\"os\":").Append(Js.S(os)).Append('}').ToString();
        }
    }

    // ------------------------------------------------------------ PowerShell a partir de um ficheiro .ps1 normal (legível), em vez de comandos codificados
    static class PsFile
    {
        public static string Run(string name, string script, int ms)
        {
            try
            {
                string dir = Path.Combine(AppSettings.Dir, "scripts");
                Directory.CreateDirectory(dir);
                string f = Path.Combine(dir, "nexus_" + name + ".ps1");
                string body = "# NEXUS Monitor - " + name + " (criado pelo NEXUS; pode ser apagado)\r\n[Console]::OutputEncoding = [Text.Encoding]::UTF8\r\n" + script.Replace("\r\n", "\n").Replace("\n", "\r\n") + "\r\n";
                if (!File.Exists(f) || File.ReadAllText(f, Encoding.UTF8) != body) File.WriteAllText(f, body, new UTF8Encoding(true));
                ProcessStartInfo psi = new ProcessStartInfo("powershell.exe", "-NoProfile -ExecutionPolicy Bypass -File \"" + f + "\"");
                psi.StandardOutputEncoding = Encoding.UTF8; psi.StandardErrorEncoding = Encoding.UTF8;
                int code; return ProcOut.Run(psi, ms, out code, false).Trim();   // só a saída normal (os erros do PowerShell não são JSON)
            }
            catch { return ""; }
        }
    }

    // ------------------------------------------------------------ cópia de segurança: exportar / importar definições, perfis, medições e sessões
    static class Copia
    {
        static readonly string[] Files = { "settings.ini", "perfis.txt", "medicoes.txt", "sessoes.txt", "nexus23.ini", "mudancas.txt", "inventario.txt" };
        public static string ExportJson()
        {
            StringBuilder sb = new StringBuilder("{\"nexus\":" + Js.S(Assembly()) + ",\"date\":" + Js.S(DateTime.Now.ToString("yyyy-MM-dd HH:mm")) + ",\"files\":{");
            bool first = true;
            foreach (string f in Files)
            {
                string p = Path.Combine(AppSettings.Dir, f);
                if (!File.Exists(p)) continue;
                string t = File.ReadAllText(p, Encoding.UTF8);
                // o código de acesso do telemóvel nunca sai do PC
                if (f == "settings.ini" || f == "nexus23.ini") t = string.Join("\n", t.Replace("\r", "").Split('\n').Where(l => !l.StartsWith("token=") && !l.StartsWith("viewtok=")).ToArray());
                if (!first) sb.Append(','); first = false;
                sb.Append(Js.S(f)).Append(':').Append(Js.S(t));
            }
            sb.Append("},\"tweaks\":[");
            try { sb.Append(string.Join(",", Tweaks.ChangedIds().Select(x => Js.S(x)).ToArray())); } catch { }
            return sb.Append("]}").ToString();
        }
        static string Assembly() { Version v = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version; return v.Major + "." + v.Minor + (v.Build > 0 ? "." + v.Build : ""); }

        // corpo: uma linha por ficheiro "nome<TAB>base64" e, se escolhido, "tweaks<TAB>id1,id2"
        public static string Import(string body)
        {
            if (string.IsNullOrEmpty(body)) return "{\"ok\":false,\"error\":\"vazio\"}";
            int n = 0; string tweaks = null;
            foreach (string line in body.Replace("\r", "").Split('\n'))
            {
                int t = line.IndexOf('\t');
                if (t <= 0) continue;
                string name = line.Substring(0, t), val = line.Substring(t + 1);
                if (name == "tweaks") { tweaks = val; continue; }
                if (!Files.Contains(name)) continue;
                string text;
                try { text = Encoding.UTF8.GetString(Convert.FromBase64String(val)); } catch { continue; }
                string p = Path.Combine(AppSettings.Dir, name);
                if (name == "settings.ini")
                {
                    // mantém o código de acesso do telemóvel deste PC
                    string tok = File.Exists(p) ? File.ReadAllLines(p).FirstOrDefault(l => l.StartsWith("token=")) : null;
                    List<string> lines = text.Replace("\r", "").Split('\n').Where(l => !l.StartsWith("token=") && l.Trim() != "").ToList();
                    if (tok != null) lines.Add(tok);
                    text = string.Join("\r\n", lines.ToArray()) + "\r\n";
                }
                else if (name == "nexus23.ini")
                {
                    // o link do modo só de leitura deste PC também fica (a cópia nunca o leva)
                    string vt = Cfg23.Get("viewtok", null);
                    List<string> lines = text.Replace("\r", "").Split('\n').Where(l => !l.StartsWith("viewtok=") && l.Trim() != "").ToList();
                    if (!string.IsNullOrEmpty(vt)) lines.Add("viewtok=" + vt);
                    text = string.Join("\r\n", lines.ToArray()) + "\r\n";
                }
                try { Directory.CreateDirectory(AppSettings.Dir); File.WriteAllText(p, text, new UTF8Encoding(false)); n++; } catch { }
            }
            try { AppSettings.Load(); } catch { }
            try { Cfg23.Reload(); } catch { }   // antes ficava com as definições antigas na memória e a próxima gravação apagava as importadas
            try { Macros.OnStart(); } catch { }
            try { Perfis.Reload(); } catch { }
            try { Medicao.Reload(); } catch { }
            try { Historico.ReloadSessions(); } catch { }
            string applied = "";
            if (!string.IsNullOrEmpty(tweaks)) { try { applied = Tweaks.Bulk(true, tweaks); } catch { } }
            Program.Ui(GameOverlay.Apply);
            return "{\"ok\":true,\"files\":" + n + ",\"tweaks\":" + (applied == "" ? "null" : applied) + "}";
        }
    }
}
