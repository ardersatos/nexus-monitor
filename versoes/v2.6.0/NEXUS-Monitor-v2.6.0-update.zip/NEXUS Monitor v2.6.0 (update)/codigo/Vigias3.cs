// NEXUS // MONITOR 2.6 - vigias novas, tudo local (nada sai do PC):
// estatísticas do rato e do teclado, aviso de pó, fugas de memória, arranque escalonado, jogos atualizados,
// portas USB lentas e programas a trabalhar com o PC parado (mineradores).
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;
using Microsoft.Win32.SafeHandles;

namespace Nexus
{
    static class Vigias3
    {
        static int tick;
        static readonly Encoding Utf8 = new UTF8Encoding(false);
        public static string FileOf(string n) { return Path.Combine(AppSettings.Dir, n); }
        public static string[] Read(string n) { return SafeFile.ReadLines(FileOf(n), Utf8); }
        public static void Write(string n, IEnumerable<string> lines) { try { Directory.CreateDirectory(AppSettings.Dir); SafeFile.WriteLines(FileOf(n), lines.ToArray()); } catch { } }
        public static string Clean(string s) { return (s ?? "").Replace("|", "/").Replace("\r", " ").Replace("\n", " ").Trim(); }
        public static string F1(double v) { return v.ToString("0.#", CultureInfo.InvariantCulture); }

        public static void Start()
        {
            try { Entrada.Start(); } catch { }
        }

        // chamado pelo histórico a cada 2 s
        public static void Tick(double cpu, double? cpuT, double? gpu, double? gpuT, string game)
        {
            tick++;
            try { Entrada.Tick(game); } catch { }
            try { Vigias4.Tick(game); } catch { }
            try { Vigias5.Tick(); } catch { }
            try { Po.Sample(cpu, cpuT, gpu, gpuT); } catch { }
            if (tick % 30 == 0) ThreadPool.QueueUserWorkItem(delegate { try { Fugas.Sample(); } catch { } });              // 1 min
            if (tick % 15 == 7) ThreadPool.QueueUserWorkItem(delegate { try { Mineradores.Check(game); } catch { } });     // 30 s
            if (tick % 30 == 12) ThreadPool.QueueUserWorkItem(delegate { try { JogosAtualizados.Check(); } catch { } });  // 1 min
            if (tick == 10) ThreadPool.QueueUserWorkItem(delegate { try { Escalonado.OnStart(); } catch { } });
            if (tick % 30 == 20) { string g = game; ThreadPool.QueueUserWorkItem(delegate { try { Conquistas.Check(g); } catch { } }); }   // 1 min
            if (tick % 900 == 90) ThreadPool.QueueUserWorkItem(delegate { try { UsbLento.Check(true); } catch { } });      // 30 min
        }

        public static void Save()
        {
            try { Entrada.Save(); } catch { }
            try { Po.Save(); } catch { }
            try { Conquistas.FlushGame(); } catch { }
            try { RedeProg.Flush(); RedeProg.Stop(); } catch { }
        }

        // um aviso por coisa, no máximo uma vez a cada X horas (no PC e, se o ntfy estiver ligado, no telemóvel)
        public static void Notify(string key, string title, string text, int hours)
        {
            string k = "nv_" + Regex.Replace(key, "[^A-Za-z0-9_.-]", "_");
            if (k.Length > 80) k = k.Substring(0, 80);
            long last; long.TryParse(Cfg23.Get(k, "0"), out last);
            if (DateTime.UtcNow.Ticks - last < TimeSpan.FromHours(hours).Ticks) return;
            Cfg23.Set(k, DateTime.UtcNow.Ticks.ToString());
            Program.Notify(title, text);
        }

        // resumo para a barra de avisos do Painel (pó, fugas, mineradores, USB)
        public static string Json()
        {
            StringBuilder sb = new StringBuilder("{\"ok\":true");
            try { sb.Append(",\"po\":").Append(Po.Brief()); } catch { sb.Append(",\"po\":null"); }
            try { sb.Append(",\"leaks\":").Append(Fugas.Brief()); } catch { sb.Append(",\"leaks\":[]"); }
            try { sb.Append(",\"miner\":").Append(Mineradores.Brief()); } catch { sb.Append(",\"miner\":[]"); }
            try { sb.Append(",\"usb\":").Append(UsbLento.Brief()); } catch { sb.Append(",\"usb\":[]"); }
            try { sb.Append(",\"hosts\":").Append(Hosts.Brief()); } catch { sb.Append(",\"hosts\":null"); }
            try { sb.Append(",\"proxy\":").Append(VpnProxy.Brief()); } catch { sb.Append(",\"proxy\":null"); }
            try { sb.Append(",\"cam\":").Append(CamMic.Brief()); } catch { sb.Append(",\"cam\":[]"); }
            try { sb.Append(",\"router\":").Append(RedeCasa.Brief()); } catch { sb.Append(",\"router\":false"); }
            return sb.Append('}').ToString();
        }

        [StructLayout(LayoutKind.Sequential)] struct LASTINPUTINFO { public uint cbSize, dwTime; }
        [DllImport("user32.dll")] static extern bool GetLastInputInfo(ref LASTINPUTINFO l);
        public static double IdleSecs()
        {
            LASTINPUTINFO l = new LASTINPUTINFO(); l.cbSize = (uint)Marshal.SizeOf(l);
            if (!GetLastInputInfo(ref l)) return 0;
            return unchecked((uint)Environment.TickCount - l.dwTime) / 1000.0;
        }
        [DllImport("kernel32.dll")] static extern ulong GetTickCount64();
        public static double UptimeMin { get { try { return GetTickCount64() / 60000.0; } catch { return 9999; } } }
    }

    // ============================================================ entrada "raw input" partilhada
    // O Windows só deixa UMA janela por programa receber o raw input do teclado/rato: os atalhos presos a um dispositivo
    // (Macros) e as estatísticas usam esta, em vez de cada um registar a sua e roubar ao outro.
    static class RawHub
    {
        [StructLayout(LayoutKind.Sequential)] struct RID { public ushort page, usage; public uint flags; public IntPtr target; }
        [DllImport("user32.dll")] static extern bool RegisterRawInputDevices(RID[] d, uint n, uint size);
        [DllImport("user32.dll")] static extern uint GetRawInputData(IntPtr h, uint cmd, IntPtr data, ref uint size, uint hsize);
        [DllImport("user32.dll")] static extern bool PostMessage(IntPtr h, int msg, IntPtr w, IntPtr l);

        static readonly object lk = new object();
        static Thread th; static Win win;
        static bool Want { get { return Macros.WantRaw || Entrada.On; } }

        public static void Sync()
        {
            lock (lk)
            {
                if (th == null)
                {
                    if (!Want) return;
                    th = new Thread(Loop) { IsBackground = true, Name = "NEXUS entrada" };
                    th.SetApartmentState(ApartmentState.STA);
                    th.Start();
                }
                else if (win != null) win.Post(0x8001);
            }
        }
        static void Loop()
        {
            try { Win w = new Win(); lock (lk) win = w; w.Apply(); if (w.Handle != IntPtr.Zero) Application.Run(); }
            catch { }
            finally { lock (lk) { win = null; th = null; } }
            if (Want) Sync();   // ligaram outra vez enquanto fechava
        }

        class Win : NativeWindow
        {
            bool on;
            readonly IntPtr buf = Marshal.AllocHGlobal(256);   // um só buffer: o rato pode mandar milhares de mensagens por segundo
            public Win() { CreateParams cp = new CreateParams(); cp.Parent = new IntPtr(-3); CreateHandle(cp); }
            public void Post(int m) { try { if (Handle != IntPtr.Zero) PostMessage(Handle, m, IntPtr.Zero, IntPtr.Zero); } catch { } }
            public void Apply()
            {
                bool want = Want;
                if (want != on)
                {
                    RID[] d = { new RID { page = 1, usage = 6, flags = want ? 0x100u : 0x1u, target = want ? Handle : IntPtr.Zero },
                                new RID { page = 1, usage = 2, flags = want ? 0x100u : 0x1u, target = want ? Handle : IntPtr.Zero } };
                    RegisterRawInputDevices(d, 2, (uint)Marshal.SizeOf(typeof(RID)));
                    on = want;
                }
                if (!want) { try { DestroyHandle(); } catch { } Application.ExitThread(); }
            }
            protected override void WndProc(ref Message m)
            {
                if (m.Msg == 0x8001) { Apply(); return; }
                if (m.Msg == 0x00FF) { try { Input(m.LParam); } catch { } }
                base.WndProc(ref m);
            }
            void Input(IntPtr h)
            {
                uint hs = (uint)(IntPtr.Size == 8 ? 24 : 16), size = 256;
                uint got = GetRawInputData(h, 0x10000003, buf, ref size, hs);
                if (got == 0 || got == uint.MaxValue) return;
                uint type = (uint)Marshal.ReadInt32(buf);
                IntPtr dev = Marshal.ReadIntPtr(buf, 8);
                if (dev == IntPtr.Zero) return;   // teclas e cliques simulados (macros, programas) não contam
                int o = (int)hs;
                if (type == 1)   // teclado: MakeCode(2) Flags(2) Reserved(2) VKey(2) Message(4)
                {
                    int vk = (ushort)Marshal.ReadInt16(buf, o + 6), msg = Marshal.ReadInt32(buf, o + 8);
                    bool down = msg == 0x100 || msg == 0x104, up = msg == 0x101 || msg == 0x105;
                    if (!down && !up) return;
                    if (Entrada.On) Entrada.Key(vk, down);
                    if (Macros.WantRaw) Macros.OnRawKey(vk, down, dev);
                }
                else if (type == 0)   // rato: flags(2) pad(2) buttonFlags(2) buttonData(2) rawButtons(4) lastX(4) lastY(4)
                {
                    int fl = (ushort)Marshal.ReadInt16(buf, o), bf = (ushort)Marshal.ReadInt16(buf, o + 4);
                    short bd = Marshal.ReadInt16(buf, o + 6);
                    int dx = Marshal.ReadInt32(buf, o + 12), dy = Marshal.ReadInt32(buf, o + 16);
                    if (Entrada.On) Entrada.Mouse(fl, bf, bd, dx, dy);
                    if (bf != 0 && Macros.WantRaw) Macros.OnRawMouse(bf, dev);
                }
            }
        }
    }

    // ============================================================ 6. estatísticas do rato e do teclado
    // Conta teclas, cliques e a distância do rato. NUNCA guarda o que escreves: só quantas vezes cada tecla foi carregada.
    static class Entrada
    {
        public static volatile bool On;
        static readonly object lk = new object();
        static readonly bool[] down = new bool[256];
        static long[] heat = new long[256];
        class Day { public string D; public long Keys, L, R, M, X, Wheel, Acts; public double Meters; public int GameSec; }
        static readonly List<Day> days = new List<Day>();
        static readonly Dictionary<string, long[]> games = new Dictionary<string, long[]>(StringComparer.OrdinalIgnoreCase);   // jogo -> [segundos, ações]
        static Day today; static string curGame; static bool loaded, dirty; static DateTime lastSave = DateTime.UtcNow;
        static double dpi = 800; static string dpiSrc = "default", dpiName = "";
        const string FILE = "entrada.txt";

        public static void Start() { On = Cfg23.On("instat", false); if (On) { Load(); RawHub.Sync(); } }
        public static string SetOn(bool on)
        {
            Cfg23.Set("instat", on ? "1" : "0");
            if (on) Load(); else Save();
            On = on; RawHub.Sync();
            return Json();
        }
        public static string SetDpi(string v)
        {
            int d; int.TryParse(v ?? "", out d);
            Cfg23.Set("instat_dpi", d >= 100 && d <= 40000 ? d.ToString() : null);
            RefreshDpi(); return Json();
        }
        public static string Reset()
        {
            Load();
            lock (lk) { days.Clear(); games.Clear(); heat = new long[256]; today = null; Roll(); dirty = true; }
            Save(); return Json();
        }

        static void Load()
        {
            lock (lk)
            {
                if (loaded) return; loaded = true;
                foreach (string l in Vigias3.Read(FILE))
                {
                    string[] p = l.Split('|');
                    try
                    {
                        if (p[0] == "d" && p.Length >= 11)
                            days.Add(new Day { D = p[1], Keys = long.Parse(p[2]), L = long.Parse(p[3]), R = long.Parse(p[4]), M = long.Parse(p[5]), X = long.Parse(p[6]), Wheel = long.Parse(p[7]),
                                               Meters = double.Parse(p[8], CultureInfo.InvariantCulture), GameSec = int.Parse(p[9]), Acts = long.Parse(p[10]) });
                        else if (p[0] == "h" && p.Length >= 2)
                            foreach (string kv in p[1].Split(','))
                            { string[] a = kv.Split(':'); int vk; long c; if (a.Length == 2 && int.TryParse(a[0], out vk) && long.TryParse(a[1], out c) && vk > 0 && vk < 256) heat[vk] = c; }
                        else if (p[0] == "g" && p.Length >= 4) games[p[1]] = new[] { long.Parse(p[2]), long.Parse(p[3]) };
                    }
                    catch { }
                }
                Roll();
            }
        }
        static void Roll()
        {
            string d = DateTime.Now.ToString("yyyy-MM-dd");
            if (today != null && today.D == d) return;
            today = days.FirstOrDefault(x => x.D == d);
            if (today == null) { today = new Day { D = d }; days.Add(today); }
            if (days.Count > 400) days.RemoveRange(0, days.Count - 400);
        }
        public static void Save()
        {
            List<string> l = new List<string> { "v1" };
            lock (lk)
            {
                if (!loaded || !dirty) return;
                foreach (Day d in days)
                    l.Add("d|" + d.D + "|" + d.Keys + "|" + d.L + "|" + d.R + "|" + d.M + "|" + d.X + "|" + d.Wheel + "|" + d.Meters.ToString("0.###", CultureInfo.InvariantCulture) + "|" + d.GameSec + "|" + d.Acts);
                StringBuilder h = new StringBuilder("h|");
                for (int i = 1; i < 256; i++) if (heat[i] > 0) h.Append(i).Append(':').Append(heat[i]).Append(',');
                l.Add(h.ToString().TrimEnd(','));
                foreach (KeyValuePair<string, long[]> g in games) l.Add("g|" + Vigias3.Clean(g.Key) + "|" + g.Value[0] + "|" + g.Value[1]);
                dirty = false; lastSave = DateTime.UtcNow;
            }
            Vigias3.Write(FILE, l);
        }

        public static void Key(int vk, bool isDown)
        {
            if (vk <= 0 || vk > 255) return;
            lock (lk)
            {
                if (!isDown) { down[vk] = false; return; }
                if (down[vk]) return;   // tecla presa a repetir: conta uma vez
                down[vk] = true;
                if (today == null) return;
                today.Keys++; heat[vk]++; dirty = true;
                Act();
            }
        }
        public static void Mouse(int flags, int bf, short wheel, int dx, int dy)
        {
            lock (lk)
            {
                if (today == null) return;
                if ((flags & 1) == 0 && (dx != 0 || dy != 0)) today.Meters += Math.Sqrt((double)dx * dx + (double)dy * dy) / dpi * 0.0254;
                if (bf == 0) return;
                if ((bf & 0x001) != 0) { today.L++; Act(); }
                if ((bf & 0x004) != 0) { today.R++; Act(); }
                if ((bf & 0x010) != 0) { today.M++; Act(); }
                if ((bf & 0x040) != 0 || (bf & 0x100) != 0) { today.X++; Act(); }
                if ((bf & 0x400) != 0) today.Wheel += Math.Max(1, Math.Abs((int)wheel) / 120);
                dirty = true;
            }
        }
        static void Act()
        {
            if (curGame == null) return;
            today.Acts++;
            long[] g; if (!games.TryGetValue(curGame, out g)) games[curGame] = g = new long[2];
            g[1]++;
        }

        static int tk;
        public static void Tick(string game)
        {
            if (!On) return;
            if (++tk % 15 == 1) RefreshDpi();   // de 30 em 30 s
            lock (lk)
            {
                if (!loaded) return;
                Roll();
                curGame = game;
                if (game != null)
                {
                    today.GameSec += 2;
                    long[] g; if (!games.TryGetValue(game, out g)) games[game] = g = new long[2];
                    g[0] += 2; dirty = true;
                }
            }
            if ((DateTime.UtcNow - lastSave).TotalMinutes >= 5) Save();
        }
        static void RefreshDpi()
        {
            int man = Cfg23.Int("instat_dpi", 0);
            if (man >= 100) { dpi = man; dpiSrc = "manual"; dpiName = ""; return; }
            try
            {
                Aparelho a = Aparelhos.All.FirstOrDefault(x => x.Kind == "mouse" && x.Dpi > 0);
                if (a != null) { dpi = a.Dpi; dpiSrc = "mouse"; dpiName = a.Name; return; }
            }
            catch { }
            dpi = 800; dpiSrc = "default"; dpiName = "";
        }

        // para as conquistas: totais e o melhor APM (jogos com 30+ minutos)
        public static void Totals(out long keys, out long clicks, out double meters, out double apm)
        {
            keys = clicks = 0; meters = apm = 0;
            if (!On && !File.Exists(Vigias3.FileOf(FILE))) return;
            Load();
            lock (lk)
            {
                keys = days.Sum(d => d.Keys); clicks = days.Sum(d => d.L + d.R + d.M + d.X); meters = days.Sum(d => d.Meters);
                foreach (long[] g in games.Values) if (g[0] >= 1800) apm = Math.Max(apm, g[1] / (g[0] / 60.0));
            }
        }
        public static string Json()
        {
            if (On) Load();
            StringBuilder sb = new StringBuilder("{\"ok\":true,\"on\":" + (On ? "true" : "false"));
            sb.Append(",\"dpi\":").Append((int)dpi).Append(",\"dpiSrc\":").Append(Js.S(dpiSrc)).Append(",\"dpiName\":").Append(Js.S(dpiName));
            lock (lk)
            {
                Func<Day, string> dj = d => "{\"d\":" + Js.S(d.D) + ",\"keys\":" + d.Keys + ",\"l\":" + d.L + ",\"r\":" + d.R + ",\"m\":" + d.M + ",\"x\":" + d.X +
                    ",\"clicks\":" + (d.L + d.R + d.M + d.X) + ",\"wheel\":" + d.Wheel + ",\"meters\":" + Vigias3.F1(d.Meters) + ",\"gsec\":" + d.GameSec + ",\"acts\":" + d.Acts + "}";
                sb.Append(",\"today\":").Append(today != null ? dj(today) : "null");
                sb.Append(",\"days\":[").Append(string.Join(",", days.Skip(Math.Max(0, days.Count - 30)).Select(dj))).Append(']');
                long tk2 = days.Sum(d => d.Keys), tc = days.Sum(d => d.L + d.R + d.M + d.X); double tm = days.Sum(d => d.Meters);
                sb.Append(",\"tot\":{\"keys\":").Append(tk2).Append(",\"clicks\":").Append(tc).Append(",\"meters\":").Append(Vigias3.F1(tm))
                  .Append(",\"days\":").Append(days.Count).Append(",\"since\":").Append(Js.S(days.Count > 0 ? days[0].D : "")).Append('}');
                sb.Append(",\"heat\":{");
                bool first = true;
                for (int i = 1; i < 256; i++) if (heat[i] > 0) { if (!first) sb.Append(','); first = false; sb.Append('"').Append(i).Append("\":").Append(heat[i]); }
                sb.Append('}');
                sb.Append(",\"games\":[").Append(string.Join(",", games.Where(g => g.Value[0] >= 60).OrderByDescending(g => g.Value[0]).Take(12)
                    .Select(g => "{\"n\":" + Js.S(g.Key) + ",\"min\":" + (g.Value[0] / 60) + ",\"apm\":" + Vigias3.F1(g.Value[1] / (g.Value[0] / 60.0)) + "}"))).Append(']');
            }
            return sb.Append('}').ToString();
        }
    }

    // ============================================================ 17. aviso de pó
    // Compara quanto o processador e a placa aquecem acima do repouso (com carga parecida) agora e há 1–4 meses.
    // Usar a diferença carga − repouso tira quase todo o efeito da temperatura da sala (verão/inverno).
    static class Po
    {
        static readonly object lk = new object();
        static string day; static int[] cI = new int[126], cL = new int[126], gI = new int[126], gL = new int[126];
        static Dictionary<string, string> rows; static DateTime lastSave = DateTime.UtcNow;
        const string FILE = "po.txt"; const int MIN_N = 150;   // 5 minutos de amostras de 2 s

        static void Load()
        {
            if (rows != null) return;
            rows = new Dictionary<string, string>();
            foreach (string l in Vigias3.Read(FILE)) { int i = l.IndexOf('|'); if (i == 10) rows[l.Substring(0, 10)] = l.Substring(11); }
            // o dia de hoje continua a contar a partir do que estava gravado não é possível (só há medianas): recomeça
        }
        public static void Sample(double cpu, double? cpuT, double? gpu, double? gpuT)
        {
            lock (lk)
            {
                Load();
                string d = DateTime.Now.ToString("yyyy-MM-dd");
                if (day != d)
                {
                    if (day != null) Commit();
                    day = d; Array.Clear(cI, 0, 126); Array.Clear(cL, 0, 126); Array.Clear(gI, 0, 126); Array.Clear(gL, 0, 126);
                    string old; if (rows.TryGetValue(d, out old)) Seed(old);   // o NEXUS reiniciou a meio do dia
                }
                if (cpuT.HasValue && cpuT.Value > 15 && cpuT.Value < 120 && !double.IsNaN(cpu))
                { int t = (int)Math.Round(cpuT.Value); if (cpu < 12) cI[t]++; else if (cpu >= 60) cL[t]++; }
                if (gpu.HasValue && gpuT.HasValue && gpuT.Value > 15 && gpuT.Value < 120)
                { int t = (int)Math.Round(gpuT.Value); if (gpu.Value < 10) gI[t]++; else if (gpu.Value >= 80) gL[t]++; }
            }
            if ((DateTime.UtcNow - lastSave).TotalMinutes >= 10) { Save(); Evaluate(); }
        }
        // repõe as contagens do dia a partir das medianas gravadas (aproximado: n amostras na mediana)
        static void Seed(string r)
        {
            string[] p = r.Split('|'); if (p.Length < 8) return;
            int[][] hs = { cI, gI, cL, gL }; int[] mi = { 0, 2, 1, 3 }, ni = { 4, 6, 5, 7 };
            for (int k = 0; k < 4; k++) { int m, n; if (int.TryParse(p[mi[k]], out m) && int.TryParse(p[ni[k]], out n) && m > 0 && m < 126) hs[k][m] += n; }
        }
        static int Med(int[] h, out int n)
        {
            n = 0; foreach (int x in h) n += x;
            if (n == 0) return -1;
            int half = (n + 1) / 2, acc = 0;
            for (int i = 0; i < h.Length; i++) { acc += h[i]; if (acc >= half) return i; }
            return -1;
        }
        static void Commit()
        {
            if (day == null) return;
            int a, b, c, d;
            int mcI = Med(cI, out a), mcL = Med(cL, out b), mgI = Med(gI, out c), mgL = Med(gL, out d);
            if (a + b + c + d == 0) return;
            rows[day] = mcI + "|" + mcL + "|" + mgI + "|" + mgL + "|" + a + "|" + b + "|" + c + "|" + d;
        }
        public static void Save()
        {
            List<string> l;
            lock (lk)
            {
                if (rows == null) return;
                Commit();
                string cut = DateTime.Now.AddDays(-200).ToString("yyyy-MM-dd");
                l = rows.Where(x => string.CompareOrdinal(x.Key, cut) >= 0).OrderBy(x => x.Key).Select(x => x.Key + "|" + x.Value).ToList();
                lastSave = DateTime.UtcNow;
            }
            Vigias3.Write(FILE, l);
        }
        public static string Reset()
        {
            Cfg23.Set("po_reset", DateTime.Now.ToString("yyyy-MM-dd"));
            Conquistas.Mark("limpo");
            return Json();
        }

        class Res { public double Base = double.NaN, Recent = double.NaN, Rise = double.NaN; public int NB, NR; }
        static double Median(List<double> v) { if (v.Count == 0) return double.NaN; v.Sort(); int n = v.Count; return n % 2 == 1 ? v[n / 2] : (v[n / 2 - 1] + v[n / 2]) / 2; }
        // delta por dia (carga − repouso) dos dias com dados suficientes
        static List<KeyValuePair<DateTime, double>> Deltas(bool gpuSide)
        {
            List<KeyValuePair<DateTime, double>> r = new List<KeyValuePair<DateTime, double>>();
            string reset = Cfg23.Get("po_reset", "");
            lock (lk)
            {
                Load(); Commit();
                foreach (KeyValuePair<string, string> x in rows)
                {
                    if (reset != "" && string.CompareOrdinal(x.Key, reset) < 0) continue;
                    string[] p = x.Value.Split('|'); if (p.Length < 8) continue;
                    int idle, load, ni, nl;
                    int o = gpuSide ? 2 : 0;
                    if (!int.TryParse(p[o], out idle) || !int.TryParse(p[o + 1], out load) || !int.TryParse(p[o + 4], out ni) || !int.TryParse(p[o + 5], out nl)) continue;
                    if (idle <= 0 || load <= 0 || ni < MIN_N || nl < MIN_N) continue;
                    DateTime d; if (!DateTime.TryParseExact(x.Key, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out d)) continue;
                    r.Add(new KeyValuePair<DateTime, double>(d, load - idle));
                }
            }
            return r.OrderBy(x => x.Key).ToList();
        }
        static Res Analyze(bool gpuSide)
        {
            Res r = new Res();
            List<KeyValuePair<DateTime, double>> d = Deltas(gpuSide);
            DateTime now = DateTime.Now.Date;
            List<double> rec = d.Where(x => (now - x.Key).TotalDays <= 21).Select(x => x.Value).ToList();
            if (rec.Count > 10) rec = rec.Skip(rec.Count - 10).ToList();
            List<double> bas = d.Where(x => (now - x.Key).TotalDays >= 28 && (now - x.Key).TotalDays <= 150).Select(x => x.Value).ToList();
            r.NR = rec.Count; r.NB = bas.Count;
            if (rec.Count >= 3) r.Recent = Median(rec);
            if (bas.Count >= 4) r.Base = Median(bas);
            if (!double.IsNaN(r.Recent) && !double.IsNaN(r.Base)) r.Rise = r.Recent - r.Base;
            return r;
        }
        static string level = "learning";
        static void Evaluate()
        {
            Res c = Analyze(false), g = Analyze(true);
            double rise = Math.Max(double.IsNaN(c.Rise) ? -99 : c.Rise, double.IsNaN(g.Rise) ? -99 : g.Rise);
            level = double.IsNaN(c.Rise) && double.IsNaN(g.Rise) ? "learning" : rise >= 10 ? "strong" : rise >= 6 ? "warn" : "ok";
            if (level == "warn" || level == "strong")
                Vigias3.Notify("po", "NEXUS · " + Lang.L("Pó no PC?"),
                    Lang.L("O PC aquece mais do que há uns meses com a mesma carga") + " (+" + Math.Round(rise) + " °C). " + Lang.L("Pode estar na hora de limpar o pó das ventoinhas e filtros."), 24 * 14);
        }
        static string R(Res r) { Func<double, string> f = v => double.IsNaN(v) ? "null" : Vigias3.F1(v); return "{\"base\":" + f(r.Base) + ",\"recent\":" + f(r.Recent) + ",\"rise\":" + f(r.Rise) + ",\"nb\":" + r.NB + ",\"nr\":" + r.NR + "}"; }
        public static string Json()
        {
            Evaluate();
            Res c = Analyze(false), g = Analyze(true);
            List<KeyValuePair<DateTime, double>> dc = Deltas(false), dg = Deltas(true);
            int validDays = dc.Select(x => x.Key).Union(dg.Select(x => x.Key)).Distinct().Count();
            string first; lock (lk) { Load(); first = rows.Keys.OrderBy(x => x).FirstOrDefault() ?? ""; }
            DateTime from = DateTime.Now.Date.AddDays(-90);
            Dictionary<DateTime, double> mc = dc.Where(x => x.Key >= from).ToDictionary(x => x.Key, x => x.Value), mg = dg.Where(x => x.Key >= from).ToDictionary(x => x.Key, x => x.Value);
            string series = string.Join(",", mc.Keys.Union(mg.Keys).OrderBy(x => x).Select(d =>
            { double v; return "{\"d\":" + Js.S(d.ToString("yyyy-MM-dd")) + ",\"c\":" + (mc.TryGetValue(d, out v) ? Vigias3.F1(v) : "null") + ",\"g\":" + (mg.TryGetValue(d, out v) ? Vigias3.F1(v) : "null") + "}"; }));
            return "{\"ok\":true,\"level\":" + Js.S(level) + ",\"days\":" + validDays + ",\"since\":" + Js.S(first) + ",\"reset\":" + Js.S(Cfg23.Get("po_reset", "")) +
                   ",\"cpu\":" + R(c) + ",\"gpu\":" + R(g) + ",\"series\":[" + series + "]}";
        }
        public static string Brief()
        {
            if (level != "warn" && level != "strong") return "null";
            Res c = Analyze(false), g = Analyze(true);
            double rise = Math.Max(double.IsNaN(c.Rise) ? -99 : c.Rise, double.IsNaN(g.Rise) ? -99 : g.Rise);
            return "{\"level\":" + Js.S(level) + ",\"rise\":" + Vigias3.F1(rise) + ",\"part\":" + Js.S(!double.IsNaN(g.Rise) && (double.IsNaN(c.Rise) || g.Rise >= c.Rise) ? "gpu" : "cpu") + "}";
        }
    }

    // ============================================================ 23. fugas de memória
    // Um programa que ocupa cada vez mais RAM durante horas, sem nunca a devolver. Lê a memória de todos de minuto a minuto
    // (sem abrir os processos: vem da lista do Windows).
    static class Fugas
    {
        class P { public int Pid; public string Name; public DateTime First; public readonly List<KeyValuePair<DateTime, double>> S = new List<KeyValuePair<DateTime, double>>(); }
        class Sus { public string Name; public int Pid; public double Mb, Start, Rate, R2; public int Mins; }
        static readonly object lk = new object();
        static readonly Dictionary<int, P> ps = new Dictionary<int, P>();
        static List<Sus> sus = new List<Sus>(), grow = new List<Sus>();
        static int busy; static DateTime started = DateTime.UtcNow;
        static readonly HashSet<string> skip = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "System", "Idle", "Registry", "Memory Compression", "vmmem", "vmmemWSL", "Secure System" };

        public static void Sample()
        {
            if (Interlocked.Exchange(ref busy, 1) == 1) return;
            try
            {
                DateTime now = DateTime.UtcNow; HashSet<int> seen = new HashSet<int>();
                foreach (Process p in Process.GetProcesses())
                {
                    try
                    {
                        int id = p.Id; if (id <= 4) continue;
                        string n = p.ProcessName; if (skip.Contains(n)) continue;
                        double mb = p.PrivateMemorySize64 / 1048576.0;
                        seen.Add(id);
                        lock (lk)
                        {
                            P x; if (!ps.TryGetValue(id, out x) || x.Name != n) { x = new P { Pid = id, Name = n, First = now }; ps[id] = x; }
                            x.S.Add(new KeyValuePair<DateTime, double>(now, mb));
                            Thin(x, now);
                        }
                    }
                    catch { }
                    finally { p.Dispose(); }
                }
                lock (lk) foreach (int id in ps.Keys.Where(k => !seen.Contains(k)).ToList()) ps.Remove(id);
                Evaluate(now);
            }
            finally { Interlocked.Exchange(ref busy, 0); }
        }
        // as últimas 2 h ficam todas (1 por minuto); antes disso, uma a cada 10 minutos (até 24 h)
        static void Thin(P x, DateTime now)
        {
            if (x.S.Count < 200) return;
            List<KeyValuePair<DateTime, double>> keep = new List<KeyValuePair<DateTime, double>>();
            DateTime last = DateTime.MinValue;
            foreach (KeyValuePair<DateTime, double> s in x.S)
            {
                double age = (now - s.Key).TotalHours;
                if (age > 24) continue;
                if (age <= 2 || (s.Key - last).TotalMinutes >= 10) { keep.Add(s); last = s.Key; }
            }
            x.S.Clear(); x.S.AddRange(keep);
        }
        static void Evaluate(DateTime now)
        {
            List<Sus> s = new List<Sus>(), g = new List<Sus>();
            lock (lk)
            {
                foreach (P x in ps.Values)
                {
                    int mins = (int)(now - x.First).TotalMinutes;
                    if (mins < 30 || x.S.Count < 15) continue;
                    List<KeyValuePair<DateTime, double>> w = x.S.Where(v => (now - v.Key).TotalHours <= 6).ToList();
                    if (w.Count < 15) continue;
                    // regressão linear: MB por hora e quão "a direito" sobe (R²)
                    double n = w.Count, sx = 0, sy = 0, sxx = 0, sxy = 0, syy = 0;
                    DateTime t0 = w[0].Key;
                    foreach (KeyValuePair<DateTime, double> v in w) { double t = (v.Key - t0).TotalHours, y = v.Value; sx += t; sy += y; sxx += t * t; sxy += t * y; syy += y * y; }
                    double den = n * sxx - sx * sx; if (den <= 0) continue;
                    double slope = (n * sxy - sx * sy) / den;
                    double vy = n * syy - sy * sy, r2 = vy <= 0 ? 0 : Math.Pow(n * sxy - sx * sy, 2) / (den * vy);
                    double start = w.Take(3).Min(v => v.Value), cur = w[w.Count - 1].Value;
                    Sus z = new Sus { Name = x.Name, Pid = x.Pid, Mb = cur, Start = start, Rate = slope, R2 = r2, Mins = mins };
                    if (slope > 20 && r2 > 0.5 && cur > 150) g.Add(z);
                    if (mins >= 90 && cur >= 300 && cur - start >= 300 && cur >= start * 1.5 && slope >= 50 && r2 >= 0.75) s.Add(z);
                }
            }
            sus = s.OrderByDescending(x => x.Rate).ToList();
            grow = g.OrderByDescending(x => x.Rate).Take(6).ToList();
            foreach (Sus z in sus.Take(2))
                Vigias3.Notify("leak_" + z.Name, "NEXUS · " + Lang.L("Programa a gastar cada vez mais RAM"),
                    z.Name + ": " + Math.Round(z.Mb) + " MB (+" + Math.Round(z.Rate) + " MB/h). " + Lang.L("Fechar e voltar a abrir esse programa liberta a memória."), 12);
        }
        static string J(Sus z) { return "{\"n\":" + Js.S(z.Name) + ",\"pid\":" + z.Pid + ",\"mb\":" + Math.Round(z.Mb) + ",\"start\":" + Math.Round(z.Start) + ",\"rate\":" + Math.Round(z.Rate) + ",\"r2\":" + z.R2.ToString("0.00", CultureInfo.InvariantCulture) + ",\"mins\":" + z.Mins + "}"; }
        public static string Json()
        {
            return "{\"ok\":true,\"watch\":" + (int)(DateTime.UtcNow - started).TotalMinutes + ",\"sus\":[" + string.Join(",", sus.Select(J)) + "],\"grow\":[" + string.Join(",", grow.Select(J)) + "]}";
        }
        public static string Brief() { return "[" + string.Join(",", sus.Take(3).Select(J)) + "]"; }
        // fechar o programa (pedido do utilizador no PC): o processo tem de ser o mesmo que está na lista
        public static string Kill(string pid)
        {
            int id; if (!int.TryParse(pid ?? "", out id)) return Ps23.Ok(false, "?");
            Sus z = sus.Concat(grow).FirstOrDefault(x => x.Pid == id);
            if (z == null) return Ps23.Ok(false, Lang.L("Já não está na lista."));
            try { using (Process p = Process.GetProcessById(id)) { if (p.ProcessName != z.Name) return Ps23.Ok(false, "?"); p.CloseMainWindow(); if (!p.WaitForExit(4000)) p.Kill(); } }
            catch (Exception e) { return Ps23.Ok(false, e.Message); }
            Conquistas.Mark("cacador");
            lock (lk) ps.Remove(id);
            sus.RemoveAll(x => x.Pid == id); grow.RemoveAll(x => x.Pid == id);
            return Json();
        }
    }

    // ============================================================ 24. arranque escalonado
    // Os programas escolhidos deixam de arrancar com o Windows (desligados como no Gestor de Tarefas) e é o NEXUS que os
    // abre, um de cada vez, depois de o PC acalmar. Voltar atrás repõe o arranque normal do Windows.
    static class Escalonado
    {
        const string FILE = "arranque_escalonado.txt";
        static readonly object lk = new object();
        static volatile string status = "";
        class E { public string Id, Name, Cmd; }
        static List<E> Load()
        {
            List<E> l = new List<E>();
            foreach (string s in Vigias3.Read(FILE)) { string[] p = s.Split('\t'); if (p.Length >= 3 && p[0] != "") l.Add(new E { Id = p[0], Name = p[1], Cmd = p[2] }); }
            return l;
        }
        static void SaveList(List<E> l) { Vigias3.Write(FILE, l.Select(e => e.Id.Replace("\t", " ") + "\t" + e.Name.Replace("\t", " ") + "\t" + e.Cmd.Replace("\t", " "))); }

        public static string Json()
        {
            List<E> mine; lock (lk) mine = Load();
            StringBuilder sb = new StringBuilder("{\"ok\":true,\"gap\":" + Cfg23.Int("stag_gap", 8) + ",\"wait\":" + Cfg23.Int("stag_wait", 30) +
                ",\"autostart\":" + (AppSettings.AutoStart ? "true" : "false") + ",\"status\":" + Js.S(status) + ",\"items\":[");
            sb.Append(string.Join(",", mine.Select(e => "{\"id\":" + Js.S(e.Id) + ",\"name\":" + Js.S(e.Name) + ",\"cmd\":" + Js.S(e.Cmd) + "}")));
            sb.Append("],\"avail\":[");
            // o que ainda arranca com o Windows e pode passar para aqui (o próprio NEXUS fica de fora)
            sb.Append(string.Join(",", Arranque.Items().Where(x => x[3] == "1" && x[1].IndexOf("NEXUS", StringComparison.OrdinalIgnoreCase) < 0 && !mine.Any(m => m.Id == x[0]))
                .Select(x => "{\"id\":" + Js.S(x[0]) + ",\"name\":" + Js.S(x[1]) + ",\"cmd\":" + Js.S(x[2]) + "}")));
            return sb.Append("]}").ToString();
        }
        public static string Add(string id)
        {
            lock (lk)
            {
                string[] it = Arranque.Items().FirstOrDefault(x => x[0] == id);
                if (it == null) return Ps23.Ok(false, Lang.L("Já não existe."));
                List<E> l = Load();
                if (!l.Any(e => e.Id == id)) l.Add(new E { Id = id, Name = it[1], Cmd = it[2] });
                SaveList(l);
                Arranque.Set(id, false);   // o Windows deixa de o abrir; quem abre é o NEXUS
            }
            return Json();
        }
        public static string Remove(string id)
        {
            lock (lk)
            {
                List<E> l = Load();
                l.RemoveAll(e => e.Id == id);
                SaveList(l);
                Arranque.Set(id, true);    // volta ao arranque normal do Windows
            }
            return Json();
        }
        public static string Move(string id, int dir)
        {
            lock (lk)
            {
                List<E> l = Load(); int i = l.FindIndex(e => e.Id == id), j = i + dir;
                if (i >= 0 && j >= 0 && j < l.Count) { E t = l[i]; l[i] = l[j]; l[j] = t; SaveList(l); }
            }
            return Json();
        }
        public static string SetGap(string gap, string wait)
        {
            int g, w;
            if (int.TryParse(gap ?? "", out g)) Cfg23.Set("stag_gap", Math.Max(2, Math.Min(120, g)).ToString());
            if (int.TryParse(wait ?? "", out w)) Cfg23.Set("stag_wait", Math.Max(0, Math.Min(600, w)).ToString());
            return Json();
        }
        public static string TestNow() { ThreadPool.QueueUserWorkItem(delegate { try { Run(true); } catch { } }); return Json(); }

        // ao arrancar o NEXUS: só se foi logo a seguir a ligar o PC (senão os programas já estariam abertos ou o utilizador fechou-os)
        public static void OnStart()
        {
            if (Vigias3.UptimeMin > 20) { status = ""; return; }
            Run(false);
        }
        static int running;
        static void Run(bool manual)
        {
            if (Interlocked.Exchange(ref running, 1) == 1) return;
            try
            {
                List<E> l; lock (lk) l = Load();
                if (l.Count == 0) return;
                int gap = Cfg23.Int("stag_gap", 8), wait = Cfg23.Int("stag_wait", 30);
                if (!manual)
                {
                    // espera até ~wait s depois de ligar o PC e o processador acalmar (máximo +60 s)
                    double left = wait - Vigias3.UptimeMin * 60;
                    if (left > 0) Thread.Sleep((int)(left * 1000));
                    for (int i = 0; i < 30 && Stats.CpuNow() > 50; i++) Thread.Sleep(2000);
                }
                int k = 0;
                foreach (E e in l)
                {
                    k++;
                    status = Lang.L("A abrir") + " " + e.Name + " (" + k + "/" + l.Count + ")";
                    if (!AlreadyRunning(e.Cmd)) Launch(e);
                    if (k < l.Count) { Thread.Sleep(gap * 1000); for (int i = 0; i < 10 && Stats.CpuNow() > 70; i++) Thread.Sleep(1000); }
                }
                status = Lang.L("Último arranque:") + " " + DateTime.Now.ToString("HH:mm") + " · " + l.Count + " " + Lang.L("programas");
            }
            catch (Exception ex) { status = ex.Message; }
            finally { Interlocked.Exchange(ref running, 0); }
        }
        static string ExeOf(string cmd)
        {
            if (string.IsNullOrEmpty(cmd)) return "";
            cmd = Environment.ExpandEnvironmentVariables(cmd.Trim());
            if (cmd.StartsWith("\"")) { int e = cmd.IndexOf('"', 1); return e > 1 ? cmd.Substring(1, e - 1) : cmd.Trim('"'); }
            int x = cmd.IndexOf(".exe", StringComparison.OrdinalIgnoreCase);
            return x > 0 ? cmd.Substring(0, x + 4) : cmd.Split(' ')[0];
        }
        static bool AlreadyRunning(string cmd)
        {
            string exe = ExeOf(cmd);
            if (!exe.EndsWith(".exe", StringComparison.OrdinalIgnoreCase)) return false;
            string n = Path.GetFileNameWithoutExtension(exe);
            foreach (Process p in Process.GetProcessesByName(n))
            {
                try { string ep = Optimizer.ExePath(p.Id); if (ep == "" || string.Equals(ep, exe, StringComparison.OrdinalIgnoreCase)) return true; }
                catch { }
                finally { p.Dispose(); }
            }
            return false;
        }
        // abre como utilizador normal: um atalho .lnk aberto pelo Explorador (o NEXUS pode estar como administrador)
        static void Launch(E e)
        {
            string cmd = Environment.ExpandEnvironmentVariables(e.Cmd.Trim());
            if (cmd.EndsWith(".lnk", StringComparison.OrdinalIgnoreCase) || (!cmd.Contains(" ") && File.Exists(cmd) && !cmd.EndsWith(".exe", StringComparison.OrdinalIgnoreCase)))
            { Process.Start(new ProcessStartInfo("explorer.exe", "\"" + cmd + "\"") { UseShellExecute = false }); return; }
            string exe = ExeOf(cmd), args = cmd.Length > 0 && cmd.StartsWith("\"") ? cmd.Substring(Math.Min(cmd.Length, exe.Length + 2)).Trim() : cmd.Substring(Math.Min(cmd.Length, exe.Length)).Trim();
            string lnk = Path.Combine(AppSettings.Dir, "scripts", "arranque-" + Regex.Replace(e.Name, "[^A-Za-z0-9_-]", "_") + ".lnk");
            Directory.CreateDirectory(Path.GetDirectoryName(lnk));
            object sh = Activator.CreateInstance(Type.GetTypeFromProgID("WScript.Shell"));
            object sc = sh.GetType().InvokeMember("CreateShortcut", BindingFlags.InvokeMethod, null, sh, new object[] { lnk });
            sc.GetType().InvokeMember("TargetPath", BindingFlags.SetProperty, null, sc, new object[] { exe });
            sc.GetType().InvokeMember("Arguments", BindingFlags.SetProperty, null, sc, new object[] { args });
            try { sc.GetType().InvokeMember("WorkingDirectory", BindingFlags.SetProperty, null, sc, new object[] { Path.GetDirectoryName(exe) }); } catch { }
            sc.GetType().InvokeMember("Save", BindingFlags.InvokeMethod, null, sc, null);
            Marshal.FinalReleaseComObject(sc); Marshal.FinalReleaseComObject(sh);
            Process.Start(new ProcessStartInfo("explorer.exe", "\"" + lnk + "\"") { UseShellExecute = false });
        }
    }

    // ============================================================ 27. jogos atualizados (Steam e Epic)
    static class JogosAtualizados
    {
        const string FILE = "jogos_versoes.txt";
        static readonly object lk = new object();
        static Dictionary<string, string> known;              // id -> versão|nome
        static readonly List<string> events = new List<string>();   // "quando|nome|tipo|loja"
        static List<string> busyNow = new List<string>();     // a atualizar agora
        static int busy;
        static readonly Dictionary<string, KeyValuePair<DateTime, string[]>> fcache = new Dictionary<string, KeyValuePair<DateTime, string[]>>(StringComparer.OrdinalIgnoreCase);
        // só volta a ler um manifesto quando ele muda (há bibliotecas com centenas de jogos)
        static string[] Parse(string f, Func<string, string[]> parse)
        {
            DateTime m; try { m = File.GetLastWriteTimeUtc(f); } catch { return null; }
            KeyValuePair<DateTime, string[]> c;
            lock (fcache) if (fcache.TryGetValue(f, out c) && c.Key == m) return c.Value;
            string t; try { t = File.ReadAllText(f); } catch { return null; }
            string[] v = parse(t);
            lock (fcache) fcache[f] = new KeyValuePair<DateTime, string[]>(m, v);
            return v;
        }

        public static bool On { get { return Cfg23.On("jupd", true); } }
        public static string SetOn(bool on) { Cfg23.Set("jupd", on ? "1" : "0"); return Json(); }

        static void Load()
        {
            if (known != null) return;
            known = new Dictionary<string, string>();
            foreach (string l in Vigias3.Read(FILE))
            {
                string[] p = l.Split('\t');
                if (p.Length >= 3 && p[0] == "k") known[p[1]] = p[2] + "|" + (p.Length > 3 ? p[3] : "");
                else if (p.Length >= 2 && p[0] == "e") events.Add(p[1]);
            }
        }
        static void Save()
        {
            List<string> l = known.Select(x => { string[] v = x.Value.Split(new[] { '|' }, 2); return "k\t" + x.Key + "\t" + v[0] + "\t" + (v.Length > 1 ? v[1] : ""); }).ToList();
            l.AddRange(events.Skip(Math.Max(0, events.Count - 40)).Select(e => "e\t" + e));
            Vigias3.Write(FILE, l);
        }

        static List<string> SteamLibs()
        {
            List<string> libs = new List<string>();
            try
            {
                string steam = null;
                using (RegistryKey k = Registry.CurrentUser.OpenSubKey(@"Software\Valve\Steam")) if (k != null) steam = Convert.ToString(k.GetValue("SteamPath"));
                if (string.IsNullOrEmpty(steam)) return libs;
                libs.Add(Path.Combine(steam.Replace('/', '\\'), "steamapps"));
                string vdf = Path.Combine(libs[0], "libraryfolders.vdf");
                if (File.Exists(vdf)) foreach (Match m in Regex.Matches(File.ReadAllText(vdf), "\"path\"\\s+\"([^\"]+)\"")) libs.Add(Path.Combine(m.Groups[1].Value.Replace("\\\\", "\\"), "steamapps"));
            }
            catch { }
            return libs.Distinct(StringComparer.OrdinalIgnoreCase).Where(Directory.Exists).ToList();
        }

        public static void Check()
        {
            if (Interlocked.Exchange(ref busy, 1) == 1) return;
            try
            {
                Dictionary<string, string[]> now = new Dictionary<string, string[]>();   // id -> [versão, nome, a atualizar?, loja]
                List<string> updating = new List<string>();
                foreach (string lib in SteamLibs())
                {
                    string[] files; try { files = Directory.GetFiles(lib, "appmanifest_*.acf"); } catch { continue; }
                    foreach (string f in files)
                    {
                        string[] v = Parse(f, t =>
                        {
                            Func<string, string> g = k => { Match m = Regex.Match(t, "\"" + k + "\"\\s+\"([^\"]*)\""); return m.Success ? m.Groups[1].Value : ""; };
                            return new[] { g("appid"), g("name"), g("StateFlags"), g("buildid"), g("BytesToDownload"), g("BytesDownloaded") };
                        });
                        if (v == null) continue;
                        string id = v[0], n = v[1], st = v[2], build = v[3];
                        if (id == "" || id == "228980") continue;   // Steamworks Common Redistributables
                        long todo, done; long.TryParse(v[4], out todo); long.TryParse(v[5], out done);
                        bool up = st != "4" && st != "" && st != "0";
                        if (up) updating.Add(Vigias3.Clean(n) + (todo > 0 ? " · " + (int)(100.0 * done / todo) + " %" : ""));
                        now["steam:" + id] = new[] { build, n, up ? "1" : "0", "Steam" };
                    }
                }
                try
                {
                    string man = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), @"Epic\EpicGamesLauncher\Data\Manifests");
                    if (Directory.Exists(man))
                        foreach (string f in Directory.GetFiles(man, "*.item"))
                        {
                            string[] v = Parse(f, t =>
                            {
                                Func<string, string> g = k => { Match m = Regex.Match(t, "\"" + k + "\"\\s*:\\s*\"([^\"]*)\""); return m.Success ? m.Groups[1].Value : ""; };
                                return new[] { g("AppName"), g("DisplayName"), g("AppVersionString"), Regex.IsMatch(t, "\"bIsIncompleteInstall\"\\s*:\\s*true") ? "1" : "0" };
                            });
                            if (v == null) continue;
                            string id = v[0], n = v[1], ver = v[2];
                            bool inc = v[3] == "1";
                            if (id == "") continue;
                            if (inc) updating.Add(Vigias3.Clean(n));
                            now["epic:" + id] = new[] { ver, n, inc ? "1" : "0", "Epic" };
                        }
                }
                catch { }
                busyNow = updating;
                lock (lk)
                {
                    bool first = known == null || known.Count == 0; Load(); first = first && known.Count == 0;
                    bool changed = false;
                    foreach (KeyValuePair<string, string[]> x in now)
                    {
                        if (x.Value[2] == "1") continue;   // ainda a meio: espera que acabe
                        string ver = x.Value[0], name = Vigias3.Clean(x.Value[1]);
                        string old; bool had = known.TryGetValue(x.Key, out old);
                        string oldVer = had ? old.Split('|')[0] : null;
                        if (had && oldVer == ver) continue;
                        known[x.Key] = ver + "|" + name; changed = true;
                        if (first) continue;   // primeira vez: só aprende o que está instalado
                        string kind = had ? "upd" : "new";
                        events.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm") + "|" + name + "|" + kind + "|" + x.Value[3]);
                        if (On)
                            Vigias3.Notify("jupd_" + x.Key + "_" + ver, "NEXUS · " + (kind == "upd" ? Lang.L("Jogo atualizado") : Lang.L("Jogo instalado")),
                                name + (kind == "upd" ? " " + Lang.L("acabou de atualizar e está pronto a jogar.") : " " + Lang.L("acabou de instalar e está pronto a jogar.")), 24 * 30);
                    }
                    if (changed) Save();
                }
            }
            finally { Interlocked.Exchange(ref busy, 0); }
        }

        public static string Json()
        {
            List<string> ev; lock (lk) { Load(); ev = events.ToList(); }
            ev.Reverse();
            return "{\"ok\":true,\"on\":" + (On ? "true" : "false") + ",\"now\":[" + string.Join(",", busyNow.Select(Js.S)) + "],\"events\":[" +
                string.Join(",", ev.Take(20).Select(e => { string[] p = e.Split('|'); return p.Length < 4 ? "null" : "{\"when\":" + Js.S(p[0]) + ",\"name\":" + Js.S(p[1]) + ",\"kind\":" + Js.S(p[2]) + ",\"store\":" + Js.S(p[3]) + "}"; }).Where(s => s != "null")) + "]}";
        }
    }

    // ============================================================ 31. portas USB lentas
    // Um dispositivo que sabe USB 3 (5 Gb/s ou mais) mas está a funcionar a USB 2 (480 Mb/s): cabo, hub ou porta errada.
    static class UsbLento
    {
        [StructLayout(LayoutKind.Sequential)] struct IFDATA { public int cbSize; public Guid cls; public int flags; public IntPtr reserved; }
        [StructLayout(LayoutKind.Sequential)] struct DEVINFO { public int cbSize; public Guid cls; public int inst; public IntPtr reserved; }
        [DllImport("setupapi.dll", SetLastError = true)] static extern IntPtr SetupDiGetClassDevs(ref Guid g, IntPtr e, IntPtr w, int flags);
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)] static extern IntPtr SetupDiGetClassDevs(IntPtr g, string e, IntPtr w, int flags);
        [DllImport("setupapi.dll", SetLastError = true)] static extern bool SetupDiEnumDeviceInterfaces(IntPtr set, IntPtr info, ref Guid g, int idx, ref IFDATA d);
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)] static extern bool SetupDiGetDeviceInterfaceDetail(IntPtr set, ref IFDATA d, IntPtr detail, int size, out int need, IntPtr info);
        [DllImport("setupapi.dll", SetLastError = true)] static extern bool SetupDiEnumDeviceInfo(IntPtr set, int idx, ref DEVINFO d);
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)] static extern bool SetupDiGetDeviceRegistryProperty(IntPtr set, ref DEVINFO d, int prop, out int type, byte[] buf, int size, out int need);
        [DllImport("setupapi.dll")] static extern bool SetupDiDestroyDeviceInfoList(IntPtr set);
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)] static extern SafeFileHandle CreateFile(string n, uint acc, uint share, IntPtr sec, uint disp, uint flags, IntPtr tpl);
        [DllImport("kernel32.dll", SetLastError = true)] static extern bool DeviceIoControl(SafeFileHandle h, uint code, byte[] inb, int inLen, byte[] outb, int outLen, out int ret, IntPtr ov);

        class U { public string Name, Key; public ushort Vid, Pid; public int Speed; public bool Capable, Super, Hub; }
        static List<U> last = new List<U>(); static DateTime lastAt = DateTime.MinValue;
        static readonly object lk = new object();

        static string Prop(IntPtr set, ref DEVINFO d, int prop)
        {
            byte[] b = new byte[1024]; int type, need;
            if (!SetupDiGetDeviceRegistryProperty(set, ref d, prop, out type, b, b.Length, out need)) return "";
            return Encoding.Unicode.GetString(b, 0, Math.Max(0, Math.Min(need, b.Length))).TrimEnd('\0');
        }
        // chave do driver -> nome que aparece no Gestor de Dispositivos
        static Dictionary<string, string> Names()
        {
            Dictionary<string, string> r = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            IntPtr set = SetupDiGetClassDevs(IntPtr.Zero, "USB", IntPtr.Zero, 0x6);   // presentes, todas as classes
            if (set == IntPtr.Zero || set == new IntPtr(-1)) return r;
            try
            {
                for (int i = 0; i < 1024; i++)
                {
                    DEVINFO d = new DEVINFO(); d.cbSize = Marshal.SizeOf(typeof(DEVINFO));
                    if (!SetupDiEnumDeviceInfo(set, i, ref d)) break;
                    string key = Prop(set, ref d, 9);   // SPDRP_DRIVER
                    if (key == "") continue;
                    string n = Prop(set, ref d, 12); if (n == "") n = Prop(set, ref d, 0);   // FRIENDLYNAME / DEVICEDESC
                    r[key] = n;
                }
            }
            finally { SetupDiDestroyDeviceInfoList(set); }
            return r;
        }
        static List<string> Hubs()
        {
            List<string> r = new List<string>();
            Guid g = new Guid("f18a0e88-c30c-11d0-8815-00a0c906bed8");   // GUID_DEVINTERFACE_USB_HUB
            IntPtr set = SetupDiGetClassDevs(ref g, IntPtr.Zero, IntPtr.Zero, 0x12);
            if (set == IntPtr.Zero || set == new IntPtr(-1)) return r;
            try
            {
                for (int i = 0; i < 128; i++)
                {
                    IFDATA d = new IFDATA(); d.cbSize = Marshal.SizeOf(typeof(IFDATA));
                    if (!SetupDiEnumDeviceInterfaces(set, IntPtr.Zero, ref g, i, ref d)) break;
                    int need; SetupDiGetDeviceInterfaceDetail(set, ref d, IntPtr.Zero, 0, out need, IntPtr.Zero);
                    if (need <= 0) continue;
                    IntPtr buf = Marshal.AllocHGlobal(need);
                    try
                    {
                        Marshal.WriteInt32(buf, IntPtr.Size == 8 ? 8 : 6);
                        if (SetupDiGetDeviceInterfaceDetail(set, ref d, buf, need, out need, IntPtr.Zero)) r.Add(Marshal.PtrToStringUni(new IntPtr(buf.ToInt64() + 4)));
                    }
                    finally { Marshal.FreeHGlobal(buf); }
                }
            }
            finally { SetupDiDestroyDeviceInfoList(set); }
            return r;
        }
        static List<U> Scan()
        {
            List<U> r = new List<U>();
            Dictionary<string, string> names = Names();
            foreach (string hub in Hubs())
            {
                using (SafeFileHandle h = CreateFile(hub, 0x40000000, 2, IntPtr.Zero, 3, 0, IntPtr.Zero))
                {
                    if (h.IsInvalid) continue;
                    int ret; byte[] ni = new byte[76];
                    if (!DeviceIoControl(h, 0x220408, ni, ni.Length, ni, ni.Length, out ret, IntPtr.Zero)) continue;   // IOCTL_USB_GET_NODE_INFORMATION
                    int ports = ni[6];
                    for (int port = 1; port <= ports && port <= 32; port++)
                    {
                        byte[] ci = new byte[512]; BitConverter.GetBytes(port).CopyTo(ci, 0);
                        if (!DeviceIoControl(h, 0x220448, ci, ci.Length, ci, ci.Length, out ret, IntPtr.Zero)) continue;   // ..._CONNECTION_INFORMATION_EX
                        int conn = BitConverter.ToInt32(ci, 31); if (conn != 1) continue;   // DeviceConnected
                        U u = new U { Vid = BitConverter.ToUInt16(ci, 12), Pid = BitConverter.ToUInt16(ci, 14), Speed = ci[23], Hub = ci[24] != 0 };
                        byte[] v2 = new byte[16]; BitConverter.GetBytes(port).CopyTo(v2, 0); BitConverter.GetBytes(16).CopyTo(v2, 4); BitConverter.GetBytes(7).CopyTo(v2, 8);
                        if (DeviceIoControl(h, 0x22045C, v2, 16, v2, 16, out ret, IntPtr.Zero))   // ..._CONNECTION_INFORMATION_EX_V2 (Windows 8+)
                        { int fl = BitConverter.ToInt32(v2, 12); u.Super = (fl & 1) != 0; u.Capable = (fl & 2) != 0; }
                        else u.Super = u.Speed >= 3;
                        byte[] dk = new byte[1024]; BitConverter.GetBytes(port).CopyTo(dk, 0);
                        if (DeviceIoControl(h, 0x220420, dk, dk.Length, dk, dk.Length, out ret, IntPtr.Zero) && ret > 8)   // ..._DRIVERKEY_NAME
                        {
                            u.Key = Encoding.Unicode.GetString(dk, 8, Math.Min(ret, dk.Length) - 8).TrimEnd('\0');
                            string n; if (names.TryGetValue(u.Key, out n)) u.Name = n;
                        }
                        // nome genérico do Windows ("Dispositivo de armazenamento USB", "Dispositivo USB composto"…): pede o nome ao próprio dispositivo
                        if (string.IsNullOrEmpty(u.Name) || Regex.IsMatch(u.Name, "USB (Mass Storage|Composite)|armazenamento.*USB|USB compo|Dispositivo USB|Input Device|entrada USB", RegexOptions.IgnoreCase))
                        { string ps = Product(h, port, ci[19]); if (ps != "") u.Name = ps; }
                        if (string.IsNullOrEmpty(u.Name)) u.Name = Lang.L("Dispositivo USB");
                        r.Add(u);
                    }
                }
            }
            return r;
        }
        // IOCTL_USB_GET_DESCRIPTOR_FROM_NODE_CONNECTION: descritor de texto iProduct (inglês)
        static string Product(SafeFileHandle h, int port, byte idx)
        {
            if (idx == 0) return "";
            byte[] b = new byte[12 + 255]; int ret;
            BitConverter.GetBytes(port).CopyTo(b, 0);
            b[4] = 0x80; b[5] = 6;                                   // GET_DESCRIPTOR
            BitConverter.GetBytes((ushort)(0x0300 | idx)).CopyTo(b, 6);
            BitConverter.GetBytes((ushort)0x0409).CopyTo(b, 8);
            BitConverter.GetBytes((ushort)255).CopyTo(b, 10);
            if (!DeviceIoControl(h, 0x220410, b, b.Length, b, b.Length, out ret, IntPtr.Zero) || ret < 14) return "";
            int len = Math.Min(b[12], ret - 12);
            return len > 2 && b[13] == 3 ? Encoding.Unicode.GetString(b, 14, len - 2).Trim('\0', ' ') : "";
        }
        public static void Check(bool notify)
        {
            List<U> l;
            try { l = Scan(); } catch { return; }
            lock (lk) { last = l; lastAt = DateTime.Now; }
            if (!notify) return;
            foreach (U u in l.Where(x => x.Capable && !x.Super && !x.Hub).Take(2))
                Vigias3.Notify("usb_" + u.Vid.ToString("x4") + u.Pid.ToString("x4"), "NEXUS · " + Lang.L("Porta USB lenta"),
                    u.Name + " " + Lang.L("sabe USB 3, mas está ligado a USB 2 (até 10× mais lento). Experimenta outra porta (normalmente azul ou com SS) ou outro cabo."), 24 * 7);
        }
        static string Speed(U u) { return u.Super ? "5+ Gb/s" : u.Speed == 2 ? "480 Mb/s" : u.Speed == 1 ? "12 Mb/s" : u.Speed == 0 ? "1,5 Mb/s" : "?"; }
        public static string Json(bool fresh)
        {
            if (fresh || (DateTime.Now - lastAt).TotalMinutes > 5) Check(false);
            List<U> l; lock (lk) l = last.ToList();
            return "{\"ok\":true,\"devs\":[" + string.Join(",", l.Where(u => !u.Hub || u.Capable && !u.Super).OrderByDescending(u => u.Capable && !u.Super).ThenByDescending(u => u.Super).Select(u =>
                "{\"name\":" + Js.S(u.Name) + ",\"vid\":" + Js.S(u.Vid.ToString("X4")) + ",\"pid\":" + Js.S(u.Pid.ToString("X4")) + ",\"speed\":" + Js.S(Speed(u)) +
                ",\"usb3\":" + (u.Super ? "true" : "false") + ",\"capable\":" + (u.Capable ? "true" : "false") + ",\"slow\":" + (u.Capable && !u.Super ? "true" : "false") + ",\"hub\":" + (u.Hub ? "true" : "false") + "}")) + "]}";
        }
        public static string Brief()
        {
            List<U> l; lock (lk) l = last.ToList();
            return "[" + string.Join(",", l.Where(u => u.Capable && !u.Super && !u.Hub).Select(u => Js.S(u.Name))) + "]";
        }
    }

    // ============================================================ 33. programas a trabalhar com o PC parado (mineradores)
    static class Mineradores
    {
        [DllImport("pdh.dll", CharSet = CharSet.Unicode)] static extern int PdhOpenQuery(string src, IntPtr user, out IntPtr q);
        [DllImport("pdh.dll", CharSet = CharSet.Unicode)] static extern int PdhAddEnglishCounter(IntPtr q, string path, IntPtr user, out IntPtr c);
        [DllImport("pdh.dll")] static extern int PdhCollectQueryData(IntPtr q);
        [DllImport("pdh.dll", CharSet = CharSet.Unicode)] static extern int PdhGetFormattedCounterArray(IntPtr c, uint fmt, ref uint size, ref uint count, IntPtr buf);
        [DllImport("pdh.dll")] static extern int PdhCloseQuery(IntPtr q);

        class C { public int Pid; public string Name, Path; public double Gpu, Cpu; public int Mins; public DateTime First, Last; public bool Stealth, Flagged; }
        class Find { public string When, Name, Path, Verdict, Why; public double Gpu, Cpu; public int Mins; public bool Stealth; }
        static readonly object lk = new object();
        static readonly Dictionary<int, C> cands = new Dictionary<int, C>();
        static readonly Dictionary<int, TimeSpan> cpuPrev = new Dictionary<int, TimeSpan>();
        static DateTime cpuPrevAt = DateTime.MinValue;
        static IntPtr q, cGpu; static bool pdhOk;
        static List<Find> finds;
        static int busy; static bool wasIdle;
        const string FILE = "mineradores.txt";
        static readonly string[] MinerNames = { "xmrig", "nicehash", "phoenixminer", "t-rex", "trex", "lolminer", "gminer", "nbminer", "ethminer", "cgminer", "bminer", "teamredminer", "nanominer", "srbminer", "excavator", "minerd", "cpuminer" };
        static readonly string[] SysNames = { "svchost", "csrss", "lsass", "conhost", "explorer", "dwm", "rundll32", "winlogon", "services", "smss", "taskhostw", "wininit", "dllhost", "spoolsv", "sihost", "ctfmon" };
        static readonly string[] Normal = { "MsMpEng", "TiWorker", "TrustedInstaller", "SearchIndexer", "SearchProtocolHost", "CompatTelRunner", "MoUsoCoreWorker", "wuauclt", "fossilize_replay", "steamwebhelper", "MpCmdRun", "NisSrv", "WmiPrvSE", "OneDrive" };
        static readonly string[] Work = { "HandBrake", "ffmpeg", "obs64", "blender", "Resolve", "Adobe Premiere Pro", "AfterFX", "Adobe Media Encoder", "Photoshop", "7zG", "7z", "WinRAR", "qbittorrent", "Steam" };

        static void LoadFinds()
        {
            if (finds != null) return;
            finds = new List<Find>();
            foreach (string l in Vigias3.Read(FILE))
            {
                string[] p = l.Split('|'); if (p.Length < 9) continue;
                double g, c; int m;
                double.TryParse(p[3], NumberStyles.Float, CultureInfo.InvariantCulture, out g); double.TryParse(p[4], NumberStyles.Float, CultureInfo.InvariantCulture, out c); int.TryParse(p[5], out m);
                finds.Add(new Find { When = p[0], Name = p[1], Path = p[2], Gpu = g, Cpu = c, Mins = m, Verdict = p[6], Stealth = p[7] == "1", Why = p[8] });
            }
        }
        static void SaveFinds()
        {
            Vigias3.Write(FILE, finds.Skip(Math.Max(0, finds.Count - 40)).Select(f => f.When + "|" + Vigias3.Clean(f.Name) + "|" + Vigias3.Clean(f.Path) + "|" + Vigias3.F1(f.Gpu) + "|" + Vigias3.F1(f.Cpu) + "|" + f.Mins + "|" + f.Verdict + "|" + (f.Stealth ? "1" : "0") + "|" + Vigias3.Clean(f.Why)));
        }

        // utilização da placa por processo (o mesmo que o Gestor de Tarefas mostra na coluna GPU)
        static Dictionary<int, double> GpuByPid()
        {
            Dictionary<int, double> r = new Dictionary<int, double>();
            if (q == IntPtr.Zero)
            {
                if (PdhOpenQuery(null, IntPtr.Zero, out q) != 0) { q = IntPtr.Zero; return r; }
                pdhOk = PdhAddEnglishCounter(q, @"\GPU Engine(*)\Utilization Percentage", IntPtr.Zero, out cGpu) == 0;
                PdhCollectQueryData(q);
                return r;   // a primeira leitura só serve de base
            }
            if (!pdhOk || PdhCollectQueryData(q) != 0) return r;
            uint size = 0, count = 0;
            PdhGetFormattedCounterArray(cGpu, 0x200, ref size, ref count, IntPtr.Zero);
            if (size == 0 || size > 16 << 20) return r;
            IntPtr buf = Marshal.AllocHGlobal((int)size);
            try
            {
                if (PdhGetFormattedCounterArray(cGpu, 0x200, ref size, ref count, buf) != 0) return r;
                int isz = IntPtr.Size == 8 ? 24 : 16, vo = IntPtr.Size == 8 ? 16 : 8;
                Dictionary<string, double> perEng = new Dictionary<string, double>();
                for (int i = 0; i < count; i++)
                {
                    IntPtr it = new IntPtr(buf.ToInt64() + i * isz);
                    string name = Marshal.PtrToStringUni(Marshal.ReadIntPtr(it)) ?? "";
                    double v = BitConverter.Int64BitsToDouble(Marshal.ReadInt64(it, vo));
                    Match m = Regex.Match(name, @"pid_(\d+)_.*engtype_(\w+)");
                    if (!m.Success || v <= 0) continue;
                    string k = m.Groups[1].Value + "|" + m.Groups[2].Value;
                    double o; perEng[k] = (perEng.TryGetValue(k, out o) ? o : 0) + v;
                }
                // por processo: o motor mais ocupado (3D, Compute, …), como o Gestor de Tarefas
                foreach (KeyValuePair<string, double> x in perEng)
                {
                    int pid = int.Parse(x.Key.Split('|')[0]);
                    double o; r[pid] = Math.Min(100, Math.Max(r.TryGetValue(pid, out o) ? o : 0, x.Value));
                }
            }
            finally { Marshal.FreeHGlobal(buf); }
            return r;
        }
        static Dictionary<int, double> CpuByPid(out Dictionary<int, string> names)
        {
            Dictionary<int, double> r = new Dictionary<int, double>(); names = new Dictionary<int, string>();
            DateTime now = DateTime.UtcNow; double el = (now - cpuPrevAt).TotalSeconds; bool ok = cpuPrevAt != DateTime.MinValue && el > 5 && el < 600;
            Dictionary<int, TimeSpan> cur = new Dictionary<int, TimeSpan>();
            foreach (Process p in Process.GetProcesses())
            {
                try
                {
                    int id = p.Id; if (id <= 4) continue;
                    names[id] = p.ProcessName;
                    TimeSpan t = p.TotalProcessorTime; cur[id] = t;
                    TimeSpan o; if (ok && cpuPrev.TryGetValue(id, out o)) r[id] = (t - o).TotalSeconds / el / Environment.ProcessorCount * 100;
                }
                catch { }
                finally { p.Dispose(); }
            }
            cpuPrev.Clear(); foreach (KeyValuePair<int, TimeSpan> x in cur) cpuPrev[x.Key] = x.Value;
            cpuPrevAt = now;
            return r;
        }
        static void Reset() { cands.Clear(); cpuPrev.Clear(); cpuPrevAt = DateTime.MinValue; }

        public static void Check(string game)
        {
            if (Interlocked.Exchange(ref busy, 1) == 1) return;
            try
            {
                bool idle = game == null && !Stress.Running && Vigias3.IdleSecs() >= 300;
                lock (lk)
                {
                    LoadFinds();
                    if (!idle)
                    {
                        // voltaste ao PC: os que estavam a trabalhar e param logo são o sinal clássico de um minerador escondido
                        if (wasIdle && cands.Values.Any(z => z.Mins >= 5) && game == null && Vigias3.IdleSecs() < 60)
                        {
                            Dictionary<int, double> g2 = GpuByPid(); Dictionary<int, string> n2; Dictionary<int, double> c2 = CpuByPid(out n2);
                            foreach (C c in cands.Values.Where(z => z.Mins >= 5))
                            {
                                double gv, cv; g2.TryGetValue(c.Pid, out gv); c2.TryGetValue(c.Pid, out cv);
                                if (gv < 3 && cv < 3 && n2.ContainsKey(c.Pid)) { c.Stealth = true; Flag(c); }
                            }
                        }
                        if (Vigias3.IdleSecs() < 60) { wasIdle = false; Reset(); }
                        return;
                    }
                    wasIdle = true;
                    Dictionary<int, double> gpu = GpuByPid(); Dictionary<int, string> names; Dictionary<int, double> cpu = CpuByPid(out names);
                    int me = Process.GetCurrentProcess().Id;
                    DateTime now = DateTime.Now;
                    foreach (int pid in names.Keys)
                    {
                        if (pid == me) continue;
                        double gv, cv; gpu.TryGetValue(pid, out gv); cpu.TryGetValue(pid, out cv);
                        C c;
                        if (gv >= 25 || cv >= 35)
                        {
                            if (!cands.TryGetValue(pid, out c)) { c = new C { Pid = pid, Name = names[pid], Path = Optimizer.ExePath(pid), First = now }; cands[pid] = c; }
                            c.Gpu = Math.Max(c.Gpu, gv); c.Cpu = Math.Max(c.Cpu, cv); c.Last = now;
                            c.Mins = (int)(now - c.First).TotalMinutes;
                            if (c.Mins >= 10) Flag(c);
                        }
                        else if (cands.TryGetValue(pid, out c) && (now - c.Last).TotalMinutes > 3) cands.Remove(pid);
                    }
                    foreach (int pid in cands.Keys.Where(k => !names.ContainsKey(k)).ToList()) cands.Remove(pid);
                }
            }
            finally { Interlocked.Exchange(ref busy, 0); }
        }

        static string[] Classify(C c)
        {
            string n = c.Name ?? "", p = (c.Path ?? "").ToLowerInvariant(), win = Environment.GetFolderPath(Environment.SpecialFolder.Windows).ToLowerInvariant();
            List<string> why = new List<string>(); int score = 0;
            if (MinerNames.Any(m => n.ToLowerInvariant().Contains(m))) { score += 3; why.Add(Lang.L("nome de um programa de mineração conhecido")); }
            bool inWin = p.StartsWith(win + "\\system32\\") || p.StartsWith(win + "\\syswow64\\") || p.StartsWith(win + "\\");
            if (SysNames.Any(s => s.Equals(n, StringComparison.OrdinalIgnoreCase)) && p != "" && !inWin) { score += 3; why.Add(Lang.L("tem nome de programa do Windows mas não está na pasta do Windows")); }
            if (p.Contains("\\appdata\\local\\temp\\") || p.Contains("\\appdata\\roaming\\") || p.Contains("\\users\\public\\") || (p.Contains("\\programdata\\") && !p.Contains("\\microsoft\\"))) { score += 1; why.Add(Lang.L("corre de uma pasta onde os programas normais não costumam estar")); }
            if (c.Stealth) { score += 2; why.Add(Lang.L("parou assim que voltaste ao PC")); }
            if (c.Gpu >= 60) { score += 1; why.Add(Lang.L("placa gráfica muito ocupada sem nenhum jogo aberto")); }
            if (Normal.Any(s => s.Equals(n, StringComparison.OrdinalIgnoreCase)) && (inWin || p.Contains("\\program files")) && score < 3) return new[] { "normal", Lang.L("tarefa normal (Windows, antivírus ou Steam a preparar shaders)") };
            if (Work.Any(s => n.IndexOf(s, StringComparison.OrdinalIgnoreCase) >= 0) && score < 3) return new[] { "normal", Lang.L("programa de trabalho ou transferências (normal se o deixaste a trabalhar)") };
            if (p == "" && score < 2) why.Add(Lang.L("não consegui ver onde está o programa"));
            return new[] { score >= 3 ? "alto" : score >= 1 ? "medio" : "baixo", why.Count > 0 ? string.Join("; ", why) : Lang.L("trabalhou muito com o PC parado") };
        }
        static void Flag(C c)
        {
            if (c.Flagged && !c.Stealth) return;
            c.Flagged = true;
            string[] v = Classify(c);
            string ign = "\n" + Cfg23.Get("miner_ign", "") + "\n";
            if (c.Path != "" && ign.Contains("\n" + c.Path.ToLowerInvariant() + "\n")) return;
            string today = DateTime.Now.ToString("yyyy-MM-dd");
            Find f = finds.LastOrDefault(x => x.Path == (c.Path ?? "") && x.Name == c.Name && x.When.StartsWith(today));
            if (f == null) { f = new Find { When = DateTime.Now.ToString("yyyy-MM-dd HH:mm"), Name = c.Name, Path = c.Path ?? "" }; finds.Add(f); }
            f.Gpu = Math.Max(f.Gpu, c.Gpu); f.Cpu = Math.Max(f.Cpu, c.Cpu); f.Mins = Math.Max(f.Mins, c.Mins); f.Stealth = f.Stealth || c.Stealth; f.Verdict = v[0]; f.Why = v[1];
            SaveFinds();
            if (v[0] == "alto" || v[0] == "medio")
                Vigias3.Notify("miner_" + (c.Path != "" ? c.Path : c.Name), "NEXUS · " + Lang.L("Programa a trabalhar com o PC parado"),
                    c.Name + ": " + Lang.L("placa") + " " + Math.Round(c.Gpu) + " %, " + Lang.L("processador") + " " + Math.Round(c.Cpu) + " %. " + v[1] + ". " + Lang.L("Vê em Saúde do PC."), 24);
        }
        public static string Ignore(string path)
        {
            if (string.IsNullOrEmpty(path)) return Json();
            List<string> l = Cfg23.Get("miner_ign", "").Split('\n').Where(s => s != "").ToList();
            if (!l.Contains(path.ToLowerInvariant())) l.Add(path.ToLowerInvariant());
            Cfg23.Set("miner_ign", string.Join("\n", l.ToArray()));
            lock (lk) { LoadFinds(); finds.RemoveAll(f => f.Path.Equals(path, StringComparison.OrdinalIgnoreCase)); SaveFinds(); }
            return Json();
        }
        public static string Open(string path)
        {
            lock (lk) { LoadFinds(); if (!finds.Any(f => f.Path.Equals(path ?? "", StringComparison.OrdinalIgnoreCase))) return Ps23.Ok(false, "?"); }
            try { if (File.Exists(path)) Process.Start("explorer.exe", "/select,\"" + path + "\""); } catch { }
            return Json();
        }
        public static string Json()
        {
            List<Find> l; int watching;
            lock (lk) { LoadFinds(); l = finds.ToList(); watching = cands.Count; }
            l.Reverse();
            return "{\"ok\":true,\"idle\":" + (Vigias3.IdleSecs() >= 300 ? "true" : "false") + ",\"watching\":" + watching + ",\"finds\":[" + string.Join(",", l.Take(20).Select(f =>
                "{\"when\":" + Js.S(f.When) + ",\"name\":" + Js.S(f.Name) + ",\"path\":" + Js.S(f.Path) + ",\"gpu\":" + Math.Round(f.Gpu) + ",\"cpu\":" + Math.Round(f.Cpu) +
                ",\"mins\":" + f.Mins + ",\"verdict\":" + Js.S(f.Verdict) + ",\"stealth\":" + (f.Stealth ? "true" : "false") + ",\"why\":" + Js.S(f.Why) + "}")) + "]}";
        }
        public static string Brief()
        {
            List<Find> l; lock (lk) { LoadFinds(); l = finds.ToList(); }
            string since = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd HH:mm");
            return "[" + string.Join(",", l.Where(f => (f.Verdict == "alto" || f.Verdict == "medio") && string.CompareOrdinal(f.When, since) >= 0).Select(f => "{\"name\":" + Js.S(f.Name) + ",\"verdict\":" + Js.S(f.Verdict) + ",\"when\":" + Js.S(f.When) + "}")) + "]";
        }
    }

    // ============================================================ 58. conquistas (e os temas que desbloqueiam)
    static class Conquistas
    {
        class A { public string Id, Name, Desc, Theme; public Func<double> Val; public double Goal; }
        static readonly List<A> all = new List<A>();
        static long eKeys, eClicks; static double eMeters, eApm;
        static double sessMax, fps144, coolGame;
        static int busy;
        static double C(string k) { double v; return double.TryParse(Cfg23.Get(k, "0"), NumberStyles.Float, CultureInfo.InvariantCulture, out v) ? v : 0; }
        static void Add(string id, string name, string desc, double goal, Func<double> val, string theme)
        { all.Add(new A { Id = id, Name = name, Desc = desc, Goal = goal, Val = val, Theme = theme }); }
        static Conquistas()
        {
            Add("teclas_10k", "Dedos aquecidos", "10 000 teclas carregadas", 10000, () => eKeys, null);
            Add("teclas_1m", "Pianista", "1 milhão de teclas carregadas", 1000000, () => eKeys, "ouro");
            Add("cliques_100k", "Clique-clique", "100 000 cliques", 100000, () => eClicks, "sty:retro");
            Add("rato_1km", "Primeiro quilómetro", "1 km de rato", 1000, () => eMeters, "sty:vidro");
            Add("rato_42km", "Maratona do rato", "42 km de rato (uma maratona)", 42195, () => eMeters, "aurora");
            Add("rato_100km", "Volta ao país", "100 km de rato", 100000, () => eMeters, null);
            Add("apm_200", "Mãos rápidas", "200 ações por minuto num jogo (30 min ou mais)", 200, () => eApm, "sty:elegante");
            Add("sess_5h", "Maratonista", "Uma sessão de jogo de 5 horas", 300, () => sessMax, "lava");
            Add("jogo_100h", "Sem vida social", "100 horas de jogo com o NEXUS aberto", 6000, () => C("ach_gmin") + gpend, null);
            Add("fps_144", "Rápido como o vento", "Média de 144 FPS ou mais numa sessão de 30 min", 1, () => fps144, "relampago");
            Add("frio", "Sangue frio", "Uma hora de jogo sem a placa passar dos 65 °C", 1, () => coolGame, "artico");
            Add("coruja", "Coruja", "Usar o PC às 4 da manhã", 1, () => C("ach_coruja"), "noite");
            Add("limpo", "Pó? Que pó?", "Limpar o pó (botão JÁ LIMPEI)", 1, () => C("ach_limpo"), "menta");
            Add("stress", "Teste de fogo", "Fazer o teste de estabilidade", 1, () => C("ach_stress"), null);
            Add("cacador", "Caça-fugas", "Fechar um programa com fuga de memória pelo NEXUS", 1, () => C("ach_cacador"), "sty:blocos");
            Add("suave", "Arranque suave", "3 programas no arranque escalonado", 3, () => C("ach_suave"), null);
            Add("dias_30", "Habitual", "Usar o NEXUS em 30 dias diferentes", 30, () => C("ach_days"), "classic,sty:classico");   // o Windows 98 só sai com esta
            Add("dias_365", "Veterano", "Usar o NEXUS em 365 dias diferentes", 365, () => C("ach_days"), "holo");
        }
        static int gpend;
        public static void FlushGame() { int n = Interlocked.Exchange(ref gpend, 0); if (n > 0) Cfg23.Set("ach_gmin", ((int)C("ach_gmin") + n).ToString()); }
        public static void Mark(string id) { Cfg23.Set("ach_" + id, "1"); ThreadPool.QueueUserWorkItem(delegate { try { Check(null); } catch { } }); }
        static bool Cheat { get { return Cfg23.Get("ach_cheat", "") == "1"; } }
        static bool Got(A a) { return Cfg23.Get("achok_" + a.Id, "") != ""; }

        static void Refresh()
        {
            try { Entrada.Totals(out eKeys, out eClicks, out eMeters, out eApm); } catch { }
            try
            {
                double mx = 0, f = 0, cool = 0;
                foreach (Historico.Res r in Historico.Sessions())
                {
                    if (r.Mins > mx) mx = r.Mins;
                    if (r.Mins >= 30 && r.Avg >= 144) f = 1;
                    if (r.Mins >= 60 && !double.IsNaN(r.GpuT) && r.GpuT > 20 && r.GpuT <= 65) cool = 1;
                }
                double cur = Historico.SessionMins; if (!double.IsNaN(cur) && cur > mx) mx = cur;
                sessMax = mx; fps144 = f; coolGame = cool;
            }
            catch { }
        }
        public static void Check(string game)
        {
            if (Interlocked.Exchange(ref busy, 1) == 1) return;
            try
            {
                string d = DateTime.Now.ToString("yyyy-MM-dd");
                if (Cfg23.Get("ach_lastday", "") != d) { Cfg23.Set("ach_lastday", d); Cfg23.Set("ach_days", ((int)C("ach_days") + 1).ToString()); }
                if (game != null && ++gpend >= 10) FlushGame();   // grava de 10 em 10 minutos (não escreve as definições a cada minuto)
                if (DateTime.Now.Hour == 4 && Vigias3.IdleSecs() < 120) Cfg23.Set("ach_coruja", "1");
                if (Stress.Running) Cfg23.Set("ach_stress", "1");
                try { int n = Vigias3.Read("arranque_escalonado.txt").Count(l => l.Contains("\t")); if (n > C("ach_suave")) Cfg23.Set("ach_suave", n.ToString()); } catch { }
                Refresh();
                foreach (A a in all)
                {
                    if (Got(a) || a.Val() < a.Goal) continue;
                    Cfg23.Set("achok_" + a.Id, d);   // ganha a sério (também com o código ligado: fica quando o código se desliga)
                    Program.Notify("NEXUS · " + Lang.L("Conquista desbloqueada"), Lang.L(a.Name) + " — " + Lang.L(a.Desc) + (a.Theme != null ? ". " + Lang.L(a.Theme.Contains("sty:") && !a.Theme.Contains(",") ? "Novo estilo desbloqueado!" : "Novo tema desbloqueado!") : ""));
                }
            }
            finally { Interlocked.Exchange(ref busy, 0); }
        }
        // código secreto: só se guardam dois resumos (nunca o código) e é preciso bater os dois
        static uint Fnv(string s) { uint h = 0x811c9dc5; foreach (byte b in Encoding.UTF8.GetBytes(s)) { h ^= b; h = unchecked(h * 0x01000193); } return h; }
        static uint Djb(string s) { uint h = 5381; foreach (byte b in Encoding.UTF8.GetBytes(s)) h = unchecked(h * 33) ^ b; return h; }
        public static string TryCode(string c)
        {
            c = (c ?? "").ToLowerInvariant();
            if (c.Length != 12 || Fnv(c) != 1923806436u || Djb(c) != 939511152u) return Ps23.Ok(false, "?");
            Cfg23.Set("ach_cheat", Cheat ? null : "1");   // escrever outra vez volta a trancar (as conquistas ganhas a sério ficam)
            return Json();
        }
        public static string Json()
        {
            Refresh();
            bool cheat = Cheat;
            StringBuilder sb = new StringBuilder("{\"ok\":true,\"cheat\":" + (cheat ? "true" : "false") + ",\"list\":[");
            sb.Append(string.Join(",", all.Select(a =>
            {
                string when = Cfg23.Get("achok_" + a.Id, ""); double v = 0; try { v = a.Val(); } catch { }
                return "{\"id\":" + Js.S(a.Id) + ",\"name\":" + Js.S(a.Name) + ",\"desc\":" + Js.S(a.Desc) + ",\"goal\":" + Vigias3.F1(a.Goal) + ",\"val\":" + Vigias3.F1(Math.Min(v, a.Goal)) +
                       ",\"when\":" + Js.S(when) + ",\"theme\":" + Js.S(a.Theme ?? "") + "}";
            })));
            sb.Append("],\"themes\":[");
            // recompensas: temas de cores e estilos ("sty:…"); uma conquista pode dar mais do que uma
            List<string> th = all.Where(a => a.Theme != null && (cheat || Got(a))).SelectMany(a => a.Theme.Split(',')).ToList();
            if (cheat) th.Add("criador");
            sb.Append(string.Join(",", th.Select(Js.S)));
            return sb.Append("]}").ToString();
        }
    }
}
