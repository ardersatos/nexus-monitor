// NEXUS // MONITOR 2.6 - microfone (tecla, falar enquanto se carrega, aviso no ecrã), rede de casa (dispositivos ligados ao router,
// portas abertas pelo router, router trocado), rato e teclado pelo telemóvel e galeria de capturas e clipes.
// Privacidade: a rede de casa só fala com a própria rede (router e dispositivos de casa), nunca com a internet.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

namespace Nexus
{
    static class Vigias5
    {
        static int tick;
        public static void Start()
        {
            try { MicPlus.Start(); } catch { }
        }
        // a cada 2 s (vem do Vigias3)
        public static void Tick()
        {
            tick++;
            if (tick % 60 == 30) Run(() => RedeCasa.Passive());                                  // 2 min: só lê a tabela do Windows
            if (tick % 30 == 22 && RedeCasa.AutoMin > 0 && tick % (RedeCasa.AutoMin * 30) == 22) Run(() => RedeCasa.Scan(false));
        }
        static void Run(Action a) { ThreadPool.QueueUserWorkItem(delegate { try { a(); } catch { } }); }
    }

    // ============================================================ 71. microfone
    static class MicPlus
    {
        static Badge badge; static HotWin hot; static volatile bool muted; static Thread ptt;
        public static bool All { get { return Cfg23.On("mic_all", false); } }
        public static bool ShowBadge { get { return Cfg23.On("mic_badge", true); } }
        public static bool Sound { get { return Cfg23.On("mic_sound", true); } }
        public static string Key { get { return Cfg23.Get("mic_key", ""); } }
        public static int PttVk { get { return Cfg23.Int("mic_ptt", 0); } }

        public static void Start()
        {
            Program.Ui(() => { try { hot = new HotWin(); hot.Apply(); badge = new Badge(); badge.Check(); } catch { } });
            SyncPtt();
        }
        public static void Toggle() { Set(!Som.MicMuted()); }
        public static void Set(bool mute)
        {
            Som.SetMics(mute, All);
            muted = mute;
            if (Sound) ThreadPool.QueueUserWorkItem(delegate { try { Chime(mute); } catch { } });
            Program.Ui(() => { if (badge != null) badge.Check(); });
        }
        // som suave (duas notas curtas, como um "pop" de app): a descer ao silenciar, a subir ao ligar
        static byte[] wavOn, wavOff;
        static byte[] Wav(double f1, double f2)
        {
            const int rate = 44100; int n1 = (int)(rate * 0.09), gap = (int)(rate * 0.035), n2 = (int)(rate * 0.20), total = n1 + gap + n2;
            short[] s = new short[total];
            Action<int, int, double, double> note = (start, len, f, vol) =>
            {
                for (int i = 0; i < len && start + i < total; i++)
                {
                    double t = (double)i / rate;
                    double env = Math.Min(1.0, t / 0.008) * Math.Exp(-t * 14);                       // ataque suave e cauda curta
                    double v = Math.Sin(2 * Math.PI * f * t) * 0.8 + Math.Sin(2 * Math.PI * f * 2 * t) * 0.12 + Math.Sin(2 * Math.PI * f * 3 * t) * 0.04;   // quase seno: redondo, sem "bip"
                    int idx = start + i; int val = s[idx] + (int)(v * env * vol * 32767);
                    s[idx] = (short)Math.Max(-32767, Math.Min(32767, val));
                }
            };
            note(0, n1 + gap + n2, f1, 0.16);
            note(n1 + gap, n2, f2, 0.18);
            using (MemoryStream ms = new MemoryStream())
            using (BinaryWriter w = new BinaryWriter(ms))
            {
                w.Write(Encoding.ASCII.GetBytes("RIFF")); w.Write(36 + total * 2); w.Write(Encoding.ASCII.GetBytes("WAVEfmt "));
                w.Write(16); w.Write((short)1); w.Write((short)1); w.Write(rate); w.Write(rate * 2); w.Write((short)2); w.Write((short)16);
                w.Write(Encoding.ASCII.GetBytes("data")); w.Write(total * 2);
                foreach (short x in s) w.Write(x);
                w.Flush(); return ms.ToArray();
            }
        }
        static void Chime(bool mute)
        {
            if (wavOn == null) { wavOff = Wav(659.25, 440.0); wavOn = Wav(523.25, 783.99); }   // Mi→Lá ao silenciar, Dó→Sol ao ligar
            using (MemoryStream ms = new MemoryStream(mute ? wavOff : wavOn))
            using (System.Media.SoundPlayer sp = new System.Media.SoundPlayer(ms)) sp.PlaySync();
        }
        // falar enquanto se carrega numa tecla: o micro fica silenciado e só abre com a tecla em baixo
        [DllImport("user32.dll")] static extern short GetAsyncKeyState(int vk);
        static void SyncPtt()
        {
            if (PttVk <= 0 || ptt != null) return;
            ptt = new Thread(() =>
            {
                bool was = false; Set(true);
                while (PttVk > 0)
                {
                    bool down = (GetAsyncKeyState(PttVk) & 0x8000) != 0;
                    if (down != was) { was = down; Som.SetMics(!down, All); muted = !down; Program.Ui(() => { if (badge != null) badge.Check(); }); }
                    Thread.Sleep(25);
                }
                ptt = null;
            }) { IsBackground = true, Name = "NEXUS falar com tecla" };
            ptt.Start();
        }
        public static string Opts(string all, string bdg, string snd, string key, string pttVk)
        {
            if (all != null) Cfg23.Set("mic_all", all == "1" ? "1" : "0");
            if (bdg != null) Cfg23.Set("mic_badge", bdg == "1" ? "1" : "0");
            if (snd != null) Cfg23.Set("mic_sound", snd == "1" ? "1" : "0");
            if (key != null) { string k = key.Trim().ToLowerInvariant(); Cfg23.Set("mic_key", k == "" || GameOverlay.ParseKey(k) != null ? (k == "" ? null : k) : Key); }
            if (pttVk != null) { int v; int.TryParse(pttVk, out v); Cfg23.Set("mic_ptt", v > 0 && v < 256 ? v.ToString() : null); if (v <= 0) Set(false); SyncPtt(); }
            Program.Ui(() => { try { if (hot != null) hot.Apply(); if (badge != null) badge.Check(); } catch { } });
            return Json();
        }
        public static string Json()
        {
            bool m = Som.MicMuted();
            return "{\"ok\":true,\"muted\":" + (m ? "true" : "false") + ",\"name\":" + Js.S(Som.MicName()) + ",\"all\":" + (All ? "true" : "false") + ",\"badge\":" + (ShowBadge ? "true" : "false") +
                   ",\"sound\":" + (Sound ? "true" : "false") + ",\"key\":" + Js.S(Key) + ",\"keyOk\":" + (hot == null || hot.Ok ? "true" : "false") + ",\"ptt\":" + PttVk + "}";
        }

        class HotWin : NativeWindow
        {
            [DllImport("user32.dll")] static extern bool RegisterHotKey(IntPtr h, int id, uint mods, uint vk);
            [DllImport("user32.dll")] static extern bool UnregisterHotKey(IntPtr h, int id);
            public bool Ok = true; string cur;
            public HotWin() { CreateHandle(new CreateParams()); }
            public void Apply()
            {
                string k = Key; if (k == cur) return;
                UnregisterHotKey(Handle, 21); cur = k;
                uint[] p = GameOverlay.ParseKey(k);
                Ok = p == null ? k == "" : RegisterHotKey(Handle, 21, p[0] | 0x4000, p[1]);
            }
            protected override void WndProc(ref Message m)
            {
                if (m.Msg == 0x0312 && m.WParam.ToInt32() == 21) ThreadPool.QueueUserWorkItem(delegate { try { Toggle(); } catch { } });
                base.WndProc(ref m);
            }
        }

        // aviso pequeno no canto do ecrã enquanto o micro está silenciado (por cima de tudo, os cliques passam)
        class Badge : Form
        {
            readonly System.Windows.Forms.Timer t = new System.Windows.Forms.Timer { Interval = 1000 };
            public Badge()
            {
                FormBorderStyle = FormBorderStyle.None; ShowInTaskbar = false; TopMost = true; StartPosition = FormStartPosition.Manual;
                BackColor = Color.FromArgb(20, 0, 0); ForeColor = Color.FromArgb(255, 80, 80); Opacity = 0.88;
                Font = new Font("Segoe UI", 10f, FontStyle.Bold); Size = new Size(210, 30);
                t.Tick += (s, e) => Check(); t.Start();
            }
            protected override bool ShowWithoutActivation { get { return true; } }
            protected override CreateParams CreateParams { get { CreateParams cp = base.CreateParams; cp.ExStyle |= 0x80 | 0x8 | 0x08000000 | 0x20; return cp; } }
            public void Check()
            {
                bool m = muted;
                try { if (PttVk <= 0) m = Som.MicMuted(); } catch { }
                muted = m;
                bool show = m && ShowBadge;
                if (show && !Visible)
                {
                    Rectangle wa = Screen.PrimaryScreen.WorkingArea;
                    Location = new Point(wa.Right - Width - 16, wa.Top + 16);
                    Show();
                }
                else if (!show && Visible) Hide();
                if (Visible) Invalidate();
            }
            protected override void OnPaint(PaintEventArgs e)
            {
                e.Graphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
                using (Pen p = new Pen(ForeColor, 2)) e.Graphics.DrawRectangle(p, 1, 1, Width - 3, Height - 3);
                TextRenderer.DrawText(e.Graphics, "● " + Lang.L("MICROFONE SILENCIADO"), Font, ClientRectangle, ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            }
        }
    }

    // ============================================================ 72. rede de casa
    static class RedeCasa
    {
        [DllImport("iphlpapi.dll")] static extern int GetIpNetTable(IntPtr t, ref int size, bool order);
        class D { public string Mac, Ip, Name = "", Label = "", Kind = ""; public DateTime First, Last; public bool Online, Random, Me, Router; }
        static readonly object lk = new object();
        static Dictionary<string, D> devs;            // MAC -> dispositivo
        static volatile string state = ""; static DateTime lastScan = DateTime.MinValue;
        static string routerIp = "", routerMac = "", myIp = "", myMac = "", subnet = "";
        static readonly List<string> alerts = new List<string>();
        static volatile bool routerChanged;
        const string FILE = "rede_casa.txt";

        public static bool Alert { get { return Cfg23.On("lan_alert", true); } }
        public static int AutoMin { get { return Cfg23.Int("lan_auto", 0); } }          // 0 = só quando carregas em procurar
        public static bool AskRouter { get { return Cfg23.On("lan_dns", true); } }     // nomes perguntados ao router
        public static bool AskDevices { get { return Cfg23.On("lan_nb", true); } }     // nomes perguntados aos PCs (NetBIOS)
        public static bool Phone { get { return Cfg23.On("lan_phone", false); } }      // mostrar no telemóvel

        static void Load()
        {
            if (devs != null) return;
            devs = new Dictionary<string, D>(StringComparer.OrdinalIgnoreCase);
            foreach (string l in Vigias3.Read(FILE))
            {
                string[] p = l.Split('|'); if (p.Length < 7) continue;
                long f, a; long.TryParse(p[5], out f); long.TryParse(p[6], out a);
                devs[p[0]] = new D { Mac = p[0], Ip = p[1], Name = p[2], Label = p[3], Kind = p[4], First = new DateTime(f), Last = new DateTime(a), Random = IsRandom(p[0]) };
            }
            routerMac = Cfg23.Get("lan_router_mac", "");
        }
        static void Save() { Vigias3.Write(FILE, devs.Values.Select(d => d.Mac + "|" + d.Ip + "|" + Vigias3.Clean(d.Name) + "|" + Vigias3.Clean(d.Label) + "|" + d.Kind + "|" + d.First.Ticks + "|" + d.Last.Ticks)); }
        // endereço "privado" (os telemóveis inventam um por rede Wi-Fi): o 2.º bit do 1.º byte
        static bool IsRandom(string mac) { int b; return mac.Length >= 2 && int.TryParse(mac.Substring(0, 2), NumberStyles.HexNumber, null, out b) && (b & 2) != 0; }

        // a placa de rede principal (a que tem o router)
        static bool Local(out IPAddress ip, out IPAddress mask, out IPAddress gw, out string mac)
        {
            ip = mask = gw = null; mac = "";
            foreach (NetworkInterface n in NetworkInterface.GetAllNetworkInterfaces())
            {
                if (n.OperationalStatus != OperationalStatus.Up || n.NetworkInterfaceType == NetworkInterfaceType.Loopback) continue;
                IPInterfaceProperties pr; try { pr = n.GetIPProperties(); } catch { continue; }
                GatewayIPAddressInformation g = pr.GatewayAddresses.FirstOrDefault(x => x.Address.AddressFamily == AddressFamily.InterNetwork && !x.Address.Equals(IPAddress.Any));
                if (g == null) continue;
                UnicastIPAddressInformation u = pr.UnicastAddresses.FirstOrDefault(x => x.Address.AddressFamily == AddressFamily.InterNetwork);
                if (u == null || u.IPv4Mask == null) continue;
                ip = u.Address; mask = u.IPv4Mask; gw = g.Address; mac = Mac(n.GetPhysicalAddress().GetAddressBytes());
                return true;
            }
            return false;
        }
        static string Mac(byte[] b) { return b == null || b.Length < 6 ? "" : string.Join(":", b.Take(6).Select(x => x.ToString("x2")).ToArray()); }
        static bool Private(IPAddress a)
        {
            byte[] b = a.GetAddressBytes();
            return b.Length == 4 && (b[0] == 10 || (b[0] == 172 && b[1] >= 16 && b[1] <= 31) || (b[0] == 192 && b[1] == 168) || (b[0] == 169 && b[1] == 254));
        }
        // tabela de vizinhos do Windows (IP -> MAC): não manda nada para a rede
        static Dictionary<string, string> Arp()
        {
            Dictionary<string, string> r = new Dictionary<string, string>();
            int size = 0; GetIpNetTable(IntPtr.Zero, ref size, false);
            if (size <= 0) return r;
            IntPtr b = Marshal.AllocHGlobal(size);
            try
            {
                if (GetIpNetTable(b, ref size, false) != 0) return r;
                int n = Marshal.ReadInt32(b);
                for (int i = 0; i < n && i < 4096; i++)
                {
                    IntPtr row = new IntPtr(b.ToInt64() + 4 + i * 24);
                    int len = Marshal.ReadInt32(row, 4), type = Marshal.ReadInt32(row, 20);
                    if (len != 6 || type == 2) continue;   // 2 = inválido
                    byte[] m = new byte[6]; Marshal.Copy(new IntPtr(row.ToInt64() + 8), m, 0, 6);
                    if (m.All(x => x == 0) || m.All(x => x == 0xFF) || (m[0] & 1) != 0) continue;   // vazio, difusão, multicast
                    uint a = (uint)Marshal.ReadInt32(row, 16);
                    string ip = (a & 0xFF) + "." + ((a >> 8) & 0xFF) + "." + ((a >> 16) & 0xFF) + "." + (a >> 24);
                    r[ip] = Mac(m);
                }
            }
            finally { Marshal.FreeHGlobal(b); }
            return r;
        }

        // de 2 em 2 minutos, sem mandar nada: o router mudou de MAC? (troca de router ou alguém a fingir ser o router)
        public static void Passive()
        {
            IPAddress ip, mask, gw; string mm;
            if (!Local(out ip, out mask, out gw, out mm)) return;
            Dictionary<string, string> arp = Arp();
            string gmac; if (!arp.TryGetValue(gw.ToString(), out gmac)) return;
            lock (lk)
            {
                Load();
                routerIp = gw.ToString(); myIp = ip.ToString(); myMac = mm;
                string known = Cfg23.Get("lan_router_mac", ""), kip = Cfg23.Get("lan_router_ip", "");
                // outro IP com o MAC do router = alguém a responder como se fosse o router
                List<string> dup = arp.Where(x => x.Value == gmac && x.Key != routerIp && !x.Key.EndsWith(".255")).Select(x => x.Key).ToList();
                if (known == "" || kip != routerIp) { Cfg23.Set("lan_router_mac", gmac); Cfg23.Set("lan_router_ip", routerIp); routerMac = gmac; }
                else if (known != gmac && !routerChanged)
                {
                    AddAlert(Lang.L("O router mudou de endereço físico (MAC)") + ": " + known + " → " + gmac); routerChanged = true;
                    Vigias3.Notify("lan_rmac_" + gmac, "NEXUS · " + Lang.L("Router diferente"),
                        Lang.L("O router da tua rede tem outro endereço físico. Se trocaste de router é normal; se não, pode ser alguém a fazer-se passar por ele. Vê em Rede de casa."), 24 * 30);
                    routerMac = gmac;
                }
                if (dup.Count > 0)
                    Vigias3.Notify("lan_dup_" + gmac, "NEXUS · " + Lang.L("Dois aparelhos com o endereço do router"),
                        string.Join(", ", dup.ToArray()) + " " + Lang.L("responde com o mesmo endereço físico do router. Pode ser um repetidor Wi-Fi, ou alguém a desviar o tráfego. Vê em Rede de casa."), 24);
            }
        }
        public static string AcceptRouter()
        {
            Cfg23.Set("lan_router_mac", null); Cfg23.Set("lan_router_ip", null);
            lock (lk) alerts.Clear();
            routerChanged = false;
            Passive();
            return Json(false);
        }
        static void AddAlert(string s) { lock (lk) { alerts.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm") + " · " + s); if (alerts.Count > 20) alerts.RemoveAt(0); } }

        static int busy;
        public static string Scan(bool manual)
        {
            if (Interlocked.Exchange(ref busy, 1) == 1) return Json(false);
            try
            {
                IPAddress ip, mask, gw; string mm;
                if (!Local(out ip, out mask, out gw, out mm) || !Private(ip)) { state = Lang.L("Sem rede de casa (ou rede que não é privada)."); return Json(false); }
                state = Lang.L("A procurar…");
                byte[] a = ip.GetAddressBytes(), m = mask.GetAddressBytes();
                // no máximo 254 endereços (uma rede /24 à volta deste PC), por respeito à rede
                if (m[2] != 255) m = new byte[] { 255, 255, 255, 0 };
                byte[] net = new byte[4]; for (int i = 0; i < 4; i++) net[i] = (byte)(a[i] & m[i]);
                subnet = net[0] + "." + net[1] + "." + net[2] + ".0/24";
                List<IPAddress> targets = new List<IPAddress>();
                for (int h = 1; h < 255; h++) { byte[] t = { net[0], net[1], net[2], (byte)h }; if (t[3] != a[3]) targets.Add(new IPAddress(t)); }
                // um "ping" a cada um (64 de cada vez): quem responde, ou quem só responde ao ARP, fica na tabela do Windows
                HashSet<string> alive = new HashSet<string>();
                foreach (IEnumerable<IPAddress> chunk in targets.Select((x, i) => new { x, i }).GroupBy(z => z.i / 64).Select(g => g.Select(z => z.x)))
                {
                    List<Thread> ths = new List<Thread>();
                    foreach (IPAddress t in chunk)
                    {
                        IPAddress tt = t;
                        Thread th = new Thread(() => { try { using (Ping p = new Ping()) if (p.Send(tt, 600).Status == IPStatus.Success) lock (alive) alive.Add(tt.ToString()); } catch { } }) { IsBackground = true };
                        th.Start(); ths.Add(th);
                    }
                    foreach (Thread th in ths) th.Join(2000);
                }
                Dictionary<string, string> arp = Arp();
                DateTime now = DateTime.Now;
                List<D> fresh = new List<D>();
                lock (lk)
                {
                    Load();
                    bool first = devs.Count == 0;
                    routerIp = gw.ToString(); myIp = ip.ToString(); myMac = mm;
                    foreach (D d in devs.Values) d.Online = false;
                    Action<string, string> see = (ipx, mac) =>
                    {
                        if (string.IsNullOrEmpty(mac)) return;
                        D d; if (!devs.TryGetValue(mac, out d)) { d = new D { Mac = mac, First = now, Random = IsRandom(mac) }; devs[mac] = d; if (!first) fresh.Add(d); }
                        d.Ip = ipx; d.Last = now; d.Online = true; d.Router = ipx == routerIp; d.Me = mac == myMac;
                    };
                    foreach (KeyValuePair<string, string> x in arp) if (x.Key.StartsWith(net[0] + "." + net[1] + "." + net[2] + ".")) see(x.Key, x.Value);
                    see(myIp, myMac);
                }
                // nomes: perguntados ao router (DNS) e aos PCs (NetBIOS); nunca à internet
                List<D> online; lock (lk) online = devs.Values.Where(d => d.Online).ToList();
                List<Thread> nth = new List<Thread>();
                foreach (D d in online)
                {
                    D dd = d;
                    Thread th = new Thread(() =>
                    {
                        string n = "";
                        if (dd.Me) n = Environment.MachineName;
                        if (n == "" && AskRouter) n = Ptr(dd.Ip, routerIp);
                        if (n == "" && AskDevices) n = NetBios(dd.Ip);
                        if (n != "") dd.Name = n;
                        dd.Kind = Guess(dd);
                    }) { IsBackground = true };
                    th.Start(); nth.Add(th);
                }
                foreach (Thread th in nth) th.Join(3000);
                lock (lk) Save();
                lastScan = now;
                state = "";
                if (Alert)
                    foreach (D d in fresh.Take(3))
                    {
                        AddAlert(Lang.L("Dispositivo novo na rede") + ": " + (d.Name != "" ? d.Name : d.Mac) + " (" + d.Ip + ")");
                        Vigias3.Notify("lan_new_" + d.Mac, "NEXUS · " + Lang.L("Dispositivo novo na rede"),
                            (d.Name != "" ? d.Name : Lang.L("Sem nome")) + " · " + d.Ip + ". " + Lang.L("Se não o conheces, vê em Rede de casa."), 24 * 365);
                    }
                return Json(false);
            }
            catch (Exception e) { state = e.Message; return Json(false); }
            finally { Interlocked.Exchange(ref busy, 0); }
        }
        static string Guess(D d)
        {
            if (d.Router) return "router";
            if (d.Me) return "pc";
            string n = (d.Name + " " + d.Label).ToLowerInvariant();
            if (Regex.IsMatch(n, "iphone|android|galaxy|pixel|redmi|xiaomi|huawei|oneplus|oppo|realme|motorola|moto-|sm-[a-z]")) return "phone";
            if (Regex.IsMatch(n, "ipad|tab|kindle")) return "tablet";
            if (Regex.IsMatch(n, "tv|webos|bravia|roku|chromecast|fire|shield|appletv|tizen|android-tv|meo|vodafone-box|nos-box")) return "tv";
            if (Regex.IsMatch(n, "ps4|ps5|playstation|xbox|nintendo|switch")) return "console";
            if (Regex.IsMatch(n, "print|epson|canon|brother|hp[0-9a-f]{6}|laserjet|officejet|deskjet")) return "printer";
            if (Regex.IsMatch(n, "echo|alexa|google-home|nest|homepod|sonos")) return "speaker";
            if (Regex.IsMatch(n, "cam|ezviz|hikvision|tapo|ring|imou|reolink")) return "camera";
            if (Regex.IsMatch(n, "desktop|laptop|pc|macbook|imac|-mbp|notebook")) return "pc";
            if (Regex.IsMatch(n, "repeater|extender|mesh|deco|orbi|eero|ap-")) return "wifi";
            if (d.Random) return "phone";   // endereço privado: quase sempre telemóvel ou tablet
            return "";
        }
        // nome pelo DNS do router (pergunta só ao router, mesmo que o PC use outro DNS: não sai para a internet)
        static string Ptr(string ip, string router)
        {
            try
            {
                string[] o = ip.Split('.');
                string q = o[3] + "." + o[2] + "." + o[1] + "." + o[0] + ".in-addr.arpa";
                List<byte> pk = new List<byte> { 0x4e, 0x58, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0 };
                foreach (string part in q.Split('.')) { pk.Add((byte)part.Length); pk.AddRange(Encoding.ASCII.GetBytes(part)); }
                pk.AddRange(new byte[] { 0, 0, 12, 0, 1 });
                using (UdpClient u = new UdpClient())
                {
                    u.Client.ReceiveTimeout = 800;
                    IPEndPoint ep = new IPEndPoint(IPAddress.Parse(router), 53);
                    u.Send(pk.ToArray(), pk.Count, ep);
                    byte[] r = u.Receive(ref ep);
                    if (r.Length < 12 || (r[3] & 0x0F) != 0 || ((r[6] << 8) | r[7]) == 0) return "";
                    int i = 12;
                    while (i < r.Length && r[i] != 0) i += r[i] + 1;
                    i += 5;   // fim do nome + tipo + classe
                    // primeira resposta: nome (comprimido) + tipo(2) classe(2) ttl(4) tamanho(2) dados
                    if (i + 12 > r.Length) return "";
                    i += (r[i] & 0xC0) == 0xC0 ? 2 : Skip(r, i) - i;
                    int type = (r[i] << 8) | r[i + 1]; i += 10;
                    if (type != 12) return "";
                    string n = ReadName(r, i, 0);
                    n = Regex.Replace(n, @"\.(lan|home|local|localdomain|home\.arpa|router|meo|vodafone)$", "", RegexOptions.IgnoreCase);
                    return n.Length > 60 ? n.Substring(0, 60) : n;
                }
            }
            catch { return ""; }
        }
        static int Skip(byte[] r, int i) { while (i < r.Length && r[i] != 0) { if ((r[i] & 0xC0) == 0xC0) return i + 2; i += r[i] + 1; } return i + 1; }
        static string ReadName(byte[] r, int i, int depth)
        {
            StringBuilder sb = new StringBuilder();
            while (i < r.Length && r[i] != 0 && depth < 8)
            {
                if ((r[i] & 0xC0) == 0xC0) { if (i + 1 >= r.Length) break; string rest = ReadName(r, ((r[i] & 0x3F) << 8) | r[i + 1], depth + 1); if (sb.Length > 0 && rest != "") sb.Append('.'); sb.Append(rest); return sb.ToString(); }
                int len = r[i]; if (i + 1 + len > r.Length) break;
                if (sb.Length > 0) sb.Append('.');
                sb.Append(Encoding.ASCII.GetString(r, i + 1, len)); i += len + 1;
            }
            return sb.ToString();
        }
        // nome NetBIOS (PCs com Windows, NAS, Samba): pergunta diretamente ao dispositivo
        static string NetBios(string ip)
        {
            try
            {
                byte[] q = { 0x4e, 0x42, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0x20, (byte)'C', (byte)'K' };
                List<byte> pk = new List<byte>(q); for (int i = 0; i < 30; i++) pk.Add((byte)'A');
                pk.AddRange(new byte[] { 0, 0, 0x21, 0, 1 });
                using (UdpClient u = new UdpClient())
                {
                    u.Client.ReceiveTimeout = 700;
                    IPEndPoint ep = new IPEndPoint(IPAddress.Parse(ip), 137);
                    u.Send(pk.ToArray(), pk.Count, ep);
                    byte[] r = u.Receive(ref ep);
                    if (r.Length < 57) return "";
                    int names = r[56];
                    for (int k = 0; k < names && 57 + k * 18 + 18 <= r.Length; k++)
                    {
                        int o = 57 + k * 18; byte suffix = r[o + 15]; int flags = (r[o + 16] << 8) | r[o + 17];
                        if (suffix == 0 && (flags & 0x8000) == 0) return Encoding.ASCII.GetString(r, o, 15).Trim();
                    }
                }
            }
            catch { }
            return "";
        }

        public static string SetLabel(string mac, string label)
        {
            lock (lk) { Load(); D d; if (devs.TryGetValue(mac ?? "", out d)) { d.Label = Vigias3.Clean(label ?? "").Replace("|", ""); if (d.Label.Length > 40) d.Label = d.Label.Substring(0, 40); d.Kind = Guess(d); Save(); } }
            return Json(false);
        }
        public static string Forget(string mac)
        {
            lock (lk) { Load(); if (mac == "*") devs.Clear(); else devs.Remove(mac ?? ""); Save(); }
            return Json(false);
        }
        public static string Opts(string alert, string auto, string dns, string nb, string phone)
        {
            if (alert != null) Cfg23.Set("lan_alert", alert == "1" ? "1" : "0");
            if (auto != null) { int a; int.TryParse(auto, out a); Cfg23.Set("lan_auto", a == 10 || a == 30 || a == 60 ? a.ToString() : null); }
            if (dns != null) Cfg23.Set("lan_dns", dns == "1" ? "1" : "0");
            if (nb != null) Cfg23.Set("lan_nb", nb == "1" ? "1" : "0");
            if (phone != null) Cfg23.Set("lan_phone", phone == "1" ? "1" : "0");
            return Json(false);
        }
        // velocidade da ligação (cabo a 100 Mb/s em vez de 1 Gb/s = cabo ou ficha com problemas)
        static string Links()
        {
            List<string> r = new List<string>();
            try
            {
                foreach (NetworkInterface n in NetworkInterface.GetAllNetworkInterfaces())
                {
                    if (n.OperationalStatus != OperationalStatus.Up || n.NetworkInterfaceType == NetworkInterfaceType.Loopback || n.NetworkInterfaceType == NetworkInterfaceType.Tunnel) continue;
                    string d = n.Description;
                    if (Regex.IsMatch(d, "virtual|hyper-v|vmware|virtualbox|tap-|wintun|wireguard|loopback|bluetooth|pseudo|vEthernet", RegexOptions.IgnoreCase)) continue;
                    bool wifi = n.NetworkInterfaceType == NetworkInterfaceType.Wireless80211;
                    long sp = n.Speed;
                    bool slow = !wifi && sp > 0 && sp <= 100000000 && !Regex.IsMatch(d, "usb", RegexOptions.IgnoreCase);
                    r.Add("{\"name\":" + Js.S(n.Name) + ",\"desc\":" + Js.S(d) + ",\"wifi\":" + (wifi ? "true" : "false") + ",\"mbps\":" + (sp > 0 ? (sp / 1000000).ToString() : "null") + ",\"slow\":" + (slow ? "true" : "false") + "}");
                }
            }
            catch { }
            return "[" + string.Join(",", r.ToArray()) + "]";
        }
        public static string Json(bool passive)
        {
            if (passive) Passive();
            List<D> l; List<string> al;
            lock (lk) { Load(); l = devs.Values.ToList(); al = alerts.ToList(); }
            return "{\"ok\":true,\"state\":" + Js.S(state) + ",\"scanning\":" + (busy == 1 ? "true" : "false") + ",\"last\":" + Js.S(lastScan == DateTime.MinValue ? "" : lastScan.ToString("HH:mm")) +
                ",\"subnet\":" + Js.S(subnet) + ",\"router\":" + Js.S(routerIp) + ",\"routerMac\":" + Js.S(routerMac) + ",\"routerChanged\":" + (routerChanged ? "true" : "false") + ",\"me\":" + Js.S(myIp) +
                ",\"alert\":" + (Alert ? "true" : "false") + ",\"auto\":" + AutoMin + ",\"dns\":" + (AskRouter ? "true" : "false") + ",\"nb\":" + (AskDevices ? "true" : "false") + ",\"phone\":" + (Phone ? "true" : "false") +
                ",\"links\":" + Links() + ",\"alerts\":[" + string.Join(",", al.Select(Js.S)) + "],\"devs\":[" +
                string.Join(",", l.OrderByDescending(d => d.Online).ThenByDescending(d => d.Router).ThenByDescending(d => d.Me).ThenBy(d => IpNum(d.Ip)).Select(d =>
                    "{\"mac\":" + Js.S(d.Mac) + ",\"ip\":" + Js.S(d.Ip) + ",\"name\":" + Js.S(d.Name) + ",\"label\":" + Js.S(d.Label) + ",\"kind\":" + Js.S(d.Kind) +
                    ",\"online\":" + (d.Online ? "true" : "false") + ",\"random\":" + (d.Random ? "true" : "false") + ",\"me\":" + (d.Me ? "true" : "false") + ",\"router\":" + (d.Router ? "true" : "false") +
                    ",\"first\":" + Js.S(d.First.ToString("yyyy-MM-dd")) + ",\"last\":" + Js.S(d.Last.ToString("yyyy-MM-dd HH:mm")) + "}").ToArray()) + "]}";
        }
        static long IpNum(string ip) { long n = 0; foreach (string p in (ip ?? "").Split('.')) { int v; int.TryParse(p, out v); n = n * 256 + v; } return n; }
        public static string Brief() { return routerChanged ? "true" : "false"; }
    }

    // ============================================================ 72b. portas que o router abriu para a internet (UPnP)
    // Jogos e programas pedem ao router para abrir portas sozinhos. Aqui vê-se quais e para que PC.
    static class Upnp
    {
        class M { public string Ext, Proto, Client, Int, Desc, Enabled, Remote; }
        static List<M> last = new List<M>(); static string ctrl = "", svc = "", err = "", routerName = ""; static DateTime at = DateTime.MinValue;
        static int busy;
        static string Find()
        {
            // SSDP: pergunta na rede de casa (multicast local) quem é o router com UPnP
            using (UdpClient u = new UdpClient(new IPEndPoint(IPAddress.Any, 0)))
            {
                u.Client.ReceiveTimeout = 1500;
                foreach (string st in new[] { "urn:schemas-upnp-org:device:InternetGatewayDevice:1", "urn:schemas-upnp-org:device:InternetGatewayDevice:2" })
                {
                    byte[] q = Encoding.ASCII.GetBytes("M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 1\r\nST: " + st + "\r\n\r\n");
                    u.Send(q, q.Length, new IPEndPoint(IPAddress.Parse("239.255.255.250"), 1900));
                }
                DateTime end = DateTime.Now.AddSeconds(2.5);
                while (DateTime.Now < end)
                {
                    IPEndPoint ep = new IPEndPoint(IPAddress.Any, 0); byte[] r;
                    try { r = u.Receive(ref ep); } catch { break; }
                    Match m = Regex.Match(Encoding.ASCII.GetString(r), @"LOCATION:\s*(\S+)", RegexOptions.IgnoreCase);
                    if (!m.Success) continue;
                    Uri loc; if (!Uri.TryCreate(m.Groups[1].Value, UriKind.Absolute, out loc)) continue;
                    IPAddress h; if (!IPAddress.TryParse(loc.Host, out h) || !IsPrivate(h)) continue;   // só routers da rede de casa
                    return loc.ToString();
                }
            }
            return null;
        }
        static bool IsPrivate(IPAddress a) { byte[] b = a.GetAddressBytes(); return b.Length == 4 && (b[0] == 10 || (b[0] == 172 && b[1] >= 16 && b[1] <= 31) || (b[0] == 192 && b[1] == 168)); }
        static string Get(string url) { using (WebClient w = new WebClient()) { w.Proxy = null; return w.DownloadString(url); } }
        static string Soap(string action, string args)
        {
            string body = "<?xml version=\"1.0\"?><s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><s:Body><u:" + action + " xmlns:u=\"" + svc + "\">" + args + "</u:" + action + "></s:Body></s:Envelope>";
            HttpWebRequest rq = (HttpWebRequest)WebRequest.Create(ctrl);
            rq.Method = "POST"; rq.Proxy = null; rq.Timeout = 3000; rq.ContentType = "text/xml; charset=\"utf-8\"";
            rq.Headers.Add("SOAPACTION", "\"" + svc + "#" + action + "\"");
            byte[] b = Encoding.UTF8.GetBytes(body);
            using (Stream s = rq.GetRequestStream()) s.Write(b, 0, b.Length);
            using (WebResponse rs = rq.GetResponse()) using (StreamReader rd = new StreamReader(rs.GetResponseStream())) return rd.ReadToEnd();
        }
        static string Tag(string x, string t) { Match m = Regex.Match(x, "<(?:\\w+:)?" + t + ">([^<]*)</"); return m.Success ? WebUtilityDecode(m.Groups[1].Value) : ""; }
        static string WebUtilityDecode(string s) { return s.Replace("&lt;", "<").Replace("&gt;", ">").Replace("&quot;", "\"").Replace("&apos;", "'").Replace("&amp;", "&"); }
        public static string Scan()
        {
            if (Interlocked.Exchange(ref busy, 1) == 1) return Json();
            try
            {
                err = "";
                string loc = Find();
                if (loc == null) { err = Lang.L("O router não respondeu ao UPnP (está desligado no router, o que é mais seguro)."); last = new List<M>(); return Json(); }
                string xml = Get(loc);
                routerName = Tag(xml, "friendlyName");
                Match sv = Regex.Match(xml, @"<serviceType>(urn:schemas-upnp-org:service:WAN(?:IP|PPP)Connection:\d)</serviceType>.*?<controlURL>([^<]+)</controlURL>", RegexOptions.Singleline);
                if (!sv.Success) { err = Lang.L("O router não tem o serviço de portas UPnP."); return Json(); }
                svc = sv.Groups[1].Value; ctrl = new Uri(new Uri(loc), sv.Groups[2].Value).ToString();
                List<M> l = new List<M>();
                for (int i = 0; i < 128; i++)
                {
                    string r;
                    try { r = Soap("GetGenericPortMappingEntry", "<NewPortMappingIndex>" + i + "</NewPortMappingIndex>"); } catch { break; }   // erro = acabou a lista
                    l.Add(new M { Ext = Tag(r, "NewExternalPort"), Proto = Tag(r, "NewProtocol"), Client = Tag(r, "NewInternalClient"), Int = Tag(r, "NewInternalPort"), Desc = Tag(r, "NewPortMappingDescription"), Enabled = Tag(r, "NewEnabled"), Remote = Tag(r, "NewRemoteHost") });
                }
                last = l; at = DateTime.Now;
            }
            catch (Exception e) { err = e.Message; }
            finally { Interlocked.Exchange(ref busy, 0); }
            return Json();
        }
        public static string Delete(string ext, string proto)
        {
            if (ctrl == "" || !Regex.IsMatch(ext ?? "", @"^\d{1,5}$") || (proto != "TCP" && proto != "UDP")) return Ps23.Ok(false, "?");
            try { Soap("DeletePortMapping", "<NewRemoteHost></NewRemoteHost><NewExternalPort>" + ext + "</NewExternalPort><NewProtocol>" + proto + "</NewProtocol>"); }
            catch (Exception e) { return Ps23.Ok(false, Lang.L("O router não deixou.") + " " + e.Message); }
            return Scan();
        }
        public static string Json()
        {
            string me = "";
            try { foreach (NetworkInterface n in NetworkInterface.GetAllNetworkInterfaces()) foreach (UnicastIPAddressInformation u in n.GetIPProperties().UnicastAddresses) if (u.Address.AddressFamily == AddressFamily.InterNetwork) me += "," + u.Address; } catch { }
            me += ",";
            return "{\"ok\":true,\"busy\":" + (busy == 1 ? "true" : "false") + ",\"err\":" + Js.S(err) + ",\"router\":" + Js.S(routerName) + ",\"at\":" + Js.S(at == DateTime.MinValue ? "" : at.ToString("HH:mm")) + ",\"items\":[" +
                string.Join(",", last.Select(m => "{\"ext\":" + Js.S(m.Ext) + ",\"proto\":" + Js.S(m.Proto) + ",\"client\":" + Js.S(m.Client) + ",\"int\":" + Js.S(m.Int) + ",\"desc\":" + Js.S(m.Desc) +
                    ",\"on\":" + (m.Enabled != "0" ? "true" : "false") + ",\"mine\":" + (me.Contains("," + m.Client + ",") ? "true" : "false") + "}").ToArray()) + "]}";
        }
    }

    // ============================================================ 73. rato e teclado pelo telemóvel (só telemóveis aceites no PC)
    static class RatoRemoto
    {
        [DllImport("user32.dll")] static extern void mouse_event(uint f, int dx, int dy, int data, UIntPtr extra);
        [DllImport("user32.dll")] static extern uint SendInput(uint n, IntPtr i, int size);
        // INPUT montado à mão: 40 bytes em 64 bits, 28 em 32 (o tipo, e o teclado a seguir: vk, scan, flags, time, extra)
        static void Send(ushort vk, ushort scan, uint flags)
        {
            int size = IntPtr.Size == 8 ? 40 : 28, o = IntPtr.Size == 8 ? 8 : 4;
            IntPtr b = Marshal.AllocHGlobal(size);
            try
            {
                for (int i = 0; i < size; i++) Marshal.WriteByte(b, i, 0);
                Marshal.WriteInt32(b, 0, 1);                       // INPUT_KEYBOARD
                Marshal.WriteInt16(b, o, (short)vk); Marshal.WriteInt16(b, o + 2, (short)scan); Marshal.WriteInt32(b, o + 4, (int)flags);
                SendInput(1, b, size);
            }
            finally { Marshal.FreeHGlobal(b); }
        }
        static void Uni(char c, bool up) { Send(0, c, 0x4u | (up ? 2u : 0u)); }
        static void Vk(ushort vk, bool up)
        {
            bool ext = vk == 0x25 || vk == 0x26 || vk == 0x27 || vk == 0x28 || vk == 0x2E || vk == 0x24 || vk == 0x23 || vk == 0x21 || vk == 0x22 || vk == 0x5B;
            Send(vk, 0, (up ? 2u : 0u) | (ext ? 1u : 0u));
        }
        static readonly Dictionary<string, ushort[]> KeyMap = new Dictionary<string, ushort[]>
        {
            { "enter", new ushort[] { 0x0D } }, { "back", new ushort[] { 0x08 } }, { "esc", new ushort[] { 0x1B } }, { "tab", new ushort[] { 0x09 } }, { "space", new ushort[] { 0x20 } },
            { "up", new ushort[] { 0x26 } }, { "down", new ushort[] { 0x28 } }, { "left", new ushort[] { 0x25 } }, { "right", new ushort[] { 0x27 } }, { "del", new ushort[] { 0x2E } },
            { "alttab", new ushort[] { 0x12, 0x09 } }, { "win", new ushort[] { 0x5B } }, { "f11", new ushort[] { 0x7A } }, { "altf4", new ushort[] { 0x12, 0x73 } }, { "desk", new ushort[] { 0x5B, 0x44 } }
        };
        public static string Do(string q, string body)
        {
            string a = q ?? "";
            switch (a)
            {
                case "move":
                    {
                        int dx, dy; int.TryParse(Field(body, "x"), out dx); int.TryParse(Field(body, "y"), out dy);
                        dx = Math.Max(-400, Math.Min(400, dx)); dy = Math.Max(-400, Math.Min(400, dy));
                        if (dx != 0 || dy != 0) mouse_event(0x1, dx, dy, 0, UIntPtr.Zero);
                        break;
                    }
                case "click": mouse_event(0x2, 0, 0, 0, UIntPtr.Zero); mouse_event(0x4, 0, 0, 0, UIntPtr.Zero); break;
                case "dbl": for (int i = 0; i < 2; i++) { mouse_event(0x2, 0, 0, 0, UIntPtr.Zero); mouse_event(0x4, 0, 0, 0, UIntPtr.Zero); } break;
                case "right": mouse_event(0x8, 0, 0, 0, UIntPtr.Zero); mouse_event(0x10, 0, 0, 0, UIntPtr.Zero); break;
                case "down": mouse_event(0x2, 0, 0, 0, UIntPtr.Zero); break;
                case "up": mouse_event(0x4, 0, 0, 0, UIntPtr.Zero); break;
                case "scroll": { int d; int.TryParse(Field(body, "d"), out d); d = Math.Max(-1200, Math.Min(1200, d)); if (d != 0) mouse_event(0x800, 0, 0, d, UIntPtr.Zero); break; }
                case "text":
                    {
                        string s = Field(body, "t") ?? ""; if (s.Length > 500) s = s.Substring(0, 500);
                        foreach (char c in s) { if (c == '\n') { Vk(0x0D, false); Vk(0x0D, true); continue; } Uni(c, false); Uni(c, true); }
                        break;
                    }
                case "key":
                    {
                        ushort[] ks; if (!KeyMap.TryGetValue(Field(body, "k") ?? "", out ks)) return Ps23.Ok(false, "?");
                        foreach (ushort k in ks) Vk(k, false);
                        for (int i = ks.Length - 1; i >= 0; i--) Vk(ks[i], true);
                        break;
                    }
                case "mic": MicPlus.Toggle(); return "{\"ok\":true,\"muted\":" + (Som.MicMuted() ? "true" : "false") + "}";
                default: return Ps23.Ok(false, "?");
            }
            return "{\"ok\":true}";
        }
        // corpo "x=3&y=-2" (o telemóvel manda em POST)
        static string Field(string body, string k)
        {
            foreach (string p in (body ?? "").Split('&')) { int i = p.IndexOf('='); if (i > 0 && p.Substring(0, i) == k) return Uri.UnescapeDataString(p.Substring(i + 1).Replace('+', ' ')); }
            return null;
        }
    }

    // ============================================================ 74. galeria de capturas e clipes
    static class Galeria
    {
        class F { public string Path, Game, Src; public DateTime When; public long Size; public bool Vid; }
        static List<F> items = new List<F>(); static DateTime at = DateTime.MinValue; static int busy;
        static readonly object lk = new object();
        static readonly string[] Img = { ".png", ".jpg", ".jpeg", ".webp", ".bmp", ".jxr" }, Vid = { ".mp4", ".mkv", ".mov", ".webm", ".avi" };
        public static bool Phone { get { return Cfg23.On("gal_phone", false); } }
        static string Thumbs { get { return Path.Combine(AppSettings.Dir, "miniaturas"); } }

        static void Add(List<F> l, string dir, string src, Func<string, string> game, int depth)
        {
            if (!Directory.Exists(dir) || l.Count > 8000) return;
            try
            {
                foreach (string f in Directory.GetFiles(dir))
                {
                    string e = System.IO.Path.GetExtension(f).ToLowerInvariant();
                    bool v = Vid.Contains(e); if (!v && !Img.Contains(e)) continue;
                    FileInfo fi = new FileInfo(f);
                    if (fi.Length < 2048) continue;
                    l.Add(new F { Path = f, Src = src, Game = game(f), When = fi.LastWriteTime, Size = fi.Length, Vid = v });
                }
                if (depth > 0) foreach (string d in Directory.GetDirectories(dir)) { string n = System.IO.Path.GetFileName(d); if (n.StartsWith(".") || n.Equals("thumbnails", StringComparison.OrdinalIgnoreCase)) continue; Add(l, d, src, game, depth - 1); }
            }
            catch { }
        }
        static string Clean(string n)
        {
            n = Regex.Replace(n ?? "", @"[ _-]*\d{4}[._-]\d{2}[._-]\d{2}.*$", "");   // "Jogo 2024-01-31 22-10-05" -> "Jogo"
            n = Regex.Replace(n, @"\s+(Screenshot|Captura de ecrã|Captura de tela).*$", "", RegexOptions.IgnoreCase);
            return n.Trim(' ', '-', '_', '.');
        }
        public static void Index()
        {
            if (Interlocked.Exchange(ref busy, 1) == 1) return;
            try
            {
                List<F> l = new List<F>();
                string vids = Environment.GetFolderPath(Environment.SpecialFolder.MyVideos), pics = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);
                // Xbox Game Bar (Win+Alt+PrtSc / Win+Alt+G)
                Add(l, Path.Combine(vids, "Captures"), "Xbox Game Bar", f => Clean(System.IO.Path.GetFileNameWithoutExtension(f)), 0);
                // Win+PrtSc e Ferramenta de Recorte
                Add(l, Path.Combine(pics, "Screenshots"), "Windows", f => Lang.L("Capturas do Windows"), 0);
                // NVIDIA, AMD, Medal, OBS: uma pasta por jogo dentro de Vídeos
                string[] skip = { "Captures", "Captures (old)" };
                try
                {
                    foreach (string d in Directory.GetDirectories(vids))
                    {
                        string n = Path.GetFileName(d); if (skip.Contains(n)) continue;
                        if (n.Equals("Radeon ReLive", StringComparison.OrdinalIgnoreCase) || n.Equals("Medal", StringComparison.OrdinalIgnoreCase))
                            foreach (string g in Directory.GetDirectories(d)) { string gg = Path.GetFileName(g); Add(l, g, n, f => FolderGame(f, d), 2); }
                        else Add(l, d, "NVIDIA / " + Lang.L("Vídeos"), f => FolderGame(f, vids), 2);
                    }
                }
                catch { }
                Add(l, vids, Lang.L("Vídeos"), f => Lang.L("Gravações"), 0);   // OBS grava na pasta Vídeos
                // Steam (F12): userdata\<conta>\760\remote\<appid>\screenshots
                try
                {
                    string steam = null;
                    using (RegistryKey k = Registry.CurrentUser.OpenSubKey(@"Software\Valve\Steam")) if (k != null) steam = Convert.ToString(k.GetValue("SteamPath"));
                    if (!string.IsNullOrEmpty(steam))
                    {
                        Dictionary<string, string> names = SteamNames(steam.Replace('/', '\\'));
                        string ud = Path.Combine(steam.Replace('/', '\\'), "userdata");
                        if (Directory.Exists(ud))
                            foreach (string acc in Directory.GetDirectories(ud))
                            {
                                string rem = Path.Combine(acc, @"760\remote");
                                if (!Directory.Exists(rem)) continue;
                                foreach (string app in Directory.GetDirectories(rem))
                                {
                                    string id = Path.GetFileName(app), nm; if (!names.TryGetValue(id, out nm)) nm = "Steam " + id;
                                    Add(l, Path.Combine(app, "screenshots"), "Steam", f => nm, 0);
                                }
                            }
                    }
                }
                catch { }
                foreach (string d in Cfg23.Get("gal_dirs", "").Split('\n').Where(x => x.Trim() != "")) Add(l, d.Trim(), Lang.L("Pasta tua"), f => FolderGame(f, d.Trim()), 3);
                lock (lk) { items = l.GroupBy(x => x.Path.ToLowerInvariant()).Select(g => g.First()).OrderByDescending(x => x.When).ToList(); at = DateTime.Now; }
            }
            finally { Interlocked.Exchange(ref busy, 0); }
        }
        static string FolderGame(string f, string root)
        {
            string dir = Path.GetDirectoryName(f);
            if (string.Equals(dir.TrimEnd('\\'), root.TrimEnd('\\'), StringComparison.OrdinalIgnoreCase)) return Clean(Path.GetFileNameWithoutExtension(f));
            string rel = dir.Substring(Math.Min(dir.Length, root.TrimEnd('\\').Length)).Trim('\\');
            string first = rel.Split('\\')[0];
            return first.Equals("Clips", StringComparison.OrdinalIgnoreCase) || first.Equals("Screenshots", StringComparison.OrdinalIgnoreCase) ? (rel.Split('\\').Length > 1 ? rel.Split('\\')[1] : Clean(Path.GetFileNameWithoutExtension(f))) : first;
        }
        static Dictionary<string, string> SteamNames(string steam)
        {
            Dictionary<string, string> r = new Dictionary<string, string>();
            List<string> libs = new List<string> { Path.Combine(steam, "steamapps") };
            try { string vdf = Path.Combine(libs[0], "libraryfolders.vdf"); if (File.Exists(vdf)) foreach (Match m in Regex.Matches(File.ReadAllText(vdf), "\"path\"\\s+\"([^\"]+)\"")) libs.Add(Path.Combine(m.Groups[1].Value.Replace("\\\\", "\\"), "steamapps")); } catch { }
            foreach (string lib in libs.Distinct(StringComparer.OrdinalIgnoreCase))
            {
                try
                {
                    foreach (string f in Directory.GetFiles(lib, "appmanifest_*.acf"))
                    {
                        string t = File.ReadAllText(f);
                        Match a = Regex.Match(t, "\"appid\"\\s+\"(\\d+)\""), n = Regex.Match(t, "\"name\"\\s+\"([^\"]+)\"");
                        if (a.Success && n.Success) r[a.Groups[1].Value] = n.Groups[1].Value;
                    }
                }
                catch { }
            }
            return r;
        }
        static List<F> All() { if ((DateTime.Now - at).TotalSeconds > 90) Index(); lock (lk) return items; }

        public static string Json(string game, int page)
        {
            List<F> l = All();
            var games = l.GroupBy(x => x.Game).Select(g => new { n = g.Key, c = g.Count(), last = g.Max(x => x.When), size = g.Sum(x => x.Size) }).OrderByDescending(g => g.last).ToList();
            List<int> idx = new List<int>();
            for (int i = 0; i < l.Count; i++) if (string.IsNullOrEmpty(game) || l[i].Game == game) idx.Add(i);
            int per = 60, p = Math.Max(0, page);
            return "{\"ok\":true,\"total\":" + l.Count + ",\"size\":" + l.Sum(x => x.Size) + ",\"count\":" + idx.Count + ",\"page\":" + p + ",\"pages\":" + Math.Max(1, (idx.Count + per - 1) / per) +
                ",\"phone\":" + (Phone ? "true" : "false") + ",\"dirs\":" + Js.S(Cfg23.Get("gal_dirs", "")) +
                ",\"games\":[" + string.Join(",", games.Select(g => "{\"n\":" + Js.S(g.n) + ",\"c\":" + g.c + ",\"size\":" + g.size + ",\"last\":" + Js.S(g.last.ToString("yyyy-MM-dd")) + "}").ToArray()) +
                "],\"items\":[" + string.Join(",", idx.Skip(p * per).Take(per).Select(i =>
                {
                    F f = l[i];
                    return "{\"i\":" + i + ",\"k\":" + Js.S(KeyOf(f)) + ",\"game\":" + Js.S(f.Game) + ",\"src\":" + Js.S(f.Src) + ",\"vid\":" + (f.Vid ? "true" : "false") +
                           ",\"when\":" + Js.S(f.When.ToString("yyyy-MM-dd HH:mm")) + ",\"size\":" + f.Size + ",\"name\":" + Js.S(Path.GetFileName(f.Path)) + "}";
                }).ToArray()) + "]}";
        }
        // chave curta para confirmar que o ficheiro pedido é o mesmo da lista (a lista pode mudar entre pedidos)
        static string KeyOf(F f) { unchecked { int h = 17; foreach (char c in f.Path.ToLowerInvariant()) h = h * 31 + c; return ((uint)h ^ (uint)f.Size).ToString("x8"); } }
        static F Pick(string i, string k)
        {
            int n; if (!int.TryParse(i ?? "", out n)) return null;
            List<F> l; lock (lk) l = items;
            if (n < 0 || n >= l.Count || KeyOf(l[n]) != k) return null;
            return File.Exists(l[n].Path) ? l[n] : null;
        }
        // miniatura 320 px (fotos com o GDI+, vídeos com a miniatura do próprio Windows), guardada em disco
        [ComImport, Guid("bcc18b79-ba16-442f-80c4-8a59c30c463b"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        interface IShellItemImageFactory { [PreserveSig] int GetImage(SIZE size, int flags, out IntPtr hbmp); }
        [StructLayout(LayoutKind.Sequential)] struct SIZE { public int cx, cy; }
        [DllImport("shell32.dll", CharSet = CharSet.Unicode, PreserveSig = false)] static extern void SHCreateItemFromParsingName(string path, IntPtr pbc, [MarshalAs(UnmanagedType.LPStruct)] Guid riid, [MarshalAs(UnmanagedType.Interface)] out IShellItemImageFactory f);
        [DllImport("gdi32.dll")] static extern bool DeleteObject(IntPtr h);
        public static byte[] Thumb(string i, string k)
        {
            F f = Pick(i, k); if (f == null) return null;
            string tp = Path.Combine(Thumbs, KeyOf(f) + ".jpg");
            try { if (File.Exists(tp)) return File.ReadAllBytes(tp); } catch { }
            byte[] r = null;
            Exception ex = null;
            Thread th = new Thread(() =>
            {
                try
                {
                    Bitmap src = null;
                    if (!f.Vid && f.Size < 60L << 20) { try { using (FileStream fs = File.OpenRead(f.Path)) using (Image im = Image.FromStream(fs, false, false)) src = new Bitmap(im); } catch { src = null; } }
                    if (src == null)
                    {
                        IShellItemImageFactory fac; SHCreateItemFromParsingName(f.Path, IntPtr.Zero, typeof(IShellItemImageFactory).GUID, out fac);
                        IntPtr hb; if (fac.GetImage(new SIZE { cx = 320, cy = 320 }, 0, out hb) == 0 && hb != IntPtr.Zero) { try { src = Image.FromHbitmap(hb); } finally { DeleteObject(hb); } }
                        Marshal.ReleaseComObject(fac);
                    }
                    if (src == null) return;
                    using (src)
                    {
                        double s = Math.Min(1.0, 320.0 / Math.Max(src.Width, src.Height));
                        int w = Math.Max(1, (int)(src.Width * s)), h = Math.Max(1, (int)(src.Height * s));
                        using (Bitmap b = new Bitmap(w, h))
                        {
                            using (Graphics g = Graphics.FromImage(b)) { g.InterpolationMode = InterpolationMode.HighQualityBicubic; g.DrawImage(src, 0, 0, w, h); }
                            using (MemoryStream ms = new MemoryStream())
                            {
                                ImageCodecInfo jpg = ImageCodecInfo.GetImageEncoders().First(c => c.FormatID == ImageFormat.Jpeg.Guid);
                                EncoderParameters ep = new EncoderParameters(1); ep.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, 78L);
                                b.Save(ms, jpg, ep); r = ms.ToArray();
                            }
                        }
                    }
                }
                catch (Exception e) { ex = e; }
            }) { IsBackground = true };
            th.SetApartmentState(ApartmentState.STA); th.Start(); th.Join(8000);
            if (r != null) { try { Directory.CreateDirectory(Thumbs); File.WriteAllBytes(tp, r); } catch { } }
            return r;
        }
        public static byte[] Full(string i, string k, out string ctype)
        {
            ctype = "image/jpeg";
            F f = Pick(i, k); if (f == null || f.Vid || f.Size > 40L << 20) return null;
            string e = Path.GetExtension(f.Path).ToLowerInvariant();
            ctype = e == ".png" ? "image/png" : e == ".webp" ? "image/webp" : e == ".bmp" ? "image/bmp" : "image/jpeg";
            if (e == ".jxr") return Thumb(i, k);   // HDR da Game Bar: o browser não abre, vai a miniatura
            try { return File.ReadAllBytes(f.Path); } catch { return null; }
        }
        // ficheiro para ver/descarregar (vídeo com avanço: pedidos "Range"); só o que está na lista
        public static string PathOf(string i, string k) { F f = Pick(i, k); return f == null ? null : f.Path; }
        public static string Open(string i, string k, bool folder)
        {
            F f = Pick(i, k); if (f == null) return Ps23.Ok(false, Lang.L("Já não existe."));
            try { if (folder) Process.Start("explorer.exe", "/select,\"" + f.Path + "\""); else Process.Start(new ProcessStartInfo(f.Path) { UseShellExecute = true }); }
            catch (Exception e) { return Ps23.Ok(false, e.Message); }
            return "{\"ok\":true}";
        }
        public static string Opts(string phone, string dirs)
        {
            if (phone != null) Cfg23.Set("gal_phone", phone == "1" ? "1" : "0");
            if (dirs != null) { Cfg23.Set("gal_dirs", string.Join("\n", dirs.Split('\n').Select(x => x.Trim()).Where(x => x != "" && Directory.Exists(x)).Take(10).ToArray())); at = DateTime.MinValue; }
            return Json("", 0);
        }
        public static string Refresh() { at = DateTime.MinValue; Index(); return Json("", 0); }
    }
}
