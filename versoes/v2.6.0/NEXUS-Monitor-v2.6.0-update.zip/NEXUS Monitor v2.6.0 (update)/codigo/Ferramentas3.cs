﻿// NEXUS // MONITOR 2.3 - mais ferramentas: quem usa a internet, Wi-Fi, inventário e garantias, simulador de upgrade,
// periféricos com bateria, espaço escondido, programas esquecidos, apps padrão, versão do Windows, drivers gráficos antigos,
// Modo de Jogo / HAGS, overlays, poupar SSD, atualizações do Windows, antes/depois de mudar peças, o meu PC.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using Microsoft.Win32;

namespace Nexus
{
    static partial class Ferr
    {
        // ============================================================ QUE PROGRAMAS USAM A INTERNET AGORA (ligações TCP por programa; nada sai do PC)
        [DllImport("iphlpapi.dll", SetLastError = true)]
        static extern uint GetExtendedTcpTable(IntPtr pTcpTable, ref int dwOutBufLen, bool sort, int ipVersion, int tblClass, uint reserved);
        public static string ConnsJson()
        {
            Dictionary<int, List<string>> byPid = new Dictionary<int, List<string>>();
            int len = 0;
            GetExtendedTcpTable(IntPtr.Zero, ref len, false, 2, 5, 0);   // AF_INET, TCP_TABLE_OWNER_PID_ALL
            IntPtr buf = Marshal.AllocHGlobal(len + 4096);
            try
            {
                len += 4096;
                if (GetExtendedTcpTable(buf, ref len, false, 2, 5, 0) == 0)
                {
                    int n = Marshal.ReadInt32(buf);
                    for (int i = 0; i < n; i++)
                    {
                        IntPtr row = buf + 4 + i * 24;
                        int state = Marshal.ReadInt32(row);
                        if (state != 5) continue;   // só ESTABLISHED
                        uint remote = (uint)Marshal.ReadInt32(row + 12);
                        int rport = (ushort)IPAddress.NetworkToHostOrder((short)Marshal.ReadInt32(row + 16));
                        int pid = Marshal.ReadInt32(row + 20);
                        IPAddress ip = new IPAddress(remote);
                        if (IPAddress.IsLoopback(ip)) continue;
                        byte[] b = ip.GetAddressBytes();
                        bool lan = b[0] == 10 || (b[0] == 192 && b[1] == 168) || (b[0] == 172 && b[1] >= 16 && b[1] <= 31);
                        if (!byPid.ContainsKey(pid)) byPid[pid] = new List<string>();
                        byPid[pid].Add((lan ? "LAN " : "") + ip + ":" + rport);
                    }
                }
            }
            finally { Marshal.FreeHGlobal(buf); }
            StringBuilder sb = new StringBuilder("{\"ok\":true,\"items\":[");
            bool first = true;
            foreach (var g in byPid.Select(kv =>
            {
                string name = "?", desc = "", path = "";
                try { using (Process p = Process.GetProcessById(kv.Key)) { name = p.ProcessName; try { path = Optimizer.ExePath(p.Id); if (path != "") desc = FileVersionInfo.GetVersionInfo(path).FileDescription ?? ""; } catch { } } } catch { }
                return new { kv.Key, name, desc, path, list = kv.Value };
            }).GroupBy(x => x.name, StringComparer.OrdinalIgnoreCase).OrderByDescending(x => x.Sum(y => y.list.Count)))
            {
                var f = g.First();
                List<string> all = g.SelectMany(x => x.list).ToList();
                if (!first) sb.Append(','); first = false;
                sb.Append("{\"name\":").Append(Js.S(f.name)).Append(",\"desc\":").Append(Js.S(f.desc.Trim())).Append(",\"path\":").Append(Js.S(f.path)).Append(",\"n\":").Append(all.Count)
                  .Append(",\"lan\":").Append(all.Count(x => x.StartsWith("LAN "))).Append(",\"hosts\":[").Append(string.Join(",", all.Select(x => x.Replace("LAN ", "")).Distinct().Take(8).Select(x => Js.S(x)).ToArray())).Append("]}");
            }
            return sb.Append("]}").ToString();
        }

        // ============================================================ WI-FI (sinal, canal, redes vizinhas no mesmo canal)
        public static string WifiJson()
        {
            string i = Ps23.Cmd("netsh.exe", "wlan show interfaces", 8000);
            if (!Regex.IsMatch(i, @"(?im)^\s*(SSID|Nome)\s*:")) return "{\"ok\":true,\"wifi\":false,\"msg\":" + Js.S(i.Length < 300 ? i : "") + "}";
            Func<string, string, string> val = (txt, keyRx) => { Match m = Regex.Match(txt, @"(?im)^\s*(?:" + keyRx + @")\s*:\s*(.+)$"); return m.Success ? m.Groups[1].Value.Trim() : ""; };
            string ssid = val(i, "SSID"), sig = val(i, "Sinal|Signal"), ch = val(i, "Canal|Channel"), radio = val(i, "Tipo de rádio|Radio type"), band = val(i, "Banda|Band"),
                   rx = val(i, "Velocidade de receção \\(Mbps\\)|Taxa de rece[çc][ãa]o \\(Mbps\\)|Receive rate \\(Mbps\\)"), tx = val(i, "Velocidade de transmissão \\(Mbps\\)|Taxa de transmiss[ãa]o \\(Mbps\\)|Transmit rate \\(Mbps\\)"),
                   state = val(i, "Estado|State");
            // redes à volta
            string n = Ps23.Cmd("netsh.exe", "wlan show networks mode=bssid", 10000);
            List<int[]> nets = new List<int[]>();   // {canal, sinal}
            foreach (Match m in Regex.Matches(n, @"(?ims)(?:Sinal|Signal)\s*:\s*(\d+)%.*?(?:Canal|Channel)\s*:\s*(\d+)")) nets.Add(new[] { int.Parse(m.Groups[2].Value), int.Parse(m.Groups[1].Value) });
            int myCh; int.TryParse(Regex.Match(ch, @"\d+").Value, out myCh);
            Func<int, int, bool> overlap = (a, b) => a <= 14 && b <= 14 ? Math.Abs(a - b) < 5 : a == b;
            int same = nets.Count(x => x[0] == myCh) - 1, near = nets.Count(x => x[0] != myCh && overlap(x[0], myCh));
            // canal com menos vizinhos (1, 6, 11 nos 2,4 GHz)
            int[] cands = myCh <= 14 ? new[] { 1, 6, 11 } : new[] { 36, 40, 44, 48, 149, 153, 157, 161 };
            int best = cands.OrderBy(c => nets.Where(x => overlap(x[0], c)).Sum(x => x[1])).First();
            return "{\"ok\":true,\"wifi\":true,\"ssid\":" + Js.S(ssid) + ",\"signal\":" + Js.S(sig) + ",\"channel\":" + myCh + ",\"radio\":" + Js.S(radio) + ",\"band\":" + Js.S(band) +
                   ",\"rx\":" + Js.S(rx) + ",\"tx\":" + Js.S(tx) + ",\"state\":" + Js.S(state) + ",\"networks\":" + nets.Count + ",\"same\":" + Math.Max(0, same) + ",\"near\":" + near + ",\"best\":" + best + "}";
        }

        // ============================================================ INVENTÁRIO (peças, números de série, garantias)
        public static string InvJson(bool fresh)
        {
            if (fresh) Ps23.Drop("inventario");
            string j = Ps23.Run("inventario", @"
$r = New-Object System.Collections.ArrayList
function A($k, $n, $mk, $sn, $x) { [void]$r.Add([pscustomobject]@{ k = $k; n = ([string]$n).Trim(); mk = ([string]$mk).Trim(); sn = ([string]$sn).Trim(); x = [string]$x }) }
$b = Get-CimInstance Win32_BaseBoard; A 'Placa-mãe' $b.Product $b.Manufacturer $b.SerialNumber ''
$bi = Get-CimInstance Win32_BIOS; A 'BIOS' ($bi.SMBIOSBIOSVersion) $bi.Manufacturer '' ($bi.ReleaseDate.ToString('yyyy-MM-dd'))
Get-CimInstance Win32_Processor | ForEach-Object { A 'Processador' $_.Name $_.Manufacturer '' ([string]$_.NumberOfCores + ' núcleos / ' + $_.NumberOfLogicalProcessors + ' threads') }
Get-CimInstance Win32_VideoController | Where-Object { $_.PNPDeviceID -like 'PCI*' } | ForEach-Object { A 'Placa gráfica' $_.Name $_.AdapterCompatibility '' ('driver ' + $_.DriverVersion) }
Get-CimInstance Win32_PhysicalMemory | ForEach-Object { A 'RAM' (([string]$_.PartNumber).Trim() + ' · ' + [math]::Round($_.Capacity/1GB) + ' GB') $_.Manufacturer $_.SerialNumber ([string]$_.ConfiguredClockSpeed + ' MT/s · ' + $_.DeviceLocator) }
Get-PhysicalDisk | ForEach-Object { A 'Disco' $_.FriendlyName '' $_.SerialNumber ([string]$_.MediaType + ' · ' + [math]::Round($_.Size/1GB) + ' GB · ' + $_.BusType) }
try { Get-CimInstance -Namespace root\wmi -ClassName WmiMonitorID -ErrorAction Stop | ForEach-Object { $d = { param($a) -join ($a | Where-Object { $_ } | ForEach-Object { [char]$_ }) }
  A 'Monitor' (& $d $_.UserFriendlyName) (& $d $_.ManufacturerName) (& $d $_.SerialNumberID) ('fabricado em ' + $_.YearOfManufacture) } } catch {}
Get-CimInstance Win32_NetworkAdapter | Where-Object { $_.PhysicalAdapter -and $_.PNPDeviceID -like 'PCI*' } | ForEach-Object { A 'Rede' $_.Name $_.Manufacturer '' $_.MACAddress }
$cs = Get-CimInstance Win32_ComputerSystemProduct; A 'PC' $cs.Name $cs.Vendor $cs.IdentifyingNumber ''
ConvertTo-Json -InputObject @($r) -Compress", 90000, 3600);
            StringBuilder w = new StringBuilder("{");
            bool first = true;
            foreach (string k in Cfg23.Keys("war_")) { if (!first) w.Append(','); first = false; w.Append(Js.S(k.Substring(4))).Append(':').Append(Js.S(Cfg23.Get(k, ""))); }
            return "{\"ok\":true,\"items\":" + j + ",\"war\":" + w.Append('}') + "}";
        }
        // garantia de uma peça: data de compra|anos|loja
        public static string InvSet(string id, string buy, string years, string shop)
        {
            id = Clean(id, 120); if (id == "") return Ps23.Ok(false, "?");
            if (string.IsNullOrEmpty(buy)) Cfg23.Set("war_" + id, null);
            else Cfg23.Set("war_" + id, Clean(buy, 10) + "|" + Clean(years ?? "2", 3) + "|" + Clean(shop ?? "", 40));
            return InvJson(false);
        }

        // ============================================================ PERIFÉRICOS COM BATERIA (Bluetooth: rato, teclado, comando, auscultadores)
        public static string PeriphJson(bool fresh)
        {
            if (fresh) Ps23.Drop("perifericos");
            return Ps23.Run("perifericos", @"
$r = @()
try {
  $r = @(Get-PnpDevice -PresentOnly -ErrorAction Stop | Where-Object { $_.Class -in @('Bluetooth','HIDClass','AudioEndpoint','System','Keyboard','Mouse','XboxComposite') -or $_.InstanceId -like 'BTH*' } | ForEach-Object {
    $p = Get-PnpDeviceProperty -InstanceId $_.InstanceId -KeyName '{104EA319-6EE2-4701-BD47-8DDBF425BBE5} 2' -ErrorAction SilentlyContinue
    if ($p -and $p.Data -ne $null -and [string]$p.Data -ne '') { [pscustomobject]@{ n = [string]$_.FriendlyName; b = [int]$p.Data; c = [string]$_.Class } }
  } | Sort-Object n -Unique)
} catch {}
ConvertTo-Json -InputObject @($r) -Compress", 45000, 300);
        }
        public static string PeriphCached() { return Ps23.Cached("perifericos"); }
        static readonly Dictionary<string, DateTime> lowSent = new Dictionary<string, DateTime>();
        public static void PeriphCheck()
        {
            if (!Cfg23.On("al_periph", true)) return;
            string j = PeriphJson(true);
            foreach (Match m in Regex.Matches(j, "\"n\":\"((?:[^\"\\\\]|\\\\.)*)\",\"b\":(\\d+)"))
            {
                int b = int.Parse(m.Groups[2].Value); string n = m.Groups[1].Value;
                DateTime last;
                if (b > 0 && b <= 15 && (!lowSent.TryGetValue(n, out last) || (DateTime.Now - last).TotalHours > 6))
                {
                    lowSent[n] = DateTime.Now;
                    Vigias23.Alert(Lang.L("NEXUS · Bateria fraca"), n + ": " + b + " %. " + Lang.L("Põe a carregar quando puderes."));
                }
            }
        }

        // ============================================================ ESPAÇO ESCONDIDO (pontos de restauro, hibernação, ficheiro de paginação)
        public static string SpaceJson()
        {
            string sys = Path.GetPathRoot(Environment.SystemDirectory);
            Func<string, long> size = f => { try { FileInfo fi = new FileInfo(Path.Combine(sys, f)); return fi.Exists ? fi.Length : 0; } catch { return 0; } };
            long hib = size("hiberfil.sys"), page = size("pagefile.sys"), swap = size("swapfile.sys");
            string vss = Ps23.Cmd("vssadmin.exe", "list shadowstorage", 15000);
            // "Espaço utilizado de armazenamento de sombra: 3,05 GB (1%)" / "Used Shadow Copy Storage space: ..." / máximo
            List<string> vals = Regex.Matches(vss, @":\s*([\d.,]+\s*[KMGT]?B)\s*\((\d+)%\)").Cast<Match>().Select(m => m.Groups[1].Value + "|" + m.Groups[2].Value).ToList();
            bool hibOn = false; try { using (RegistryKey k = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\Power")) hibOn = Convert.ToInt32(k.GetValue("HibernateEnabled", 0)) == 1; } catch { }
            bool fast = false; try { using (RegistryKey k = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\Session Manager\Power")) fast = Convert.ToInt32(k.GetValue("HiberbootEnabled", 0)) == 1; } catch { }
            return "{\"ok\":true,\"drive\":" + Js.S(sys) + ",\"hiber\":" + hib + ",\"hibOn\":" + (hibOn ? "true" : "false") + ",\"fastboot\":" + (fast ? "true" : "false") + ",\"page\":" + page + ",\"swap\":" + swap +
                   ",\"vssUsed\":" + Js.S(vals.Count > 0 ? vals[0] : "") + ",\"vssAlloc\":" + Js.S(vals.Count > 1 ? vals[1] : "") + ",\"vssMax\":" + Js.S(vals.Count > 2 ? vals[2] : "") + "}";
        }
        public static string SpaceHiber(bool on) { Ps23.Cmd("powercfg.exe", on ? "/hibernate on" : "/hibernate off", 20000); return SpaceJson(); }
        public static string SpaceRestore(int pct)
        {
            pct = Math.Max(3, Math.Min(20, pct));
            string d = Path.GetPathRoot(Environment.SystemDirectory).TrimEnd('\\');
            Ps23.Cmd("vssadmin.exe", "resize shadowstorage /for=" + d + " /on=" + d + " /maxsize=" + pct + "%", 30000);
            return SpaceJson();
        }

        // ============================================================ PROGRAMAS ESQUECIDOS (instalados e sem uso há muito tempo - pela pasta Prefetch do Windows)
        public static string UnusedJson()
        {
            string pf = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "Prefetch");
            Dictionary<string, DateTime> last = new Dictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);
            bool havePf = false;
            try
            {
                foreach (string f in Directory.GetFiles(pf, "*.pf"))
                {
                    havePf = true;
                    string n = Path.GetFileName(f); int dash = n.LastIndexOf('-'); if (dash < 1) continue;
                    string exe = n.Substring(0, dash);
                    DateTime t = File.GetLastWriteTime(f);
                    DateTime o; if (!last.TryGetValue(exe, out o) || t > o) last[exe] = t;
                }
            }
            catch { }
            List<string> items = new List<string>();
            HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (RegistryKey hive in new[] { Registry.LocalMachine, Registry.CurrentUser })
                foreach (string root in new[] { @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall", @"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall" })
                    try
                    {
                        using (RegistryKey k = hive.OpenSubKey(root))
                            if (k != null)
                                foreach (string sub in k.GetSubKeyNames())
                                    using (RegistryKey a = k.OpenSubKey(sub))
                                    {
                                        if (a == null) continue;
                                        string name = Convert.ToString(a.GetValue("DisplayName")) ?? "";
                                        if (name == "" || Convert.ToInt32(a.GetValue("SystemComponent", 0)) == 1 || a.GetValue("ParentKeyName") != null || !seen.Add(name)) continue;
                                        string pub = Convert.ToString(a.GetValue("Publisher")) ?? "";
                                        if (Regex.IsMatch(name, @"(?i)^(windows driver package|pacote de controladores|paquete de controladores|package de pilotes|windows-treiberpaket)|^pawnio$|librehardwaremonitor|presentmon|anticheat|anti-cheat|easyanticheat|battleye|vanguard|redistributable|runtime|driver|update for|\.net|visual c\+\+|sdk|webview|directx|vulkan|physx|chipset|intel\(r\)|realtek|nvidia|amd software|microsoft edge")) continue;
                                        string loc = Convert.ToString(a.GetValue("InstallLocation")) ?? "";
                                        if (loc == "") { string ico = (Convert.ToString(a.GetValue("DisplayIcon")) ?? "").Split(',')[0].Trim('"'); if (ico.EndsWith(".exe", StringComparison.OrdinalIgnoreCase)) loc = Path.GetDirectoryName(ico) ?? ""; }
                                        if (loc == "" || !Directory.Exists(loc)) continue;
                                        DateTime best = DateTime.MinValue; int exes = 0;
                                        try
                                        {
                                            foreach (string e in Directory.EnumerateFiles(loc, "*.exe", SearchOption.AllDirectories).Take(200))
                                            {
                                                exes++;
                                                string en = Path.GetFileName(e).ToUpperInvariant();
                                                if (en.StartsWith("UNINS") || en.Contains("UPDATE") || en.Contains("CRASH") || en.Contains("HELPER")) continue;
                                                DateTime t; if (last.TryGetValue(en, out t) && t > best) best = t;
                                            }
                                        }
                                        catch { }
                                        if (exes == 0) continue;
                                        long sizeKb = 0; try { sizeKb = Convert.ToInt64(a.GetValue("EstimatedSize", 0)); } catch { }
                                        string inst = Convert.ToString(a.GetValue("InstallDate")) ?? "";
                                        int days = best == DateTime.MinValue ? -1 : (int)(DateTime.Now - best).TotalDays;
                                        if (days >= 0 && days < 60) continue;
                                        // o mesmo identificador do desinstalador do Deep Scan
                                        string uid = "r:" + (hive == Registry.LocalMachine ? "lm" : "cu") + (root.Contains("WOW6432Node") ? "32" : "64") + ":" + sub;
                                        items.Add("{\"name\":" + Js.S(name) + ",\"pub\":" + Js.S(pub) + ",\"days\":" + days + ",\"mb\":" + (sizeKb / 1024) + ",\"inst\":" + Js.S(inst) + ",\"loc\":" + Js.S(loc) + ",\"id\":" + Js.S(uid) + "}");
                                    }
                    }
                    catch { }
            return "{\"ok\":true,\"prefetch\":" + (havePf ? "true" : "false") + ",\"items\":[" + string.Join(",", items.ToArray()) + "]}";
        }

        // ============================================================ APPS PADRÃO (avisa quando algo muda o browser / PDF sem pedires)
        static readonly string[][] DEF = {
            new[] { "http", @"Software\Microsoft\Windows\Shell\Associations\UrlAssociations\http\UserChoice", "Browser (links)" },
            new[] { "https", @"Software\Microsoft\Windows\Shell\Associations\UrlAssociations\https\UserChoice", "Browser (links seguros)" },
            new[] { ".html", @"Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\.html\UserChoice", "Páginas .html" },
            new[] { ".pdf", @"Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\.pdf\UserChoice", "PDF" },
            new[] { "mailto", @"Software\Microsoft\Windows\Shell\Associations\UrlAssociations\mailto\UserChoice", "Email" },
            new[] { ".mp4", @"Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\.mp4\UserChoice", "Vídeos .mp4" },
            new[] { ".mp3", @"Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\.mp3\UserChoice", "Música .mp3" },
            new[] { ".jpg", @"Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\.jpg\UserChoice", "Imagens .jpg" },
        };
        static string ProgId(string key) { try { using (RegistryKey k = Registry.CurrentUser.OpenSubKey(key)) return k == null ? "" : Convert.ToString(k.GetValue("ProgId")) ?? ""; } catch { return ""; } }
        static string ProgName(string pid)
        {
            if (pid == "") return "";
            try
            {
                using (RegistryKey k = Registry.ClassesRoot.OpenSubKey(pid + @"\Application"))
                    if (k != null) { string n = Convert.ToString(k.GetValue("ApplicationName")) ?? ""; if (n != "" && !n.StartsWith("@")) return n; }
                using (RegistryKey k = Registry.ClassesRoot.OpenSubKey(pid)) if (k != null) { string n = Convert.ToString(k.GetValue("")) ?? ""; if (n != "" && !n.StartsWith("@")) return n; }
            }
            catch { }
            string[] known = { "MSEdge", "Microsoft Edge", "ChromeHTML", "Google Chrome", "FirefoxURL", "Firefox", "FirefoxHTML", "Firefox", "VivaldiHTM", "Vivaldi", "BraveHTML", "Brave", "OperaStable", "Opera", "AcroExch", "Adobe Acrobat", "AppX", "App da Microsoft Store" };
            for (int i = 0; i < known.Length; i += 2) if (pid.StartsWith(known[i], StringComparison.OrdinalIgnoreCase)) return known[i + 1];
            return pid;
        }
        public static string DefaultsJson()
        {
            StringBuilder sb = new StringBuilder("{\"ok\":true,\"alert\":" + (Cfg23.On("al_defaults", true) ? "true" : "false") + ",\"items\":[");
            bool first = true;
            foreach (string[] d in DEF)
            {
                string cur = ProgId(d[1]), want = Cfg23.Get("def_" + d[0], "");
                if (cur == "" && want == "") continue;
                if (!first) sb.Append(','); first = false;
                sb.Append("{\"k\":").Append(Js.S(d[0])).Append(",\"label\":").Append(Js.S(Lang.L(d[2]))).Append(",\"now\":").Append(Js.S(ProgName(cur))).Append(",\"want\":").Append(Js.S(ProgName(want)))
                  .Append(",\"changed\":").Append(want != "" && cur != want ? "true" : "false").Append('}');
            }
            return sb.Append("]}").ToString();
        }
        public static string DefaultsSnap() { foreach (string[] d in DEF) { string c = ProgId(d[1]); if (c != "") Cfg23.Set("def_" + d[0], c); } return DefaultsJson(); }
        static readonly HashSet<string> defWarned = new HashSet<string>();
        public static void DefaultsCheck()
        {
            if (Cfg23.Keys("def_").Length == 0) { DefaultsSnap(); return; }   // primeira vez: guarda o que tens agora
            if (!Cfg23.On("al_defaults", true)) return;
            List<string> ch = new List<string>();
            foreach (string[] d in DEF)
            {
                string cur = ProgId(d[1]), want = Cfg23.Get("def_" + d[0], "");
                if (want == "" || cur == "" || cur == want) { defWarned.Remove(d[0]); continue; }
                if (defWarned.Add(d[0])) ch.Add(Lang.L(d[2]) + ": " + ProgName(want) + " → " + ProgName(cur));
            }
            if (ch.Count > 0) Vigias23.Alert(Lang.L("NEXUS · Apps padrão mudadas"), string.Join("; ", ch.ToArray()) + ". " + Lang.L("Se não foste tu, vê no NEXUS em Saúde do PC → Apps padrão."));
        }

        // ============================================================ VERSÃO DO WINDOWS (e até quando tem atualizações)
        public static string WinverJson()
        {
            string disp = "", prod = "", ed = ""; int build = WinBuild(), ubr = 0;
            try
            {
                using (RegistryKey k = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion"))
                { disp = Convert.ToString(k.GetValue("DisplayVersion") ?? k.GetValue("ReleaseId")) ?? ""; prod = Convert.ToString(k.GetValue("ProductName")) ?? ""; ed = Convert.ToString(k.GetValue("EditionID")) ?? ""; ubr = Convert.ToInt32(k.GetValue("UBR", 0)); }
            }
            catch { }
            if (build >= 22000) prod = prod.Replace("Windows 10", "Windows 11");
            // fim do suporte (edições Home/Pro) - datas públicas da Microsoft
            string[][] eos = { new[] { "26100", "2026-10-13", "24H2" }, new[] { "26200", "2027-10-12", "25H2" }, new[] { "22631", "2025-11-11", "23H2" }, new[] { "22621", "2024-10-08", "22H2" }, new[] { "22000", "2023-10-10", "21H2" }, new[] { "19045", "2025-10-14", "22H2" } };
            string[] e = eos.FirstOrDefault(x => x[0] == build.ToString());
            string newest = build >= 22000 ? "25H2" : "Windows 11";
            return "{\"ok\":true,\"product\":" + Js.S(prod) + ",\"edition\":" + Js.S(ed) + ",\"version\":" + Js.S(disp) + ",\"build\":" + Js.S(build + "." + ubr) + ",\"eos\":" + Js.S(e != null ? e[1] : "") +
                   ",\"newest\":" + Js.S(newest) + ",\"w11\":" + (build >= 22000 ? "true" : "false") + "}";
        }

        // ============================================================ DRIVERS GRÁFICOS ANTIGOS (pastas que ficam no DriverStore depois de atualizar)
        public static string GpuDrvJson(bool fresh)
        {
            if (fresh) Ps23.Drop("drivers_gpu");
            return Ps23.Run("drivers_gpu", @"
$use = @(Get-CimInstance Win32_PnPSignedDriver -ErrorAction SilentlyContinue | Where-Object { $_.DeviceClass -eq 'DISPLAY' } | ForEach-Object { [string]$_.InfName })
$out = pnputil /enum-drivers
$r = New-Object System.Collections.ArrayList; $cur = @{}
foreach ($l in $out) {
  if ($l -match '^\s*$') { if ($cur.inf) { [void]$r.Add([pscustomobject]$cur) }; $cur = @{}; continue }
  if ($l -match ':\s*(oem\d+\.inf)\s*$') { $cur.inf = $matches[1]; continue }
  if ($l -match '^[^:]*(Original|original)[^:]*:\s*(.+)$') { $cur.orig = $matches[2].Trim(); continue }
  if ($l -match '^[^:]*(Fornecedor|Provider)[^:]*:\s*(.+)$') { $cur.prov = $matches[2].Trim(); continue }
  if ($l -match '^[^:]*(Classe|Class) *(Name|nome)?[^:]*:\s*(.+)$' -and -not $cur.cls) { $cur.cls = $matches[3].Trim(); continue }
  if ($l -match '^[^:]*(Vers|Version)[^:]*:\s*(.*\d+\.\d+\.\d+.*)$') { $cur.ver = $matches[2].Trim(); continue }
}
if ($cur.inf) { [void]$r.Add([pscustomobject]$cur) }
$fr = Join-Path $env:windir 'System32\DriverStore\FileRepository'
$g = @($r | Where-Object { $_.cls -match 'Display|Ecr|Vídeo|Video|Adaptador' -or $_.orig -match '^nv_disp|^nvlddmkm|^u\d+\.inf|^amdkmdag|^iigd' } | ForEach-Object {
  $o = $_.orig; $mb = 0
  if ($o) { Get-ChildItem $fr -Directory -Filter ($o + '_*') -ErrorAction SilentlyContinue | ForEach-Object { $mb += [math]::Round(((Get-ChildItem $_.FullName -Recurse -File -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum)/1MB) } }
  [pscustomobject]@{ inf = $_.inf; orig = $o; prov = $_.prov; ver = $_.ver; mb = $mb; used = ($use -contains $_.inf) }
})
ConvertTo-Json -InputObject @($g) -Compress", 120000, 300);
        }
        public static string GpuDrvDelete(string inf)
        {
            if (!Regex.IsMatch(inf ?? "", @"^oem\d+\.inf$", RegexOptions.IgnoreCase)) return Ps23.Ok(false, "?");
            // sem /force: se estiver a ser usado, o Windows recusa
            string o = Ps23.Cmd("pnputil.exe", "/delete-driver " + inf, 60000);
            Ps23.Drop("drivers_gpu");
            return "{\"ok\":true,\"out\":" + Js.S(o) + ",\"list\":" + GpuDrvJson(true) + "}";
        }

        // ============================================================ OVERLAYS (programas que desenham por cima dos jogos) - vê os processos, não mexe no jogo (seguro com anti-cheat)
        static readonly string[][] OVL = {
            new[] { "Discord", "Discord", "Overlay do Discord (Definições → Overlay do jogo)." },
            new[] { "steamwebhelper", "Steam", "Overlay da Steam (Shift+Tab). Desliga em Steam → Definições → Em jogo." },
            new[] { "NVIDIA Overlay", "NVIDIA App / GeForce", "Overlay da NVIDIA (Alt+Z): gravação, filtros, estatísticas." },
            new[] { "NVIDIA Share", "GeForce Experience", "Overlay do GeForce Experience (Alt+Z)." },
            new[] { "RTSS", "RivaTuner (MSI Afterburner)", "Mostra FPS e limita FPS. O NEXUS também o usa para o limite de FPS." },
            new[] { "MSIAfterburner", "MSI Afterburner", "Overclock e estatísticas no ecrã (através do RivaTuner)." },
            new[] { "obs64", "OBS Studio", "A captura de jogo injeta-se no jogo para gravar." },
            new[] { "Overwolf", "Overwolf", "Apps por cima dos jogos (estatísticas, gravações)." },
            new[] { "MedalEncoder", "Medal", "Gravação de clipes." },
            new[] { "Medal", "Medal", "Gravação de clipes." },
            new[] { "EpicGamesLauncher", "Epic Games", "Overlay da Epic nos jogos da Epic." },
            new[] { "upc", "Ubisoft Connect", "Overlay da Ubisoft (Shift+F2)." },
            new[] { "EADesktop", "EA app", "Overlay da EA (Shift+F1)." },
            new[] { "GameBar", "Barra de Jogo Xbox", "Win+G. Também grava em segundo plano se a captura estiver ligada." },
            new[] { "XboxGameBarWidgets", "Barra de Jogo Xbox", "Widgets da Barra de Jogo." },
            new[] { "Playnite.FullscreenApp", "Playnite", "Launcher." },
            new[] { "ReShade", "ReShade", "Filtros gráficos." },
        };
        public static string OverlaysJson()
        {
            HashSet<string> running = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            try { foreach (Process p in Process.GetProcesses()) running.Add(p.ProcessName); } catch { }
            List<string> items = new List<string>(); HashSet<string> seen = new HashSet<string>();
            foreach (string[] o in OVL) if (running.Contains(o[0]) && seen.Add(o[1])) items.Add("{\"name\":" + Js.S(o[1]) + ",\"desc\":" + Js.S(Lang.L(o[2])) + ",\"proc\":" + Js.S(o[0]) + "}");
            return "{\"ok\":true,\"game\":" + Js.S(Optimizer.GameName) + ",\"items\":[" + string.Join(",", items.ToArray()) + "]}";
        }

        // ============================================================ ATUALIZAÇÕES DO WINDOWS (últimas instaladas; desinstalar uma que estragou algo)
        public static string UpdatesJson(bool fresh)
        {
            if (fresh) Ps23.Drop("atualizacoes");
            return Ps23.Run("atualizacoes", @"
$r = @()
try {
  $s = New-Object -ComObject Microsoft.Update.Session; $q = $s.CreateUpdateSearcher(); $n = $q.GetTotalHistoryCount()
  $r = @($q.QueryHistory(0, [Math]::Min($n, 40)) | Where-Object { $_.Title -and $_.Operation -eq 1 } | ForEach-Object {
    $kb = if ($_.Title -match '(KB\d{6,8})') { $matches[1] } else { '' }
    [pscustomobject]@{ t = [string]$_.Title; d = $_.Date.ToLocalTime().ToString('yyyy-MM-dd'); kb = $kb; ok = ($_.ResultCode -eq 2) } })
} catch {}
if ($r.Count -eq 0) { $r = @(Get-HotFix -ErrorAction SilentlyContinue | Sort-Object InstalledOn -Descending | Select-Object -First 20 | ForEach-Object { [pscustomobject]@{ t = [string]$_.Description + ' ' + $_.HotFixID; d = if ($_.InstalledOn) { $_.InstalledOn.ToString('yyyy-MM-dd') } else { '' }; kb = [string]$_.HotFixID; ok = $true } }) }
ConvertTo-Json -InputObject @($r) -Compress", 90000, 600);
        }
        public static string UpdateUninstall(string kb)
        {
            Match m = Regex.Match(kb ?? "", @"^KB(\d{6,8})$", RegexOptions.IgnoreCase);
            if (!m.Success) return Ps23.Ok(false, "?");
            // o wusa mostra a própria janela a pedir confirmação e diz se precisa de reiniciar
            try { Process.Start(new ProcessStartInfo("wusa.exe", "/uninstall /kb:" + m.Groups[1].Value) { UseShellExecute = true }); } catch (Exception ex) { return Ps23.Ok(false, ex.Message); }
            Ps23.Drop("atualizacoes");
            return Ps23.Ok(true, Lang.L("Abriu a janela do Windows para desinstalar. Segue o que ela disser."));
        }

        // ============================================================ ANTES / DEPOIS DE MUDAR UMA PEÇA
        static string ChgFile { get { return Path.Combine(AppSettings.Dir, "mudancas.txt"); } }
        public static string ChangesJson()
        {
            StringBuilder sb = new StringBuilder("{\"ok\":true,\"items\":[");
            try
            {
                if (File.Exists(ChgFile))
                {
                    bool first = true;
                    foreach (string l in File.ReadAllLines(ChgFile, Encoding.UTF8))
                    {
                        string[] c = l.Split('|'); if (c.Length < 4) continue;
                        if (!first) sb.Append(','); first = false;
                        sb.Append("{\"id\":").Append(Js.S(c[0])).Append(",\"when\":").Append(Js.S(c[1])).Append(",\"label\":").Append(Js.S(c[2])).Append(",\"hw\":").Append(Js.S(c[3])).Append('}');
                    }
                }
            }
            catch { }
            return sb.Append("]}").ToString();
        }
        public static string ChangeMark(string label)
        {
            label = (label ?? "").Replace("|", "/").Replace("\r", " ").Replace("\n", " ").Trim();
            if (label.Length > 80) label = label.Substring(0, 80);
            if (label == "") label = Lang.L("Mudança");
            string hw = MyPcLine();
            try { File.AppendAllText(ChgFile, DateTime.Now.Ticks.ToString("x") + "|" + DateTime.Now.ToString("yyyy-MM-dd HH:mm") + "|" + label + "|" + hw + "\r\n", new UTF8Encoding(false)); } catch { }
            return ChangesJson();
        }
        public static string ChangeDelete(string id)
        {
            try { if (File.Exists(ChgFile)) File.WriteAllLines(ChgFile, File.ReadAllLines(ChgFile, Encoding.UTF8).Where(l => !l.StartsWith((id ?? "?") + "|")).ToArray(), new UTF8Encoding(false)); } catch { }
            return ChangesJson();
        }

        // ============================================================ O MEU PC (resumo das peças)
        public static string MyPcJson()
        {
            return Ps23.Run("meupc", @"
$o = [ordered]@{}
$o.cpu = ((Get-CimInstance Win32_Processor | Select-Object -First 1).Name -replace '\s+', ' ').Trim()
$o.gpu = @(Get-CimInstance Win32_VideoController | Where-Object { $_.PNPDeviceID -like 'PCI*' } | ForEach-Object { [string]$_.Name })
$o.gpudrv = [string](Get-CimInstance Win32_VideoController | Where-Object { $_.PNPDeviceID -like 'PCI*' } | Select-Object -First 1).DriverVersion
$m = @(Get-CimInstance Win32_PhysicalMemory); $o.ram = [math]::Round(($m | Measure-Object Capacity -Sum).Sum / 1GB); $o.ramN = $m.Count; $o.ramMhz = ($m | Select-Object -First 1).ConfiguredClockSpeed
$o.board = ((Get-CimInstance Win32_BaseBoard).Manufacturer + ' ' + (Get-CimInstance Win32_BaseBoard).Product).Trim()
$o.disks = @(Get-PhysicalDisk | ForEach-Object { [string]$_.FriendlyName + ' (' + [math]::Round($_.Size/1GB) + ' GB)' })
$v = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion'; $o.os = ([string]$v.ProductName + ' ' + $v.DisplayVersion)
if ([int]$v.CurrentBuildNumber -ge 22000) { $o.os = $o.os -replace 'Windows 10', 'Windows 11' }
ConvertTo-Json -InputObject $o -Compress", 60000, 600);
        }
        static string MyPcLine()
        {
            string j = MyPcJson();
            Func<string, string> g = k => { Match m = Regex.Match(j, "\"" + k + "\":(\"(?:[^\"\\\\]|\\\\.)*\"|\\[[^\\]]*\\]|[0-9.]+)"); return m.Success ? m.Groups[1].Value.Trim('"', '[', ']').Replace("\",\"", ", ").Replace("\"", "") : ""; };
            return (g("cpu") + " · " + g("gpu") + " (" + g("gpudrv") + ") · " + g("ram") + " GB " + g("ramMhz") + " MT/s").Replace("|", "/");
        }
    }
}
