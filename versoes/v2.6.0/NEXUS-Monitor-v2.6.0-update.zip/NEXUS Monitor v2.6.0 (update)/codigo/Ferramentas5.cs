﻿// NEXUS // MONITOR 2.3 - pedidos /api/x/<ferramenta>[/<ação>]
// Ver (GET) pode ser do telemóvel; mudar (POST) só no próprio PC. Exceções: abrir jogos e música, do telemóvel já aceite no controlo remoto.
using System;
using System.Globalization;
using System.Linq;
using System.Text;

namespace Nexus
{
    static class Api23
    {
        public static void Start()
        {
            NvApp.OnStart();
            Rota.OnStart();
            Macros.OnStart();
            Vigias3.Start();
            Vigias5.Start();
            if (Aparelhos.Enabled) System.Threading.ThreadPool.QueueUserWorkItem(delegate { try { System.Threading.Thread.Sleep(1500); Aparelhos.Scan(); } catch { } });
        }

        static string Q(string path, string k) { return Program.QueryValue(path, k); }

        public static byte[] Handle(string method, string path, string body, bool remote, string ip, out int status, out string ctype)
        {
            status = 200; ctype = "application/json";
            string p = path.Split('?')[0].Substring("/api/x/".Length).TrimEnd('/');
            string[] seg = p.Split('/');
            string tool = seg[0], act = seg.Length > 1 ? seg[1] : "";
            bool write = act != "" && act != "refresh" && !(tool == "media" && act == "cover") && !(tool == "gal" && (act == "thumb" || act == "img"))
                && !(tool == "dev" && (act == "sound" || act == "profile" || act == "disclist"));   // só leem: também no telemóvel
            bool phoneOk = (tool == "rc" && act == "do") || (tool == "mic" && act == "toggle") || (tool == "media" && act == "do") || (tool == "games" && act == "launch") || (tool == "mon" && (act == "test" || act == "step"));
            if (write && method != "POST") { status = 405; return Bytes(Ps23.Ok(false, "POST")); }
            if (write && remote && !phoneOk) { status = 403; return Bytes("{\"ok\":false,\"error\":\"pc_only\"}"); }
            if (remote && phoneOk && !(AppSettings.RemoteCtl && ("," + AppSettings.RemoteCtlIps + ",").Contains("," + ip + ",")))
            {
                // o telemóvel ainda não foi aceite: o controlo remoto trata de pedir autorização no PC
                return Bytes(Controlo.Do("ping", true, ip));
            }
            if ((tool == "view" || tool == "sync") && remote) { status = 403; return Bytes("{\"ok\":false,\"error\":\"pc_only\"}"); }
            // privacidade: a rede de casa e a galeria só aparecem no telemóvel se escolheres isso no PC
            if (remote && (((tool == "lan" || tool == "upnp") && !RedeCasa.Phone) || (tool == "gal" && !Galeria.Phone))) { status = 403; return Bytes("{\"ok\":false,\"error\":\"pc_only\"}"); }
            if (tool == "gal" && (act == "thumb" || act == "img"))
            {
                string gct = "image/jpeg";
                byte[] gb = act == "thumb" ? Galeria.Thumb(Q(path, "i"), Q(path, "k")) : Galeria.Full(Q(path, "i"), Q(path, "k"), out gct);
                if (gb == null) { status = 404; return new byte[0]; }
                ctype = gct; return gb;
            }
            bool fresh = act == "refresh";
            string r;
            switch (tool + "/" + (fresh ? "" : act))
            {
                case "route/": r = Rota.Json(); break;
                case "route/consent": r = Rota.SetConsent(Q(path, "yes") == "1"); break;
                case "route/on": r = Rota.SetOn(Q(path, "on") == "1"); break;
                case "route/game": r = Rota.SetGame(Q(path, "g"), Q(path, "mode")); break;
                case "route/forget": r = Rota.Forget(Q(path, "g")); break;
                case "route/test": r = Rota.TestNow(Q(path, "host")); break;
                case "route/trace": r = Rota.TraceStart(Q(path, "host")); break;
                case "route/traceget": r = Rota.TraceJson(); break;
                case "route/uninstall": r = Rota.UninstallWarp(); break;
                case "mon/": r = Painel.MonJson(); break;
                case "vigia/": r = Vigias3.Json(); break;
                case "ach/": r = Conquistas.Json(); break;
                case "mic/": r = MicPlus.Json(); break;
                case "mic/toggle": MicPlus.Toggle(); r = MicPlus.Json(); break;
                case "mic/opts": r = MicPlus.Opts(Q(path, "all"), Q(path, "badge"), Q(path, "sound"), Q(path, "key"), Q(path, "ptt")); break;
                case "lan/": r = RedeCasa.Json(true); break;
                case "lan/scan": r = RedeCasa.Scan(true); break;
                case "lan/label": r = RedeCasa.SetLabel(Q(path, "mac"), Q(path, "label")); break;
                case "lan/forget": r = RedeCasa.Forget(Q(path, "mac")); break;
                case "lan/router": r = RedeCasa.AcceptRouter(); break;
                case "lan/opts": r = RedeCasa.Opts(Q(path, "alert"), Q(path, "auto"), Q(path, "dns"), Q(path, "nb"), Q(path, "phone")); break;
                case "upnp/": r = Upnp.Json(); break;
                case "upnp/scan": r = Upnp.Scan(); break;
                case "upnp/del": r = Upnp.Delete(Q(path, "ext"), Q(path, "proto")); break;
                case "rc/do": r = RatoRemoto.Do(Q(path, "a"), body); break;
                case "gal/": { int gp; int.TryParse(Q(path, "p") ?? "0", out gp); r = Galeria.Json(Q(path, "g"), gp); break; }
                case "gal/open": r = Galeria.Open(Q(path, "i"), Q(path, "k"), Q(path, "folder") == "1"); break;
                case "gal/opts": r = Galeria.Opts(Q(path, "phone"), body != null && body.Length > 0 && Q(path, "dirs") == "1" ? body : null); break;
                case "gal/refresh": r = Galeria.Refresh(); break;
                case "cam/": r = CamMic.Json(); break;
                case "cam/alert": r = CamMic.SetAlert(Q(path, "on") == "1"); break;
                case "netprog/": r = RedeProg.Json(Q(path, "m")); break;
                case "netprog/on": r = RedeProg.SetOn(Q(path, "on") == "1"); break;
                case "hosts/": Hosts.Check(); r = Hosts.Json(); break;
                case "hosts/accept": r = Hosts.Accept(); break;
                case "hosts/undo": r = Hosts.Undo(); break;
                case "hosts/open": r = Hosts.Open(); break;
                case "vpn/": VpnProxy.Check(null); r = VpnProxy.Json(); break;
                case "vpn/proxyoff": r = VpnProxy.ProxyOff(); break;
                case "ports/": r = Portas.Json(fresh); break;
                case "bat/": r = BateriaEta.Json(); break;
                case "ach/code": r = Conquistas.TryCode(Q(path, "c")); break;
                case "instat/": r = Entrada.Json(); break;
                case "instat/on": r = Entrada.SetOn(Q(path, "on") == "1"); break;
                case "instat/dpi": r = Entrada.SetDpi(Q(path, "v")); break;
                case "instat/reset": r = Entrada.Reset(); break;
                case "po/": r = Po.Json(); break;
                case "po/reset": r = Po.Reset(); break;
                case "leak/": r = Fugas.Json(); break;
                case "leak/kill": r = Fugas.Kill(Q(path, "pid")); break;
                case "stag/": r = Escalonado.Json(); break;
                case "stag/add": r = Escalonado.Add(Q(path, "id")); break;
                case "stag/remove": r = Escalonado.Remove(Q(path, "id")); break;
                case "stag/move": r = Escalonado.Move(Q(path, "id"), Q(path, "d") == "-1" ? -1 : 1); break;
                case "stag/gap": r = Escalonado.SetGap(Q(path, "gap"), Q(path, "wait")); break;
                case "stag/test": r = Escalonado.TestNow(); break;
                case "jupd/": r = JogosAtualizados.Json(); break;
                case "jupd/on": r = JogosAtualizados.SetOn(Q(path, "on") == "1"); break;
                case "jupd/check": JogosAtualizados.Check(); r = JogosAtualizados.Json(); break;
                case "usb/": r = UsbLento.Json(fresh); break;
                case "miner/": r = Mineradores.Json(); break;
                case "miner/ignore": r = Mineradores.Ignore(Q(path, "path")); break;
                case "miner/open": r = Mineradores.Open(Q(path, "path")); break;
                case "mon/test": r = Painel.MonTest(); break;
                case "mon/step": r = Painel.MonStep(Q(path, "a")); break;
                case "dev/": r = Aparelhos.Json(); break;
                case "dev/on": r = Aparelhos.SetOn(Q(path, "on") == "1"); break;
                case "dev/scan": r = Aparelhos.Refresh(); break;
                case "dev/forget": r = Aparelhos.Forget(Q(path, "id")); break;
                case "dev/keep": r = Aparelhos.SetKeep(Q(path, "d")); break;
                case "dev/disclist": r = Descobrir.List(); break;
                case "dev/discsnap": r = Descobrir.Snap(Q(path, "id"), Q(path, "tag")); break;
                case "dev/discdiff": r = Descobrir.Diff(Q(path, "id")); break;
                case "dev/discguess": r = Descobrir.Analyze(Q(path, "id"), Q(path, "goal"), Q(path, "hint")); break;
                case "dev/discsave": r = Descobrir.Save(Q(path, "id"), Q(path, "k"), Q(path, "o"), Q(path, "what"), Q(path, "fmt"), Q(path, "cv"), Q(path, "name"), Q(path, "kind")); break;
                case "dev/discdel": r = Descobrir.Del(Q(path, "vp")); break;
                case "dev/set": r = Aparelhos.Set(Q(path, "id"), Q(path, "k"), Q(path, "v")); break;
                case "dev/prec": Cfg23.Set("dev_prec", Q(path, "v")); r = Ps23.Ok(true, null); break;
                case "dev/profile": r = Aparelhos.ProfileJson(Q(path, "g")); break;
                case "dev/sound": r = Som.Json(); break;
                case "eq/": r = Equalizador.Json(); break;
                case "eq/set": r = Equalizador.Set(Q(path, "dev"), Q(path, "cfg")); break;
                case "eq/install": r = EqMotor.Start(false); break;
                case "eq/remove": r = EqMotor.Start(true); break;
                case "dev/cycle": { string c = Aparelhos.CycleDpi(Q(path, "dir") == "-1" ? -1 : 1); r = Ps23.Ok(c != null, c); break; }
                case "dev/soundset": { int fl; int.TryParse(Q(path, "flow"), out fl); r = Som.Set(fl, Q(path, "w"), Q(path, "v")); break; }
                case "ctl/": r = Macros.Json(); break;
                case "ctl/on": r = Macros.SetOn(Q(path, "on") == "1"); break;
                case "ctl/rec": r = Macros.RecStart(Q(path, "mouse") == "1", Q(path, "name")); break;
                case "ctl/recstop": r = Macros.RecStop(Q(path, "name"), Q(path, "ui") == "1"); break;
                case "ctl/msave": r = Macros.SaveMacro(Q(path, "id"), Q(path, "name"), Q(path, "mode"), Q(path, "times"), Q(path, "acok"), Q(path, "steps")); break;
                case "ctl/mdel": r = Macros.DelMacro(Q(path, "id")); break;
                case "ctl/play": r = Macros.PlayNow(Q(path, "id"), Q(path, "now") == "1"); break;
                case "ctl/ksave": r = Macros.SaveKey(Q(path, "id"), Q(path, "mods"), Q(path, "vk"), Q(path, "action"), Q(path, "arg"), Q(path, "g"), Q(path, "dev"), Q(path, "block")); break;
                case "ctl/kdel": r = Macros.DelKey(Q(path, "id")); break;
                case "ctl/snap": r = Macros.SetSnap(Q(path, "on"), Q(path, "pairs")); break;
                case "ctl/gm": r = Macros.SetGm(Q(path, "mode"), Q(path, "win"), Q(path, "tab"), Q(path, "f4")); break;
                case "dev/profileset": r = Aparelhos.SetProfile(Q(path, "g"), Q(path, "id"), Q(path, "dpi"), Q(path, "hz")); break;
                case "ctx/": r = Ferr.CtxJson(); break;
                case "ctx/set": r = Ferr.CtxSet(Q(path, "id"), Q(path, "off") == "1"); break;
                case "ctx/classic": r = Ferr.CtxClassic(Q(path, "on") == "1"); break;
                case "ctx/explorer": r = Ferr.RestartExplorer(); break;
                case "tasks/": r = Ferr.TasksJson(fresh); break;
                case "tasks/set": r = Ferr.TaskSet(Q(path, "path"), Q(path, "on") == "1"); break;
                case "security/": r = Ferr.SecurityJson(fresh); break;
                case "drives/": r = Ferr.DrivesJson(); break;
                case "drives/optimize": r = Ferr.DriveOptimize(Q(path, "d")); break;
                case "ssd/": r = Ferr.SsdJson(); break;
                case "psu/": r = Ferr.PsuJson(); break;
                case "psu/set":
                    { int w; int.TryParse(Q(path, "w") ?? "", out w); Cfg23.Set("psu_w", Math.Max(0, Math.Min(3000, w)).ToString(CultureInfo.InvariantCulture)); if (Q(path, "alert") != null) Cfg23.Set("al_power", Q(path, "alert") == "1" ? "1" : "0"); r = Ferr.PsuJson(); break; }
                case "boost/": r = Ferr.BoostJson(); break;
                case "boost/fix": r = Ferr.BoostFix(); break;
                case "qos/": r = Ferr.QosJson(); break;
                case "qos/set": r = Ferr.QosSet(Q(path, "on") == "1"); break;
                case "qos/remove": r = Ferr.QosRemove(Q(path, "name")); break;
                case "close/": r = Ferr.CloseJson(); break;
                case "close/set": r = Ferr.CloseSet(Q(path, "list"), Q(path, "on")); break;
                case "sess/": r = Vigias23.SessJson(); break;
                case "conns/": r = Ferr.ConnsJson(); break;
                case "wifi/": r = Ferr.WifiJson(); break;
                case "inv/": r = Ferr.InvJson(fresh); break;
                case "inv/set": r = Ferr.InvSet(Q(path, "id"), Q(path, "buy"), Q(path, "years"), Q(path, "shop")); break;
                case "periph/": r = Ferr.PeriphJson(fresh); break;
                case "space/": r = Ferr.SpaceJson(); break;
                case "space/hiber": r = Ferr.SpaceHiber(Q(path, "on") == "1"); break;
                case "space/restore": { int pc; int.TryParse(Q(path, "pct") ?? "", out pc); r = Ferr.SpaceRestore(pc); break; }
                case "unused/": r = Ferr.UnusedJson(); break;
                case "defaults/": r = Ferr.DefaultsJson(); break;
                case "defaults/snap": r = Ferr.DefaultsSnap(); break;
                case "winver/": r = Ferr.WinverJson(); break;
                case "gpudrv/": r = Ferr.GpuDrvJson(fresh); break;
                case "gpudrv/delete": r = Ferr.GpuDrvDelete(Q(path, "inf")); break;
                case "overlays/": r = Ferr.OverlaysJson(); break;
                case "updates/": r = Ferr.UpdatesJson(fresh); break;
                case "upd/auto": Cfg23.Set("up_auto", Q(path, "on") == "1" ? "1" : "0"); r = Atualizar.Json(); break;
                case "updates/uninstall": r = Ferr.UpdateUninstall(Q(path, "kb")); break;
                case "changes/": r = Ferr.ChangesJson(); break;
                case "changes/mark": r = Ferr.ChangeMark(Q(path, "label")); break;
                case "changes/delete": r = Ferr.ChangeDelete(Q(path, "id")); break;
                case "mypc/": r = "{\"ok\":true,\"pc\":" + Ferr.MyPcJson() + ",\"name\":" + Js.S(Environment.MachineName) + "}"; break;
                case "nvapp/": r = NvApp.Json(); break;
                case "nvapp/off": r = NvApp.Off(false); break;
                case "nvapp/on": r = NvApp.On(); break;
                case "nvapp/keep": r = NvApp.Keep(Q(path, "on") == "1"); break;
                case "games/": r = Ferr.GamesJson(); break;
                case "games/launch": r = Ferr.GameLaunch(Q(path, "id")); break;
                case "media/": r = Ferr.MediaJson(); break;
                case "media/do": r = Ferr.MediaDo(Q(path, "a")); break;
                case "media/cover":
                    {
                        byte[] img = Ferr.MediaCover();
                        if (img == null) { status = 404; return new byte[0]; }
                        ctype = img.Length > 3 && img[0] == 0x89 ? "image/png" : "image/jpeg";
                        return img;
                    }
                case "wall/apply": r = Ferr.WallTheme(); break;
                case "panel/": r = Painel.Json(); break;
                case "panel/start": r = Painel.Start(Q(path, "kind") == "mini" ? "mini" : "apresentacao"); break;
                case "panel/stop": r = Painel.Stop(Q(path, "kind") == "mini" ? "mini" : "apresentacao"); break;
                case "sync/code": r = Ferr.SyncCode(); break;
                case "sync/pull": r = Ferr.SyncPull(Q(path, "ip"), Q(path, "code")); break;
                case "view/": r = Ferr.ViewJson(); break;
                case "view/set": r = Ferr.ViewSet(Q(path, "on") == "1"); break;
                case "hist/": { long a0, b0; long.TryParse(Q(path, "from") ?? "", out a0); long.TryParse(Q(path, "to") ?? "", out b0); r = Historico.WindowJson(a0, b0); break; }
                case "clicks/": r = Vigias23.ClickJson(); break;
                case "clicks/reset": Vigias23.ClickReset(); r = Vigias23.ClickJson(); break;
                case "screen/": r = Vigias23.ScreenJson(); break;
                case "screen/set": Cfg23.Set("screentime", Q(path, "on") == "1" ? "1" : "0"); r = Vigias23.ScreenJson(); break;
                case "hotspot/": r = Vigias23.HotspotJson(); break;
                case "sleep/": r = Ferr.SleepJson(); break;
                case "sleep/wake": r = Ferr.WakeSet(Q(path, "dev"), Q(path, "on") == "1"); break;
                case "ramtest/": r = Ferr.RamTestJson(); break;
                case "ramtest/start": r = Ferr.RamTestStart(); break;
                case "steam/": r = Ferr.SteamJson(); break;
                case "steam/clean": r = Ferr.SteamClean(Q(path, "kind"), Q(path, "lib"), Q(path, "id")); break;
                case "proc/": r = Ferr.ProcJson(Q(path, "name")); break;
                case "support/zip": r = Ferr.SupportZip(); break;
                case "drv/remove": r = Ferr.DriverRemove(Q(path, "dev"), Q(path, "inf")); break;
                case "driver/":
                    { int dd; string vd; string v = Ferr.DriverInfo(out dd, out vd); r = "{\"ok\":true,\"ver\":" + Js.S(v) + ",\"days\":" + dd + ",\"vendor\":" + Js.S(vd) + ",\"limit\":" + Cfg23.Int("driver_days", 60) + "}"; break; }
                case "alerts/": r = AlertsJson(); break;
                case "alerts/set":
                    {
                        foreach (string k in new[] { "al_fan", "al_hotidle", "al_power", "al_periph", "al_defaults", "al_driver" }) if (Q(path, k) != null) Cfg23.Set(k, Q(path, k) == "1" ? "1" : "0");
                        r = AlertsJson(); break;
                    }
                default: status = 404; r = Ps23.Ok(false, "?"); break;
            }
            return Bytes(r);
        }
        static string AlertsJson()
        {
            return "{\"ok\":true" + string.Concat(new[] { "al_fan", "al_hotidle", "al_power", "al_periph", "al_defaults", "al_driver" }.Select(k => ",\"" + k + "\":" + (Cfg23.On(k, true) ? "true" : "false")).ToArray()) + "}";
        }
        static byte[] Bytes(string s) { return Encoding.UTF8.GetBytes(s ?? "null"); }
    }
}
