// NEXUS // MONITOR 2.6 - privacidade e rede (tudo local): câmara/microfone, internet por programa, ficheiro hosts,
// VPN/proxy esquecidos, portas abertas, tempo de bateria dos periféricos e comandos Xbox/PlayStation.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using Microsoft.Win32;
using Microsoft.Win32.SafeHandles;

namespace Nexus
{
    static class Vigias4
    {
        static int tick;
        // chamado pelo Vigias3 a cada 2 s
        public static void Tick(string game)
        {
            tick++;
            if (tick % 15 == 3) Run(() => CamMic.Check());                 // 30 s
            if (tick % 30 == 5) Run(() => RedeProg.Flush());               // 1 min
            if (tick % 30 == 9) Run(() => BateriaEta.Sample());               // 1 min
            if (tick % 30 == 15) Run(() => Comandos.Poll());               // 1 min (também em jogo: só lê)
            if (tick % 60 == 25) Run(() => VpnProxy.Check(game));          // 2 min
            if (tick % 60 == 40) Run(() => Portas.Check(true));            // 2 min
            if (tick % 150 == 50) Run(() => Hosts.Check());                // 5 min
            if (tick == 4) Run(() => RedeProg.Start());
        }
        static void Run(Action a) { ThreadPool.QueueUserWorkItem(delegate { try { a(); } catch { } }); }
        public static string Ago(DateTime t)
        {
            TimeSpan s = DateTime.Now - t;
            return s.TotalMinutes < 1 ? Lang.L("agora mesmo") : s.TotalHours < 1 ? (int)s.TotalMinutes + " min" : s.TotalDays < 1 ? (int)s.TotalHours + " h" : (int)s.TotalDays + " " + Lang.L("dias");
        }
    }

    // ============================================================ 37. quem usou a câmara e o microfone
    // O Windows guarda quando cada programa começou e acabou de usar a câmara/microfone (é o que aparece em Definições → Privacidade).
    static class CamMic
    {
        class U { public string Dev, App, Name; public DateTime Start, Stop; public bool Now; }
        static List<U> last = new List<U>();
        static HashSet<string> known; static readonly object lk = new object();
        const string KNOWN = "cam_mic_conhecidos.txt";
        public static bool Alert { get { return Cfg23.On("cam_alert", true); } }
        public static string SetAlert(bool on) { Cfg23.Set("cam_alert", on ? "1" : "0"); return Json(); }

        static string Nice(string app)
        {
            if (app.Contains("#")) { string p = app.Replace('#', '\\'); return Path.GetFileNameWithoutExtension(p); }
            string n = app; int i = n.IndexOf('_'); if (i > 0) n = n.Substring(0, i);   // Microsoft.WindowsCamera_8wekyb3d8bbwe
            i = n.LastIndexOf('.'); if (i > 0 && i < n.Length - 1) n = n.Substring(i + 1);
            return n;
        }
        static DateTime Ft(object o) { try { long v = Convert.ToInt64(o); return v > 0 ? DateTime.FromFileTime(v) : DateTime.MinValue; } catch { return DateTime.MinValue; } }
        static void Read(RegistryKey root, string dev, List<U> r)
        {
            string bp = @"Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\" + dev;
            Action<RegistryKey, string> one = (k, app) =>
            {
                DateTime s = Ft(k.GetValue("LastUsedTimeStart", 0L)), e = Ft(k.GetValue("LastUsedTimeStop", 0L));
                if (s == DateTime.MinValue) return;
                r.Add(new U { Dev = dev == "webcam" ? "cam" : "mic", App = app, Name = Nice(app), Start = s, Stop = e, Now = e < s });
            };
            try
            {
                using (RegistryKey b = root.OpenSubKey(bp))
                {
                    if (b == null) return;
                    foreach (string n in b.GetSubKeyNames())
                    {
                        if (n == "NonPackaged")
                        {
                            using (RegistryKey np = b.OpenSubKey(n))
                                if (np != null) foreach (string m in np.GetSubKeyNames()) using (RegistryKey k = np.OpenSubKey(m)) if (k != null) one(k, m);
                        }
                        else using (RegistryKey k = b.OpenSubKey(n)) if (k != null) one(k, n);
                    }
                }
            }
            catch { }
        }
        public static void Check()
        {
            List<U> r = new List<U>();
            foreach (string d in new[] { "webcam", "microphone" }) { Read(Registry.CurrentUser, d, r); Read(Registry.LocalMachine, d, r); }
            r = r.GroupBy(x => x.Dev + "|" + x.App.ToLowerInvariant()).Select(g => g.OrderByDescending(x => x.Start).First()).OrderByDescending(x => x.Now).ThenByDescending(x => x.Start).ToList();
            List<U> fresh = new List<U>();
            lock (lk)
            {
                bool first = known == null;
                if (first) known = new HashSet<string>(Vigias3.Read(KNOWN), StringComparer.OrdinalIgnoreCase);
                first = first && known.Count == 0;
                bool ch = false;
                foreach (U u in r) { string k = u.Dev + "|" + u.App; if (known.Add(k)) { ch = true; if (!first && (DateTime.Now - u.Start).TotalHours < 2) fresh.Add(u); } }
                if (ch) Vigias3.Write(KNOWN, known.OrderBy(x => x));
                last = r;
            }
            if (Alert)
                foreach (U u in fresh.Take(3))
                    Vigias3.Notify("cm_" + u.Dev + u.App, "NEXUS · " + (u.Dev == "cam" ? Lang.L("Câmara usada") : Lang.L("Microfone usado")),
                        u.Name + " " + (u.Dev == "cam" ? Lang.L("usou a câmara pela primeira vez.") : Lang.L("usou o microfone pela primeira vez.")) + " " + Lang.L("Se não foste tu, vê em Saúde do PC."), 24 * 365);
        }
        public static string Json()
        {
            if (last.Count == 0) Check();
            List<U> l; lock (lk) l = last.ToList();
            return "{\"ok\":true,\"alert\":" + (Alert ? "true" : "false") + ",\"items\":[" + string.Join(",", l.Where(u => u.Now || (DateTime.Now - u.Start).TotalDays <= 60).Take(40).Select(u =>
                "{\"dev\":" + Js.S(u.Dev) + ",\"name\":" + Js.S(u.Name) + ",\"app\":" + Js.S(u.App.Replace('#', '\\')) + ",\"now\":" + (u.Now ? "true" : "false") +
                ",\"start\":" + Js.S(u.Start.ToString("yyyy-MM-dd HH:mm")) + ",\"ago\":" + Js.S(Vigias4.Ago(u.Now ? u.Start : u.Stop)) +
                ",\"mins\":" + (u.Now ? (int)(DateTime.Now - u.Start).TotalMinutes : Math.Max(0, (int)(u.Stop - u.Start).TotalMinutes)) + "}")) + "]}";
        }
        public static string Brief()
        {
            List<U> l; lock (lk) l = last.ToList();
            return "[" + string.Join(",", l.Where(u => u.Now).Select(u => "{\"dev\":" + Js.S(u.Dev) + ",\"name\":" + Js.S(u.Name) + "}")) + "]";
        }
    }

    // ============================================================ 38. internet por programa (por mês)
    // Lê os eventos de rede do próprio Windows (ETW "Kernel-Network": quem enviou/recebeu quantos bytes). Precisa de administrador.
    static class RedeProg
    {
        [DllImport("advapi32.dll", CharSet = CharSet.Unicode)] static extern int StartTrace(out ulong h, string name, IntPtr props);
        [DllImport("advapi32.dll", CharSet = CharSet.Unicode)] static extern int ControlTrace(ulong h, string name, IntPtr props, int code);
        [DllImport("advapi32.dll")] static extern int EnableTraceEx2(ulong h, ref Guid prov, int code, byte level, ulong any, ulong all, int timeout, IntPtr p);
        [DllImport("advapi32.dll", CharSet = CharSet.Unicode)] static extern ulong OpenTrace(IntPtr logfile);
        [DllImport("advapi32.dll")] static extern int ProcessTrace(ulong[] h, int n, IntPtr a, IntPtr b);
        [DllImport("advapi32.dll")] static extern int CloseTrace(ulong h);
        [UnmanagedFunctionPointer(CallingConvention.Winapi)] delegate void EvCb(IntPtr rec);

        const string NAME = "NEXUS-rede", FILE = "rede_programas.txt";
        static Guid prov = new Guid("7DD42A49-5329-4832-8DFD-43D979153A88");   // Microsoft-Windows-Kernel-Network
        static readonly object lk = new object(), mlk = new object();
        static Dictionary<int, long[]> acc = new Dictionary<int, long[]>();   // pid -> [enviado, recebido] desde a última gravação
        static readonly Dictionary<int, string> names = new Dictionary<int, string>();
        static Dictionary<string, long[]> month;   // "yyyy-MM|nome" -> [enviado, recebido]
        static readonly Dictionary<string, long[]> today = new Dictionary<string, long[]>(StringComparer.OrdinalIgnoreCase);
        static string todayD = "";
        static EvCb cb; static Thread th; static volatile string state = "off"; static ulong sess;
        static int myPid = Process.GetCurrentProcess().Id, lastPid = -1; static long[] lastArr; static Dictionary<int, long[]> lastAcc;
        public static bool On { get { return Cfg23.On("netprog", true); } }

        public static string SetOn(bool on)
        {
            Cfg23.Set("netprog", on ? "1" : "0");
            if (on) Start(); else Stop();
            return Json(null);
        }
        public static void Start()
        {
            if (!On || th != null) return;
            if (!Program.IsAdmin()) { state = "admin"; return; }
            th = new Thread(Loop) { IsBackground = true, Name = "NEXUS rede por programa" };
            th.Start();
        }
        static IntPtr Props()
        {
            int ss = IntPtr.Size == 8 ? 120 : 116, total = ss + 1024;
            IntPtr p = Marshal.AllocHGlobal(total);
            for (int i = 0; i < total; i++) Marshal.WriteByte(p, i, 0);
            Marshal.WriteInt32(p, 0, total);             // Wnode.BufferSize
            Marshal.WriteInt32(p, 40, 1);                // Wnode.ClientContext: QPC
            Marshal.WriteInt32(p, 44, 0x20000);          // Wnode.Flags: WNODE_FLAG_TRACED_GUID
            Marshal.WriteInt32(p, 48, 64);               // BufferSize (KB)
            Marshal.WriteInt32(p, 52, 2); Marshal.WriteInt32(p, 56, 8);
            Marshal.WriteInt32(p, 64, 0x100);            // LogFileMode: EVENT_TRACE_REAL_TIME_MODE
            Marshal.WriteInt32(p, 68, 1);                // FlushTimer (s)
            Marshal.WriteInt32(p, IntPtr.Size == 8 ? 116 : 112, ss);   // LoggerNameOffset
            return p;
        }
        public static void Stop()
        {
            IntPtr p = Props();
            try { ControlTrace(0, NAME, p, 1); } catch { } finally { Marshal.FreeHGlobal(p); }   // EVENT_TRACE_CONTROL_STOP: o ProcessTrace acaba
            state = "off";
        }
        static void Loop()
        {
            IntPtr props = IntPtr.Zero, lf = IntPtr.Zero, nm = IntPtr.Zero; ulong h = ulong.MaxValue;
            try
            {
                Stop();   // sessão que ficou de um NEXUS que fechou mal
                props = Props();
                int e = StartTrace(out sess, NAME, props);
                if (e != 0) { state = "err " + e; return; }
                e = EnableTraceEx2(sess, ref prov, 1, 4, 0x30, 0, 0, IntPtr.Zero);   // IPv4 + IPv6
                if (e != 0) { state = "err " + e; Stop(); return; }
                int lsz = IntPtr.Size == 8 ? 448 : 416;
                lf = Marshal.AllocHGlobal(lsz); for (int i = 0; i < lsz; i++) Marshal.WriteByte(lf, i, 0);
                nm = Marshal.StringToHGlobalUni(NAME);
                Marshal.WriteIntPtr(lf, IntPtr.Size, nm);                                         // LoggerName
                Marshal.WriteInt32(lf, IntPtr.Size == 8 ? 28 : 20, 0x100 | 0x10000000);           // REAL_TIME | EVENT_RECORD
                cb = OnEvent;
                Marshal.WriteIntPtr(lf, IntPtr.Size == 8 ? 424 : 400, Marshal.GetFunctionPointerForDelegate(cb));
                h = OpenTrace(lf);
                if (h == ulong.MaxValue || h == 0xFFFFFFFFUL) { state = "err open"; Stop(); return; }
                state = "on";
                ProcessTrace(new[] { h }, 1, IntPtr.Zero, IntPtr.Zero);   // fica aqui até a sessão parar
            }
            catch (Exception ex) { state = "err " + ex.Message; }
            finally
            {
                if (h != ulong.MaxValue) try { CloseTrace(h); } catch { }
                if (props != IntPtr.Zero) Marshal.FreeHGlobal(props);
                if (lf != IntPtr.Zero) Marshal.FreeHGlobal(lf);
                if (nm != IntPtr.Zero) Marshal.FreeHGlobal(nm);
                th = null;
                if (state == "on") state = "off";
            }
        }
        // pode chegar milhares de vezes por segundo: só soma
        static void OnEvent(IntPtr rec)
        {
            try
            {
                int id = (ushort)Marshal.ReadInt16(rec, 40);
                bool send = id == 10 || id == 26 || id == 42 || id == 58, recv = id == 11 || id == 27 || id == 43 || id == 59;
                if (!send && !recv) return;
                int len = (ushort)Marshal.ReadInt16(rec, IntPtr.Size == 8 ? 86 : 86);
                IntPtr ud = Marshal.ReadIntPtr(rec, IntPtr.Size == 8 ? 96 : 92);
                if (ud == IntPtr.Zero || len < 8) return;
                int pid = Marshal.ReadInt32(ud, 0), size = Marshal.ReadInt32(ud, 4);
                if (size <= 0 || pid == myPid) return;
                bool v6 = id == 26 || id == 27 || id == 58 || id == 59;
                if (!v6 && len >= 16) { byte a = Marshal.ReadByte(ud, 8), b = Marshal.ReadByte(ud, 12); if (a == 127 && b == 127) return; }   // tráfego dentro do próprio PC
                if (v6 && len >= 40) { bool lo = true; for (int i = 0; i < 15 && lo; i++) lo = Marshal.ReadByte(ud, 8 + i) == 0; if (lo && Marshal.ReadByte(ud, 23) == 1) return; }
                lock (lk)
                {
                    // numa transferência chegam milhares seguidos do mesmo programa: evita procurar no dicionário
                    long[] x;
                    if (pid == lastPid && lastAcc == acc) x = lastArr;
                    else { if (!acc.TryGetValue(pid, out x)) acc[pid] = x = new long[2]; lastPid = pid; lastArr = x; lastAcc = acc; }
                    x[send ? 0 : 1] += size;
                }
            }
            catch { }
        }
        static void Load()
        {
            if (month != null) return;
            month = new Dictionary<string, long[]>(StringComparer.OrdinalIgnoreCase);
            foreach (string l in Vigias3.Read(FILE))
            {
                string[] p = l.Split('|'); long s, r;
                if (p.Length >= 4 && long.TryParse(p[2], out s) && long.TryParse(p[3], out r)) month[p[0] + "|" + p[1]] = new[] { s, r };
            }
        }
        static string NameOf(int pid)
        {
            string n;
            if (names.TryGetValue(pid, out n)) return n;
            if (pid == 0 || pid == 4) n = "System";
            else try { using (Process p = Process.GetProcessById(pid)) n = p.ProcessName; } catch { n = Lang.L("(programa já fechado)"); }
            names[pid] = n;
            return n;
        }
        public static void Flush()
        {
            if (state != "on") { if (On && th == null && state != "admin" && !state.StartsWith("err")) Start(); return; }
            Dictionary<int, long[]> a;
            lock (lk) { a = acc; acc = new Dictionary<int, long[]>(); }
            if (names.Count > 3000) names.Clear();
            string m = DateTime.Now.ToString("yyyy-MM"), d = DateTime.Now.ToString("yyyy-MM-dd");
            lock (mlk)
            {
                Load();
                if (todayD != d) { today.Clear(); todayD = d; }
                foreach (KeyValuePair<int, long[]> x in a)
                {
                    string n = Vigias3.Clean(NameOf(x.Key));
                    long[] v; if (!month.TryGetValue(m + "|" + n, out v)) month[m + "|" + n] = v = new long[2];
                    v[0] += x.Value[0]; v[1] += x.Value[1];
                    if (!today.TryGetValue(n, out v)) today[n] = v = new long[2];
                    v[0] += x.Value[0]; v[1] += x.Value[1];
                }
                // guarda 13 meses
                string cut = DateTime.Now.AddMonths(-13).ToString("yyyy-MM");
                if (a.Count > 0) Vigias3.Write(FILE, month.Where(x => string.CompareOrdinal(x.Key, cut) >= 0).OrderBy(x => x.Key).Select(x => x.Key + "|" + x.Value[0] + "|" + x.Value[1]));
            }
        }
        public static string Json(string mon)
        {
            string m = string.IsNullOrEmpty(mon) || !Regex.IsMatch(mon, @"^\d{4}-\d{2}$") ? DateTime.Now.ToString("yyyy-MM") : mon;
            List<KeyValuePair<string, long[]>> rows, td; List<string> months;
            lock (mlk)
            {
                Load();
                rows = month.Where(x => x.Key.StartsWith(m + "|")).Select(x => new KeyValuePair<string, long[]>(x.Key.Substring(8), x.Value)).OrderByDescending(x => x.Value[0] + x.Value[1]).ToList();
                months = month.Keys.Select(k => k.Substring(0, 7)).Distinct().OrderByDescending(x => x).ToList();
                td = today.OrderByDescending(x => x.Value[0] + x.Value[1]).Take(8).ToList();
            }
            Func<KeyValuePair<string, long[]>, string> j = x => "{\"n\":" + Js.S(x.Key) + ",\"s\":" + x.Value[0] + ",\"r\":" + x.Value[1] + "}";
            return "{\"ok\":true,\"on\":" + (On ? "true" : "false") + ",\"state\":" + Js.S(state) + ",\"month\":" + Js.S(m) + ",\"months\":[" + string.Join(",", months.Select(Js.S)) +
                   "],\"total\":[" + rows.Sum(x => x.Value[0]) + "," + rows.Sum(x => x.Value[1]) + "],\"items\":[" + string.Join(",", rows.Take(25).Select(j)) + "],\"today\":[" + string.Join(",", td.Select(j)) + "]}";
        }
    }

    // ============================================================ 39. ficheiro hosts alterado
    // O ficheiro hosts manda o Windows para outro sítio quando abres um site. Vírus e "cracks" mexem-lhe.
    static class Hosts
    {
        const string COPY = "hosts_conhecido.txt";
        static string HostsPath { get { return Path.Combine(Environment.SystemDirectory, @"drivers\etc\hosts"); } }
        static volatile string[] added = new string[0], removed = new string[0];
        static volatile bool changed; static DateTime when = DateTime.MinValue;
        static IEnumerable<string> Rules(IEnumerable<string> l) { return l.Select(x => { int i = x.IndexOf('#'); return Regex.Replace(i >= 0 ? x.Substring(0, i) : x, @"\s+", " ").Trim(); }).Where(x => x != ""); }
        static string[] Cur() { try { return File.ReadAllLines(HostsPath); } catch { return null; } }
        public static void Check()
        {
            string[] cur = Cur(); if (cur == null) return;
            string copy = Vigias3.FileOf(COPY);
            if (!File.Exists(copy)) { Vigias3.Write(COPY, cur); return; }   // primeira vez: o que lá está é o normal
            string[] old = Vigias3.Read(COPY);
            List<string> a = Rules(cur).Except(Rules(old), StringComparer.OrdinalIgnoreCase).ToList(), r = Rules(old).Except(Rules(cur), StringComparer.OrdinalIgnoreCase).ToList();
            if (a.Count == 0 && r.Count == 0) { if (!cur.SequenceEqual(old)) Vigias3.Write(COPY, cur); changed = false; added = removed = new string[0]; return; }   // só comentários
            bool was = changed;
            added = a.Take(50).ToArray(); removed = r.Take(50).ToArray(); changed = true;
            if (!was) { when = DateTime.Now; try { when = File.GetLastWriteTime(HostsPath); } catch { } }
            string sig = string.Join(";", a.Concat(r)); sig = sig.Length > 40 ? sig.GetHashCode().ToString("x") : sig;
            Vigias3.Notify("hosts_" + sig, "NEXUS · " + Lang.L("Ficheiro hosts alterado"),
                Lang.L("Algo mudou para onde o Windows te manda quando abres certos sites") + " (" + a.Count + " " + Lang.L("regras novas") + "). " + Lang.L("Se não foste tu, vê em Rede."), 24 * 30);
        }
        public static string Accept() { string[] cur = Cur(); if (cur != null) Vigias3.Write(COPY, cur); changed = false; added = removed = new string[0]; return Json(); }
        public static string Undo()
        {
            // repõe a versão conhecida (o NEXUS em modo completo é administrador; guarda uma cópia da que estava)
            try
            {
                string[] old = Vigias3.Read(COPY); if (old.Length == 0) return Ps23.Ok(false, "?");
                File.Copy(HostsPath, Vigias3.FileOf("hosts_antes_de_repor_" + DateTime.Now.ToString("yyyyMMdd_HHmm") + ".txt"), true);
                File.WriteAllLines(HostsPath, old, Encoding.ASCII);
                changed = false; added = removed = new string[0];
                ProcOut.Run("ipconfig.exe", "/flushdns", 8000);
                return Json();
            }
            catch (Exception e) { return Ps23.Ok(false, e is UnauthorizedAccessException ? Lang.L("Precisa do NEXUS em modo completo (administrador).") : e.Message); }
        }
        public static string Open() { try { Process.Start("notepad.exe", "\"" + HostsPath + "\""); } catch { } return Json(); }
        public static string Json()
        {
            int rules = 0; string[] cur = Cur(); if (cur != null) rules = Rules(cur).Count();
            return "{\"ok\":true,\"changed\":" + (changed ? "true" : "false") + ",\"rules\":" + rules + ",\"when\":" + Js.S(changed ? when.ToString("yyyy-MM-dd HH:mm") : "") +
                   ",\"added\":[" + string.Join(",", added.Select(Js.S)) + "],\"removed\":[" + string.Join(",", removed.Select(Js.S)) + "],\"admin\":" + (Program.IsAdmin() ? "true" : "false") + "}";
        }
        public static string Brief() { return changed ? "{\"n\":" + added.Length + "}" : "null"; }
    }

    // ============================================================ 40. VPN ou proxy esquecidos
    static class VpnProxy
    {
        class V { public string Name, Desc; public bool Full, Overlay, Nexus; }
        static List<V> vpns = new List<V>();
        static string proxy = "", pac = "", winhttp = "";
        static readonly Regex VpnRe = new Regex(@"TAP-|WireGuard|Wintun|OpenVPN|NordLynx|Nord|Mullvad|Proton|Surfshark|ExpressVPN|Windscribe|AnyConnect|FortiClient|GlobalProtect|PANGP|Hamachi|ZeroTier|Tailscale|Cloudflare WARP|Private Internet|Hotspot Shield|CyberGhost|TunnelBear|IPVanish|PureVPN|Radmin|SoftEther|\bVPN\b", RegexOptions.IgnoreCase);
        static readonly Regex OverlayRe = new Regex(@"Hamachi|ZeroTier|Tailscale|Radmin", RegexOptions.IgnoreCase);
        public static void Check(string game)
        {
            List<V> l = new List<V>();
            try
            {
                foreach (NetworkInterface n in NetworkInterface.GetAllNetworkInterfaces())
                {
                    if (n.OperationalStatus != OperationalStatus.Up) continue;
                    string s = n.Name + " " + n.Description;
                    if (n.NetworkInterfaceType != NetworkInterfaceType.Ppp && !VpnRe.IsMatch(s)) continue;
                    bool full = false;
                    try { full = n.GetIPProperties().GatewayAddresses.Any(g => g.Address != null && !g.Address.ToString().StartsWith("0.0.0.0") && g.Address.ToString() != "::"); } catch { }
                    bool warp = s.IndexOf("Cloudflare", StringComparison.OrdinalIgnoreCase) >= 0;
                    l.Add(new V { Name = n.Name, Desc = n.Description, Full = full || n.NetworkInterfaceType == NetworkInterfaceType.Ppp, Overlay = OverlayRe.IsMatch(s), Nexus = warp && Rota.Consent });
                }
            }
            catch { }
            vpns = l;
            string px = "", pc = "";
            try
            {
                using (RegistryKey k = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Internet Settings"))
                    if (k != null) { if (Convert.ToInt32(k.GetValue("ProxyEnable", 0)) == 1) px = Convert.ToString(k.GetValue("ProxyServer", "")); pc = Convert.ToString(k.GetValue("AutoConfigURL", "")); }
            }
            catch { }
            proxy = px; pac = pc;
            string wh = "";
            try
            {
                using (RegistryKey k = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\Connections"))
                {
                    byte[] b = k == null ? null : k.GetValue("WinHttpSettings") as byte[];
                    if (b != null && b.Length >= 16 && (BitConverter.ToInt32(b, 8) & 2) != 0)
                    { int len = BitConverter.ToInt32(b, 12); if (len > 0 && 16 + len <= b.Length) wh = Encoding.ASCII.GetString(b, 16, len); }
                }
            }
            catch { }
            winhttp = wh;
            // a jogar com tudo a passar pela VPN (que não é a rota do NEXUS): mais ping
            V full1 = l.FirstOrDefault(v => v.Full && !v.Overlay && !v.Nexus);
            if (game != null && full1 != null)
                Vigias3.Notify("vpn_game", "NEXUS · " + Lang.L("VPN ligada a jogar"), full1.Desc + " " + Lang.L("está ligada: o jogo passa por ela e o ping costuma subir. Desliga-a se não precisares."), 24);
            if (px != "" || pc != "")
                Vigias3.Notify("proxy_" + (px + pc).GetHashCode().ToString("x"), "NEXUS · " + Lang.L("Proxy ligado"),
                    Lang.L("O Windows está a mandar a internet por") + " " + (px != "" ? px : pc) + ". " + Lang.L("Se não foste tu que o ligaste, vê em Rede."), 24 * 7);
        }
        public static string ProxyOff()
        {
            try
            {
                using (RegistryKey k = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Internet Settings", true))
                {
                    if (k != null)
                    {
                        Cfg23.Set("proxy_backup", Convert.ToString(k.GetValue("ProxyServer", "")) + "|" + Convert.ToString(k.GetValue("AutoConfigURL", "")));
                        k.SetValue("ProxyEnable", 0, RegistryValueKind.DWord);
                        if (k.GetValue("AutoConfigURL") != null) k.DeleteValue("AutoConfigURL", false);
                    }
                }
                InternetSetOption(IntPtr.Zero, 39, IntPtr.Zero, 0); InternetSetOption(IntPtr.Zero, 37, IntPtr.Zero, 0);   // avisa os programas abertos
            }
            catch (Exception e) { return Ps23.Ok(false, e.Message); }
            Check(null);
            return Json();
        }
        [DllImport("wininet.dll")] static extern bool InternetSetOption(IntPtr h, int opt, IntPtr buf, int len);
        public static string Json()
        {
            if (vpns.Count == 0 && proxy == "" && pac == "") Check(null);
            return "{\"ok\":true,\"proxy\":" + Js.S(proxy) + ",\"pac\":" + Js.S(pac) + ",\"winhttp\":" + Js.S(winhttp) + ",\"vpns\":[" + string.Join(",", vpns.Select(v =>
                "{\"name\":" + Js.S(v.Name) + ",\"desc\":" + Js.S(v.Desc) + ",\"full\":" + (v.Full ? "true" : "false") + ",\"overlay\":" + (v.Overlay ? "true" : "false") + ",\"nexus\":" + (v.Nexus ? "true" : "false") + "}")) + "]}";
        }
        public static string Brief() { return proxy != "" || pac != "" ? Js.S(proxy != "" ? proxy : pac) : "null"; }
    }

    // ============================================================ 47. portas abertas à rede
    static class Portas
    {
        [DllImport("iphlpapi.dll")] static extern int GetExtendedTcpTable(IntPtr t, ref int size, bool order, int af, int cls, int r);
        [DllImport("iphlpapi.dll")] static extern int GetExtendedUdpTable(IntPtr t, ref int size, bool order, int af, int cls, int r);
        class P { public string Proto, Addr, Name, Path; public int Port, Pid; public bool Lan; }
        static List<P> last = new List<P>(); static HashSet<string> known; static DateTime at = DateTime.MinValue;
        static readonly object lk = new object();
        const string KNOWN = "portas_conhecidas.txt";
        static readonly Dictionary<int, string> WinPorts = new Dictionary<int, string> { { 135, "RPC" }, { 139, "NetBIOS" }, { 445, "SMB (partilha de ficheiros)" }, { 5040, "Windows" }, { 7680, "Otimização de Entrega" }, { 5357, "Descoberta de rede" }, { 3389, "Ambiente de Trabalho Remoto" }, { 8765, "NEXUS" } };

        static int Port(uint v) { return (int)(((v & 0xFF) << 8) | ((v >> 8) & 0xFF)); }
        static IntPtr Table(bool tcp, int af, out int n)
        {
            n = 0; int size = 0;
            if (tcp) GetExtendedTcpTable(IntPtr.Zero, ref size, false, af, 3, 0); else GetExtendedUdpTable(IntPtr.Zero, ref size, false, af, 1, 0);
            if (size <= 0) return IntPtr.Zero;
            size += 4096;
            IntPtr b = Marshal.AllocHGlobal(size);
            int e = tcp ? GetExtendedTcpTable(b, ref size, false, af, 3, 0) : GetExtendedUdpTable(b, ref size, false, af, 1, 0);
            if (e != 0) { Marshal.FreeHGlobal(b); return IntPtr.Zero; }
            n = Marshal.ReadInt32(b);
            return b;
        }
        static List<P> Scan()
        {
            List<P> r = new List<P>();
            foreach (bool tcp in new[] { true, false })
                foreach (int af in new[] { 2, 23 })
                {
                    int n; IntPtr b = Table(tcp, af, out n); if (b == IntPtr.Zero) continue;
                    try
                    {
                        int rs = af == 2 ? (tcp ? 24 : 12) : (tcp ? 56 : 28);
                        for (int i = 0; i < n && i < 20000; i++)
                        {
                            IntPtr row = new IntPtr(b.ToInt64() + 4 + (long)i * rs);
                            string addr; uint port; int pid;
                            if (af == 2)
                            {
                                uint a = (uint)Marshal.ReadInt32(row, tcp ? 4 : 0); port = (uint)Marshal.ReadInt32(row, tcp ? 8 : 4); pid = Marshal.ReadInt32(row, tcp ? 20 : 8);
                                addr = (a & 0xFF) + "." + ((a >> 8) & 0xFF) + "." + ((a >> 16) & 0xFF) + "." + (a >> 24);
                            }
                            else
                            {
                                byte[] a = new byte[16]; Marshal.Copy(row, a, 0, 16);
                                port = (uint)Marshal.ReadInt32(row, 20); pid = Marshal.ReadInt32(row, tcp ? 52 : 24);
                                addr = new System.Net.IPAddress(a).ToString();
                            }
                            bool loop = addr.StartsWith("127.") || addr == "::1";
                            if (loop) continue;
                            r.Add(new P { Proto = tcp ? "TCP" : "UDP", Addr = addr, Port = Port(port), Pid = pid, Lan = true });
                        }
                    }
                    finally { Marshal.FreeHGlobal(b); }
                }
            Dictionary<int, string[]> pn = new Dictionary<int, string[]>();
            foreach (P p in r)
            {
                string[] v;
                if (!pn.TryGetValue(p.Pid, out v))
                {
                    v = new[] { p.Pid == 4 ? "System" : p.Pid == 0 ? "?" : "", "" };
                    if (v[0] == "") { try { using (Process q = Process.GetProcessById(p.Pid)) v[0] = q.ProcessName; } catch { v[0] = "?"; } v[1] = Optimizer.ExePath(p.Pid); }
                    pn[p.Pid] = v;
                }
                p.Name = v[0]; p.Path = v[1];
            }
            // a mesma porta em IPv4 e IPv6 conta uma vez
            return r.GroupBy(p => p.Proto + "|" + p.Port + "|" + p.Pid).Select(g => g.First()).OrderBy(p => p.Proto).ThenBy(p => p.Port).ToList();
        }
        public static void Check(bool notify)
        {
            List<P> l; try { l = Scan(); } catch { return; }
            List<P> fresh = new List<P>();
            lock (lk)
            {
                bool first = known == null;
                if (first) known = new HashSet<string>(Vigias3.Read(KNOWN), StringComparer.OrdinalIgnoreCase);
                first = first && known.Count == 0;
                bool ch = false;
                foreach (P p in l.Where(x => x.Proto == "TCP" && x.Name != "?"))
                    if (known.Add(p.Name + "|TCP")) { ch = true; if (!first) fresh.Add(p); }
                if (ch) Vigias3.Write(KNOWN, known.OrderBy(x => x));
                last = l; at = DateTime.Now;
            }
            if (notify)
                foreach (P p in fresh.Take(2))
                    Vigias3.Notify("port_" + p.Name, "NEXUS · " + Lang.L("Programa novo à escuta na rede"),
                        p.Name + " " + Lang.L("abriu a porta") + " TCP " + p.Port + ". " + Lang.L("Outros dispositivos da rede (ou da internet, se o router deixar) podem ligar-se a ele. Vê em Rede."), 24 * 365);
        }
        public static string Json(bool fresh)
        {
            if (fresh || (DateTime.Now - at).TotalSeconds > 60) Check(false);
            List<P> l; HashSet<string> k; lock (lk) { l = last.ToList(); k = known; }
            return "{\"ok\":true,\"items\":[" + string.Join(",", l.Select(p =>
            {
                string w; WinPorts.TryGetValue(p.Port, out w);
                bool win = p.Name == "System" || p.Name == "svchost" || p.Name == "lsass" || p.Name == "wininit" || p.Name == "services" || p.Name == "spoolsv";
                return "{\"proto\":" + Js.S(p.Proto) + ",\"port\":" + p.Port + ",\"addr\":" + Js.S(p.Addr) + ",\"name\":" + Js.S(p.Name) + ",\"path\":" + Js.S(p.Path) +
                       ",\"what\":" + Js.S(w ?? "") + ",\"win\":" + (win ? "true" : "false") + "}";
            })) + "]}";
        }
    }

    // ============================================================ 41. quanto tempo falta de bateria (periféricos)
    // Guarda a bateria de cada dispositivo de minuto a minuto e vê a que ritmo desce desde a última carga.
    static class BateriaEta
    {
        class S { public DateTime T; public int P; }
        static readonly object lk = new object();
        static Dictionary<string, List<S>> hist;
        static readonly Dictionary<string, double> eta = new Dictionary<string, double>();
        const string FILE = "bateria_historico.txt";
        static int saves;

        static void Load()
        {
            if (hist != null) return;
            hist = new Dictionary<string, List<S>>();
            foreach (string l in Vigias3.Read(FILE))
            {
                string[] p = l.Split('|'); long t; int v;
                if (p.Length < 3 || !long.TryParse(p[1], out t) || !int.TryParse(p[2], out v)) continue;
                List<S> h; if (!hist.TryGetValue(p[0], out h)) hist[p[0]] = h = new List<S>();
                h.Add(new S { T = new DateTime(t), P = v });
            }
        }
        static void Add(string key, int pct, bool charging)
        {
            List<S> h; if (!hist.TryGetValue(key, out h)) hist[key] = h = new List<S>();
            if (charging) { h.Clear(); eta.Remove(key); return; }   // a carregar: recomeça
            S last = h.Count > 0 ? h[h.Count - 1] : null;
            if (last != null && pct >= last.P + 3) { h.Clear(); last = null; }   // carregou entretanto
            if (last == null || last.P != pct || (DateTime.Now - last.T).TotalMinutes >= 30) h.Add(new S { T = DateTime.Now, P = pct });
            if (h.Count > 400) h.RemoveRange(0, h.Count - 400);
            // ritmo: da primeira à última leitura da descarga atual (precisa de 30 min e 2 %, ou 2 h e 1 %)
            S a = h[0], b = h[h.Count - 1];
            double hrs = (b.T - a.T).TotalHours, drop = a.P - b.P;
            double rate = (hrs >= 0.5 && drop >= 2) || (hrs >= 2 && drop >= 1) ? drop / hrs : double.NaN;   // muitos ratos só dizem a bateria de 5 em 5 % ou 10 em 10 %
            if (!double.IsNaN(rate)) { if (h.Count % 10 == 0 || Cfg23.Get(RateKey(key), "") == "") Cfg23.Set(RateKey(key), rate.ToString("0.###", CultureInfo.InvariantCulture)); }
            else { double r0; if (double.TryParse(Cfg23.Get(RateKey(key), ""), NumberStyles.Float, CultureInfo.InvariantCulture, out r0)) rate = r0; }
            if (!double.IsNaN(rate) && rate > 0.05) eta[key] = pct / rate; else eta.Remove(key);
        }
        static string RateKey(string key) { string k = Regex.Replace(key, "[^A-Za-z0-9]", "").ToLowerInvariant(); return "bat_rate_" + (k.Length > 40 ? k.Substring(0, 40) : k); }
        public static void Sample()
        {
            List<KeyValuePair<string, int[]>> now = new List<KeyValuePair<string, int[]>>();
            try { foreach (Aparelho a in Aparelhos.All) if (a.Battery >= 0 && !a.Sleeping) now.Add(new KeyValuePair<string, int[]>(a.Id, new[] { a.Battery, a.Charging ? 1 : 0 })); } catch { }
            try
            {
                string j = Ferr.PeriphCached();
                if (j != null) foreach (Match m in Regex.Matches(j, "\"n\":\"((?:[^\"\\\\]|\\\\.)*)\",\"b\":(\\d+)")) now.Add(new KeyValuePair<string, int[]>("bt:" + m.Groups[1].Value, new[] { int.Parse(m.Groups[2].Value), 0 }));
            }
            catch { }
            if (now.Count == 0) return;
            lock (lk)
            {
                Load();
                foreach (KeyValuePair<string, int[]> x in now) Add(x.Key, x.Value[0], x.Value[1] == 1);
                if (++saves % 10 == 1)
                {
                    DateTime cut = DateTime.Now.AddDays(-14);
                    Vigias3.Write(FILE, hist.SelectMany(kv => kv.Value.Where(s => s.T > cut).Select(s => Vigias3.Clean(kv.Key) + "|" + s.T.Ticks + "|" + s.P)));
                }
            }
        }
        // horas que faltam (NaN se ainda não se sabe)
        public static double Eta(string key) { lock (lk) { double v; return eta.TryGetValue(key, out v) ? v : double.NaN; } }
        public static string Json()
        {
            lock (lk) return "{\"ok\":true,\"eta\":{" + string.Join(",", eta.Select(x => Js.S(x.Key) + ":" + Vigias3.F1(x.Value))) + "}}";
        }
    }

    // ============================================================ 50. comandos Xbox (XInput) e PlayStation (DualShock 4 / DualSense)
    class XboxPad : Aparelho
    {
        [StructLayout(LayoutKind.Sequential)] struct BAT { public byte Type, Level; }
        [DllImport("xinput1_4.dll")] static extern int XInputGetBatteryInformation(int i, byte devType, out BAT b);
        [DllImport("xinput1_4.dll")] static extern int XInputGetState(int i, byte[] state);
        readonly int idx;
        public XboxPad(int i) { idx = i; Id = "xinput" + i; Name = Lang.L("Comando Xbox") + " #" + (i + 1); Brand = "Microsoft"; Kind = "gamepad"; Wireless = true; Vid = 0x045E; }
        public static bool Connected(int i) { try { return XInputGetState(i, new byte[16]) == 0; } catch { return false; } }
        public override void Refresh()
        {
            BAT b;
            if (XInputGetBatteryInformation(idx, 0, out b) != 0 || b.Type == 0) { Sleeping = true; return; }
            Sleeping = false;
            if (b.Type == 1) { Wireless = false; Battery = -1; Extra.Clear(); Extra.Add(new KeyValuePair<string, string>(Lang.L("Ligação"), Lang.L("com fio"))); return; }
            Wireless = true;
            Battery = b.Level == 0 ? 5 : b.Level == 1 ? 25 : b.Level == 2 ? 60 : 100;   // o XInput só dá 4 níveis
            ChargeUnknown = true;
            Extra.Clear();
            Extra.Add(new KeyValuePair<string, string>(Lang.L("Nível"), Lang.L(b.Level == 0 ? "vazio" : b.Level == 1 ? "baixo" : b.Level == 2 ? "médio" : "cheio") + (b.Type == 2 ? " · " + Lang.L("pilhas") : b.Type == 3 ? " · " + Lang.L("bateria") : "")));
        }
        public override bool SetDpi(int dpi) { return false; }
    }

    class SonyPad : Aparelho
    {
        [DllImport("kernel32.dll", SetLastError = true)] static extern bool ReadFile(SafeFileHandle h, IntPtr b, int n, out int read, ref NativeOverlapped ov);
        [DllImport("kernel32.dll", SetLastError = true)] static extern bool GetOverlappedResult(SafeFileHandle h, ref NativeOverlapped ov, out int n, bool wait);
        [DllImport("kernel32.dll")] static extern bool CancelIoEx(SafeFileHandle h, ref NativeOverlapped ov);
        readonly string path; readonly bool ds5, bt; readonly int inLen; bool woke;
        public static readonly ushort[] Pids = { 0x05C4, 0x09CC, 0x0BA0, 0x0CE6, 0x0DF2 };
        public SonyPad(Hid.Dev d)
        {
            path = d.Path; inLen = d.InLen; Vid = d.Vid; Pid = d.Pid; Brand = "Sony"; Kind = "gamepad";
            ds5 = d.Pid == 0x0CE6 || d.Pid == 0x0DF2;
            bt = d.Path.IndexOf("00001124-0000-1000-8000-00805f9b34fb", StringComparison.OrdinalIgnoreCase) >= 0 || d.Path.IndexOf("&0002054c", StringComparison.OrdinalIgnoreCase) >= 0 || d.InLen > 64;
            Wireless = bt || d.Pid == 0x0BA0;
            Name = d.Pid == 0x0DF2 ? "DualSense Edge" : ds5 ? "DualSense" : "DualShock 4";
            Id = "sony:" + Hid.Parent(d.Path);
        }
        byte[] ReadReport(SafeFileHandle h, int ms)
        {
            int len = Math.Max(80, (int)inLen);
            IntPtr mem = Marshal.AllocHGlobal(len);   // memória fixa: a leitura acaba depois de o ReadFile voltar
            try
            {
                using (ManualResetEvent ev = new ManualResetEvent(false))
                {
                    NativeOverlapped ov = new NativeOverlapped(); ov.EventHandle = ev.SafeWaitHandle.DangerousGetHandle();
                    int n;
                    if (!ReadFile(h, mem, len, out n, ref ov))
                    {
                        if (Marshal.GetLastWin32Error() != 997) return null;   // ERROR_IO_PENDING
                        if (!ev.WaitOne(ms)) { CancelIoEx(h, ref ov); GetOverlappedResult(h, ref ov, out n, true); return null; }
                        if (!GetOverlappedResult(h, ref ov, out n, false)) return null;
                    }
                    if (n <= 0) return null;
                    byte[] b = new byte[len]; Marshal.Copy(mem, b, 0, Math.Min(n, len));
                    return b;
                }
            }
            finally { Marshal.FreeHGlobal(mem); }
        }
        public override void Refresh()
        {
            SafeFileHandle h0 = Hid.CreateFile(path, 0xC0000000, 3, IntPtr.Zero, 3, 0x40000000, IntPtr.Zero);
            if (h0.IsInvalid) { h0.Dispose(); h0 = Hid.CreateFile(path, 0x80000000, 3, IntPtr.Zero, 3, 0x40000000, IntPtr.Zero); }   // outro programa só deixa ler
            using (SafeFileHandle h = h0)
            {
                if (h.IsInvalid) { Err = "busy"; return; }
                if (bt && !woke)
                {
                    // por Bluetooth o comando só manda o relatório completo (com a bateria) depois de lhe pedirem a calibração
                    byte[] f = new byte[ds5 ? 41 : 37]; f[0] = (byte)(ds5 ? 0x05 : 0x02);
                    try { Hid.HidD_GetFeature(h, f, f.Length); } catch { }
                    woke = true;
                }
                for (int tries = 0; tries < 6; tries++)
                {
                    byte[] r = ReadReport(h, 400);
                    if (r == null) { Sleeping = Wireless; return; }
                    int o = -1;
                    if (ds5) o = r[0] == 0x01 && !bt ? 53 : r[0] == 0x31 ? 54 : -1;
                    else o = r[0] == 0x01 && !bt ? 30 : r[0] == 0x11 ? 32 : -1;
                    if (o < 0 || o >= r.Length) continue;
                    int v = r[o]; Sleeping = false; ChargeUnknown = false;
                    if (ds5)
                    {
                        int lvl = v & 0x0F, st = v >> 4;
                        Battery = st == 2 ? 100 : Math.Min(100, lvl * 10 + 5);
                        Charging = st == 1;
                        if (st == 0x0B || st == 0x0F) { Battery = -1; Err = ""; }   // erro de temperatura/bateria: não mostra valor errado
                    }
                    else
                    {
                        int lvl = v & 0x0F; bool cable = (v & 0x10) != 0;
                        if (Pid == 0x0BA0 && v == 0) { Sleeping = true; return; }   // recetor sem comando ligado
                        if (!cable) { Battery = Math.Min(100, (lvl + 1) * 10); Charging = false; }
                        else { Battery = lvl >= 11 ? 100 : Math.Min(100, lvl * 10); Charging = lvl < 11; }
                    }
                    return;
                }
            }
        }
        public override bool SetDpi(int dpi) { return false; }
    }

    static class Comandos
    {
        public static IEnumerable<Aparelho> Find(List<Hid.Dev> all)
        {
            List<Aparelho> r = new List<Aparelho>();
            foreach (var g in all.Where(d => d.Vid == 0x054C && SonyPad.Pids.Contains(d.Pid) && d.UsagePage == 1 && (d.Usage == 5 || d.Usage == 4)).GroupBy(d => Hid.Parent(d.Path)))
            {
                SonyPad p = new SonyPad(g.First());
                try { p.Refresh(); } catch (Exception e) { p.Err = e.Message; }
                if (p.Battery >= 0 || p.Sleeping || !p.Wireless) r.Add(p);
            }
            for (int i = 0; i < 4; i++)
            {
                if (!XboxPad.Connected(i)) continue;
                XboxPad x = new XboxPad(i);
                try { x.Refresh(); } catch { }
                if (x.Battery >= 0) r.Add(x);   // com fio ou virtual (ex.: DS4Windows) não tem nada para mostrar
            }
            return r;
        }
        // de minuto a minuto, mesmo a jogar (ler a bateria não mexe no comando): só os comandos que já estão na lista
        public static void Poll()
        {
            if (!Aparelhos.Enabled) return;
            Aparelhos.RefreshWhere(a => a is SonyPad || a is XboxPad);
        }
    }
}
