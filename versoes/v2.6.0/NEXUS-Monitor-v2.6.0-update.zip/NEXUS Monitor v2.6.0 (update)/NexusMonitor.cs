﻿// NEXUS // MONITOR - monitor do sistema em tempo real (Windows, .NET Framework 4.x, C# 5)
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Linq;
using System.Management;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Reflection;
using System.Security.Principal;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Win32;

[assembly: AssemblyTitle("NEXUS Monitor")]
[assembly: AssemblyProduct("NEXUS Monitor")]
[assembly: AssemblyDescription("Monitor do sistema em tempo real")]
[assembly: AssemblyCompany("NEXUS")]
[assembly: AssemblyCopyright("NEXUS 2026")]
[assembly: AssemblyVersion("2.6.0.0")]
[assembly: AssemblyFileVersion("2.6.0.0")]

namespace Nexus
{
    static class Program
    {
        const int PORT = 8765;
        public static int PortNumber { get { return PORT; } }
        const string URL = "http://localhost:8765/";
        static TcpListener listener;
        static string html, diskHtml, padHtml, perfHtml, i18nJs, tourJs, shellJs;
        // páginas e scripts não mudam enquanto o NEXUS corre: convertidos para bytes uma vez (o i18n.js tem mais de 1 MB)
        // e o browser guarda-os (ETag): ao mudar de página pelo menu lateral não volta a descarregar tudo
        static readonly Dictionary<string, byte[]> staticBytes = new Dictionary<string, byte[]>();
        static readonly string ETag = "\"" + System.Reflection.Assembly.GetExecutingAssembly().GetName().Version + "-" + DateTime.UtcNow.Ticks.ToString("x") + "\"";
        static byte[] Static(string key, string s)
        {
            byte[] b;
            lock (staticBytes) if (!staticBytes.TryGetValue(key, out b)) staticBytes[key] = b = Encoding.UTF8.GetBytes(s ?? "");
            return b;
        }
        static Mutex mutex;
        static NotifyIcon tray;
        static HoverPopup hover;
        static volatile bool menuOpen;
        static DateTime menuClosedAt = DateTime.MinValue;
        static Control invoker;

        public static string LhmDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "lhm");
        public static bool FullMode = File.Exists(Path.Combine(LhmDir, "LibreHardwareMonitorLib.dll"));

        // não muda enquanto o programa corre: pergunta-se ao Windows uma vez (era a cada leitura das estatísticas)
        static int admin = -1;
        public static bool IsAdmin()
        {
            if (admin < 0) { try { admin = new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator) ? 1 : 0; } catch { return false; } }
            return admin == 1;
        }

        const string MUTEX = "NEXUS_Monitor_SingleInstance";

        static bool AlreadyRunning()
        {
            try { Mutex m; if (Mutex.TryOpenExisting(MUTEX, out m)) { m.Dispose(); return true; } return false; }
            catch (UnauthorizedAccessException) { return true; }   // existe, mas foi criado como administrador
            catch { return false; }
        }

        static void CrashLog(object ex)
        {
            try
            {
                string d = AppSettings.Dir; Directory.CreateDirectory(d);
                string f = Path.Combine(d, "nexus_crash.txt");
                if (File.Exists(f) && new FileInfo(f).Length > 512 * 1024) File.Delete(f);
                File.AppendAllText(f, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " v" + Atualizar.Current + "\r\n" + ex + "\r\n\r\n");
            }
            catch { }
        }
        [STAThread]   // a interface (menus, diálogos, área de transferência) precisa de STA
        static void Main(string[] args)
        {
            // um erro inesperado deixa rasto (nexus_crash.txt na pasta das definições) em vez de o NEXUS desaparecer sem explicação
            AppDomain.CurrentDomain.UnhandledException += (s, e) => CrashLog(e.ExceptionObject);
            Application.ThreadException += (s, e) => CrashLog(e.Exception);   // erro na janela: regista e continua
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
            if (EqMotor.HandleArgs(args)) return;   // passo do equalizador que precisa de administrador
            bool argElevated = args.Contains("--elevated");
            bool argTask = args.Contains("--task");
            bool argAuto = args.Contains("--autostart");
            AppSettings.Load();
            if (AppSettings.RgbSync) { RgbSync.InstallPlugin(); RgbSync.SetActive(true); }   // cores do SignalRGB (só se a opção estiver ligada)

            // já está aberto: só abre a página (se não for um arranque automático)
            if (AlreadyRunning())
            {
                if (!argAuto && !argTask) AskRunningToShow();
                return;
            }

            // modo completo: precisa de administrador para os sensores do CPU/motherboard
            if (FullMode && !IsAdmin())
            {
                if (!argElevated)
                {
                    // 1) tarefa agendada com privilégios elevados -> sem aviso do Windows
                    if (AppSettings.TaskExists() && AppSettings.TaskPointsHere())
                    {
                        if (!argAuto) AppSettings.RequestBrowser();
                        if (AppSettings.RunTask()) return;
                    }
                    // 2) aviso normal do Windows
                    try
                    {
                        ProcessStartInfo psi = new ProcessStartInfo(Application.ExecutablePath, "--elevated" + (argAuto ? " --autostart" : ""));
                        psi.Verb = "runas";
                        psi.UseShellExecute = true;
                        Process.Start(psi);
                        return;
                    }
                    catch { /* o utilizador recusou: continua em modo normal */ }
                }
                FullMode = false;
            }

            // uma só instância
            bool created;
            mutex = new Mutex(true, MUTEX, out created);
            if (!created)
            {
                if (!argAuto && !argTask) AskRunningToShow();
                return;
            }

            // arranque automático (logon ou tarefa sem pedido de abrir) -> respeita "minimizado"
            bool launchedAutomatically = argAuto || (argTask && !AppSettings.ConsumeBrowserRequest());
            bool openBrowser = !(launchedAutomatically && AppSettings.Minimized);

            // mantém os atalhos de arranque a apontar para este executável (e regista onde o NEXUS está instalado)
            try { AppSettings.Apply(); } catch { }
            AppSettings.RepairPaths();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // a porta pode estar presa uns segundos: o NEXUS anterior ainda a fechar (reinício, atualização) ou um programa
            // que ele lançou e ficou a correr com ela herdada (PresentMon, nvidia-smi). Tenta durante ~15 s e liberta os nossos
            string portErr = null;
            for (int i = 0; i < 30; i++)
            {
                try { StartListener(); portErr = null; break; }
                catch (SocketException) { portErr = FreePort(); Thread.Sleep(500); }
            }
            if (portErr != null)
            {
                MessageBox.Show("A porta " + PORT + " já está a ser usada por outro programa" + (portErr != "" ? " (" + portErr + ")" : "") +
                                ".\n\nFecha esse programa ou reinicia o PC e abre o NEXUS outra vez.",
                                "NEXUS Monitor", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (Stream s = Assembly.GetExecutingAssembly().GetManifestResourceStream("index.html"))
            using (StreamReader r = new StreamReader(s, Encoding.UTF8))
                html = r.ReadToEnd();
            try
            {
                using (Stream s = Assembly.GetExecutingAssembly().GetManifestResourceStream("disk.html"))
                    if (s != null) using (StreamReader r = new StreamReader(s, Encoding.UTF8)) diskHtml = r.ReadToEnd();
                using (Stream s = Assembly.GetExecutingAssembly().GetManifestResourceStream("pad.html"))
                    if (s != null) using (StreamReader r = new StreamReader(s, Encoding.UTF8)) padHtml = r.ReadToEnd();
                using (Stream s = Assembly.GetExecutingAssembly().GetManifestResourceStream("perf.html"))
                    if (s != null) using (StreamReader r = new StreamReader(s, Encoding.UTF8)) perfHtml = r.ReadToEnd();
                using (Stream s = Assembly.GetExecutingAssembly().GetManifestResourceStream("i18n.js"))
                    if (s != null) using (StreamReader r = new StreamReader(s, Encoding.UTF8)) i18nJs = r.ReadToEnd();
                using (Stream s = Assembly.GetExecutingAssembly().GetManifestResourceStream("tour.js"))
                    if (s != null) using (StreamReader r = new StreamReader(s, Encoding.UTF8)) tourJs = r.ReadToEnd();
                using (Stream s = Assembly.GetExecutingAssembly().GetManifestResourceStream("shell.js"))
                    if (s != null) using (StreamReader r = new StreamReader(s, Encoding.UTF8)) shellJs = r.ReadToEnd();
            }
            catch { }
            Lang.Load(i18nJs);

            Stats.Init();
            PresentMonReader.Start();
            Optimizer.Start();
            Thread slow = new Thread(Stats.SlowLoop);
            slow.IsBackground = true;
            slow.Start();

            Thread server = new Thread(ServeLoop);
            server.IsBackground = true;
            server.Start();

            invoker = new Control();
            IntPtr forceHandle = invoker.Handle;   // cria a janela invisível usada para voltar à thread da interface

            SetupTray();
            try { GameOverlay.Apply(); } catch { }
            ThreadPool.QueueUserWorkItem(delegate { try { Perfis.RecoverSession(); } catch { } });
            try { Historico.Start(); } catch { }
            try { Saude.CheckLater(); } catch { }
            try { Atualizar.Start(); } catch { }
            try { Discord.Start(); } catch { }
            try { Ventoinhas.Start(); } catch { }
            try { PingMon.Start(); } catch { }
            try { LimpezaAuto.Start(); } catch { }
            try { NaoIncomodar.Restore(); } catch { }
            try { Vizinhos.Start(); } catch { }
            try { Api23.Start(); } catch { }
            if (openBrowser) OpenMonitor();
            Application.Run();

            GC.KeepAlive(mutex);
        }

        public static void Ui(MethodInvoker m) { try { if (invoker != null) invoker.BeginInvoke(m); } catch { } }

        static volatile bool quitting;
        public static bool Quitting { get { return quitting; } }
        static readonly object listenerLock = new object();

        [DllImport("kernel32.dll", SetLastError = true)] static extern bool SetHandleInformation(IntPtr h, int mask, int flags);
        // os programas que o NEXUS lança (PresentMon, nvidia-smi, PowerShell…) herdavam a porta: se algum ficasse a correr
        // depois de o NEXUS fechar, a porta continuava ocupada e o NEXUS seguinte não abria. Assim a porta não passa para eles
        static void NoInherit(TcpListener l) { try { SetHandleInformation(l.Server.Handle, 1, 0); } catch { } }

        // só aceita ligações da rede (telemóvel) se o acesso remoto estiver ligado
        static void StartListener()
        {
            if (AppSettings.Remote)
            {
                try { listener = new TcpListener(IPAddress.Any, PORT); listener.Start(); NoInherit(listener); return; }
                catch (SocketException) { }
            }
            listener = new TcpListener(IPAddress.Loopback, PORT);
            listener.Start(); NoInherit(listener);
        }

        // quem tem a porta? Se for um programa do próprio NEXUS que ficou órfão, fecha-o. Devolve o nome (ou "")
        static string FreePort()
        {
            try
            {
                string o = ProcOut.Run("netstat.exe", "-ano -p tcp", 6000);
                foreach (string l in o.Split('\n'))
                {
                    string[] p = l.Split(new[] { ' ', '\t', '\r' }, StringSplitOptions.RemoveEmptyEntries);
                    if (p.Length < 5 || !p[1].EndsWith(":" + PORT) || !p[3].StartsWith("LISTEN", StringComparison.OrdinalIgnoreCase)) continue;
                    int pid; if (!int.TryParse(p[4], out pid) || pid == Process.GetCurrentProcess().Id) continue;
                    string path = Optimizer.ExePath(pid), name = path != "" ? Path.GetFileName(path) : ("PID " + pid);
                    string me = AppDomain.CurrentDomain.BaseDirectory;
                    bool ours = path != "" && (path.StartsWith(me, StringComparison.OrdinalIgnoreCase) ||
                                Path.GetFileName(path).Equals("nvidia-smi.exe", StringComparison.OrdinalIgnoreCase));
                    bool oldNexus = path != "" && Path.GetFileName(path).Equals(Path.GetFileName(Application.ExecutablePath), StringComparison.OrdinalIgnoreCase);
                    if (ours && !oldNexus) { try { using (Process x = Process.GetProcessById(pid)) x.Kill(); } catch { } }
                    return name;
                }
            }
            catch { }
            return "";
        }

        public static void RestartListener()
        {
            lock (listenerLock)
            {
                try { listener.Stop(); } catch { }
                Thread.Sleep(150);
                try { StartListener(); }
                catch { try { listener = new TcpListener(IPAddress.Loopback, PORT); listener.Start(); NoInherit(listener); } catch { } }
            }
        }

        static void ServeLoop()
        {
            while (!quitting)
            {
                TcpClient c;
                try { c = listener.AcceptTcpClient(); try { SetHandleInformation(c.Client.Handle, 1, 0); } catch { } }
                catch { if (quitting) break; Thread.Sleep(200); continue; }
                ThreadPool.QueueUserWorkItem(Handle, c);
            }
        }

        // ------------------------------------------------------------ ícone na barra de tarefas
        static void SetupTray()
        {
            Icon icon;
            try { icon = MakeTrayIcon(AppSettings.ThemeColor("bg"), AppSettings.ThemeColor("c1")); }
            catch
            {
                try { icon = new Icon(Icon.ExtractAssociatedIcon(Application.ExecutablePath), SystemInformation.SmallIconSize); }
                catch { icon = SystemIcons.Application; }
            }

            ContextMenuStrip menu = new ContextMenuStrip();
            menu.Renderer = new DarkRenderer();
            menu.ShowImageMargin = false;
            menu.ShowCheckMargin = true;
            menu.Padding = new Padding(2, 4, 2, 4);
            menu.Opening += delegate { try { BuildMenu(menu); } catch { } };
            BuildMenu(menu);

            tray = new NotifyIcon();
            tray.Icon = icon;
            tray.Text = "NEXUS Monitor";
            tray.ContextMenuStrip = menu;
            tray.MouseClick += delegate(object sender, MouseEventArgs e)
            {
                if (e.Button == MouseButtons.Left) OpenMonitor();
            };
            tray.Visible = true;

            // CPU e RAM ao passar o rato por cima
            // painel próprio ao passar o rato (a dica normal do Windows pisca sempre que o texto muda)
            tray.Text = "";
            hover = new HoverPopup();
            // O painel tem de sair ANTES de o Windows abrir o menu: esconder uma janela nossa enquanto o menu
            // abre faz o Windows achar que se clicou fora e fecha-o logo (menu a piscar / só abria ao 2.º clique).
            tray.MouseDown += delegate { hover.Hide(); };
            tray.MouseMove += delegate
            {
                if (menuOpen || (DateTime.UtcNow - menuClosedAt).TotalMilliseconds < 600) return;   // nunca por cima do menu
                hover.Touch();
            };
            menu.Opening += delegate { menuOpen = true; };
            menu.Closed += delegate { menuOpen = false; menuClosedAt = DateTime.UtcNow; };
            // tema mudado com o menu aberto (ex.: pela página ou pelo telemóvel): repinta logo com as cores novas
            System.Windows.Forms.Timer mt = new System.Windows.Forms.Timer();
            mt.Interval = 150;
            string menuTheme = AppSettings.ThemeJson();
            mt.Tick += delegate
            {
                if (!menuOpen) return;
                RgbSync.Watch();
                string now = AppSettings.ThemeJson();
                if (now == menuTheme) return;
                menuTheme = now;
                Recolor(menu.Items);
                menu.Invalidate();
            };
            menu.Opening += delegate { RgbSync.Watch(); menuTheme = AppSettings.ThemeJson(); };
            mt.Start();

            // alertas: notificação do Windows (no máximo uma por tipo a cada 5 minutos)
            tray.BalloonTipClicked += delegate { OpenMonitor(); };
            System.Windows.Forms.Timer at = new System.Windows.Forms.Timer();
            at.Interval = 5000;
            at.Tick += delegate { try { CheckAlerts(); } catch { } };
            at.Start();
        }

        static DateTime lastCpuAlert = DateTime.MinValue, lastGpuAlert = DateTime.MinValue, lastRamAlert = DateTime.MinValue;

        static void CheckAlerts()
        {
            if (!AppSettings.Alerts || tray == null) return;
            double? cpuT, gpuT; double ram;
            Stats.AlertSnapshot(out cpuT, out gpuT, out ram);
            DateTime now = DateTime.Now;
            TimeSpan cool = TimeSpan.FromMinutes(5);
            if (cpuT.HasValue && cpuT.Value >= AppSettings.AlertCpu && now - lastCpuAlert > cool)
            {
                lastCpuAlert = now;
                AlertToast.Show(Lang.L("NEXUS · CPU quente"), Lang.L("CPU a " + Math.Round(cpuT.Value) + " °C (limite " + AppSettings.AlertCpu + " °C)."));
            }
            else if (gpuT.HasValue && gpuT.Value >= AppSettings.AlertGpu && now - lastGpuAlert > cool)
            {
                lastGpuAlert = now;
                AlertToast.Show(Lang.L("NEXUS · GPU quente"), Lang.L("GPU a " + Math.Round(gpuT.Value) + " °C (limite " + AppSettings.AlertGpu + " °C)."));
            }
            else if (ram >= AppSettings.AlertRam && now - lastRamAlert > cool)
            {
                lastRamAlert = now;
                AlertToast.Show(Lang.L("NEXUS · Memória cheia"), Lang.L("RAM a " + Math.Round(ram) + "% (limite " + AppSettings.AlertRam + "%)."));
            }
        }

        [DllImport("user32.dll")] static extern bool DestroyIcon(IntPtr h);
        static IntPtr lastIconHandle = IntPtr.Zero, pendingDestroy = IntPtr.Zero;

        // desenha o losango NEXUS com as cores do tema
        public static Icon MakeTrayIcon(Color bg, Color c1)
        {
            int S = 32;
            using (Bitmap bmp = new Bitmap(S, S, System.Drawing.Imaging.PixelFormat.Format32bppArgb))
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                g.Clear(Color.Transparent);
                using (System.Drawing.Drawing2D.GraphicsPath rr = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    int r = 8;
                    rr.AddArc(0, 0, r, r, 180, 90); rr.AddArc(S - 1 - r, 0, r, r, 270, 90);
                    rr.AddArc(S - 1 - r, S - 1 - r, r, r, 0, 90); rr.AddArc(0, S - 1 - r, r, r, 90, 90);
                    rr.CloseFigure();
                    using (SolidBrush b = new SolidBrush(bg)) g.FillPath(b, rr);
                }
                PointF[] outer = { new PointF(16, 4), new PointF(28, 16), new PointF(16, 28), new PointF(4, 16) };
                PointF[] inner = { new PointF(16, 11.5f), new PointF(20.5f, 16), new PointF(16, 20.5f), new PointF(11.5f, 16) };
                using (Pen pen = new Pen(c1, 2.6f)) g.DrawPolygon(pen, outer);
                using (SolidBrush b = new SolidBrush(c1)) g.FillPolygon(b, inner);
                // o handle fica vivo enquanto o ícone for usado; o anterior é libertado na troca de tema
                IntPtr h = bmp.GetHicon();
                if (lastIconHandle != IntPtr.Zero) { IntPtr prev = lastIconHandle; lastIconHandle = h; pendingDestroy = prev; }
                else lastIconHandle = h;
                return Icon.FromHandle(h);
            }
        }

        public static void ApplyTrayTheme()
        {
            try
            {
                invoker.BeginInvoke(new MethodInvoker(delegate
                {
                    try
                    {
                        if (tray == null) return;
                        Icon old = tray.Icon;
                        tray.Icon = MakeTrayIcon(AppSettings.ThemeColor("bg"), AppSettings.ThemeColor("c1"));
                        if (old != null) old.Dispose();
                        if (pendingDestroy != IntPtr.Zero) { DestroyIcon(pendingDestroy); pendingDestroy = IntPtr.Zero; }
                    }
                    catch { }
                }));
            }
            catch { }
        }

        public static void Notify(string title, string text)
        {
            try
            {
                invoker.BeginInvoke(new MethodInvoker(delegate
                {
                    title = Lang.L(title); text = Lang.L(text) ?? "";
                    try { if (tray != null) tray.ShowBalloonTip(6000, title, text.Length > 250 ? text.Substring(0, 247) + "..." : text, ToolTipIcon.Info); } catch { }
                    try { Ntfy.Send(title, text); } catch { }
                }));
            }
            catch { }
        }

        // ------------------------------------------------------------ menu do ícone (botão direito)
        // cores do menu vêm do tema atual (mudam logo quando trocas de tema)
        static Color MenuFg { get { return AppSettings.ThemeColor("txt"); } }
        static Color MenuDim { get { return AppSettings.ThemeColor("dim"); } }

        static ToolStripMenuItem Item(string text, Action click, bool bold)
        {
            ToolStripMenuItem it = new ToolStripMenuItem(Lang.L(text));
            it.Font = new Font("Segoe UI", 9.5f, bold ? FontStyle.Bold : FontStyle.Regular);
            it.ForeColor = MenuFg;
            it.Padding = new Padding(4, 3, 4, 3);
            if (click != null) it.Click += delegate { try { click(); } catch { } };
            return it;
        }

        static ToolStripMenuItem Toggle(string text, bool on, string key)
        {
            ToolStripMenuItem it = Item(text, null, false);
            it.Checked = on;
            it.Tag = "toggle";
            it.Click += delegate
            {
                string q = "/api/settings?" + key + "=" + (on ? "0" : "1");
                ThreadPool.QueueUserWorkItem(delegate
                {
                    string msg = null;
                    try { msg = AppSettings.Update(q); } catch (Exception ex) { msg = ex.Message; }
                    if (msg != null && msg.Length > 0) Notify("NEXUS · Definições", msg);
                });
            };
            return it;
        }

        static ToolStripLabel Info(string text, Color c)
        {
            ToolStripLabel l = new ToolStripLabel(Lang.L(text));
            l.Font = new Font("Consolas", 9f);
            l.ForeColor = c;
            l.Padding = new Padding(4, 1, 4, 1);
            return l;
        }

        static void Recolor(ToolStripItemCollection items)
        {
            foreach (ToolStripItem it in items)
            {
                if (it is ToolStripLabel) it.ForeColor = it.Font.Bold ? AppSettings.ThemeColor("c1") : (it.ForeColor == AppSettings.ThemeColor("ok") ? it.ForeColor : MenuDim);
                else if (it.Text == Lang.L("Sair")) it.ForeColor = AppSettings.ThemeColor("crit");
                else it.ForeColor = MenuFg;
                ToolStripMenuItem mi = it as ToolStripMenuItem;
                if (mi != null && mi.HasDropDownItems) { Recolor(mi.DropDownItems); mi.DropDown.Invalidate(); }
            }
        }

        static void BuildMenu(ContextMenuStrip menu)
        {
            menu.SuspendLayout();
            menu.Items.Clear();
            Color c1 = AppSettings.ThemeColor("c1");

            ToolStripLabel title = new ToolStripLabel("NEXUS // MONITOR");
            title.Font = new Font("Consolas", 9.5f, FontStyle.Bold);
            title.ForeColor = c1;
            title.Padding = new Padding(4, 4, 4, 2);
            menu.Items.Add(title);

            // informação mais importante do PC
            foreach (string line in Stats.MenuLines()) menu.Items.Add(Info(line, line.StartsWith(Lang.L("JOGO")) ? AppSettings.ThemeColor("ok") : MenuDim));
            menu.Items.Add(new ToolStripSeparator());

            menu.Items.Add(Item("Abrir o monitor", OpenMonitor, true));
            menu.Items.Add(Item("Deep Scan (analisador de disco)", delegate { OpenUrl(URL + "disk"); }, false));
            menu.Items.Add(Item("Otimizar (jogos e Windows)", delegate { OpenUrl(URL + "perf#otim"); }, false));
            menu.Items.Add(Item("Testar comando", delegate { OpenUrl(URL + "perf#comando"); }, false));
            menu.Items.Add(Item("Limpar a RAM agora", delegate
            {
                ThreadPool.QueueUserWorkItem(delegate
                {
                    string j; try { j = Optimizer.Clean(false); } catch { return; }
                    System.Text.RegularExpressions.Match m = System.Text.RegularExpressions.Regex.Match(j, "\"message\":\"([^\"]*)\"");
                    Notify("NEXUS · RAM limpa", m.Success ? m.Groups[1].Value : "Feito.");
                });
            }, false));
            menu.Items.Add(new ToolStripSeparator());

            // opções que se podem ligar/desligar aqui mesmo
            menu.Items.Add(Toggle("Iniciar com o Windows", AppSettings.AutoStart, "autostart"));
            menu.Items.Add(Toggle("Iniciar minimizado", AppSettings.Minimized, "minimized"));
            if (FullMode) menu.Items.Add(Toggle("Abrir como administrador sem aviso", AppSettings.NoPrompt, "noprompt"));
            menu.Items.Add(Toggle("Alertas (CPU " + AppSettings.AlertCpu + "° · GPU " + AppSettings.AlertGpu + "° · RAM " + AppSettings.AlertRam + "%)", AppSettings.Alerts, "alerts"));
            menu.Items.Add(Toggle("Limpar a RAM acima de " + AppSettings.RamCleanPct + "%", AppSettings.RamClean, "ramclean"));
            menu.Items.Add(Toggle("Deteção de jogo", AppSettings.GameMode, "gamemode"));
            menu.Items.Add(Toggle("Overlay em jogo", AppSettings.OverlayOn, "overlay"));
            menu.Items.Add(Toggle("Acesso pelo telemóvel", AppSettings.Remote, "remote"));

            ToolStripMenuItem tema = Item("Tema", null, false);
            tema.DropDown.Renderer = new DarkRenderer();
            ((ToolStripDropDownMenu)tema.DropDown).ShowImageMargin = false;
            ((ToolStripDropDownMenu)tema.DropDown).ShowCheckMargin = true;
            string cur = AppSettings.UiTheme();
            foreach (string[] t in AppSettings.Themes)
            {
                string key = t[0];
                ToolStripMenuItem ti = Item(t[1], delegate { AppSettings.ApplyNamedTheme(key); ApplyTrayTheme(); }, false);
                ti.Checked = key == cur;
                ti.Tag = "toggle";
                tema.DropDownItems.Add(ti);
            }
            menu.Items.Add(tema);

            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add(Item("Desinstalar o NEXUS…", delegate
            {
                if (MessageBox.Show(Lang.L("Abrir o desinstalador do NEXUS? Ele mostra o que vai ser removido e pergunta antes de apagar."), "NEXUS Monitor", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
                string r = StartUninstaller();
                if (r.Contains("\"ok\":false")) MessageBox.Show(Lang.L("Não encontrei o desinstalador na pasta do NEXUS."), "NEXUS Monitor", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }, false));
            ToolStripMenuItem quit = Item("Sair", Quit, false);
            quit.ForeColor = AppSettings.ThemeColor("crit");
            menu.Items.Add(quit);
            menu.ResumeLayout();
        }

        // ------------------------------------------------------------ desinstalar a partir do NEXUS
        // corre o UNINSTALL NEXUS.bat da pasta instalada numa consola à vista (herda o administrador do NEXUS)
        public static string StartUninstaller()
        {
            try
            {
                string dir = AppDomain.CurrentDomain.BaseDirectory.TrimEnd('\\');
                string bat = Path.Combine(dir, "UNINSTALL NEXUS.bat");
                if (!File.Exists(bat)) bat = Path.Combine(dir, "DESINSTALAR NEXUS.bat");
                if (!File.Exists(bat)) return "{\"ok\":false,\"error\":" + Js.S(Lang.L("Não encontrei o desinstalador na pasta do NEXUS.")) + "}";
                ProcessStartInfo p = new ProcessStartInfo("cmd.exe", "/c \"\"" + bat + "\"\"");
                p.WorkingDirectory = dir; p.UseShellExecute = true; p.WindowStyle = ProcessWindowStyle.Normal;
                Process.Start(p);
                return "{\"ok\":true}";
            }
            catch (Exception e) { return "{\"ok\":false,\"error\":" + Js.S(e.Message) + "}"; }
        }

        // ------------------------------------------------------------ abrir o monitor sem repetir páginas
        [DllImport("user32.dll")] static extern bool EnumWindows(EnumWinProc cb, IntPtr lp);
        delegate bool EnumWinProc(IntPtr h, IntPtr lp);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetWindowText(IntPtr h, StringBuilder sb, int max);
        [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
        [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
        [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr h, int cmd);
        [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr h);
        [DllImport("user32.dll")] static extern bool AllowSetForegroundWindow(int pid);

        static DateTime lastPagePing = DateTime.MinValue;
        public static void PagePing() { lastPagePing = DateTime.UtcNow; }
        public static void PageBye() { lastPagePing = DateTime.MinValue; }

        static IntPtr FindMonitorWindow()
        {
            IntPtr found = IntPtr.Zero;
            EnumWindows((h, lp) =>
            {
                if (!IsWindowVisible(h)) return true;
                StringBuilder sb = new StringBuilder(256);
                GetWindowText(h, sb, 256);
                if (sb.ToString().IndexOf("NEXUS // System Monitor", StringComparison.Ordinal) >= 0) { found = h; return false; }
                return true;
            }, IntPtr.Zero);
            return found;
        }

        public static void OpenMonitor()
        {
            IntPtr w = FindMonitorWindow();
            if (w != IntPtr.Zero)
            {
                if (IsIconic(w)) ShowWindow(w, 9);   // SW_RESTORE
                SetForegroundWindow(w);
                return;
            }
            // a página está aberta mas num separador escondido: não abre outra
            if ((DateTime.UtcNow - lastPagePing).TotalSeconds < 9)
            {
                Notify("NEXUS já está aberto", "Está noutro separador do browser.");
                return;
            }
            OpenUrl(URL);
        }

        // abriram o NEXUS outra vez: pede à cópia que já está a correr para mostrar o monitor
        static void AskRunningToShow()
        {
            try
            {
                AllowSetForegroundWindow(-1);
                HttpWebRequest req = (HttpWebRequest)WebRequest.Create("http://127.0.0.1:" + PORT + "/api/show");
                req.Method = "POST"; req.Timeout = 3000; req.Proxy = null; req.ContentLength = 0;
                using (WebResponse r = req.GetResponse()) { }
            }
            catch { OpenUrl(URL); }
        }

        public static void RequestQuit()
        {
            try { invoker.BeginInvoke(new MethodInvoker(Quit)); }
            catch { Environment.Exit(0); }
        }

        static void Quit()
        {
            try { if (tray != null) { tray.Visible = false; tray.Dispose(); } } catch { }
            try { Ventoinhas.Shutdown(); } catch { }     // as ventoinhas voltam ao controlo da BIOS
            try { EtwNet.Stop(); if (Rota.Active) Rota.Off("o NEXUS fechou"); } catch { }   // a rota da Cloudflare não fica ligada sem o NEXUS
            try { Macros.Quit(); Aparelhos.GameEnd(); } catch { }   // nada de macros a correr nem DPI de jogo depois de fechar
            if (FullMode) { try { Embedded.Shutdown(); } catch { } }
            quitting = true;
            try { PresentMonReader.Stop(); } catch { }
            try { Stats.StopGpu(); } catch { }
            try { DiskScan.Stop(); } catch { }
            try { Optimizer.ResumeAll(false); } catch { }
            try { Tweaks.OnGame(false, null); } catch { }
            try { Perfis.Stop(); } catch { }        // já, sem esperar: as otimizações do perfil não podem ficar ligadas
            try { Historico.Shutdown(); } catch { }
            try { if (Stress.Running) Stress.Stop(); } catch { }
            try { Discord.Stop(); } catch { }
            try { NaoIncomodar.Restore(); } catch { }
            try { listener.Stop(); } catch { }
            Application.Exit();
        }

        public static void OpenUrl(string u)
        {
            try
            {
                if (IsAdmin()) Process.Start("explorer.exe", "\"" + u + "\"");   // abre no browser normal, sem admin
                else Process.Start(u);
            }
            catch { try { Process.Start(u); } catch { } }
        }

        public static string QueryValue(string path, string key)
        {
            int qi = path.IndexOf('?');
            if (qi < 0) return null;
            foreach (string part in path.Substring(qi + 1).Split('&'))
            {
                string[] kv = part.Split('=');
                if (kv.Length == 2 && kv[0] == key) return Uri.UnescapeDataString(kv[1]);
            }
            return null;
        }

        static string CookieValue(string cookie, string key)
        {
            foreach (string part in cookie.Split(';'))
            {
                string t = part.Trim();
                if (t.StartsWith(key + "=")) return t.Substring(key.Length + 1);
            }
            return null;
        }

        static string DeniedPage(string msg)
        {
            return "<!DOCTYPE html><html lang=pt><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'>" +
                   "<title>NEXUS</title><body style='margin:0;min-height:100vh;display:grid;place-items:center;background:#05070d;color:#d4e8ff;" +
                   "font:14px ui-monospace,Consolas,monospace;text-align:center;padding:24px;box-sizing:border-box'><div>" +
                   "<div style='color:#3ee8ff;letter-spacing:.3em;font-size:18px;margin-bottom:14px'>NEXUS // MONITOR</div>" +
                   "<div style='color:#ff4e6a;margin-bottom:10px'>ACESSO NEGADO</div><div style='color:#8aa0b8;line-height:1.6;max-width:420px'>" +
                   System.Net.WebUtility.HtmlEncode(msg) + "</div></div>" +
                   "<script>try{var k=localStorage.getItem('nexus_k');if(k&&!sessionStorage.getItem('nx_retry')){sessionStorage.setItem('nx_retry','1');" +
                   "location.replace('/?k='+encodeURIComponent(k)+'&r='+encodeURIComponent(location.pathname));}}catch(e){}</script></body></html>";
        }

        // manda um ficheiro grande aos bocados (sem o carregar todo para a memória), com suporte de "Range" para os vídeos
        static void SendFile(NetworkStream ns, string file, string range, bool download)
        {
            using (FileStream fs = new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
            {
                long len = fs.Length, start = 0, end = len - 1; bool part = false;
                System.Text.RegularExpressions.Match m = range == null ? System.Text.RegularExpressions.Match.Empty : System.Text.RegularExpressions.Regex.Match(range, @"bytes=(\d*)-(\d*)");
                if (m.Success && (m.Groups[1].Value != "" || m.Groups[2].Value != ""))
                {
                    if (m.Groups[1].Value == "") { long n = long.Parse(m.Groups[2].Value); start = Math.Max(0, len - n); }
                    else { start = long.Parse(m.Groups[1].Value); if (m.Groups[2].Value != "") end = Math.Min(len - 1, long.Parse(m.Groups[2].Value)); }
                    part = start < len && start <= end;
                    if (!part) { byte[] eh = Encoding.ASCII.GetBytes("HTTP/1.1 416 Range Not Satisfiable\r\nContent-Range: bytes */" + len + "\r\nContent-Length: 0\r\nConnection: close\r\n\r\n"); ns.Write(eh, 0, eh.Length); return; }
                }
                string ext = Path.GetExtension(file).ToLowerInvariant();
                string ct = ext == ".mp4" ? "video/mp4" : ext == ".webm" ? "video/webm" : ext == ".mkv" ? "video/x-matroska" : ext == ".mov" ? "video/quicktime" : ext == ".avi" ? "video/x-msvideo" :
                            ext == ".png" ? "image/png" : ext == ".webp" ? "image/webp" : ext == ".bmp" ? "image/bmp" : ext == ".jpg" || ext == ".jpeg" ? "image/jpeg" : "application/octet-stream";
                string fn = System.Text.RegularExpressions.Regex.Replace(Path.GetFileName(file), "[^A-Za-z0-9 ._()-]", "_");
                string head = "HTTP/1.1 " + (part ? "206 Partial Content" : "200 OK") + "\r\nContent-Type: " + ct + "\r\nAccept-Ranges: bytes\r\nContent-Length: " + (end - start + 1) + "\r\n" +
                              (part ? "Content-Range: bytes " + start + "-" + end + "/" + len + "\r\n" : "") +
                              (download ? "Content-Disposition: attachment; filename=\"" + fn + "\"\r\n" : "") + "Cache-Control: no-store\r\nConnection: close\r\n\r\n";
                byte[] hb = Encoding.ASCII.GetBytes(head); ns.Write(hb, 0, hb.Length);
                fs.Position = start;
                byte[] buf = new byte[128 * 1024]; long left = end - start + 1;
                while (left > 0) { int n = fs.Read(buf, 0, (int)Math.Min(buf.Length, left)); if (n <= 0) break; ns.Write(buf, 0, n); left -= n; }
                ns.Flush();
            }
        }

        static void Handle(object o)
        {
            TcpClient client = (TcpClient)o;
            try
            {
                client.ReceiveTimeout = 5000;
                NetworkStream ns = client.GetStream();
                StreamReader reader = new StreamReader(ns, Encoding.ASCII);
                string line = reader.ReadLine();
                if (line == null) return;
                string h, origin = null, host = null, cookie = "", inm = null, range = null;
                int reqLen = 0;
                while (!string.IsNullOrEmpty(h = reader.ReadLine()))
                {
                    if (h.StartsWith("Origin:", StringComparison.OrdinalIgnoreCase)) origin = h.Substring(7).Trim();
                    else if (h.StartsWith("Host:", StringComparison.OrdinalIgnoreCase)) host = h.Substring(5).Trim();
                    else if (h.StartsWith("Cookie:", StringComparison.OrdinalIgnoreCase)) cookie = h.Substring(7).Trim();
                    else if (h.StartsWith("If-None-Match:", StringComparison.OrdinalIgnoreCase)) inm = h.Substring(14).Trim();
                    else if (h.StartsWith("Range:", StringComparison.OrdinalIgnoreCase)) range = h.Substring(6).Trim();
                    else if (h.StartsWith("Content-Length:", StringComparison.OrdinalIgnoreCase)) int.TryParse(h.Substring(15).Trim(), out reqLen);
                }
                bool sameOrigin = origin == null || origin == "http://localhost:" + PORT || origin == "http://127.0.0.1:" + PORT ||
                                  (host != null && origin == "http://" + host);

                // corpo do pedido (só texto ASCII, ex.: a importação manda base64), até 8 MB
                string reqBody = null;
                if (reqLen > 0 && reqLen <= 8 * 1024 * 1024)
                {
                    char[] rbuf = new char[reqLen]; int rgot = 0;
                    while (rgot < reqLen) { int rn = reader.Read(rbuf, rgot, reqLen - rgot); if (rn <= 0) break; rgot += rn; }
                    reqBody = new string(rbuf, 0, rgot);
                }
                string[] parts = line.Split(' ');
                string method = parts[0];
                string path = parts.Length > 1 ? parts[1] : "/";
                byte[] body = null;
                string ctype = "text/plain";
                int status = 200;
                bool exit = false;
                string extraHeaders = "";
                bool cacheable = false;   // página ou script fixo (pode ficar guardado no browser)

                // ligações vindas da rede (telemóvel): precisam do acesso remoto ligado e do código
                bool remote = false;
                try { remote = !IPAddress.IsLoopback(((IPEndPoint)client.Client.RemoteEndPoint).Address); } catch { }
                bool denied = false;
                // o manifesto e os ícones da app do telemóvel não têm nada privado (o ecrã principal pede-os sem o código)
                bool pubFile = path == "/manifest.webmanifest" || path.StartsWith("/nexus-icon-");
                string rip0 = ""; try { rip0 = ((IPEndPoint)client.Client.RemoteEndPoint).Address.ToString(); } catch { }
                bool syncGet = remote && method == "GET" && path.StartsWith("/api/x/sync/get?");
                // pedidos deste PC só com o nome certo no endereço: impede que um site malicioso (truque de "DNS rebinding")
                // fale com o NEXUS fingindo ser outro nome que aponta para 127.0.0.1
                string hn = (host ?? "").ToLowerInvariant();
                bool hostOk = hn == "localhost:" + PORT || hn == "127.0.0.1:" + PORT || hn == "[::1]:" + PORT || hn == "localhost" || hn == "127.0.0.1";
                if (!remote && !hostOk)
                {
                    denied = true; status = 403; ctype = "text/plain"; body = Encoding.UTF8.GetBytes("403");
                }
                else if (syncGet)
                {
                    // outro PC da casa a copiar as definições: vale o código de 6 números (uma vez, 5 minutos)
                    denied = true; ctype = "application/json";
                    body = Encoding.UTF8.GetBytes(Ferr.SyncGet(QueryValue(path, "code") ?? "", rip0));
                }
                else if (remote && !pubFile && AppSettings.Remote && !AppSettings.TokenMatches(CookieValue(cookie, "nexus_k") ?? "") && (Ferr.ViewMatches(QueryValue(path, "v")) || Ferr.ViewMatches(CookieValue(cookie, "nexus_v"))))
                {
                    // modo só de leitura: vê o painel ao vivo, não mexe em nada
                    string qv = QueryValue(path, "v");
                    if (qv != null)
                    {
                        denied = true; status = 302; body = new byte[0];
                        extraHeaders = "Location: /?view=1\r\nSet-Cookie: nexus_v=" + Ferr.ViewToken + "; Path=/; Max-Age=2592000; SameSite=Lax; HttpOnly\r\n";
                    }
                    else if (!Ferr.ViewAllowed(method, path))
                    {
                        denied = true; status = 403; ctype = "application/json";
                        body = Encoding.UTF8.GetBytes("{\"ok\":false,\"error\":\"view_only\"}");
                    }
                }
                else if (remote && !pubFile)
                {
                    string qk = QueryValue(path, "k");
                    string ck = CookieValue(cookie, "nexus_k");
                    if (!AppSettings.Remote)
                    {
                        denied = true; status = 403;
                        body = Encoding.UTF8.GetBytes(DeniedPage("O acesso pelo telemóvel está desligado no NEXUS do PC."));
                        ctype = "text/html; charset=utf-8";
                    }
                    else if (qk != null && AppSettings.TokenMatches(qk))
                    {
                        denied = true; status = 302; body = new byte[0];
                        string rq = QueryValue(path, "r"); string back = rq == "/disk" ? "/disk" : rq == "/pad" ? "/pad" : rq == "/perf" ? "/perf" : "/";
                        extraHeaders = "Location: " + back + "#nk=" + AppSettings.Token + "\r\nSet-Cookie: nexus_k=" + AppSettings.Token + "; Path=/; Max-Age=315360000; SameSite=Lax; HttpOnly\r\n";
                    }
                    else if (ck == null || !AppSettings.TokenMatches(ck))
                    {
                        denied = true; status = 401;
                        body = Encoding.UTF8.GetBytes(DeniedPage("Código em falta ou errado. Abre o link ou o QR code que aparece em DEFINIÇÕES → TELEMÓVEL E REMOTO, no PC."));
                        ctype = "text/html; charset=utf-8";
                    }
                }
                else body = null;

                if (denied) { }
                else if (method == "POST" && !sameOrigin)
                {
                    status = 404; body = Encoding.UTF8.GetBytes("404");
                }
                else if (remote && method == "POST" && path.StartsWith("/api/settings") &&
                         (QueryValue(path, "remote") != null || QueryValue(path, "newtoken") != null || QueryValue(path, "showhidden") != null ||
                          QueryValue(path, "remotectl") != null || QueryValue(path, "upcheck") != null || QueryValue(path, "discord_id") != null ||
                          QueryValue(path, "ntfy_topic") != null || QueryValue(path, "ntfy_server") != null))
                {
                    status = 200; ctype = "application/json";
                    body = Encoding.UTF8.GetBytes(AppSettings.Json(QueryValue(path, "showhidden") != null ? "Os ficheiros ocultos só se mostram a partir do PC." : "O acesso pelo telemóvel só se muda no PC.", false));
                }
                else if (method == "POST" && path.StartsWith("/api/settings"))
                {
                    string msg = AppSettings.Update(path);
                    body = Encoding.UTF8.GetBytes(AppSettings.Json(msg, !remote));
                    ctype = "application/json";
                }
                else if (method == "POST" && path.StartsWith("/api/ui"))
                {
                    AppSettings.SetUi(QueryValue(path, "d"));
                    body = Encoding.UTF8.GetBytes(AppSettings.UiJson());
                    ctype = "application/json";
                }
                else if (path.StartsWith("/api/ping"))
                {
                    if (!remote) PagePing();
                    status = 204; body = new byte[0];
                }
                else if (method == "POST" && path.StartsWith("/api/bye"))
                {
                    if (!remote) PageBye();
                    status = 204; body = new byte[0];
                }
                else if (method == "POST" && path.StartsWith("/api/show"))
                {
                    if (!remote) try { invoker.BeginInvoke(new MethodInvoker(OpenMonitor)); } catch { }
                    status = 204; body = new byte[0];
                }
                else if (method == "GET" && path.StartsWith("/api/procs"))
                {
                    body = Encoding.UTF8.GetBytes(Optimizer.ProcsJson());
                    ctype = "application/json";
                }
                else if (method == "POST" && path.StartsWith("/api/ramclean"))
                {
                    body = Encoding.UTF8.GetBytes(Optimizer.Clean(false));
                    ctype = "application/json";
                }
                else if (method == "GET" && path.StartsWith("/api/ui"))
                {
                    body = Encoding.UTF8.GetBytes(AppSettings.UiJson());
                    ctype = "application/json";
                }
                else if (method == "POST" && path.StartsWith("/api/theme"))
                {
                    AppSettings.SetTheme(path);
                    ApplyTrayTheme();
                    status = 204; body = new byte[0];
                }
                else if (method == "GET" && path.StartsWith("/api/settings"))
                {
                    body = Encoding.UTF8.GetBytes(AppSettings.Json(null, !remote));
                    ctype = "application/json";
                }
                else if (method == "POST" && path == "/api/uninstall")
                {
                    // abre o desinstalador do NEXUS (faz as perguntas dele e fecha o NEXUS no fim). Só no próprio PC.
                    ctype = "application/json";
                    body = Encoding.UTF8.GetBytes(remote ? "{\"ok\":false}" : Program.StartUninstaller());
                }
                else if (method == "POST" && path == "/api/shutdown")
                {
                    // fechar o NEXUS: só no próprio PC (do telemóvel não havia maneira de o voltar a abrir)
                    if (remote) { status = 403; body = Encoding.UTF8.GetBytes("{\"ok\":false,\"error\":\"pc_only\"}"); ctype = "application/json"; }
                    else { status = 204; body = new byte[0]; exit = true; }
                }
                else if (method == "GET" && path.StartsWith("/api/stats"))
                {
                    if (QueryValue(path, "nogpu") != "1") Stats.WantGpu();
                    if (QueryValue(path, "deck") == "1") RgbSync.Watch();      // teclas do NEXUS à vista na Stream Deck
                    else Stats.WantProcs();                                     // uma página: precisa da lista de processos
                    body = Encoding.UTF8.GetBytes(Stats.CollectCached());
                    ctype = "application/json";
                }
                else if (method == "GET" && path.StartsWith("/api/report"))
                {
                    body = Encoding.UTF8.GetBytes(Program.FullMode ? Embedded.Report() : "modo normal");
                    ctype = "text/plain; charset=utf-8";
                }
                else if (method == "GET" && (path == "/" || path.StartsWith("/?") || path == "/index.html" || path.StartsWith("/index.html?")))
                {
                    body = Static("index", html); cacheable = true;
                    ctype = "text/html; charset=utf-8";
                }
                else if (method == "POST" && path.StartsWith("/api/alert/preview") && !remote)
                {
                    int op; if (!int.TryParse(QueryValue(path, "op") ?? "", out op)) op = 80;
                    bool game = QueryValue(path, "game") == "1";
                    op = Math.Max(15, Math.Min(100, op));
                    try { invoker.BeginInvoke(new MethodInvoker(delegate { AlertToast.Preview(game, op); })); } catch { }
                    ctype = "application/json"; body = Encoding.UTF8.GetBytes("{\"ok\":true}");
                }
                else if (method == "GET" && path == "/shell.js")
                {
                    body = Static("shell", shellJs); cacheable = true;
                    ctype = "application/javascript; charset=utf-8";
                }
                else if (method == "GET" && path == "/tour.js")
                {
                    body = Static("tour", tourJs ?? "window.NXTOUR={start:function(){},end:function(){},resume:function(){}};"); cacheable = true;
                    ctype = "application/javascript; charset=utf-8";
                }
                else if (method == "GET" && path == "/i18n.js")
                {
                    body = Static("i18n", i18nJs ?? "window.NX={lang:'pt',T:function(s){return s},menu:function(){},set:function(){}};"); cacheable = true;
                    ctype = "application/javascript; charset=utf-8";
                }
                else if (method == "POST" && path.StartsWith("/api/lang") && !remote)
                {
                    AppSettings.Lang = Lang.Pick(QueryValue(path, "l"));
                    try { AppSettings.Save(); } catch { }
                    ctype = "application/json"; body = Encoding.UTF8.GetBytes("{\"ok\":true,\"lang\":\"" + Lang.Current + "\"}");
                }
                else if (method == "GET" && (path == "/pad" || path.StartsWith("/pad?") || path == "/pad.html"))
                {
                    body = Static("pad", padHtml); cacheable = true;
                    ctype = "text/html; charset=utf-8";
                }
                else if (method == "GET" && (path == "/perf" || path.StartsWith("/perf?") || path == "/perf.html"))
                {
                    body = Static("perf", perfHtml); cacheable = true;
                    ctype = "text/html; charset=utf-8";
                }
                else if (method == "GET" && (path == "/disk" || path.StartsWith("/disk?") || path == "/disk.html"))
                {
                    body = Static("disk", diskHtml); cacheable = true;
                    ctype = "text/html; charset=utf-8";
                }
                else if (path.StartsWith("/api/rgb"))
                {
                    RgbSync.Watch();
                    ctype = "application/json";
                    body = Encoding.UTF8.GetBytes(RgbSync.Json());
                }
                else if (path.StartsWith("/api/speedtest"))
                {
                    ctype = "application/json";
                    string act = path.StartsWith("/api/speedtest/start") ? "start" : path.StartsWith("/api/speedtest/stop") ? "stop" : "";
                    if (act != "" && method != "POST") { status = 405; body = Encoding.UTF8.GetBytes("{\"ok\":false}"); }
                    else
                    {
                        if (act == "start") SpeedTest.Start();
                        else if (act == "stop") SpeedTest.Stop();
                        body = Encoding.UTF8.GetBytes(SpeedTest.Json());
                    }
                }
                else if (path.StartsWith("/api/folder"))
                {
                    // DEFINIÇÕES > GERAL > PASTAS: abre no Explorador a pasta das definições ou a pasta onde o NEXUS está instalado (só no PC)
                    ctype = "application/json";
                    if (remote || method != "POST") { status = 403; body = Encoding.UTF8.GetBytes("{\"ok\":false,\"error\":\"pc_only\"}"); }
                    else
                    {
                        string which = QueryValue(path, "f");
                        string dir = which == "settings" ? AppSettings.Dir : AppDomain.CurrentDomain.BaseDirectory.TrimEnd('\\');
                        bool ok = false;
                        try { Directory.CreateDirectory(dir); Front.Explorer("\"" + dir + "\""); ok = true; } catch { }
                        body = Encoding.UTF8.GetBytes("{\"ok\":" + (ok ? "true" : "false") + "}");
                    }
                }
                else if (path.StartsWith("/api/pad/rumble"))
                {
                    ctype = "application/json";
                    if (remote || method != "POST") { status = 403; body = Encoding.UTF8.GetBytes("{\"ok\":false,\"error\":\"pc_only\"}"); }
                    else
                    {
                        double w = 0, st2 = 0; int ms = 0;
                        double.TryParse(QueryValue(path, "weak"), NumberStyles.Float, CultureInfo.InvariantCulture, out w);
                        double.TryParse(QueryValue(path, "strong"), NumberStyles.Float, CultureInfo.InvariantCulture, out st2);
                        int.TryParse(QueryValue(path, "ms"), out ms);
                        string r;
                        try { r = PadRumble.Rumble(w, st2, ms, QueryValue(path, "vid"), QueryValue(path, "pid"), QueryValue(path, "x") == "1"); }
                        catch (Exception ex) { r = "{\"ok\":false,\"error\":\"" + ex.GetType().Name + "\"}"; }
                        body = Encoding.UTF8.GetBytes(r);
                    }
                }
                else if (path.StartsWith("/api/clean/"))
                {
                    ctype = "application/json";
                    string what = path.Substring(11).Split('?')[0];
                    if (remote) { status = 403; body = Encoding.UTF8.GetBytes("{\"ok\":false,\"error\":\"pc_only\"}"); }
                    else if (what == "scan") body = Encoding.UTF8.GetBytes(Cleaner.ScanJson());
                    else if (method == "POST" && what == "run") body = Encoding.UTF8.GetBytes(Cleaner.Run(QueryValue(path, "ids")));
                    else { status = 404; body = Encoding.UTF8.GetBytes("{}"); }
                }
                else if (path == "/api/perf" || path.StartsWith("/api/perf/") || path.StartsWith("/api/perf?"))
                {
                    // página Performance: ler pode ser do telemóvel; mudar só no próprio PC
                    ctype = "application/json";
                    string what = path.Length > 10 ? path.Substring(10).Split('?')[0] : "";
                    bool write = what != "" && what != "apps";
                    if (remote && write) { status = 403; body = Encoding.UTF8.GetBytes("{\"ok\":false,\"error\":\"pc_only\"}"); }
                    else if (write && method != "POST") { status = 405; body = Encoding.UTF8.GetBytes("{\"ok\":false}"); }
                    else if (what == "") body = Encoding.UTF8.GetBytes(Tweaks.Json());
                    else if (what == "apps") body = Encoding.UTF8.GetBytes(remote ? "{\"ok\":true,\"apps\":[]}" : Tweaks.AppsJson());
                    else if (what == "set") body = Encoding.UTF8.GetBytes(Tweaks.SetJson(QueryValue(path, "id") ?? "", QueryValue(path, "on") == "1"));
                    else if (what == "recommended") { try { Tweaks.AutoRestorePoint(); } catch { } body = Encoding.UTF8.GetBytes(Tweaks.Bulk(true, QueryValue(path, "ids"))); }
                    else if (what == "revertall") body = Encoding.UTF8.GetBytes(Tweaks.Bulk(false, QueryValue(path, "ids")));
                    else if (what == "restorepoint") body = Encoding.UTF8.GetBytes(Tweaks.RestorePoint());
                    else if (what == "removeapps") { try { Tweaks.AutoRestorePoint(); } catch { } body = Encoding.UTF8.GetBytes(Tweaks.RemoveApps(QueryValue(path, "names"))); }
                    else { status = 404; body = Encoding.UTF8.GetBytes("{\"ok\":false}"); }
                }
                else if (path == "/api/profiles" || path.StartsWith("/api/profiles/") || path.StartsWith("/api/profiles?"))
                {
                    // perfis por jogo: ver pode ser do telemóvel; mudar só no próprio PC
                    ctype = "application/json";
                    string what = path.Substring(13).Split('?')[0].TrimStart('/');
                    if (what == "") body = Encoding.UTF8.GetBytes(Perfis.Json());
                    else if (remote) { status = 403; body = Encoding.UTF8.GetBytes("{\"ok\":false,\"error\":\"pc_only\"}"); }
                    else if (method != "POST") { status = 405; body = Encoding.UTF8.GetBytes("{\"ok\":false}"); }
                    else if (what == "save") body = Encoding.UTF8.GetBytes(Perfis.SaveQ(QueryValue(path, "exe"), QueryValue(path, "overlay"), QueryValue(path, "prio"), QueryValue(path, "power"), QueryValue(path, "ram"), QueryValue(path, "tweaks"), QueryValue(path, "fps")));
                    else if (what == "delete") body = Encoding.UTF8.GetBytes(Perfis.Delete(QueryValue(path, "exe")));
                    else { status = 404; body = Encoding.UTF8.GetBytes("{\"ok\":false}"); }
                }
                else if (path == "/api/bench" || path.StartsWith("/api/bench/") || path.StartsWith("/api/bench?"))
                {
                    // medir FPS: ver pode ser do telemóvel; começar/parar/apagar só no PC
                    ctype = "application/json";
                    string what = path.Substring(10).Split('?')[0].TrimStart('/');
                    if (what == "") body = Encoding.UTF8.GetBytes(Medicao.Json());
                    else if (remote) { status = 403; body = Encoding.UTF8.GetBytes("{\"ok\":false,\"error\":\"pc_only\"}"); }
                    else if (method != "POST") { status = 405; body = Encoding.UTF8.GetBytes("{\"ok\":false}"); }
                    else if (what == "start") body = Encoding.UTF8.GetBytes(Medicao.StartJson(QueryValue(path, "secs"), QueryValue(path, "delay"), QueryValue(path, "label")));
                    else if (what == "stop") { Medicao.Stop(); body = Encoding.UTF8.GetBytes(Medicao.Json()); }
                    else if (what == "delete") body = Encoding.UTF8.GetBytes(Medicao.Delete(QueryValue(path, "id")));
                    else { status = 404; body = Encoding.UTF8.GetBytes("{\"ok\":false}"); }
                }
                else if (path == "/api/update" || path.StartsWith("/api/update?") || path.StartsWith("/api/update/"))
                {
                    ctype = "application/json";
                    if (path.StartsWith("/api/update/"))
                    {
                        if (remote || method != "POST") { status = 403; body = Encoding.UTF8.GetBytes("{\"ok\":false,\"error\":\"pc_only\"}"); }
                        else if (path.StartsWith("/api/update/check")) body = Encoding.UTF8.GetBytes(Atualizar.Check());
                        else if (path.StartsWith("/api/update/install")) body = Encoding.UTF8.GetBytes(Atualizar.Install());
                        else { status = 404; body = Encoding.UTF8.GetBytes("{\"ok\":false}"); }
                    }
                    else body = Encoding.UTF8.GetBytes(Atualizar.Json());
                }
                else if (path == "/manifest.webmanifest")
                {
                    ctype = "application/manifest+json"; body = Encoding.UTF8.GetBytes(AppTel.Manifest());
                }
                else if (path.StartsWith("/nexus-icon-"))
                {
                    ctype = "image/png"; body = AppTel.Icon(path.StartsWith("/nexus-icon-512") ? 512 : 192);
                }
                else if (path.StartsWith("/api/remote/"))
                {
                    // controlar o PC a partir do telemóvel (desligado por defeito; cada telemóvel aceite no PC uma vez)
                    ctype = "application/json";
                    string rip = ""; try { rip = ((IPEndPoint)client.Client.RemoteEndPoint).Address.ToString(); } catch { }
                    if (method != "POST") { status = 405; body = Encoding.UTF8.GetBytes("{\"ok\":false}"); }
                    else if (path.StartsWith("/api/remote/forget")) body = Encoding.UTF8.GetBytes(remote ? "{\"ok\":false}" : Controlo.Forget());
                    else body = Encoding.UTF8.GetBytes(Controlo.Do(QueryValue(path, "a") ?? "", remote, rip));
                }
                else if (method == "GET" && (path.StartsWith("/api/x/gal/vid?") || path.StartsWith("/api/x/gal/dl?")))
                {
                    // galeria: ver os clipes (com avanço) e descarregar, no PC e no telemóvel (se escolhido no PC)
                    string gp = remote && !Galeria.Phone ? null : Galeria.PathOf(QueryValue(path, "i"), QueryValue(path, "k"));
                    if (gp == null) { status = remote ? 403 : 404; body = Encoding.UTF8.GetBytes("{}"); ctype = "application/json"; }
                    else { SendFile(ns, gp, range, path.StartsWith("/api/x/gal/dl?")); return; }
                }
                else if (path.StartsWith("/api/x/"))
                {
                    // ferramentas da 2.3
                    string ripx = ""; try { ripx = ((IPEndPoint)client.Client.RemoteEndPoint).Address.ToString(); } catch { }
                    int stx; string ctx;
                    body = Api23.Handle(method, path, reqBody, remote, ripx, out stx, out ctx);
                    status = stx; ctype = ctx;
                }
                else if (path.StartsWith("/api/scenes") || path.StartsWith("/api/boot") || path.StartsWith("/api/dspeed") || path.StartsWith("/api/hwcheck") ||
                         path.StartsWith("/api/battery") || path.StartsWith("/api/dups") || path.StartsWith("/api/crashes") || path.StartsWith("/api/repair") ||
                         path.StartsWith("/api/admin") || path.StartsWith("/api/watch") || path.StartsWith("/api/peers"))
                {
                    // ver pode ser do telemóvel; mudar só no próprio PC (vigiar transferência também do telemóvel, se o controlo remoto estiver aceite)
                    ctype = "application/json";
                    string a3 = path.Split('?')[0];
                    bool w3 = a3.Count(ch => ch == '/') >= 3;
                    string rip3 = ""; try { rip3 = ((IPEndPoint)client.Client.RemoteEndPoint).Address.ToString(); } catch { }
                    bool watchOk = a3.StartsWith("/api/watch/") && (QueryValue(path, "a") == "notify" || a3 == "/api/watch/cancel" || (AppSettings.RemoteCtl && ("," + AppSettings.RemoteCtlIps + ",").Contains("," + rip3 + ",")));
                    if (w3 && (method != "POST" || (remote && !watchOk))) { status = 403; body = Encoding.UTF8.GetBytes("{\"ok\":false,\"error\":\"pc_only\"}"); }
                    else if (a3 == "/api/scenes") body = Encoding.UTF8.GetBytes(Cenarios.Json());
                    else if (a3 == "/api/scenes/apply") body = Encoding.UTF8.GetBytes(Cenarios.Apply(QueryValue(path, "id") ?? ""));
                    else if (a3 == "/api/scenes/save") body = Encoding.UTF8.GetBytes(Cenarios.Save(QueryValue(path, "name")));
                    else if (a3 == "/api/scenes/delete") body = Encoding.UTF8.GetBytes(Cenarios.Delete(QueryValue(path, "id") ?? ""));
                    else if (a3 == "/api/boot") body = Encoding.UTF8.GetBytes(Boot.Json());
                    else if (a3 == "/api/dspeed") body = Encoding.UTF8.GetBytes(DiscoVel.Json());
                    else if (a3 == "/api/dspeed/start") { int mb; int.TryParse(QueryValue(path, "mb") ?? "1024", out mb); body = Encoding.UTF8.GetBytes(DiscoVel.Start(QueryValue(path, "drive"), mb)); }
                    else if (a3 == "/api/hwcheck") body = Encoding.UTF8.GetBytes(HwCheck.Json());
                    else if (a3 == "/api/battery") body = Encoding.UTF8.GetBytes(Bateria.Json());
                    else if (a3 == "/api/dups") body = Encoding.UTF8.GetBytes(Duplicados.Json());
                    else if (a3 == "/api/dups/start") { int mn; int.TryParse(QueryValue(path, "min") ?? "1", out mn); body = Encoding.UTF8.GetBytes(Duplicados.Start(QueryValue(path, "dir"), mn)); }
                    else if (a3 == "/api/dups/delete") body = Encoding.UTF8.GetBytes(Duplicados.Delete(reqBody));
                    else if (a3 == "/api/crashes") body = Encoding.UTF8.GetBytes(Crashes.Json());
                    else if (a3 == "/api/repair") body = Encoding.UTF8.GetBytes(Reparar.Json());
                    else if (a3 == "/api/repair/start") body = Encoding.UTF8.GetBytes(Reparar.Start());
                    else if (a3 == "/api/admin") body = Encoding.UTF8.GetBytes(AdminApps.Json());
                    else if (a3 == "/api/admin/unflag") body = Encoding.UTF8.GetBytes(AdminApps.Unflag(QueryValue(path, "path") ?? "", QueryValue(path, "machine") == "1"));
                    else if (a3 == "/api/watch") body = Encoding.UTF8.GetBytes(Vigia.Json());
                    else if (a3 == "/api/watch/arm") body = Encoding.UTF8.GetBytes(Vigia.Arm(QueryValue(path, "a")));
                    else if (a3 == "/api/watch/cancel") body = Encoding.UTF8.GetBytes(Vigia.Cancel());
                    else if (a3 == "/api/peers") body = Encoding.UTF8.GetBytes(Vizinhos.Json());
                    else { status = 404; body = Encoding.UTF8.GetBytes("{\"ok\":false}"); }
                }
                else if (path.StartsWith("/api/fans") || path.StartsWith("/api/netping") || path.StartsWith("/api/dns") || path.StartsWith("/api/bios") || path.StartsWith("/api/ntfy") || path.StartsWith("/api/wol"))
                {
                    // ver pode ser do telemóvel; mudar só no próprio PC e por POST
                    ctype = "application/json";
                    string a22 = path.Split('?')[0];
                    bool w22 = a22 == "/api/fans/set" || a22 == "/api/dns/run" || a22 == "/api/dns/apply" || a22.StartsWith("/api/ntfy/") || a22 == "/api/wol/enable" || a22 == "/api/wol/wake";
                    if (w22 && (remote || method != "POST")) { status = 403; body = Encoding.UTF8.GetBytes("{\"ok\":false,\"error\":\"pc_only\"}"); }
                    else if (a22 == "/api/fans") body = Encoding.UTF8.GetBytes(Ventoinhas.Json());
                    else if (a22 == "/api/fans/set") body = Encoding.UTF8.GetBytes(Ventoinhas.Set(QueryValue(path, "id"), QueryValue(path, "mode"), QueryValue(path, "src"), QueryValue(path, "fixed"), QueryValue(path, "t"), QueryValue(path, "p")));
                    else if (a22 == "/api/netping") body = Encoding.UTF8.GetBytes(PingMon.Json());
                    else if (a22 == "/api/dns") body = Encoding.UTF8.GetBytes(DnsBench.Json());
                    else if (a22 == "/api/dns/run") body = Encoding.UTF8.GetBytes(DnsBench.Run());
                    else if (a22 == "/api/dns/apply") body = Encoding.UTF8.GetBytes(DnsBench.Apply(QueryValue(path, "ip") ?? "", QueryValue(path, "ip2") ?? ""));
                    else if (a22 == "/api/bios") body = Encoding.UTF8.GetBytes(Bios.Json());
                    else if (a22 == "/api/ntfy/test") { Ntfy.Send("NEXUS Monitor", Lang.L("Teste: as notificações do NEXUS chegam a este telemóvel."), true); body = Encoding.UTF8.GetBytes("{\"ok\":true}"); }
                    else if (a22 == "/api/ntfy/new") body = Encoding.UTF8.GetBytes("{\"ok\":true,\"topic\":" + Js.S(Ntfy.NewTopic()) + "}");
                    else if (a22 == "/api/wol") body = Encoding.UTF8.GetBytes(Wol.Json());
                    else if (a22 == "/api/wol/enable") body = Encoding.UTF8.GetBytes(Wol.Enable());
                    else if (a22 == "/api/wol/wake") body = Encoding.UTF8.GetBytes(Wol.Wake(QueryValue(path, "mac")));
                    else { status = 404; body = Encoding.UTF8.GetBytes("{\"ok\":false}"); }
                }
                else if (path.StartsWith("/api/gpu") || path.StartsWith("/api/startup") || path.StartsWith("/api/stress") || path.StartsWith("/api/analise"))
                {
                    // ver pode ser do telemóvel; mudar só no próprio PC e por POST
                    ctype = "application/json";
                    string act = path.Split('?')[0];
                    bool write = act == "/api/gpu/power" || act == "/api/startup/set" || act == "/api/stress/start" || act == "/api/stress/stop" || act == "/api/stress/gpu";
                    if (write && (remote || method != "POST")) { status = 403; body = Encoding.UTF8.GetBytes("{\"ok\":false,\"error\":\"pc_only\"}"); }
                    else if (act == "/api/gpu") body = Encoding.UTF8.GetBytes(GpuCtl.Json());
                    else if (act == "/api/gpu/power") body = Encoding.UTF8.GetBytes(GpuCtl.SetPower(QueryValue(path, "w") ?? ""));
                    else if (act == "/api/startup") body = Encoding.UTF8.GetBytes(Arranque.Json());
                    else if (act == "/api/startup/set") body = Encoding.UTF8.GetBytes(Arranque.Set(QueryValue(path, "id") ?? "", QueryValue(path, "on") == "1"));
                    else if (act == "/api/stress") body = Encoding.UTF8.GetBytes(Stress.Json());
                    else if (act == "/api/stress/start") { int ss; int.TryParse(QueryValue(path, "secs") ?? "120", out ss); int lv; int.TryParse(QueryValue(path, "lvl") ?? "2", out lv); body = Encoding.UTF8.GetBytes(Stress.Start(ss, QueryValue(path, "ram") == "1", QueryValue(path, "cpu") != "0", QueryValue(path, "gpu") == "1", lv)); }
                    else if (act == "/api/stress/stop") body = Encoding.UTF8.GetBytes(Stress.Stop());
                    else if (act == "/api/stress/gpu") body = Encoding.UTF8.GetBytes(Stress.GpuReport(QueryValue(path, "fps"), QueryValue(path, "err")));
                    else if (act == "/api/analise") body = Encoding.UTF8.GetBytes(Analise.Json());
                    else { status = 404; body = Encoding.UTF8.GetBytes("{\"ok\":false}"); }
                }
                else if (path.StartsWith("/api/history"))
                {
                    ctype = "application/json";
                    body = Encoding.UTF8.GetBytes(Historico.HistoryJson(QueryValue(path, "range") ?? "24h"));
                }
                else if (path == "/api/sessions" || path.StartsWith("/api/sessions?") || path.StartsWith("/api/sessions/"))
                {
                    ctype = "application/json";
                    if (path.StartsWith("/api/sessions/clear")) { if (remote || method != "POST") { status = 403; body = Encoding.UTF8.GetBytes("{\"ok\":false}"); } else body = Encoding.UTF8.GetBytes(Historico.ClearSessions()); }
                    else body = Encoding.UTF8.GetBytes(Historico.SessionsJson());
                }
                else if (path.StartsWith("/api/disks"))
                {
                    ctype = "application/json";
                    body = Encoding.UTF8.GetBytes(Saude.DisksJson());
                }
                else if (path.StartsWith("/api/drivers"))
                {
                    ctype = "application/json";
                    body = Encoding.UTF8.GetBytes(Saude.DriversJson());
                }
                else if (path.StartsWith("/api/backup/"))
                {
                    // exportar / importar definições: só no próprio PC
                    ctype = "application/json";
                    if (remote) { status = 403; body = Encoding.UTF8.GetBytes("{\"ok\":false,\"error\":\"pc_only\"}"); }
                    else if (path.StartsWith("/api/backup/export")) body = Encoding.UTF8.GetBytes(Copia.ExportJson());
                    else if (path.StartsWith("/api/backup/import") && method == "POST") body = Encoding.UTF8.GetBytes(Copia.Import(reqBody));
                    else { status = 405; body = Encoding.UTF8.GetBytes("{\"ok\":false}"); }
                }
                else if (path.StartsWith("/api/overlay/edit"))
                {
                    ctype = "application/json";
                    if (remote) { status = 403; body = Encoding.UTF8.GetBytes("{\"ok\":false,\"error\":\"pc_only\"}"); }
                    else if (method != "POST") { status = 405; body = Encoding.UTF8.GetBytes("{\"ok\":false}"); }
                    else { Ui(GameOverlay.Edit); body = Encoding.UTF8.GetBytes("{\"ok\":true}"); }
                }
                else if (path.StartsWith("/api/apps/"))
                {
                    // desinstalador: só no próprio PC
                    ctype = "application/json";
                    string what = path.Substring(10).Split('?')[0];
                    string id = QueryValue(path, "id");
                    if (remote) { status = 403; body = Encoding.UTF8.GetBytes("{\"ok\":false,\"error\":\"pc_only\"}"); }
                    else if (what == "list") body = Encoding.UTF8.GetBytes(Uninstaller.ListJson(QueryValue(path, "store") == "1"));
                    else if (what == "icon")
                    {
                        byte[] png = Uninstaller.IconPng(id ?? "");
                        if (png == null) { status = 404; body = new byte[0]; }
                        else { ctype = "image/png"; body = png; }
                    }
                    else if (what == "status") body = Encoding.UTF8.GetBytes(Uninstaller.StatusJson());
                    else if (method == "POST" && what == "uninstall") body = Encoding.UTF8.GetBytes(Uninstaller.Start(QueryValue(path, "ids") ?? id, QueryValue(path, "force") == "1", QueryValue(path, "quiet") == "1"));
                    else if (method == "POST" && what == "abandon") { Uninstaller.Abandon(); body = Encoding.UTF8.GetBytes("{\"ok\":true}"); }
                    else if (method == "POST" && what == "clean") body = Encoding.UTF8.GetBytes(Uninstaller.Clean(QueryValue(path, "ids")));
                    else if (method == "POST" && what == "reset") body = Encoding.UTF8.GetBytes(Uninstaller.Reset());
                    else { status = 404; body = Encoding.UTF8.GetBytes("{}"); }
                }
                else if (path.StartsWith("/api/disk/"))
                {
                    ctype = "application/json";
                    string what = path.Substring(10).Split('?')[0];
                    string arg = QueryValue(path, "p");
                    if (what == "state") body = Encoding.UTF8.GetBytes(DiskScan.StateJson());
                    else if (what == "dir") body = Encoding.UTF8.GetBytes(DiskScan.DirJson(arg));
                    else if (what == "top") body = Encoding.UTF8.GetBytes(DiskScan.TopJson());
                    else if (method == "POST" && what == "scan") body = Encoding.UTF8.GetBytes(DiskScan.Start(arg));
                    else if (method == "POST" && what == "stop") { DiskScan.Stop(); body = Encoding.UTF8.GetBytes("{\"ok\":true}"); }
                    else if (method == "POST" && what == "clear") { DiskScan.Free(); body = Encoding.UTF8.GetBytes("{\"ok\":true}"); }
                    else if (method == "POST" && what == "install") body = Encoding.UTF8.GetBytes(DiskScan.Install());
                    else if (method == "POST" && what == "open" && !remote) { DiskScan.Open(arg); body = Encoding.UTF8.GetBytes("{\"ok\":true}"); }
                    else if (method == "POST" && what == "delete" && !remote) body = Encoding.UTF8.GetBytes(DiskScan.Delete(arg, QueryValue(path, "perm") == "1", QueryValue(path, "confirm") == "1"));
                    else if (what == "risk" && !remote) body = Encoding.UTF8.GetBytes(DiskScan.RiskJson(arg));
                    else { status = 404; body = Encoding.UTF8.GetBytes("{}"); }
                }
                else
                {
                    status = 404; body = Encoding.UTF8.GetBytes("404");
                }

                // o browser já tem esta versão: responde só "não mudou" (sem voltar a mandar o ficheiro)
                if (cacheable && status == 200 && inm != null && inm == ETag) { status = 304; body = new byte[0]; }
                string reason = status == 304 ? "Not Modified" : status == 200 ? "OK" : status == 204 ? "No Content" : status == 302 ? "Found" :
                                status == 401 ? "Unauthorized" : status == 403 ? "Forbidden" : status == 405 ? "Method Not Allowed" : "Not Found";
                string head = "HTTP/1.1 " + status + " " + reason + "\r\n" + extraHeaders +
                              "Content-Type: " + ctype + "\r\n" +
                              "Content-Length: " + body.Length + "\r\n" +
                              (cacheable ? "Cache-Control: no-cache\r\nETag: " + ETag + "\r\n" : "Cache-Control: no-store\r\n") + "Connection: close\r\n\r\n";
                byte[] hb = Encoding.ASCII.GetBytes(head);
                ns.Write(hb, 0, hb.Length);
                ns.Write(body, 0, body.Length);
                ns.Flush();

                if (exit)
                {
                    client.Close();
                    RequestQuit();
                }
            }
            catch { }
            finally
            {
                try { client.Close(); } catch { }
            }
        }
    }
}
