@echo off
chcp 65001 >NUL
setlocal EnableExtensions
call :nxlang
setlocal EnableExtensions EnableDelayedExpansion
set "VER=2.6.0"
title NEXUS Monitor %VER% !T_1!
cd /d "%~dp0"
set "HERE=%~dp0"
if "%HERE:~-1%"=="\" set "HERE=%HERE:~0,-1%"
set "DEST=%LOCALAPPDATA%\Programs\NEXUS Monitor"
for /F %%a in ('echo prompt $E ^| cmd') do set "ESC=%%a"
set "C=%ESC%[96m" & set "M=%ESC%[95m" & set "G=%ESC%[92m" & set "Y=%ESC%[93m" & set "R=%ESC%[91m" & set "D=%ESC%[90m" & set "B=%ESC%[1m" & set "N=%ESC%[0m"
set "HR=%D%  ────────────────────────────────────────────────────────────%N%"
set "PS=powershell -NoProfile -ExecutionPolicy Bypass -File "%HERE%\nexus_files.ps1""

for %%f in (NexusMonitor.cs codigo\Otimizacao.cs index.html disk.html pad.html perf.html i18n.js tour.js shell.js nexus.ico nexus_files.txt nexus_files.ps1) do if not exist "%%f" goto naoextraido

rem argumentos (ao reabrir como administrador): 2 stream-deck presentmon gdu apagar-antiga atalho-menu atalho-ambiente
set "DECK=%~2" & set "PM=%~3" & set "GDU=%~4" & set "RMOLD=%~5" & set "SM=%~6" & set "SD=%~7"
set "ARGS=%~1"
rem (na pasta do pacote e não no TEMP: se o administrador for outra conta, o TEMP dela é outro)
set "DESTF=%HERE%\nexus_target.txt"
if defined ARGS if exist "%DESTF%" (set /p DEST=<"%DESTF%" & del "%DESTF%" >NUL 2>NUL)
if defined ARGS goto detetar

rem ---- onde instalar: se já houver um NEXUS instalado, a sugestão é a pasta dele
set "ACHADO="
for /f "usebackq delims=" %%i in (`%PS% -Modo Procurar`) do set "ACHADO=%%i"
if defined ACHADO set "DEST=%ACHADO%"
:pasta
cls
call :logo
echo   %B%!T_2!%N%
echo.
echo      %C%%DEST%%N%
if defined ACHADO if /i "%DEST%"=="%ACHADO%" echo      %D%!T_3!%N%
echo.
echo      %B%!K_S1!%N% !T_4!
echo      %B%!K_S2!%N% !T_5!
echo      %B%!K_S3!%N% !T_6!
echo.
choice /c !K_SEC! /n /m "  %C%»%N% !T_7! "
if errorlevel 3 goto escreverPasta
if errorlevel 2 goto escolherPasta
goto detetar
:escolherPasta
echo.
echo   %D%!T_8!%N%
echo   %D%!T_9!%N%
echo   %D%!T_10!%N%
set "NOVA="
for /f "usebackq delims=" %%i in (`powershell -NoProfile -STA -ExecutionPolicy Bypass -File "%HERE%\nexus_files.ps1" -Modo Escolher -Destino "%DEST%"`) do set "NOVA=%%i"
if "%NOVA%"=="?" goto escreverPasta
goto validarPasta
:escreverPasta
echo.
echo   !T_11!
echo   %D%!T_12!%N%
set "ESCRITA="
set /p "ESCRITA=  %C%»%N% "
if not defined ESCRITA goto pasta
set "NOVA="
for /f "usebackq delims=" %%i in (`%PS% -Modo Validar -Destino "%ESCRITA%"`) do set "NOVA=%%i"
:validarPasta
if "%NOVA%"=="*" (
  echo.
  echo   %R%✗%N% !T_13!
  timeout /t 3 >NUL
  goto pasta
)
if defined NOVA set "DEST=%NOVA%"
goto pasta

rem ---- o que já existe neste PC (na pasta escolhida)
:detetar
set "SDEXE="
if exist "streamdeck\procurar_streamdeck.ps1" for /f "usebackq delims=" %%p in (`powershell -NoProfile -ExecutionPolicy Bypass -File "streamdeck\procurar_streamdeck.ps1"`) do set "SDEXE=%%p"
set "HASDECK="
if defined SDEXE if exist "streamdeck\NexusDeck.cs" set "HASDECK=1"
if exist "%APPDATA%\Elgato\StreamDeck\Plugins" if exist "streamdeck\NexusDeck.cs" set "HASDECK=1"
set "HASPM=" & set "HASGDU="
rem outras cópias do NEXUS neste PC (noutras pastas): o que descarregaram é aproveitado e no fim são apagadas
set "COPIAS=%TEMP%\nexus_copias.txt"
%PS% -Modo Antiga -Destino "%DEST%" -Origem "%HERE%" > "%COPIAS%" 2>NUL
set "OLD=" & set /a NOLD=0
for /f "usebackq delims=" %%o in ("%COPIAS%") do (
  if not defined OLD set "OLD=%%o"
  set /a NOLD+=1
  if exist "%%o\presentmon\PresentMon.exe" set "HASPM=1"
  if exist "%%o\gdu\gdu.exe" set "HASGDU=1"
)
if exist "%DEST%\presentmon\PresentMon.exe" set "HASPM=1"
if exist "%DEST%\gdu\gdu.exe" set "HASGDU=1"
set "JA="
if exist "%DEST%\NEXUS Monitor.exe" set "JA=1"
set "ADMIN="
net session >NUL 2>NUL && set "ADMIN=1"

rem plugin Stream Deck: assinatura dos ficheiros + pasta do NEXUS; igual à instalada = já está atualizado
set "PLUGSRC=%DEST%\streamdeck\com.nexus.monitor.sdPlugin"
set "PLUGDST=%APPDATA%\Elgato\StreamDeck\Plugins\com.nexus.monitor.sdPlugin"
set "PLUGSTATE=nenhum"
if defined HASDECK call :plugEstado "%HERE%"

if defined ARGS goto instalar

rem ================================================================ PERGUNTAS
cls
call :logo
if defined JA (
  echo   %B%!T_15! %VER%%N%  %D%!T_14!%N%
) else (
  echo   %B%!T_16! %VER%%N%
)
echo.
echo      !T_17!
echo      %D%!T_18!%N%
echo      %Y%!T_19!%N%
echo      %D%!T_20! %DEST%%N%
echo      %D%!T_21!%N%
echo.
echo   %B%!T_22!%N%
echo.
choice /c !K_YN! /n /m "     !T_23! "
if errorlevel 2 (set "SM=N") else (set "SM=S")
choice /c !K_YN! /n /m "     !T_24! "
if errorlevel 2 (set "SD=N") else (set "SD=S")
echo.
echo   %B%!T_26!%N%  %D%!T_25!%N%
echo.
if defined HASPM (
  echo      %G%✓%N% !T_28!  %D%!T_27!%N%
  set "PM=S"
) else (
  echo      %C%Intel PresentMon%N%  %D%!T_29!%N%
  choice /c !K_YN! /n /m "     !T_30! "
)
if not defined HASPM if errorlevel 2 (set "PM=N") else (set "PM=S")
echo.
if defined HASGDU (
  echo      %G%✓%N% !T_32!  %D%!T_31!%N%
  set "GDU=S"
) else (
  echo      %C%gdu%N%  %D%!T_33!%N%
  choice /c !K_YN! /n /m "     !T_30! "
)
if not defined HASGDU if errorlevel 2 (set "GDU=N") else (set "GDU=S")
echo.
set "DECK=N"
if "%PLUGSTATE%"=="ok" echo      %G%✓%N% !T_34!
rem plugin já instalado mas antigo: atualiza sempre, sem perguntar
if "%PLUGSTATE%"=="velho" echo      %C%!T_35!%N%  %D%· vai ser atualizado ^(a Stream Deck reinicia^)%N%
if "%PLUGSTATE%"=="velho" set "DECK=S"
if defined HASDECK if "%PLUGSTATE%"=="nenhum" (
  echo      %C%!T_35!%N%  %D%!T_36!%N%
  choice /c !K_YN! /n /m "     !T_30! "
)
if defined HASDECK if "%PLUGSTATE%"=="nenhum" if not errorlevel 2 set "DECK=S"
if not defined OLD goto resumo
echo.
echo      %Y%!T_38!%N% %D%!T_37!%N%
for /f "usebackq delims=" %%o in ("%COPIAS%") do echo        %D%·%N% %%o
echo      %D%!T_39!%N%

:resumo
echo.
echo %HR%
if /i "%PM%"=="S" (set "TXT_PM=!T_41!") else (set "TXT_PM=!T_40!")
if /i "%GDU%"=="S" (set "TXT_GDU=!T_41!") else (set "TXT_GDU=!T_40!")
if /i "%DECK%"=="S" (set "TXT_DECK=!T_41!") else (set "TXT_DECK=!T_40!")
if "%PLUGSTATE%"=="ok" set "TXT_DECK=!T_42!"
if /i "%SM%"=="S" (set "TXT_SM=!T_41!") else (set "TXT_SM=!T_40!")
if /i "%SD%"=="S" (set "TXT_SD=!T_41!") else (set "TXT_SD=!T_40!")
echo      !T_43! %C%%DEST%%N%
echo      !T_45! %B%%TXT_SM%%N%   !T_44! %B%%TXT_SD%%N%
if defined HASDECK echo      PresentMon %B%%TXT_PM%%N%   ·   gdu %B%%TXT_GDU%%N%   ·   Stream Deck %B%%TXT_DECK%%N%
if not defined HASDECK echo      PresentMon %B%%TXT_PM%%N%   ·   gdu %B%%TXT_GDU%%N%
echo      %D%!T_46!%N%
echo %HR%
echo.
choice /c !K_YN! /n /m "  %C%»%N% !T_47! "
if errorlevel 2 goto cancelado

rem ================================================================ INSTALAR
:instalar
if not defined DECK set "DECK=N"
if not defined PM set "PM=N"
if not defined GDU set "GDU=N"
if not defined RMOLD set "RMOLD=N"
if not defined SM set "SM=S"
if not defined SD set "SD=N"
if not defined HASDECK set "DECK=N"
if not defined ADMIN (
  echo.
  echo   %Y%!T_50!%N% !T_49! %B%!T_48!%N%.
  > "%DESTF%" echo %DEST%
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -ArgumentList '2','%DECK%','%PM%','%GDU%','%RMOLD%','%SM%','%SD%' -Verb RunAs"
  exit /b 0
)
set /a TOTAL=6, I=0
if /i "%PM%"=="S" set /a TOTAL+=1
if /i "%GDU%"=="S" set /a TOTAL+=1
if /i "%DECK%"=="S" set /a TOTAL+=1

cls
call :logo
echo   %B%!T_51!%N%
echo.

set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%CSC%" (
  echo   %R%✗%N% !T_52!
  goto erroFim
)

call :fecharNexus

rem ---- driver PawnIO
call :passo "!T_53!"
call :temPawn && (call :ok "!T_54!" & goto ficheiros)
where winget >NUL 2>NUL && winget install --id namazso.PawnIO -e --silent --accept-package-agreements --accept-source-agreements >NUL 2>NUL
call :temPawn && (call :ok "!T_55!" & goto ficheiros)
curl -L -s -o "%TEMP%\PawnIO_setup.exe" "https://github.com/namazso/PawnIO.Setup/releases/latest/download/PawnIO_setup.exe"
if exist "%TEMP%\PawnIO_setup.exe" "%TEMP%\PawnIO_setup.exe" -install -silent
del "%TEMP%\PawnIO_setup.exe" >NUL 2>NUL
call :temPawn && (call :ok "!T_55!") || call :falha "!T_56!"

rem ---- ficheiros para a pasta do NEXUS (só o que mudou; o que está a mais sai)
:ficheiros
call :passo "!T_57!"
mkdir "%DEST%" >NUL 2>NUL
rem o que a versão antiga já tinha descarregado passa para aqui (não volta a descarregar)
for /f "usebackq delims=" %%o in ("%COPIAS%") do for %%d in (lhm presentmon gdu) do if exist "%%o\%%d" if not exist "%DEST%\%%d" xcopy "%%o\%%d" "%DEST%\%%d\" /e /i /y /q >NUL
set "CP=0 0"
for /f "usebackq delims=" %%r in (`%PS% -Modo Copiar -Origem "%HERE%" -Destino "%DEST%"`) do set "CP=%%r"
call :tirarModulos
for /f "tokens=1,2" %%a in ("%CP%") do (set "NCOP=%%a" & set "NDEL=%%b")
if exist "%DEST%\NexusMonitor.cs" (call :ok "%NCOP% !T_60! %NDEL% !T_59!") else (call :falha "!T_58! %DEST%" & goto erroFim)
cd /d "%DEST%"

rem ---- LibreHardwareMonitor
call :passo "LibreHardwareMonitor"
if exist "lhm\LibreHardwareMonitorLib.dll" (call :ok "!T_61!" & goto compilar)
set "LHMZIP=%TEMP%\nexus_lhm.zip"
del "%LHMZIP%" >NUL 2>NUL
curl -L -s -o "%LHMZIP%" "https://github.com/LibreHardwareMonitor/LibreHardwareMonitor/releases/download/v0.9.6/LibreHardwareMonitor.zip"
rmdir /s /q "%TEMP%\nexus_lhm" >NUL 2>NUL
if exist "%LHMZIP%" powershell -NoProfile -Command "Expand-Archive -LiteralPath '%LHMZIP%' -DestinationPath '%TEMP%\nexus_lhm' -Force" >NUL 2>NUL
del "%LHMZIP%" >NUL 2>NUL
set "LIBDIR="
for /f "delims=" %%F in ('dir /s /b "%TEMP%\nexus_lhm\LibreHardwareMonitorLib.dll" 2^>NUL') do if not defined LIBDIR set "LIBDIR=%%~dpF"
if defined LIBDIR (
  mkdir "lhm" >NUL 2>NUL
  copy /y "%LIBDIR%*.dll" "lhm\" >NUL
)
rmdir /s /q "%TEMP%\nexus_lhm" >NUL 2>NUL
if exist "lhm\LibreHardwareMonitorLib.dll" (call :ok "!T_63!") else (call :falha "!T_62!")

rem ---- NEXUS Monitor.exe
:compilar
call :passo "NEXUS Monitor"
call :compilarNexus || goto erroFim
call :ok "!T_64!"

rem ---- Intel PresentMon
if /i not "%PM%"=="S" goto gdu
call :passo "Intel PresentMon"
if exist "presentmon\PresentMon.exe" (call :ok "!T_61!" & goto gdu)
mkdir "presentmon" >NUL 2>NUL
powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol='Tls12'; $h=@{'User-Agent'='NEXUS-Monitor'}; $rs=Invoke-RestMethod -UseBasicParsing -Headers $h 'https://api.github.com/repos/GameTechDev/PresentMon/releases?per_page=30'; $a=$null; foreach($r in $rs){ if($r.prerelease){continue}; $a=$r.assets | Where-Object { $_.name -match '^PresentMon-[0-9.]+-x64\.exe$' } | Select-Object -First 1; if($a){break} }; if(-not $a){ exit 2 }; Invoke-WebRequest -UseBasicParsing -Headers $h $a.browser_download_url -OutFile '%DEST%\presentmon\PresentMon.exe'" >NUL 2>NUL
if exist "presentmon\PresentMon.exe" (call :ok "!T_63!") else (call :falha "!T_65!")

rem ---- gdu (motor do Deep Scan, open-source MIT)
:gdu
if /i not "%GDU%"=="S" goto deck
call :passo "gdu"
if exist "gdu\gdu.exe" (call :ok "!T_61!" & goto deck)
mkdir "gdu" >NUL 2>NUL
del "%TEMP%\nexus_gdu.zip" >NUL 2>NUL
curl -L -s -o "%TEMP%\nexus_gdu.zip" "https://github.com/dundee/gdu/releases/latest/download/gdu_windows_amd64.exe.zip"
if exist "%TEMP%\nexus_gdu.zip" powershell -NoProfile -Command "Expand-Archive -LiteralPath '%TEMP%\nexus_gdu.zip' -DestinationPath '%DEST%\gdu' -Force; Get-ChildItem -LiteralPath '%DEST%\gdu' -Filter 'gdu*.exe' | Where-Object { $_.Name -ne 'gdu.exe' } | Select-Object -First 1 | Move-Item -Destination '%DEST%\gdu\gdu.exe' -Force" >NUL 2>NUL
del "%TEMP%\nexus_gdu.zip" >NUL 2>NUL
if exist "gdu\gdu.exe" (call :ok "!T_63!") else (call :falha "!T_66!")

rem ---- plugin Stream Deck (só se for novo ou mudou - senão não mexe na Stream Deck)
:deck
if /i not "%DECK%"=="S" goto atalhos
call :passo "!T_67!"
call :instalarPlugin
if "%PLUGRES%"=="ok" call :ok "!T_68!"
if "%PLUGRES%"=="novo" call :ok "!T_55!"
if "%PLUGRES%"=="erro" call :falha "!T_69!"
if "%PLUGRES%"=="copia" call :falha "!T_70!"

rem ---- menu Iniciar e lista de aplicações do Windows
:atalhos
call :passo "!T_71!"
call :registar
set "TXT_AT=!T_72!"
if /i "%SM%"=="S" set "TXT_AT=%TXT_AT%!T_73!"
if /i "%SD%"=="S" set "TXT_AT=%TXT_AT%!T_74!"
call :ok "%TXT_AT%"

rem ---- versão antiga e ficheiros do instalador
call :passo "!T_75!"
set "TXTL=!T_76!"
if defined OLD (
  set "RES=0 0"
  for /f "usebackq delims=" %%r in (`%PS% -Modo ApagarOutras -Destino "%DEST%" -Origem "%HERE%"`) do set "RES=%%r"
)
if defined OLD for /f "tokens=1,2" %%a in ("%RES%") do (
  if "%%b"=="0" (set "TXTL=%%a !T_79!") else (set "TXTL=%%a !T_78! %%b !T_77!")
)
del "%COPIAS%" >NUL 2>NUL
call :ok "%TXTL%"

rem ================================================================ FIM
echo.
echo %HR%
echo   %G%%B%!T_81!%N%  NEXUS Monitor %VER% !T_80!
echo.
echo   %D%·%N% !T_84! %D%!T_83!%N% !T_82!
echo   %D%·%N% !T_85!
if /i "%DECK%"=="S" if "%PLUGRES%"=="novo" echo   %D%·%N% !T_86! %C%NEXUS Monitor%N%.
echo   %D%·%N% !T_88! %C%UPDATE NEXUS.bat%N% !T_87!
echo %HR%
echo.
start "" "%DEST%\NEXUS Monitor.exe"
echo   %D%!T_89!%N%
timeout /t 8 >NUL
goto autoApagar

:erroFim
echo.
pause
exit /b 1

:cancelado
echo.
echo   %D%!T_90!%N%
timeout /t 3 >NUL
exit /b 0

:naoextraido
cls
echo.
echo   !T_91!
echo.
echo   !T_92!
echo     !T_93!
echo     !T_94!
echo     !T_95!
echo.
echo   !T_96!
echo.
pause
exit /b 1

rem ================================================================ FUNÇÕES
:logo
echo.
echo   %C%███╗   ██╗███████╗██╗  ██╗██╗   ██╗███████╗%N%
echo   %C%████╗  ██║██╔════╝╚██╗██╔╝██║   ██║██╔════╝%N%
echo   %C%██╔██╗ ██║█████╗   ╚███╔╝ ██║   ██║███████╗%N%
echo   %M%██║╚██╗██║██╔══╝   ██╔██╗ ██║   ██║╚════██║%N%
echo   %M%██║ ╚████║███████╗██╔╝ ██╗╚██████╔╝███████║%N%
echo   %M%╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝%N%  %D%MONITOR %VER%%N%
echo.
exit /b 0

rem escreve "[n/total] Nome  " sem mudar de linha; :ok / :falha acabam a linha
:passo
set /a I+=1
set "PNOME=%~1                         "
<NUL set /p "=%N%   %D%[%I%/%TOTAL%]%N%  %PNOME:~0,24%"
exit /b 0

:ok
echo %G%✓%N% %D%%~1%N%
exit /b 0

:falha
echo %R%✗%N% %~1
exit /b 0

rem ---- módulos que este PC não tem (Stream Deck / SignalRGB): os ficheiros deles saem da pasta do NEXUS
:tirarModulos
set "TEMSD="
if defined SDEXE set "TEMSD=1"
if exist "%APPDATA%\Elgato\StreamDeck" set "TEMSD=1"
if not defined TEMSD rmdir /s /q "%DEST%\streamdeck" >NUL 2>NUL
if not defined TEMSD del "%DEST%\INSTALL STREAM DECK ADDON.bat" >NUL 2>NUL
set "TEMSR="
if exist "%LOCALAPPDATA%\VortxEngine" set "TEMSR=1"
if exist "%LOCALAPPDATA%\WhirlwindFX\SignalRgb" set "TEMSR=1"
if not defined TEMSR for /f "usebackq delims=" %%d in (`powershell -NoProfile -Command "[Environment]::GetFolderPath('MyDocuments')"`) do del "%%d\WhirlwindFX\Plugins\NEXUS_Monitor.js" >NUL 2>NUL
exit /b 0

rem cria o NEXUS Monitor.exe na pasta do NEXUS
:compilarNexus
pushd "%DEST%"
del "NEXUS Monitor.exe" >NUL 2>NUL
"%CSC%" /nologo /codepage:65001 /target:winexe /optimize+ /out:"NEXUS Monitor.exe" /win32icon:nexus.ico /resource:index.html,index.html /resource:disk.html,disk.html /resource:pad.html,pad.html /resource:perf.html,perf.html /resource:i18n.js,i18n.js /resource:tour.js,tour.js /resource:shell.js,shell.js /r:System.Management.dll /r:System.Windows.Forms.dll /r:System.Drawing.dll /r:System.Core.dll /r:System.ServiceProcess.dll /r:Microsoft.VisualBasic.dll NexusMonitor.cs codigo\*.cs > erro.txt 2>&1
if not exist "NEXUS Monitor.exe" (
  call :falha "!T_97!"
  echo.
  type erro.txt
  echo.
  echo   %D%!T_99!%DEST%!T_98!%N%
  popd
  exit /b 1
)
del erro.txt >NUL 2>NUL
> "versao.txt" echo %VER%
popd
exit /b 0

rem PLUGSTATE = nenhum / velho / ok, comparando a assinatura com a do plugin instalado
rem %1 = pasta de onde vêm os ficheiros do plugin (a extraída, antes de copiar; ou a do NEXUS)
:plugEstado
set "PLUGHASH="
for /f "usebackq delims=" %%h in (`powershell -NoProfile -Command "((Get-FileHash -Algorithm SHA256 -LiteralPath '%~1\streamdeck\NexusDeck.cs','%~1\streamdeck\com.nexus.monitor.sdPlugin\pi.html','%~1\streamdeck\com.nexus.monitor.sdPlugin\manifest.json' | ForEach-Object Hash) -join '').Substring(0,40)"`) do set "PLUGHASH=%%h"
set "PLUGHASH=%PLUGHASH%@%DEST%\"
set "PLUGSTATE=nenhum"
if not exist "%PLUGDST%\NexusDeck.exe" exit /b 0
set "PLUGSTATE=velho"
set "OLDHASH="
if exist "%PLUGDST%\nexus_build.txt" set /p OLDHASH=<"%PLUGDST%\nexus_build.txt"
if "%OLDHASH%"=="%PLUGHASH%" set "PLUGSTATE=ok"
exit /b 0

rem PLUGRES = ok (já estava) / novo / erro
:instalarPlugin
call :plugEstado "%DEST%"
set "PLUGRES=ok"
if "%PLUGSTATE%"=="ok" exit /b 0
del "%PLUGSRC%\NexusDeck.exe" >NUL 2>NUL
"%CSC%" /nologo /codepage:65001 /target:winexe /optimize+ /out:"%PLUGSRC%\NexusDeck.exe" /r:System.Drawing.dll /r:System.Web.Extensions.dll /r:System.Core.dll "%DEST%\streamdeck\NexusDeck.cs" > "%DEST%\erro_deck.txt" 2>&1
if not exist "%PLUGSRC%\NexusDeck.exe" (set "PLUGRES=erro" & exit /b 0)
del "%DEST%\erro_deck.txt" >NUL 2>NUL
> "%PLUGSRC%\nexus_path.txt" echo %DEST%\NEXUS Monitor.exe
> "%PLUGSRC%\nexus_build.txt" echo %PLUGHASH%
if not defined SDEXE for /f "usebackq delims=" %%p in (`powershell -NoProfile -Command "(Get-Process StreamDeck -ErrorAction SilentlyContinue | Select-Object -First 1).Path"`) do set "SDEXE=%%p"
taskkill /im "StreamDeck.exe" /f >NUL 2>NUL
taskkill /im "NexusDeck.exe" /f >NUL 2>NUL
timeout /t 2 /nobreak >NUL
rem a Stream Deck pode demorar a largar os ficheiros: tenta até 3 vezes e confere que o plugin copiado é mesmo o novo
set "CPOK="
for /l %%i in (1,1,3) do if not defined CPOK (
  taskkill /im "StreamDeck.exe" /f >NUL 2>NUL
  taskkill /im "NexusDeck.exe" /f >NUL 2>NUL
  if exist "%PLUGDST%" rmdir /s /q "%PLUGDST%" >NUL 2>NUL
  xcopy "%PLUGSRC%" "%PLUGDST%\" /e /i /y /q >NUL 2>NUL
  fc /b "%PLUGSRC%\NexusDeck.exe" "%PLUGDST%\NexusDeck.exe" >NUL 2>NUL && set "CPOK=1"
  if not defined CPOK timeout /t 2 /nobreak >NUL
)
rem reabre a Stream Deck sem administrador
if defined SDEXE explorer.exe "%SDEXE%"
if defined CPOK (set "PLUGRES=novo") else (set "PLUGRES=copia")
exit /b 0

rem atalho no menu Iniciar + entrada em Definições > Aplicações (com o desinstalador)
:registar
set "UK=HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\NEXUS Monitor"
reg add "%UK%" /v DisplayName /d "NEXUS Monitor" /f >NUL
reg add "%UK%" /v DisplayVersion /d "%VER%" /f >NUL
reg add "%UK%" /v Publisher /d "NEXUS" /f >NUL
reg add "%UK%" /v DisplayIcon /d "%DEST%\NEXUS Monitor.exe" /f >NUL
reg add "%UK%" /v InstallLocation /d "%DEST%" /f >NUL
reg add "%UK%" /v UninstallString /d "cmd.exe /c \"\"%DEST%\UNINSTALL NEXUS.bat\"\"" /f >NUL
reg add "%UK%" /v NoModify /t REG_DWORD /d 1 /f >NUL
reg add "%UK%" /v NoRepair /t REG_DWORD /d 1 /f >NUL
if /i "%SM%"=="S" (
  powershell -NoProfile -Command "$p=[Environment]::GetFolderPath('Programs')+'\NEXUS Monitor.lnk'; $s=(New-Object -ComObject WScript.Shell).CreateShortcut($p); $s.TargetPath='%DEST%\NEXUS Monitor.exe'; $s.WorkingDirectory='%DEST%'; $s.IconLocation='%DEST%\NEXUS Monitor.exe,0'; $s.Description='NEXUS Monitor'; $s.Save()" >NUL 2>NUL
) else (
  powershell -NoProfile -Command "Remove-Item -LiteralPath ([Environment]::GetFolderPath('Programs')+'\NEXUS Monitor.lnk') -Force -ErrorAction SilentlyContinue" >NUL 2>NUL
)
if /i "%SD%"=="S" (
  powershell -NoProfile -Command "$p=[Environment]::GetFolderPath('Desktop')+'\NEXUS Monitor.lnk'; $s=(New-Object -ComObject WScript.Shell).CreateShortcut($p); $s.TargetPath='%DEST%\NEXUS Monitor.exe'; $s.WorkingDirectory='%DEST%'; $s.IconLocation='%DEST%\NEXUS Monitor.exe,0'; $s.Description='NEXUS Monitor'; $s.Save()" >NUL 2>NUL
) else (
  powershell -NoProfile -Command "Remove-Item -LiteralPath ([Environment]::GetFolderPath('Desktop')+'\NEXUS Monitor.lnk') -Force -ErrorAction SilentlyContinue" >NUL 2>NUL
)
exit /b 0

rem fecha o NEXUS com calma (retoma apps em pausa) e só depois à força
:fecharNexus
tasklist /fi "imagename eq NEXUS Monitor.exe" 2>NUL | find /i "NEXUS Monitor.exe" >NUL || exit /b 0
curl -s -m 3 -X POST http://127.0.0.1:8765/api/shutdown >NUL 2>NUL
timeout /t 2 /nobreak >NUL
taskkill /im "NEXUS Monitor.exe" /f >NUL 2>NUL
taskkill /im "PresentMon.exe" /f >NUL 2>NUL
timeout /t 1 /nobreak >NUL
exit /b 0

:temPawn
powershell -NoProfile -Command "if (Get-ItemProperty 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*','HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*' -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -like 'PawnIO*' }) { exit 0 } else { exit 1 }" >NUL 2>NUL
exit /b %errorlevel%

rem apaga os ficheiros extraídos do zip (e este .bat) depois de a janela fechar
:autoApagar
set "RM=%TEMP%\nexus_limpar.bat"
> "%RM%" echo @echo off
>>"%RM%" echo timeout /t 2 /nobreak ^>NUL
>>"%RM%" echo powershell -NoProfile -ExecutionPolicy Bypass -File "%TEMP%\nexus_limpar.ps1" -Modo Limpar -Origem "%HERE%" ^>NUL 2^>NUL
>>"%RM%" echo del "%TEMP%\nexus_limpar.ps1" ^>NUL 2^>NUL
>>"%RM%" echo (goto) 2^>NUL ^& del "%%~f0"
copy /y "%HERE%\nexus_files.ps1" "%TEMP%\nexus_limpar.ps1" >NUL
cd /d "%TEMP%"
start "" /min cmd /c ""%RM%""
exit

rem ================================================================ LÍNGUA (gerado na build)
:nxlang
set "NXL=en"
for /f "usebackq delims=" %%l in (`powershell -NoProfile -Command "(Get-UICulture).TwoLetterISOLanguageName"`) do set "NXL=%%l"
if defined NEXUS_LANG set "NXL=%NEXUS_LANG%"
if /i not "%NXL%"=="pt" if /i not "%NXL%"=="es" if /i not "%NXL%"=="fr" if /i not "%NXL%"=="de" set "NXL=en"
goto nxl_%NXL%
:nxl_pt
set "K_YN=SN" & set "K_SEC=SEC" & set "K_S1=S" & set "K_S2=E" & set "K_S3=C"
set "T_1=· Instalador"
set "T_2=Onde queres instalar o NEXUS Monitor?"
set "T_3=(é onde o NEXUS já está instalado)"
set "T_4=- instalar aqui"
set "T_5=- escolher outra pasta (abre uma janela)"
set "T_6=- escrever o caminho"
set "T_7=Escolhe (S/E/C):"
set "T_8=A abrir a janela para escolher a pasta..."
set "T_9=Se não a vires, carrega Alt+Tab ou procura "NEXUS Monitor" na barra de tarefas."
set "T_10=Se não abrir de todo, fecha-a (ou espera 3 min) e escreve o caminho."
set "T_11=Escreve a pasta onde instalar (ex.: D:\Programas) e carrega Enter."
set "T_12=Enter vazio = voltar. É criada uma pasta "NEXUS Monitor" lá dentro."
set "T_13=Essa pasta não pode ser usada (pasta do Windows, raiz do sistema ou disco que não existe)."
set "T_14=· as definições ficam"
set "T_15=Vai ser reinstalado o NEXUS Monitor"
set "T_16=Vai ser instalado o NEXUS Monitor"
set "T_17=Lê sozinho todas as temperaturas, ventoinhas e consumos."
set "T_18=Usa o driver PawnIO (assinado, open-source) e pede administrador."
set "T_19=Alguns antivírus e anti-cheats de jogos podem dar aviso."
set "T_20=Fica em:"
set "T_21=Definições em: Documentos\NEXUS Monitor"
set "T_22=Atalhos"
set "T_23=Atalho no menu Iniciar? (S/N):"
set "T_24=Atalho no ambiente de trabalho? (S/N):"
set "T_25=(opcionais)"
set "T_26=Extras"
set "T_27=· FPS e latência dos jogos"
set "T_28=Intel PresentMon já está instalado"
set "T_29=· FPS, frametime e latência dos jogos (~1 MB)"
set "T_30=Instalar? (S/N):"
set "T_31=· motor do Deep Scan"
set "T_32=gdu já está instalado"
set "T_33=· motor do Deep Scan, open-source (~6 MB) - só corre quando pedes"
set "T_34=Plugin Stream Deck já instalado e atualizado"
set "T_35=Plugin Stream Deck"
set "T_36=· estatísticas do PC nas teclas"
set "T_37=- vão ser apagadas no fim (fica só a da pasta escolhida):"
set "T_38=Outras cópias do NEXUS neste PC"
set "T_39=O que já tinham descarregado passa para a pasta nova. As definições ficam."
set "T_40=não"
set "T_41=sim"
set "T_42=já atualizado"
set "T_43=Pasta:"
set "T_44=·   ambiente de trabalho"
set "T_45=Atalhos: menu Iniciar"
set "T_46=No fim, o instalador e os ficheiros extraídos são apagados (já não fazem falta)."
set "T_47=Instalar agora? (S/N):"
set "T_48=Sim"
set "T_49=No aviso do Windows carrega em"
set "T_50=!"
set "T_51=A instalar"
set "T_52=Não encontrei o .NET Framework 4 neste PC."
set "T_53=Driver PawnIO"
set "T_54=já instalado"
set "T_55=instalado"
set "T_56=não consegui - o CPU pode ficar sem temperatura"
set "T_57=Ficheiros"
set "T_58=não consegui copiar para"
set "T_59=antigos removidos"
set "T_60=novos/atualizados,"
set "T_61=já existe"
set "T_62=falhou o download - sem internet? volta a correr o instalador"
set "T_63=descarregado"
set "T_64=criado"
set "T_65=não consegui descarregar"
set "T_66=não consegui descarregar - dá para descarregar depois no Deep Scan"
set "T_67=Plugin Stream Deck"
set "T_68=já atualizado"
set "T_69=erro ao criar - vê o erro_deck.txt"
set "T_70=não consegui copiar"
set "T_71=Atalhos"
set "T_72=Aplicações do Windows"
set "T_73=, menu Iniciar"
set "T_74=, ambiente de trabalho"
set "T_75=Limpeza"
set "T_76=ficheiros do instalador apagados ao fechar"
set "T_77=não deu ^(ficheiro em uso?^)"
set "T_78=cópia^(s^) apagada^(s^),"
set "T_79=outra^(s^) cópia^(s^) do NEXUS e ficheiros do instalador apagados"
set "T_80=instalado."
set "T_81=✓ Pronto!"
set "T_82=e no menu Iniciar."
set "T_83=(ícones ocultos ^)"
set "T_84=Fica junto ao relógio"
set "T_85=Opções, temas, línguas, Deep Scan e telemóvel no topo da página."
set "T_86=Stream Deck: procura a categoria"
set "T_87=das versões novas."
set "T_88=Para atualizar no futuro usa o"
set "T_89=A abrir o NEXUS... esta janela fecha-se e apaga os ficheiros do instalador."
set "T_90=Cancelado - nada foi alterado."
set "T_91=[!] Faltam ficheiros nesta pasta."
set "T_92=Abriste este ficheiro de dentro do zip?"
set "T_93=1. Fecha esta janela."
set "T_94=2. Botão direito no zip > "Extrair tudo..." > Extrair."
set "T_95=3. Abre a pasta extraída e corre o INSTALL NEXUS.bat de lá."
set "T_96=Se já extraíste: o antivírus pode ter apagado o NexusMonitor.cs."
set "T_97=erro ao criar o programa"
set "T_98=) a quem te deu o NEXUS."
set "T_99=Envia o ficheiro erro.txt ("
exit /b 0
:nxl_en
set "K_YN=YN" & set "K_SEC=HBT" & set "K_S1=H" & set "K_S2=B" & set "K_S3=T"
set "T_1=· Installer"
set "T_2=Where do you want to install NEXUS Monitor?"
set "T_3=(NEXUS is already installed here)"
set "T_4=- install here"
set "T_5=- browse for another folder (opens a window)"
set "T_6=- type the path"
set "T_7=Choose (H/B/T):"
set "T_8=Opening the folder picker..."
set "T_9=If you can't see it, press Alt+Tab or look for "NEXUS Monitor" on the taskbar."
set "T_10=If it doesn't open at all, close it (or wait 3 min) and type the path."
set "T_11=Type the folder to install to (e.g. D:\Programs) and press Enter."
set "T_12=Empty Enter = go back. A "NEXUS Monitor" folder is created inside it."
set "T_13=That folder can't be used (Windows folder, system root or a drive that doesn't exist)."
set "T_14=· your settings are kept"
set "T_15=NEXUS Monitor will be reinstalled"
set "T_16=NEXUS Monitor will be installed"
set "T_17=Reads all temperatures, fans and power draw by itself."
set "T_18=Uses the PawnIO driver (signed, open source) and asks for admin rights."
set "T_19=Some antivirus and game anti-cheats may show a warning."
set "T_20=Location:"
set "T_21=Settings in: Documents\NEXUS Monitor"
set "T_22=Shortcuts"
set "T_23=Start menu shortcut? (Y/N):"
set "T_24=Desktop shortcut? (Y/N):"
set "T_25=(optional)"
set "T_26=Extras"
set "T_27=· game FPS and latency"
set "T_28=Intel PresentMon is already installed"
set "T_29=· game FPS, frame time and latency (~1 MB)"
set "T_30=Install? (Y/N):"
set "T_31=· Deep Scan engine"
set "T_32=gdu is already installed"
set "T_33=· Deep Scan engine, open source (~6 MB) - only runs when you ask"
set "T_34=Stream Deck plugin already installed and up to date"
set "T_35=Stream Deck plugin"
set "T_36=· PC stats on the keys"
set "T_37=- will be deleted at the end (only the one in the chosen folder stays):"
set "T_38=Other NEXUS copies on this PC"
set "T_39=What they had downloaded moves to the new folder. Settings are kept."
set "T_40=no"
set "T_41=yes"
set "T_42=already up to date"
set "T_43=Folder:"
set "T_44=·   desktop"
set "T_45=Shortcuts: Start menu"
set "T_46=At the end, the installer and the extracted files are deleted (they're no longer needed)."
set "T_47=Install now? (Y/N):"
set "T_48=Yes"
set "T_49=In the Windows prompt, click"
set "T_50=!"
set "T_51=Installing"
set "T_52=Couldn't find .NET Framework 4 on this PC."
set "T_53=PawnIO driver"
set "T_54=already installed"
set "T_55=installed"
set "T_56=failed - the CPU temperature may be missing"
set "T_57=Files"
set "T_58=couldn't copy to"
set "T_59=old ones removed"
set "T_60=new/updated,"
set "T_61=already there"
set "T_62=download failed - no internet? run the installer again"
set "T_63=downloaded"
set "T_64=created"
set "T_65=couldn't download"
set "T_66=couldn't download - you can download it later in Deep Scan"
set "T_67=Stream Deck plugin"
set "T_68=already up to date"
set "T_69=build error - see erro_deck.txt"
set "T_70=couldn't copy"
set "T_71=Shortcuts"
set "T_72=Windows apps list"
set "T_73=, Start menu"
set "T_74=, desktop"
set "T_75=Cleanup"
set "T_76=installer files deleted on close"
set "T_77=failed ^(file in use?^)"
set "T_78=cop^(ies^) deleted,"
set "T_79=other NEXUS cop^(ies^) and installer files deleted"
set "T_80=installed."
set "T_81=✓ Done!"
set "T_82=and in the Start menu."
set "T_83=(hidden icons ^)"
set "T_84=It sits next to the clock"
set "T_85=Options, themes, languages, Deep Scan and phone access at the top of the page."
set "T_86=Stream Deck: look for the category"
set "T_87=from new versions."
set "T_88=To update in the future, use"
set "T_89=Opening NEXUS... this window closes and deletes the installer files."
set "T_90=Cancelled - nothing was changed."
set "T_91=[!] Files are missing in this folder."
set "T_92=Did you open this file from inside the zip?"
set "T_93=1. Close this window."
set "T_94=2. Right-click the zip > "Extract All..." > Extract."
set "T_95=3. Open the extracted folder and run INSTALL NEXUS.bat from there."
set "T_96=If you already extracted it: your antivirus may have deleted NexusMonitor.cs."
set "T_97=error building the program"
set "T_98=) to whoever gave you NEXUS."
set "T_99=Send the erro.txt file ("
exit /b 0
:nxl_es
set "K_YN=SN" & set "K_SEC=AEC" & set "K_S1=A" & set "K_S2=E" & set "K_S3=C"
set "T_1=· Instalador"
set "T_2=¿Dónde quieres instalar NEXUS Monitor?"
set "T_3=(es donde NEXUS ya está instalado)"
set "T_4=- instalar aquí"
set "T_5=- elegir otra carpeta (abre una ventana)"
set "T_6=- escribir la ruta"
set "T_7=Elige (A/E/C):"
set "T_8=Abriendo la ventana para elegir la carpeta..."
set "T_9=Si no la ves, pulsa Alt+Tab o busca "NEXUS Monitor" en la barra de tareas."
set "T_10=Si no se abre, ciérrala (o espera 3 min) y escribe la ruta."
set "T_11=Escribe la carpeta donde instalar (ej.: D:\Programas) y pulsa Enter."
set "T_12=Enter vacío = volver. Se crea una carpeta "NEXUS Monitor" dentro."
set "T_13=Esa carpeta no se puede usar (carpeta de Windows, raíz del sistema o disco que no existe)."
set "T_14=· los ajustes se mantienen"
set "T_15=Se va a reinstalar NEXUS Monitor"
set "T_16=Se va a instalar NEXUS Monitor"
set "T_17=Lee solo todas las temperaturas, ventiladores y consumos."
set "T_18=Usa el driver PawnIO (firmado, open source) y pide administrador."
set "T_19=Algunos antivirus y anti-cheats de juegos pueden avisar."
set "T_20=Se queda en:"
set "T_21=Ajustes en: Documentos\NEXUS Monitor"
set "T_22=Accesos directos"
set "T_23=¿Acceso en el menú Inicio? (S/N):"
set "T_24=¿Acceso en el escritorio? (S/N):"
set "T_25=(opcionales)"
set "T_26=Extras"
set "T_27=· FPS y latencia de los juegos"
set "T_28=Intel PresentMon ya está instalado"
set "T_29=· FPS, frametime y latencia de los juegos (~1 MB)"
set "T_30=¿Instalar? (S/N):"
set "T_31=· motor del Deep Scan"
set "T_32=gdu ya está instalado"
set "T_33=· motor del Deep Scan, open source (~6 MB) - solo se ejecuta cuando lo pides"
set "T_34=Plugin de Stream Deck ya instalado y actualizado"
set "T_35=Plugin de Stream Deck"
set "T_36=· estadísticas del PC en las teclas"
set "T_37=- se borrarán al final (solo queda la de la carpeta elegida):"
set "T_38=Otras copias de NEXUS en este PC"
set "T_39=Lo que ya habían descargado pasa a la carpeta nueva. Los ajustes se mantienen."
set "T_40=no"
set "T_41=sí"
set "T_42=ya actualizado"
set "T_43=Carpeta:"
set "T_44=·   escritorio"
set "T_45=Accesos: menú Inicio"
set "T_46=Al final, el instalador y los archivos extraídos se borran (ya no hacen falta)."
set "T_47=¿Instalar ahora? (S/N):"
set "T_48=Sí"
set "T_49=En el aviso de Windows pulsa"
set "T_50=!"
set "T_51=Instalando"
set "T_52=No encontré .NET Framework 4 en este PC."
set "T_53=Driver PawnIO"
set "T_54=ya instalado"
set "T_55=instalado"
set "T_56=no pude - la CPU puede quedarse sin temperatura"
set "T_57=Archivos"
set "T_58=no pude copiar a"
set "T_59=antiguos eliminados"
set "T_60=nuevos/actualizados,"
set "T_61=ya existe"
set "T_62=falló la descarga - ¿sin internet? vuelve a ejecutar el instalador"
set "T_63=descargado"
set "T_64=creado"
set "T_65=no pude descargar"
set "T_66=no pude descargar - se puede descargar luego en el Deep Scan"
set "T_67=Plugin de Stream Deck"
set "T_68=ya actualizado"
set "T_69=error al crear - mira erro_deck.txt"
set "T_70=no pude copiar"
set "T_71=Accesos directos"
set "T_72=Aplicaciones de Windows"
set "T_73=, menú Inicio"
set "T_74=, escritorio"
set "T_75=Limpieza"
set "T_76=archivos del instalador borrados al cerrar"
set "T_77=no se pudo ^(¿archivo en uso?^)"
set "T_78=copia^(s^) borrada^(s^),"
set "T_79=otra^(s^) copia^(s^) de NEXUS y archivos del instalador borrados"
set "T_80=instalado."
set "T_81=✓ ¡Listo!"
set "T_82=y en el menú Inicio."
set "T_83=(iconos ocultos ^)"
set "T_84=Está junto al reloj"
set "T_85=Opciones, temas, idiomas, Deep Scan y móvil arriba en la página."
set "T_86=Stream Deck: busca la categoría"
set "T_87=de las versiones nuevas."
set "T_88=Para actualizar en el futuro usa el"
set "T_89=Abriendo NEXUS... esta ventana se cierra y borra los archivos del instalador."
set "T_90=Cancelado - no se ha cambiado nada."
set "T_91=[!] Faltan archivos en esta carpeta."
set "T_92=¿Abriste este archivo desde dentro del zip?"
set "T_93=1. Cierra esta ventana."
set "T_94=2. Botón derecho en el zip > "Extraer todo..." > Extraer."
set "T_95=3. Abre la carpeta extraída y ejecuta INSTALL NEXUS.bat desde allí."
set "T_96=Si ya lo extrajiste: el antivirus puede haber borrado NexusMonitor.cs."
set "T_97=error al crear el programa"
set "T_98=) a quien te dio NEXUS."
set "T_99=Envía el archivo erro.txt ("
exit /b 0
:nxl_fr
set "K_YN=ON" & set "K_SEC=ICS" & set "K_S1=I" & set "K_S2=C" & set "K_S3=S"
set "T_1=· Installation"
set "T_2=Où veux-tu installer NEXUS Monitor ?"
set "T_3=(NEXUS est déjà installé ici)"
set "T_4=- installer ici"
set "T_5=- choisir un autre dossier (ouvre une fenêtre)"
set "T_6=- saisir le chemin"
set "T_7=Choisis (I/C/S) :"
set "T_8=Ouverture de la fenêtre de choix du dossier..."
set "T_9=Si tu ne la vois pas, fais Alt+Tab ou cherche "NEXUS Monitor" dans la barre des tâches."
set "T_10=Si elle ne s'ouvre pas, ferme-la (ou attends 3 min) et saisis le chemin."
set "T_11=Saisis le dossier d'installation (ex. : D:\Programmes) et appuie sur Entrée."
set "T_12=Entrée vide = retour. Un dossier "NEXUS Monitor" est créé dedans."
set "T_13=Ce dossier ne peut pas être utilisé (dossier Windows, racine du système ou disque inexistant)."
set "T_14=· les réglages sont conservés"
set "T_15=NEXUS Monitor va être réinstallé"
set "T_16=NEXUS Monitor va être installé"
set "T_17=Lit tout seul toutes les températures, ventilateurs et consommations."
set "T_18=Utilise le pilote PawnIO (signé, open source) et demande les droits administrateur."
set "T_19=Certains antivirus et anti-triches de jeux peuvent afficher une alerte."
set "T_20=Emplacement :"
set "T_21=Réglages dans : Documents\NEXUS Monitor"
set "T_22=Raccourcis"
set "T_23=Raccourci dans le menu Démarrer ? (O/N) :"
set "T_24=Raccourci sur le bureau ? (O/N) :"
set "T_25=(facultatifs)"
set "T_26=Extras"
set "T_27=· FPS et latence des jeux"
set "T_28=Intel PresentMon est déjà installé"
set "T_29=· FPS, temps d'image et latence des jeux (~1 Mo)"
set "T_30=Installer ? (O/N) :"
set "T_31=· moteur du Deep Scan"
set "T_32=gdu est déjà installé"
set "T_33=· moteur du Deep Scan, open source (~6 Mo) - ne tourne que quand tu le demandes"
set "T_34=Plugin Stream Deck déjà installé et à jour"
set "T_35=Plugin Stream Deck"
set "T_36=· stats du PC sur les touches"
set "T_37=- seront supprimées à la fin (seule celle du dossier choisi reste) :"
set "T_38=Autres copies de NEXUS sur ce PC"
set "T_39=Ce qu'elles avaient téléchargé passe dans le nouveau dossier. Les réglages sont conservés."
set "T_40=non"
set "T_41=oui"
set "T_42=déjà à jour"
set "T_43=Dossier :"
set "T_44=·   bureau"
set "T_45=Raccourcis : menu Démarrer"
set "T_46=À la fin, l'installateur et les fichiers extraits sont supprimés (ils ne servent plus)."
set "T_47=Installer maintenant ? (O/N) :"
set "T_48=Oui"
set "T_49=Dans l'alerte de Windows, clique sur"
set "T_50=!"
set "T_51=Installation"
set "T_52=.NET Framework 4 introuvable sur ce PC."
set "T_53=Pilote PawnIO"
set "T_54=déjà installé"
set "T_55=installé"
set "T_56=échec - la température du CPU peut manquer"
set "T_57=Fichiers"
set "T_58=impossible de copier vers"
set "T_59=anciens supprimés"
set "T_60=nouveaux/mis à jour,"
set "T_61=déjà présent"
set "T_62=échec du téléchargement - pas d'internet ? relance l'installateur"
set "T_63=téléchargé"
set "T_64=créé"
set "T_65=téléchargement impossible"
set "T_66=téléchargement impossible - tu pourras le télécharger plus tard dans Deep Scan"
set "T_67=Plugin Stream Deck"
set "T_68=déjà à jour"
set "T_69=erreur de création - voir erro_deck.txt"
set "T_70=copie impossible"
set "T_71=Raccourcis"
set "T_72=Applications Windows"
set "T_73=, menu Démarrer"
set "T_74=, bureau"
set "T_75=Nettoyage"
set "T_76=fichiers d'installation supprimés à la fermeture"
set "T_77=échec ^(fichier utilisé ?^)"
set "T_78=copie^(s^) supprimée^(s^),"
set "T_79=autre^(s^) copie^(s^) de NEXUS et fichiers d'installation supprimés"
set "T_80=installé."
set "T_81=✓ Terminé !"
set "T_82=et dans le menu Démarrer."
set "T_83=(icônes cachées ^)"
set "T_84=Il se trouve près de l'horloge"
set "T_85=Options, thèmes, langues, Deep Scan et téléphone en haut de la page."
set "T_86=Stream Deck : cherche la catégorie"
set "T_87=des nouvelles versions."
set "T_88=Pour mettre à jour plus tard, utilise"
set "T_89=Ouverture de NEXUS... cette fenêtre se ferme et supprime les fichiers d'installation."
set "T_90=Annulé - rien n'a été modifié."
set "T_91=[!] Il manque des fichiers dans ce dossier."
set "T_92=As-tu ouvert ce fichier depuis le zip ?"
set "T_93=1. Ferme cette fenêtre."
set "T_94=2. Clic droit sur le zip > "Extraire tout..." > Extraire."
set "T_95=3. Ouvre le dossier extrait et lance INSTALL NEXUS.bat depuis celui-ci."
set "T_96=Si tu l'as déjà extrait : l'antivirus a peut-être supprimé NexusMonitor.cs."
set "T_97=erreur lors de la création du programme"
set "T_98=) à la personne qui t'a donné NEXUS."
set "T_99=Envoie le fichier erro.txt ("
exit /b 0
:nxl_de
set "K_YN=JN" & set "K_SEC=HWE" & set "K_S1=H" & set "K_S2=W" & set "K_S3=E"
set "T_1=· Installation"
set "T_2=Wo soll NEXUS Monitor installiert werden?"
set "T_3=(hier ist NEXUS bereits installiert)"
set "T_4=- hier installieren"
set "T_5=- anderen Ordner wählen (öffnet ein Fenster)"
set "T_6=- Pfad eingeben"
set "T_7=Wähle (H/W/E):"
set "T_8=Ordnerauswahl wird geöffnet..."
set "T_9=Wenn du es nicht siehst, drücke Alt+Tab oder suche "NEXUS Monitor" in der Taskleiste."
set "T_10=Wenn es gar nicht aufgeht, schließe es (oder warte 3 Min.) und gib den Pfad ein."
set "T_11=Gib den Installationsordner ein (z. B. D:\Programme) und drücke Enter."
set "T_12=Leeres Enter = zurück. Darin wird ein Ordner "NEXUS Monitor" erstellt."
set "T_13=Dieser Ordner geht nicht (Windows-Ordner, Systemstamm oder Laufwerk existiert nicht)."
set "T_14=· Einstellungen bleiben erhalten"
set "T_15=NEXUS Monitor wird neu installiert"
set "T_16=NEXUS Monitor wird installiert"
set "T_17=Liest alle Temperaturen, Lüfter und Verbräuche selbst aus."
set "T_18=Nutzt den PawnIO-Treiber (signiert, Open Source) und braucht Adminrechte."
set "T_19=Manche Virenscanner und Anti-Cheats können warnen."
set "T_20=Ort:"
set "T_21=Einstellungen in: Dokumente\NEXUS Monitor"
set "T_22=Verknüpfungen"
set "T_23=Verknüpfung im Startmenü? (J/N):"
set "T_24=Verknüpfung auf dem Desktop? (J/N):"
set "T_25=(optional)"
set "T_26=Extras"
set "T_27=· FPS und Latenz in Spielen"
set "T_28=Intel PresentMon ist bereits installiert"
set "T_29=· FPS, Frametime und Latenz in Spielen (~1 MB)"
set "T_30=Installieren? (J/N):"
set "T_31=· Deep-Scan-Engine"
set "T_32=gdu ist bereits installiert"
set "T_33=· Deep-Scan-Engine, Open Source (~6 MB) - läuft nur auf Wunsch"
set "T_34=Stream-Deck-Plugin bereits installiert und aktuell"
set "T_35=Stream-Deck-Plugin"
set "T_36=· PC-Werte auf den Tasten"
set "T_37=- werden am Ende gelöscht (nur die im gewählten Ordner bleibt):"
set "T_38=Andere NEXUS-Kopien auf diesem PC"
set "T_39=Bereits Heruntergeladenes wandert in den neuen Ordner. Einstellungen bleiben."
set "T_40=nein"
set "T_41=ja"
set "T_42=bereits aktuell"
set "T_43=Ordner:"
set "T_44=·   Desktop"
set "T_45=Verknüpfungen: Startmenü"
set "T_46=Am Ende werden Installer und entpackte Dateien gelöscht (nicht mehr nötig)."
set "T_47=Jetzt installieren? (J/N):"
set "T_48=Ja"
set "T_49=Klicke in der Windows-Abfrage auf"
set "T_50=!"
set "T_51=Installation läuft"
set "T_52=.NET Framework 4 wurde auf diesem PC nicht gefunden."
set "T_53=PawnIO-Treiber"
set "T_54=bereits installiert"
set "T_55=installiert"
set "T_56=fehlgeschlagen - CPU-Temperatur fehlt evtl."
set "T_57=Dateien"
set "T_58=konnte nicht kopieren nach"
set "T_59=alte entfernt"
set "T_60=neu/aktualisiert,"
set "T_61=bereits vorhanden"
set "T_62=Download fehlgeschlagen - kein Internet? Installer erneut starten"
set "T_63=heruntergeladen"
set "T_64=erstellt"
set "T_65=Download nicht möglich"
set "T_66=Download nicht möglich - später im Deep Scan nachholbar"
set "T_67=Stream-Deck-Plugin"
set "T_68=bereits aktuell"
set "T_69=Fehler beim Erstellen - siehe erro_deck.txt"
set "T_70=konnte nicht kopieren"
set "T_71=Verknüpfungen"
set "T_72=Windows-Apps"
set "T_73=, Startmenü"
set "T_74=, Desktop"
set "T_75=Aufräumen"
set "T_76=Installer-Dateien werden beim Schließen gelöscht"
set "T_77=fehlgeschlagen ^(Datei in Benutzung?^)"
set "T_78=Kopie^(n^) gelöscht,"
set "T_79=andere NEXUS-Kopie^(n^) und Installer-Dateien gelöscht"
set "T_80=installiert."
set "T_81=✓ Fertig!"
set "T_82=und im Startmenü."
set "T_83=(ausgeblendete Symbole ^)"
set "T_84=Es sitzt neben der Uhr"
set "T_85=Optionen, Themes, Sprachen, Deep Scan und Handy oben auf der Seite."
set "T_86=Stream Deck: suche die Kategorie"
set "T_87=aus neuen Versionen."
set "T_88=Zum Aktualisieren später nutze"
set "T_89=NEXUS wird geöffnet... dieses Fenster schließt sich und löscht die Installer-Dateien."
set "T_90=Abgebrochen - nichts wurde geändert."
set "T_91=[!] In diesem Ordner fehlen Dateien."
set "T_92=Hast du diese Datei direkt im Zip geöffnet?"
set "T_93=1. Schließe dieses Fenster."
set "T_94=2. Rechtsklick auf das Zip > "Alle extrahieren..." > Extrahieren."
set "T_95=3. Öffne den entpackten Ordner und starte dort INSTALL NEXUS.bat."
set "T_96=Falls schon entpackt: Der Virenscanner hat evtl. NexusMonitor.cs gelöscht."
set "T_97=Fehler beim Erstellen des Programms"
set "T_98=) an die Person, von der du NEXUS hast."
set "T_99=Schicke die Datei erro.txt ("
exit /b 0
