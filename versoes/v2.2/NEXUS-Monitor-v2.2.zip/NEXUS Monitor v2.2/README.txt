NEXUS // MONITOR  v2.2
========================

Real-time system monitor for Windows 10/11 with a futuristic interface in
the browser: CPU, cores, RAM, temperatures, GPU, disks, network, fans,
power, processes and game FPS / latency. Can also be opened on your phone.
Includes Deep Scan (what takes up space on your disks, quick cleanup and a
program uninstaller that leaves nothing behind), the Performance page
(Windows gaming optimizations, debloat and in-game overlay) and a speed test.
Available in Portuguese, English, Spanish, French and German.

Files: README.txt (this one) and CHANGELOG.txt (what changed in each
version). In Portuguese: LEIA-ME.txt and ATUALIZACOES.txt.


INSTALL (normal release)
------------------------
1. Extract the zip (right-click > "Extract All...").
   IMPORTANT: don't run the installer from inside the zip.
2. Open the extracted folder and double-click "INSTALAR NEXUS.bat".
3. Answer the questions (optional extras), check the summary, press S and
   accept the Windows administrator prompt. The rest is automatic.

What the installer does:
   - Asks where to install: by default in
     AppData\Local\Programs\NEXUS Monitor (or wherever NEXUS already is), or
     you pick another folder in a window (E) or type the path (C); a
     "NEXUS Monitor" folder is created inside.
   - Asks whether you want a shortcut in the Start menu and on the desktop.
     It always shows in Settings > Apps (you can also uninstall from
     there).
   - Installs the PawnIO driver (signed, open-source) and downloads
     LibreHardwareMonitor from GitHub - it reads every temperature, fan and
     power sensor by itself. Needs internet the first time.
   - Builds NEXUS Monitor.exe on your own PC.
   - Optional extras:
       . Intel PresentMon - game FPS and latency
       . gdu - Deep Scan engine (disk analyzer, open-source)
       . Stream Deck plugin - only offered if the app is installed
   - Only one copy of NEXUS stays on the PC: if there are others (old
     versions or installs in other folders), it lists them, moves what they
     had already downloaded to the chosen folder and deletes them at the
     end. Your settings stay (they're in Documents).
   - At the end it deletes itself and the files extracted from the zip
     (no longer needed). It only deletes what came in the zip.
   - Your antivirus or some game anti-cheats may warn about the driver.


UPDATE
------
Every new version comes in two zips:
   - "NEXUS Monitor vX.Y" - normal release, for a fresh install;
   - "NEXUS Monitor vX.Y (update)" - only for those who already have NEXUS.

To update: extract the update zip and run "ATUALIZAR NEXUS.bat".
   - Finds where NEXUS is installed by itself and updates it there. No
     questions: just click Yes on the Windows prompt.
   - Closes NEXUS, copies only what changed, deletes what is no longer
     part of the new version, updates the Stream Deck plugin if it changed
     and reopens NEXUS by itself.
   - At the end it deletes itself and the update files.
   - Settings, theme and the phone key stay as they were.

Updating without downloading anything by hand (from 2.1):
   - NEXUS checks github.com/ardersatos/nexus-monitor for new versions
     every 6 hours and lets you know. In Options > General > Updates click
     INSTALL UPDATE: it downloads the right zip, checks it (SHA-256) and
     runs the updater by itself, with no Windows prompt.
   - It only reads a public file on GitHub. Nothing about you or your PC is
     sent. Turn off "Check GitHub for new versions" and NEXUS never
     connects to GitHub.
   - Backup (Options > General): EXPORT saves options, theme, profiles,
     measurements and sessions to a file; IMPORT restores them (e.g. on
     another PC). The phone code is never included.


SETTINGS
--------
Stored in Documents\NEXUS Monitor (settings.ini): options, theme, language
and the phone key. That's why they survive reinstalls and updates, and your
phone stays connected. The key only changes if you press "New code".
The uninstaller asks whether you also want to delete them.
OPTIONS > GENERAL > FOLDERS has buttons to open the settings folder and the folder
where NEXUS is installed.


PERFORMANCE (its own page - PERFORMANCE button at the top)
-----------
Windows gaming optimizations, done by NEXUS itself (registry, services and
power plan), without downloading anything. Everything is off by default.
- The top shows this PC's hardware (processor, graphics card, RAM, drive,
  laptop or desktop) and the optimizations adapt to it: for example, on a
  dual-CCD Ryzen X3D the ones that break the choice of 3D cache cores are
  hidden, on a laptop they only change what happens when plugged in, and
  with integrated graphics others are recommended.
- Each optimization says what it does, the risk (SAFE, MODERATE, ADVANCED),
  whether it needs a restart and the estimated gain on this PC (FPS, fewer
  drops, lower latency...). The gain is a conservative estimate: it varies
  a lot from game to game.
- OPTIMIZE WINDOWS: shows everything that can change; the recommended ones
  are preselected and you remove or add whatever you want.
- Before changing a setting NEXUS saves the original value
  (Documents\NEXUS Monitor\performance_backup.txt). RESTORE puts it back
  exactly as it was. There's also CREATE RESTORE POINT for Windows.
- Windows debloat: privacy and ads (telemetry, suggestions, Bing in Start,
  Copilot, Recall, Widgets...) and the apps that come with Windows (only
  installed ones show up; Store, Xbox, Photos, Calculator, Notepad and
  Terminal are never touched; a removed app can be reinstalled from the
  Microsoft Store).
- On the phone the page is view-only.
- Optimizations stay in Windows even if you uninstall NEXUS: if you want
  Windows back the way it was, press RESTORE before uninstalling.

More on the Performance page:
- Game sessions: when you close a game (over 1 minute) a summary is kept
  with play time, average FPS, worst 1%, peak temperatures and usage.
- Graphics driver: version, date and age, with the official page.
- Power saving (Game boost): idle PC and no game -> Balanced plan; your
  plan comes back when you touch the mouse or keyboard.
- PC REPORT: opens a page with hardware, drivers, disks, tweaks,
  measurements and sessions, to print or save.
- A search box at the top to find a tweak or option.
- GRAPHICS CARD (NVIDIA only): power draw, clock and power limit.
- WINDOWS STARTUP: turn startup programs on/off.
- STABILITY TEST: processor (and RAM) at 100% for 1 to 10 min.
- Per-game profiles have an FPS LIMIT (needs RivaTuner Statistics Server).
- Overlay: "Bottleneck" item (CPU or GPU) and warnings for temperature,
  RAM and FPS drops.
- FANS (Full mode): curves or fixed speed for motherboard fans.
- NETWORK IN GAME: ping and fastest DNS. DRIVERS AND BIOS. REMOTE
  POWER-ON (Wake-on-LAN). YOUR PC VS OTHERS.
- Streaming mode: Alt+Shift+P anytime.
- Automatic cleanup: in Deep Scan, below Quick cleanup.
- Phone notifications: Options > Phone (free ntfy app).

Phone and Discord (Options > Phone):
- After opening the link on the phone: browser menu > "Add to Home screen"
  (works like an app).
- "Control the PC from the phone": buttons for music, volume, overlay, RAM,
  lock, sleep, restart and shut down. The first time, a question appears on
  the PC to accept the phone.
- Discord: shows the game and FPS in your status. Create an application at
  discord.com/developers/applications and paste the Application ID.
- Stream Deck: the sensor list has "NEXUS buttons" (overlay, measure FPS,
  clean RAM, boost, open Performance).

The main page has a HISTORY card (temperatures and usage for the last 1 h,
6 h, 24 h or 7 days, kept 8 days in Documents\NEXUS Monitor\historico).
Deep Scan has DISK HEALTH (SMART via Windows).

Measure FPS:
- Open the game, press MEASURE (with a few seconds to get back to the game)
  or use Alt+Shift+M in game. NEXUS records every frame and calculates
  average FPS, 1% low, 0.1% low, frametime and stutters.
- Mark one measurement as BASE and the others from the same game show the
  difference. To compare well, always play the same part of the game.

Per-game profiles:
- One profile per game (by .exe name): overlay, high priority, maximum
  performance and RAM cleaning can follow the profile instead of the general
  options, and the chosen optimizations are only on while that game is
  open. When you close the game everything goes back.
- Create one by picking a game NEXUS has already detected, or by typing the
  .exe name. Optimizations that need a restart don't appear in profiles.

Game boost (needs game detection on):
- High priority for the game, Ultimate Performance plan while you play and
  RAM cleaning when a game opens. When you leave the game everything goes
  back.

Game detection
  Detects by itself when you open and close a game (fullscreen, borderless
  window covering the screen, Steam/Epic/GOG/Xbox/EA/Ubisoft/Riot/
  Battle.net games, or RivaTuner). While you play, it PAUSES background
  processes that aren't needed: updaters (Google, Edge, Adobe, Java),
  sync (OneDrive, Dropbox, iCloud, Google Drive), Phone Link, Widgets,
  telemetry...
  It never touches apps you opened (Steam, Stream Deck, Spotify, Discord,
  browser, OBS, RGB software...), anything with an open window or Windows
  itself. It doesn't close anything: when you leave the game everything
  carries on where it was.
  In "Background processes" you can remove or add others.

Clean RAM automatically
  When RAM goes above LIMIT % (30 to 98%), asks apps to give back memory
  they aren't using. Never while a game is open. After cleaning it waits
  the time you choose in WAIT before it can clean again.
  The "Clean now" button cleans right away.


IN-GAME OVERLAY (PERFORMANCE page)
---------------
A box over the game with FPS, frametime, latency, CPU, GPU, temperatures,
RAM, game name and time: you choose what shows, the style (list or row),
the size and the opacity. Clicks go through to the game.
- Position: drag the box on the screen preview, use the corner buttons,
  or press MOVE ON SCREEN and drag it on the real screen (double-click or
  Enter to finish).
- Shortcut to show/hide at any time: Alt+Shift+O (can be changed or
  removed). Also in the tray icon menu.
- "Only while playing" shows it by itself when a game opens.
- Works over windowed or borderless games. In exclusive fullscreen Windows
  doesn't allow any window on top: choose "Borderless" in the game's
  display options.


SIMPLE MODE (OPTIONS > GENERAL)
-----------
The first time NEXUS opens it asks whether you want it SIMPLE or FULL.
Simple shows only the essentials: processor, memory, temperatures,
graphics card, processes and, for the network, only download, upload and
the speed test. It hides IPs, cores, fans and technical details.


GAME FPS AND LATENCY (PresentMon)
---------------------------------
PresentMon is a free, open-source Intel tool (~1 MB) that measures the
frames of any game (DirectX, Vulkan, OpenGL) without an overlay and without
injecting anything into the game. You no longer need RivaTuner.

- Only runs while a game is open (fullscreen, borderless window covering
  the screen, Steam/Epic/GOG/Xbox/EA/Ubisoft/Riot/Battle.net game, or seen
  by RivaTuner) and stops 30 s after you close it. Games in a small window
  outside those stores aren't detected.
- The installer downloads it from Intel's GitHub into the NEXUS folder
  ("presentmon" folder). If it's already there, it isn't downloaded again.
- When you open a game, the GAME card shows FPS, frametime, latency,
  average, minimum and maximum. You can also put it on the Stream Deck.
- Works right away, no setup needed.
- If PresentMon isn't available and RivaTuner is open, NEXUS uses RivaTuner
  instead (FPS only, no latency).
- "Latency" is the time from when the game starts a frame until it shows
  on screen (depends on the graphics card and the game; some don't report
  it).


ALERTS (OPTIONS > ALERTS)
-------------------------
You choose the limits for CPU and GPU temperature and RAM usage, and how
long the alert stays on screen: OUTSIDE GAMES (20 s by default) and IN GAME
(12 s by default), from 3 to 300 s, and how transparent it is in each case
(while you move the slider, the alert shows in the corner of the screen so
you can see how it looks). When one goes over the limit:
   - a NEXUS notification appears in the corner of the screen, on top of
     everything (including borderless-window games). During a game it's
     half transparent (55% by default) and clicks go through to the game. Outside games,
     clicking it opens the monitor;
   - the page shows a pulsing red bar at the top, the related card blinks
     and the tab title also warns you;
   - on the Stream Deck, the key of the sensor in alert gets a slowly
     pulsing outline and the other NEXUS keys show a small warning sign.
Exclusive fullscreen games don't let anything appear on top - then only
the Stream Deck and the phone show the alert.


PHONE
-----
1. The PC and the phone must be on the same Wi-Fi / router.
2. On the PC open NEXUS > OPTIONS > PHONE and turn on "Open on the phone".
   Windows may ask for administrator to open port 8765 in the firewall.
3. Point the phone camera at the QR code (or type the address).
   The link has a secret key - only whoever has it can get in.
4. "New code" revokes every phone that had access.
5. The phone is remembered: even after closing the browser or days later,
   it gets back in by itself (until you press "New code").

Notes:
- The Windows network must be set to "Private" (Settings > Network &
  Internet > your connection > Network profile type > Private).
- Theme, custom colours, private mode, refresh speed and options stay IN
  SYNC: change them on the phone and the PC follows (and vice versa).
- Phone access (on/off, new code) can only be changed on the PC.
- Turning access off closes the port right away.


STREAM DECK (optional)
----------------------
After installing, in the Stream Deck app look for the "NEXUS Monitor"
category and drag "Estatistica do PC" onto a key. For each key you choose:

  SENSOR - every one NEXUS reads on your PC, in groups:
    Processor (usage, temperature, hottest core, frequency, power)
    Graphics card (usage, temperature, VRAM, power, CPU+GPU)
    Memory (RAM %, RAM in GB, virtual memory)
    Game (FPS, frametime, latency)
    Network (download, upload) and Disks (read, write, space of each disk)
    System (processes, uptime, clock, battery)
    Temperatures (every sensor: motherboard, disks, each core...)
    Fans (each one) and usage of each CPU thread
  STYLE - Graph (value + ~50 s history), Ring (dial) or Number (big).
          Futuristic look, in the theme colours.

The sensor name always shows at the top of the key. Colours follow the
theme and the language follows the one chosen in the browser on the PC.
Pressing the key opens the monitor (or starts NEXUS if it's closed).
Open NEXUS before setting up keys so you can see every sensor.

Already have NEXUS and only want the plugin? Run
"INSTALAR ADDON STREAM DECK.bat" (it's also in the NEXUS folder).
If the PC doesn't have the Stream Deck, the installer and updater don't
keep its files in the NEXUS folder: if you install it later, run the
normal release installer again.


SIGNALRGB (optional - only shows if you have SignalRGB)
--------------------------------------------------------
OPTIONS > SIGNALRGB > "SignalRGB colours": NEXUS's main and secondary
colours follow the effect playing in SignalRGB, in real time (on the
pages, the tray menu and icon, and the Stream Deck).
- When you turn it on, NEXUS puts its plugin in Documents\WhirlwindFX\
  Plugins. If needed, close and reopen SignalRGB once: "NEXUS Monitor"
  must show up in Devices and in the Layout.
- Colour delay: 0 ms follows the effect instantly; higher is smoother.
- Only works while something from NEXUS is on screen (a page, the tray
  menu or keys on the Stream Deck).
- Works with free SignalRGB. The plugin stays on this PC only: it sends
  the colours only to 127.0.0.1 and doesn't use the internet.


DEEP SCAN (disk analyzer)
-------------------------
DEEP SCAN button at the top (or in the tray icon menu). Uses gdu
(open-source, MIT), which only runs when you press SCAN and closes by
itself when done.

- Pick a disk or type a folder: disk map, file types, contents of each
  folder and the largest files.
- Navigate: BACK, UP, START (also Backspace and the mouse back button).
  Clicking a folder opens it.
- Right-click a file/folder: open in Explorer, move to the Recycle Bin or
  delete permanently (with a warning that it can't be recovered).
- Important folders: NEXUS explains the possible effects before deleting.
  Folders that would break Windows (Windows, drive root, Program Files,
  AppData, user profile, boot files) are blocked; the others ask for
  "I understand the risks".
- Hidden files: only what YOU hid shows up censored (no name, can't be
  opened or deleted). What Windows and programs hide shows normally. To
  show everything: OPTIONS > PRIVACY > Show hidden files (PC only).
- QUICK CLEANUP: shows right away how much it frees on this PC and cleans
  with 1 click: temporary files, Recycle Bin, Windows Update cache,
  graphics card shader cache, thumbnails, error reports and old logs.
  Files in use are kept.
- UNINSTALL PROGRAMS: lists what's installed (and Store apps, if you want),
  with search and sorting by name, size or date.
    1. Pick one or several and press UNINSTALL (silent mode = no windows,
       when the program allows it).
    2. Runs the program's own uninstaller. Steam games and other
       launchers: confirm in their window, NEXUS waits until it's done.
    3. Then looks for leftovers: folders, shortcuts, registry, startup,
       services, scheduled tasks and firewall. What surely belongs to the
       program is ticked; the rest shows as CHECK (look first).
    4. Files go to the Recycle Bin and the registry is backed up to .reg in
       Documents\NEXUS Monitor\Backups do desinstalador (with a
       registo.txt of what was done). To restore a key, open the .reg.
  FORCED REMOVAL: for programs with a broken uninstaller - doesn't run the
  uninstaller, only finds and deletes the leftovers.
  Never touches Windows, other programs' folders or NEXUS itself.
- Deleting, cleaning and uninstalling only work on the PC (they don't
  even show on the phone).


SPEED TEST (NETWORK card)
-------------------------
TEST SPEED button: download, upload and latency (idle and under load)
with the nearest Cloudflare server. Only runs when you press it and uses a
few hundred MB of data. The last result is kept.


WHAT'S NEW AND TUTORIAL
-----------------------
- WHAT'S NEW button at the top: what changed in each version (a dot
  lights up when there's something new).
- The tutorial shows the first time you open NEXUS (PC or phone). To see
  it again: OPTIONS > GENERAL > "Show the tutorial again".


CONTROLLER (controller tester)
------------------------------
On the PERFORMANCE page, CONTROLLER card (also "Test controller" in the tray
icon menu). It only runs once you reach that card and a controller is
connected. Headsets and other devices the browser lists as controllers are
hidden (you can show them).
   - The drawing changes with the controller: Xbox, PlayStation or
     Nintendo, with the right button names.
   - Sticks with a trail and adjustable dead zone, triggers in %, every
     button with a press count (tested ones turn green) and every axis.
   - Tests: DRIFT (let go of the sticks: measures how much they move on
     their own) and CIRCULARITY (rotate the sticks on the edge: shows the
     shape and the error).
   - Vibration: weak motor, strong motor and triggers, with strength and
     duration. If the browser can't do it, NEXUS vibrates the controller
     directly on the PC: Xbox and XInput controllers (most PC ones) and
     DualShock 4 / DualSense (USB and Bluetooth).
   - Polling: how many readings per second reach the browser.
Works on the PC (localhost). The browser only sees the controller after
you press a button.

LANGUAGES
---------
OPTIONS > APPEARANCE > LANGUAGE: Automatic (Windows / phone language), Portugues,
English, Espanol, Francais, Deutsch. Changes the page, Deep Scan, the tray
icon menu and panel, notifications and the Stream Deck keys.


USING IT
--------
- NEXUS sits next to the clock (hidden icons ^). The icon changes colour
  with the theme.
  Mouse over it: panel with CPU, RAM, GPU and game, updated every second.
  Left click: opens the monitor (if it's already open, brings that window
  to the front instead of opening another).
  Right click: CPU, RAM, GPU and game at a glance, toggles the options
  (startup, alerts, RAM cleaning, game detection, phone), changes the
  theme, "Clean RAM now" and Quit.
- At the top of the page:
    DEEP SCAN -> disk analyzer, quick cleanup and program uninstaller
    PERFORMANCE -> gaming optimizations, boost, RAM, overlay and debloat
    WHAT'S NEW -> what changed in each version
    OPTIONS  -> in tabs: APPEARANCE (theme, colours and language),
                GENERAL (simple mode, start with Windows, start minimised,
                open as administrator without prompt,
                blur personal data (IP, MAC, PC name),
                hide network data, show hidden files,
                refresh speed (0.1 to 10 s; 0.1 and 0.25 s are shown in
                red because they use more CPU),
                CPU / GPU temperature and RAM usage alerts,
                phone access (QR code),
                SignalRGB (if you have it), show the tutorial again, folders)
    (button) -> shut down NEXUS
- Processes: sort by CPU or by memory.


UNINSTALL
---------
Settings > Apps > NEXUS Monitor > Uninstall (or "DESINSTALAR NEXUS.bat" in
the NEXUS folder). Shows what will be removed, asks whether to also remove
the PawnIO driver and the settings (Documents\NEXUS Monitor) and then:
closes NEXUS and PresentMon (resuming paused processes), removes startup,
the firewall rule, the shortcut, the Apps entry, the Stream Deck plugin
(and the settings, if you chose so) and deletes the NEXUS folder.


TROUBLESHOOTING
---------------
- Error CS2001 when installing: you didn't extract the zip. See step 1.
- "NEXUS is not installed" when updating: the update is only for those who
  already have NEXUS - use the normal release.
- Blue "Windows protected your PC" warning: More info > Run anyway.
- No CPU temperature: run the installer again with internet
  (LibreHardwareMonitor is downloaded during installation).
- The GAME card shows a program that isn't a game (e.g. animated
  wallpaper): the program with the most frames is shown; once you open the
  game it switches to it.
- Phone won't open: same network? Windows network set to "Private"? Access
  turned on in OPTIONS? Try "New code" and scan the QR again.
- Stream Deck key shows "OFF": NEXUS is closed - press it.
