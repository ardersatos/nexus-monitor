﻿// NEXUS // MONITOR - leitura dos sensores (CPU, GPU, RAM, discos, rede), FPS dos jogos (PresentMon / RivaTuner) e ficheiros embutidos
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Linq;
using System.Management;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Reflection;
using System.Security.Principal;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Win32;

namespace Nexus
{

    static class Stats
    {
        // ------------------------------------------------------------ Win32 / PDH
        [DllImport("pdh.dll", CharSet = CharSet.Unicode)]
        static extern int PdhOpenQuery(string src, IntPtr user, out IntPtr query);
        [DllImport("pdh.dll", CharSet = CharSet.Unicode)]
        static extern int PdhAddEnglishCounter(IntPtr query, string path, IntPtr user, out IntPtr counter);
        [DllImport("pdh.dll")]
        static extern int PdhCollectQueryData(IntPtr query);
        [DllImport("pdh.dll", CharSet = CharSet.Unicode)]
        static extern int PdhGetFormattedCounterArray(IntPtr counter, uint fmt, ref uint size, out uint count, IntPtr buf);
        [DllImport("pdh.dll")]
        static extern int PdhGetFormattedCounterValue(IntPtr counter, uint fmt, IntPtr type, out PDH_VALUE value);

        [StructLayout(LayoutKind.Sequential)]
        struct PDH_VALUE { public uint CStatus; public double Value; }

        [StructLayout(LayoutKind.Sequential)]
        class MEMSTATUS
        {
            public uint dwLength = 64;
            public uint dwMemoryLoad;
            public ulong ullTotalPhys, ullAvailPhys, ullTotalPageFile, ullAvailPageFile,
                         ullTotalVirtual, ullAvailVirtual, ullAvailExtendedVirtual;
        }
        [DllImport("kernel32.dll")]
        static extern bool GlobalMemoryStatusEx([In, Out] MEMSTATUS m);
        [DllImport("kernel32.dll")]
        static extern ulong GetTickCount64();

        [StructLayout(LayoutKind.Sequential)]
        struct POWER { public byte AC, Flag, Percent, Saver; public int LifeTime, FullLifeTime; }
        [DllImport("kernel32.dll")]
        static extern bool GetSystemPowerStatus(out POWER p);

        const uint FMT = 0x200 | 0x1000; // DOUBLE | NOCAP100

        static readonly object sync = new object();
        static IntPtr query, cCpu, cRead, cWrite;

        // info estática
        static string hostname, os, arch, cpuModel, runtime;
        static int coresLogical;
        static int? coresPhysical, freqMhz;

        // estado entre leituras
        static DateTime lastNetT = DateTime.MinValue;
        static DateTime lastPdhT = DateTime.MinValue;
        static double[] pdhCores; static double pdhTotal, pdhRead, pdhWrite;
        static double cacheUp, cacheDown;
        static long lastSent, lastRecv;
        static DateTime lastProcT = DateTime.MinValue;
        static Dictionary<int, long> lastProc = new Dictionary<int, long>();

        // sensores lentos
        static Dictionary<string, double> temps = new Dictionary<string, double>();
        static string gpuJson = null;
        static double? gpuTemp = null, gpuUtil = null;
        static long pfTotal = -1, pfUsed = 0;
        // sensores externos (HWiNFO / LibreHardwareMonitor)
        static Dictionary<string, double> hwTemps = new Dictionary<string, double>();
        static List<KeyValuePair<string, double>> hwFans = new List<KeyValuePair<string, double>>();
        static double? cpuTemp = null, cpuPower = null, cpuClock = null;
        static double? cpuPkg = null, cpuMax = null, cpuAvg = null;

        public static void AlertSnapshot(out double? cpuT, out double? gpuT, out double ramPct)
        {
            lock (sync)
            {
                cpuT = cpuPkg ?? cpuTemp;
                gpuT = gpuTemp;
            }
            MEMSTATUS m = new MEMSTATUS();
            GlobalMemoryStatusEx(m);
            ramPct = m.ullTotalPhys > 0 ? (m.ullTotalPhys - m.ullAvailPhys) * 100.0 / m.ullTotalPhys : 0;
        }
        static double[] cpuCoreTemps = new double[0];
        static List<KeyValuePair<int, double>> cpuCcds = new List<KeyValuePair<int, double>>();   // AMD Ryzen: temperatura por CCD (não há por núcleo)
        static readonly System.Text.RegularExpressions.Regex CcdRe = new System.Text.RegularExpressions.Regex(@"^CCD\s*#?\s*(\d+)\b", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
        static string sensorSource = null;
        static string sensorDebug = "";
        static string gpuName = null;

        public static void Init()
        {
            try
            {
                if (PdhOpenQuery(null, IntPtr.Zero, out query) == 0)
                {
                    if (PdhAddEnglishCounter(query, "\\Processor Information(*)\\% Processor Utility", IntPtr.Zero, out cCpu) != 0)
                        PdhAddEnglishCounter(query, "\\Processor(*)\\% Processor Time", IntPtr.Zero, out cCpu);
                    PdhAddEnglishCounter(query, "\\PhysicalDisk(_Total)\\Disk Read Bytes/sec", IntPtr.Zero, out cRead);
                    PdhAddEnglishCounter(query, "\\PhysicalDisk(_Total)\\Disk Write Bytes/sec", IntPtr.Zero, out cWrite);
                    PdhCollectQueryData(query);
                }
            }
            catch { }

            hostname = Environment.MachineName;
            arch = Environment.Is64BitOperatingSystem ? "AMD64" : "x86";
            runtime = ".NET " + Environment.Version;
            coresLogical = Environment.ProcessorCount;

            os = "Windows";
            try
            {
                using (RegistryKey k = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion"))
                {
                    string product = (k.GetValue("ProductName") ?? "Windows").ToString();
                    int build;
                    if (int.TryParse((k.GetValue("CurrentBuildNumber") ?? "0").ToString(), out build) && build >= 22000)
                        product = product.Replace("Windows 10", "Windows 11");
                    string disp = (k.GetValue("DisplayVersion") ?? "").ToString();
                    os = product + (disp.Length > 0 ? " " + disp : "");
                }
            }
            catch { }

            cpuModel = "CPU";
            try
            {
                using (RegistryKey k = Registry.LocalMachine.OpenSubKey(@"HARDWARE\DESCRIPTION\System\CentralProcessor\0"))
                {
                    cpuModel = (k.GetValue("ProcessorNameString") ?? "CPU").ToString().Trim();
                    object mhz = k.GetValue("~MHz");
                    if (mhz != null) freqMhz = Convert.ToInt32(mhz);
                }
            }
            catch { }

            try
            {
                using (ManagementObjectSearcher s = new ManagementObjectSearcher("SELECT NumberOfCores FROM Win32_Processor"))
                {
                    int n = 0;
                    foreach (ManagementObject mo in s.Get()) n += Convert.ToInt32(mo["NumberOfCores"]);
                    if (n > 0) coresPhysical = n;
                }
            }
            catch { }

            lock (sync) { Collect(); }   // primeira leitura serve de referência
        }

        // ------------------------------------------------------------ sensores lentos
        public static void SlowLoop()
        {
            bool tryWmi = true;
            Thread gt = new Thread(GpuLoop); gt.IsBackground = true; gt.Start();
            while (true)
            {
                if (tryWmi)
                {
                    Dictionary<string, double> t = ReadWmiTemps();
                    tryWmi = t.Count > 0;
                    lock (sync) { temps = t; }
                }
                ReadPageFile();
                ReadExternalSensors();
                Thread.Sleep(2000);
            }
        }

        static Dictionary<string, double> ReadWmiTemps()
        {
            Dictionary<string, double> t = new Dictionary<string, double>();
            try
            {
                using (ManagementObjectSearcher s = new ManagementObjectSearcher(@"root\WMI", "SELECT CurrentTemperature FROM MSAcpi_ThermalZoneTemperature"))
                {
                    int i = 0;
                    foreach (ManagementObject mo in s.Get())
                    {
                        double c = Convert.ToDouble(mo["CurrentTemperature"]) / 10.0 - 273.15;
                        if (c > 0 && c < 130) t["Zona térmica " + i] = Math.Round(c, 1);
                        i++;
                    }
                }
            }
            catch { }
            return t;
        }

        // ------------------------------------------------------------ HWiNFO / LibreHardwareMonitor
        internal class HwData
        {
            public Dictionary<string, double> Temps = new Dictionary<string, double>();
            public List<KeyValuePair<string, double>> Fans = new List<KeyValuePair<string, double>>();
            public double? CpuTemp, CpuPower, CpuClock;
            public double? Package, CoreMax, CoreAvg;
            public SortedDictionary<int, double> Cores = new SortedDictionary<int, double>();
        }

        static void ReadExternalSensors()
        {
            HwData d = null;
            string src = null;
            hwDbg = "";
            if (Program.FullMode)
            {
                try { d = Embedded.Read(); if (d != null) src = "NEXUS Completo"; }
                catch (Exception ex) { d = null; hwDbg = "completo: " + ex.GetType().Name + " " + ex.Message + " | "; }
            }
            if (d == null) try { d = ReadHwinfo(); if (d != null) src = "HWiNFO"; } catch (Exception ex) { d = null; hwDbg = "hwinfo erro: " + ex.Message; }
            if (d == null)
            {
                try { d = ReadLhm(); if (d != null) src = "LibreHardwareMonitor"; } catch (Exception ex) { d = null; hwDbg += " | lhm: " + ex.Message.Trim(); }
            }
            lock (sync)
            {
                sensorDebug = hwDbg;
                if (d == null)
                {
                    hwTemps = new Dictionary<string, double>();
                    hwFans = new List<KeyValuePair<string, double>>();
                    cpuTemp = cpuPower = cpuClock = null;
                    cpuPkg = cpuMax = cpuAvg = null; cpuCoreTemps = new double[0]; cpuCcds = new List<KeyValuePair<int, double>>();
                    sensorSource = null;
                }
                else
                {
                    hwTemps = d.Temps; hwFans = d.Fans;
                    cpuTemp = d.CpuTemp; cpuPower = d.CpuPower; cpuClock = d.CpuClock;
                    cpuPkg = d.Package; cpuMax = d.CoreMax; cpuAvg = d.CoreAvg;
                    cpuCoreTemps = d.Cores.Values.Select(x => Math.Round(x, 1)).ToArray();
                    List<KeyValuePair<int, double>> cc = new List<KeyValuePair<int, double>>();
                    foreach (KeyValuePair<string, double> t in d.Temps)
                    {
                        System.Text.RegularExpressions.Match m = CcdRe.Match(t.Key.Trim());
                        int n;
                        if (m.Success && int.TryParse(m.Groups[1].Value, out n) && !cc.Any(x => x.Key == n)) cc.Add(new KeyValuePair<int, double>(n, Math.Round(t.Value, 1)));
                    }
                    cpuCcds = cc.OrderBy(x => x.Key).ToList();
                    sensorSource = src;
                }
            }
        }

        internal static readonly string[] CpuTempPriority = {
            "CPU Package", "CPU (Tctl/Tdie)", "CPU Die (average)", "Core Max", "CPU Die", "Core (Tctl/Tdie)", "Core Average", "CPU"
        };

        static readonly System.Text.RegularExpressions.Regex CoreRe = new System.Text.RegularExpressions.Regex(
            @"^(?:CPU )?(?:[PE]-)?Core ?#?(\d+)$", System.Text.RegularExpressions.RegexOptions.IgnoreCase);

        internal static void CpuTempLabel(HwData d, string label, double v)
        {
            if (v <= 0 || v > 150) return;
            string l = label.Trim();
            if ((l == "CPU Package" || l == "CPU (Tctl/Tdie)" || l == "Core (Tctl/Tdie)") && !d.Package.HasValue) d.Package = Math.Round(v, 1);
            else if (l == "Core Max" && !d.CoreMax.HasValue) d.CoreMax = Math.Round(v, 1);
            else if ((l == "Core Average" || l == "CPU Die (average)") && !d.CoreAvg.HasValue) d.CoreAvg = Math.Round(v, 1);
            else
            {
                System.Text.RegularExpressions.Match m = CoreRe.Match(l);
                if (m.Success)
                {
                    int i = int.Parse(m.Groups[1].Value);
                    if (!d.Cores.ContainsKey(i)) d.Cores[i] = v;
                }
            }
        }

        internal static void FinishCpu(HwData d)
        {
            if (d.Cores.Count > 0)
            {
                if (!d.CoreMax.HasValue) d.CoreMax = Math.Round(d.Cores.Values.Max(), 1);
                if (!d.CoreAvg.HasValue) d.CoreAvg = Math.Round(d.Cores.Values.Average(), 1);
            }
            if (!d.Package.HasValue && d.CpuTemp.HasValue) d.Package = d.CpuTemp;
        }

        internal static bool SkipTempLabel(string l)
        {
            string x = l.ToLowerInvariant();
            if (x.Contains("distance to tjmax") || x.Contains("tjmax") || x.Contains("throttl") || x.Contains("limit")) return true;
            if (x.StartsWith("gpu temperature")) return true;                    // já vem do nvidia-smi
            if (System.Text.RegularExpressions.Regex.IsMatch(x, @"^gpu memory [a-z]\d")) return true; // chips de memória individuais
            // núcleos individuais: "Core 0", "P-core 3", "E-core 1", "Core #2", "CPU Core #1"
            System.Text.RegularExpressions.Regex re = new System.Text.RegularExpressions.Regex(
                @"^(cpu )?([pe]-)?core ?#?\d+", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            return re.IsMatch(l.Trim());
        }

        static bool IsGenericLabel(string l)
        {
            string x = l.ToLowerInvariant();
            return x.StartsWith("temperature") || x.StartsWith("drive") || x == "temp" || x.StartsWith("temp") ||
                   x.StartsWith("hot spot") || x.StartsWith("memory");
        }

        internal static void AddTemp(HwData d, string key, double v)
        {
            if (v <= 0 || v > 150 || d.Temps.Count >= 24) return;
            if (d.Temps.ContainsKey(key)) return;
            d.Temps[key] = Math.Round(v, 1);
        }

        internal static string ShortHw(string s)
        {
            if (s == null) return "";
            int p = s.IndexOf(':');
            if (p > 0 && p < s.Length - 1) s = s.Substring(p + 1).Trim();
            int q = s.IndexOf(" (");
            if (q > 0) s = s.Substring(0, q);
            s = s.Trim().TrimEnd(':').Trim();
            return s.Length > 26 ? s.Substring(0, 26) : s;
        }

        static string ReadStr(MemoryMappedViewAccessor a, long pos, int len)
        {
            byte[] b = new byte[len];
            a.ReadArray(pos, b, 0, len);
            int z = Array.IndexOf(b, (byte)0);
            return Encoding.Default.GetString(b, 0, z < 0 ? len : z).Trim();
        }

        static HwData ReadHwinfo()
        {
            MemoryMappedFile mmf;
            try { mmf = MemoryMappedFile.OpenExisting("Global\\HWiNFO_SENS_SM2", MemoryMappedFileRights.Read); }
            catch (Exception ex) { hwDbg = "hwinfo: " + ex.GetType().Name + " " + ex.Message; return null; }
            using (mmf)
            using (MemoryMappedViewAccessor a = mmf.CreateViewAccessor(0, 0, MemoryMappedFileAccess.Read))
            {
                uint sig = a.ReadUInt32(0);
                if (sig == 0x44414544) { hwDbg = "hwinfo: shared memory desativada (DEAD)"; return null; }
                if (sig != 0x48576953 && sig != 0x53695748) { hwDbg = "hwinfo: assinatura 0x" + sig.ToString("X8"); return null; }
                long offS = a.ReadUInt32(20), sizeS = a.ReadUInt32(24), numS = a.ReadUInt32(28);
                long offR = a.ReadUInt32(32), sizeR = a.ReadUInt32(36), numR = a.ReadUInt32(40);
                if (numR == 0 || sizeR < 316) { hwDbg = "hwinfo: numR=" + numR + " sizeR=" + sizeR; return null; }

                string[] sensors = new string[numS];
                for (long i = 0; i < numS; i++)
                {
                    long b = offS + i * sizeS;
                    string user = ReadStr(a, b + 8 + 128, 128);
                    sensors[i] = user.Length > 0 ? user : ReadStr(a, b + 8, 128);
                }

                HwData d = new HwData();
                Dictionary<string, double> cpuCands = new Dictionary<string, double>();
                for (long i = 0; i < numR; i++)
                {
                    long b = offR + i * sizeR;
                    uint type = a.ReadUInt32(b);
                    uint sIdx = a.ReadUInt32(b + 4);
                    string label = ReadStr(a, b + 140, 128);
                    if (label.Length == 0) label = ReadStr(a, b + 12, 128);
                    double v = a.ReadDouble(b + 284);
                    string sensor = sIdx < sensors.Length ? sensors[sIdx] : "";
                    bool isCpuSensor = sensor.StartsWith("CPU") || sensor.Contains("Intel") || sensor.Contains("AMD Ryzen");

                    if (type == 1) // temperatura
                    {
                        if (isCpuSensor && !cpuCands.ContainsKey(label)) cpuCands[label] = v;
                        if (isCpuSensor) CpuTempLabel(d, label, v);
                        if (SkipTempLabel(label)) continue;
                        if (sensor.StartsWith("GPU") && label.StartsWith("GPU Temperature")) continue; // já vem do nvidia-smi
                        string clean = label;
                        int cut = clean.IndexOf(" (");
                        if (cut > 0) clean = clean.Substring(0, cut);
                        string key;
                        if (clean.StartsWith("Drive") && sensor.Length > 0) key = "Disco · " + ShortHw(sensor);
                        else if (IsGenericLabel(clean) && sensor.Length > 0) key = ShortHw(sensor) + " · " + clean;
                        else key = clean;
                        AddTemp(d, key, v);
                    }
                    else if (type == 3) // ventoinha
                    {
                        string unit = ReadStr(a, b + 268, 16).ToUpperInvariant();
                        double rpm = -1;
                        if (unit == "RPM") rpm = v;
                        else if (unit == "CPM") rpm = v * 100;   // centenas de rotações por minuto
                        if (rpm >= 0 && d.Fans.Count < 12 && !d.Fans.Any(f => f.Key == label))
                            d.Fans.Add(new KeyValuePair<string, double>(label, rpm));
                    }
                    else if (type == 5) // potência
                    {
                        if (!d.CpuPower.HasValue && label.StartsWith("CPU Package Power")) d.CpuPower = v;
                    }
                    else if (type == 6) // relógio
                    {
                        if (!d.CpuClock.HasValue && isCpuSensor &&
                            (label.StartsWith("Core Clocks (avg)") || label.StartsWith("Average Effective Clock") || label == "Core 0 Clock"))
                            d.CpuClock = v;
                    }
                }
                foreach (string pr in CpuTempPriority)
                {
                    double cv;
                    if (cpuCands.TryGetValue(pr, out cv) && cv > 0 && cv < 150) { d.CpuTemp = Math.Round(cv, 1); break; }
                }
                hwDbg = "hwinfo: ok " + numS + " sensores, " + numR + " leituras";
                Stats.FinishCpu(d);
            return (d.Temps.Count > 0 || d.Fans.Count > 0) ? d : null;
            }
        }

        static string hwDbg = "";

        static HwData ReadLhm()
        {
            Dictionary<string, string> hwNames = new Dictionary<string, string>();
            Dictionary<string, string> hwTypes = new Dictionary<string, string>();
            using (ManagementObjectSearcher s = new ManagementObjectSearcher(@"root\LibreHardwareMonitor", "SELECT Identifier, Name, HardwareType FROM Hardware"))
            {
                foreach (ManagementObject mo in s.Get())
                {
                    string id = Convert.ToString(mo["Identifier"]);
                    hwNames[id] = Convert.ToString(mo["Name"]);
                    hwTypes[id] = Convert.ToString(mo["HardwareType"]);
                }
            }
            if (hwNames.Count == 0) return null;
            HwData d = new HwData();
            Dictionary<string, double> cpuCands = new Dictionary<string, double>();
            using (ManagementObjectSearcher s = new ManagementObjectSearcher(@"root\LibreHardwareMonitor", "SELECT Name, SensorType, Value, Parent FROM Sensor"))
            {
                foreach (ManagementObject mo in s.Get())
                {
                    string name = Convert.ToString(mo["Name"]);
                    string type = Convert.ToString(mo["SensorType"]);
                    string parent = Convert.ToString(mo["Parent"]);
                    double v = Convert.ToDouble(mo["Value"]);
                    string hwType, hwName;
                    hwTypes.TryGetValue(parent, out hwType);
                    hwNames.TryGetValue(parent, out hwName);
                    bool isCpu = (hwType ?? "").IndexOf("Cpu", StringComparison.OrdinalIgnoreCase) >= 0;
                    bool isGpu = (hwType ?? "").IndexOf("Gpu", StringComparison.OrdinalIgnoreCase) >= 0;

                    if (type == "Temperature")
                    {
                        if (isCpu) { cpuCands[name] = v; Stats.CpuTempLabel(d, name, v); }
                        if (isGpu && name == "GPU Core") continue;
                        if (SkipTempLabel(name)) continue;
                        string key = isCpu ? "CPU · " + name : ShortHw(hwName) + " · " + name;
                        AddTemp(d, key, v);
                    }
                    else if (type == "Fan")
                    {
                        if (v > 0 && d.Fans.Count < 12) d.Fans.Add(new KeyValuePair<string, double>(name, v));
                    }
                    else if (type == "Power")
                    {
                        if (isCpu && name == "CPU Package" && !d.CpuPower.HasValue) d.CpuPower = v;
                    }
                }
            }
            foreach (string pr in CpuTempPriority)
            {
                double cv;
                if (cpuCands.TryGetValue(pr, out cv) && cv > 0 && cv < 150) { d.CpuTemp = Math.Round(cv, 1); break; }
            }
            Stats.FinishCpu(d);
            return (d.Temps.Count > 0 || d.Fans.Count > 0) ? d : null;
        }

        static void ReadPageFile()
        {
            try
            {
                long total = 0, used = 0;
                using (ManagementObjectSearcher s = new ManagementObjectSearcher("SELECT AllocatedBaseSize, CurrentUsage FROM Win32_PageFileUsage"))
                {
                    foreach (ManagementObject mo in s.Get())
                    {
                        total += Convert.ToInt64(mo["AllocatedBaseSize"]) * 1048576L;
                        used += Convert.ToInt64(mo["CurrentUsage"]) * 1048576L;
                    }
                }
                lock (sync) { pfTotal = total; pfUsed = used; }
            }
            catch { }
        }

        // GPU NVIDIA: o nvidia-smi fica a correr e envia uma linha a cada 2 s
        // (antes era lançado um programa novo a cada leitura)
        // Só corre enquanto a GPU está à vista (página aberta, painel/menu do ícone, tecla de GPU na Stream Deck).
        // Fora disso, se os alertas estiverem ligados, faz só uma leitura rápida a cada 30 s.
        static Process gpuProc;
        static long gpuDemandTicks;
        public static volatile bool GpuIdle = true;
        public static void WantGpu() { Interlocked.Exchange(ref gpuDemandTicks, DateTime.UtcNow.Ticks); }
        static bool GpuWanted { get { return DateTime.UtcNow.Ticks - Interlocked.Read(ref gpuDemandTicks) < TimeSpan.FromSeconds(6).Ticks; } }
        public static void StopGpu() { try { if (gpuProc != null && !gpuProc.HasExited) gpuProc.Kill(); } catch { } }

        static void GpuLoop()
        {
            string exe = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "nvidia-smi.exe");
            if (!File.Exists(exe)) exe = "nvidia-smi";
            const string Q = "--query-gpu=name,utilization.gpu,temperature.gpu,memory.used,memory.total,power.draw --format=csv,noheader,nounits";
            int fails = 0;
            DateTime lastSample = DateTime.MinValue;
            bool first = true;
            while (!Program.Quitting && fails < 3)
            {
                bool live = GpuWanted;
                bool sample = first || (!live && AppSettings.Alerts && DateTime.UtcNow - lastSample > TimeSpan.FromSeconds(30));
                if (!live && !sample) { GpuIdle = true; Thread.Sleep(500); continue; }
                first = false;
                bool got = false;
                try
                {
                    ProcessStartInfo psi = new ProcessStartInfo(exe, live ? Q + " -lms 2000" : Q);
                    psi.UseShellExecute = false; psi.CreateNoWindow = true; psi.RedirectStandardOutput = true;
                    GpuIdle = !live;
                    gpuProc = Process.Start(psi);
                    string line;
                    while ((line = gpuProc.StandardOutput.ReadLine()) != null)
                    {
                        if (ParseGpuLine(line)) { got = true; fails = 0; }
                        if (live && !GpuWanted) { StopGpu(); break; }   // ninguém está a ver: desliga
                    }
                    try { gpuProc.WaitForExit(1000); } catch { }
                }
                catch { }
                lastSample = DateTime.UtcNow;
                GpuIdle = true;
                if (!got) { fails++; Thread.Sleep(10000); }   // sem NVIDIA: desiste depois de 3 tentativas
            }
        }

        static bool ParseGpuLine(string first)
        {
            if (string.IsNullOrWhiteSpace(first)) return false;
            string[] f = first.Split(',').Select(x => x.Trim()).ToArray();
            if (f.Length < 6) return false;
            double? util = ParseD(f[1]), temp = ParseD(f[2]), mu = ParseD(f[3]), mt = ParseD(f[4]), pw = ParseD(f[5]);
            string js = "{\"name\":" + Str(f[0]) + ",\"util\":" + N(util) + ",\"temp\":" + N(temp) +
                        ",\"mem_used\":" + N(mu) + ",\"mem_total\":" + N(mt) + ",\"power\":" + N(pw) + "}";
            lock (sync) { gpuJson = js; gpuTemp = temp; gpuUtil = util; gpuName = f[0]; }
            return true;
        }

        static double? ParseD(string s)
        {
            double d;
            if (double.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out d)) return d;
            return null;
        }

        // ------------------------------------------------------------ leitura principal
        static double[] ReadCores(out double total)
        {
            total = 0;
            if (cCpu == IntPtr.Zero) return null;
            uint size = 0, count;
            PdhGetFormattedCounterArray(cCpu, FMT, ref size, out count, IntPtr.Zero);
            if (size == 0) return null;
            IntPtr buf = Marshal.AllocHGlobal((int)size);
            try
            {
                if (PdhGetFormattedCounterArray(cCpu, FMT, ref size, out count, buf) != 0) return null;
                SortedDictionary<long, double> cores = new SortedDictionary<long, double>();
                bool hasTotal = false;
                for (int i = 0; i < count; i++)
                {
                    IntPtr item = new IntPtr(buf.ToInt64() + i * 24L);
                    string name = Marshal.PtrToStringUni(Marshal.ReadIntPtr(item)) ?? "";
                    double v = BitConverter.Int64BitsToDouble(Marshal.ReadInt64(item, 16));
                    if (double.IsNaN(v)) v = 0;
                    v = Math.Max(0, Math.Min(100, v));
                    if (name == "_Total") { total = v; hasTotal = true; continue; }
                    if (name.Contains("_Total")) continue;
                    string[] p = name.Split(',');
                    int a, b;
                    long key;
                    if (p.Length == 2 && int.TryParse(p[0], out a) && int.TryParse(p[1], out b)) key = a * 1000L + b;
                    else if (int.TryParse(name, out b)) key = b;
                    else continue;
                    cores[key] = Math.Round(v, 1);
                }
                if (cores.Count == 0) return null;
                double[] arr = cores.Values.ToArray();
                if (!hasTotal) total = arr.Average();
                total = Math.Round(total, 1);
                return arr;
            }
            finally { Marshal.FreeHGlobal(buf); }
        }

        static double ReadSingle(IntPtr c)
        {
            if (c == IntPtr.Zero) return 0;
            PDH_VALUE v;
            if (PdhGetFormattedCounterValue(c, 0x200, IntPtr.Zero, out v) != 0) return 0;
            return Math.Max(0, v.Value);
        }

        class Proc { public int Pid; public string Name; public double Cpu; public long Mem; }

        static string lastStats;
        static DateTime lastStatsT = DateTime.MinValue;

        // vários clientes ao mesmo tempo recebem a mesma leitura (em vez de medir tudo de novo)
        public static string CollectCached()
        {
            lock (sync)
            {
                DateTime n = DateTime.UtcNow;
                if (lastStats != null && (n - lastStatsT).TotalSeconds < 0.08) return lastStats;
                lastStats = Collect();
                lastStatsT = DateTime.UtcNow;
                return lastStats;
            }
        }

        // consumo do próprio NEXUS (e do PresentMon), para mostrar na página
        static DateTime selfT = DateTime.MinValue;
        static long selfCpuTicks, pmCpuTicks;
        static double selfPct, pmPct;
        static void SelfUsage(DateTime nowUtc, out double cpu, out long mem, out double pm)
        {
            mem = 0;
            try
            {
                using (Process me = Process.GetCurrentProcess())
                {
                    long t = me.TotalProcessorTime.Ticks; mem = me.PrivateMemorySize64;
                    long tp = PresentMonReader.CpuTicks();
                    double el = (nowUtc - selfT).TotalSeconds;
                    if (selfT != DateTime.MinValue && el >= 1.5)
                    {
                        selfPct = Math.Max(0, (t - selfCpuTicks) / 1e7 / el / coresLogical * 100);
                        pmPct = tp > 0 && pmCpuTicks > 0 ? Math.Max(0, (tp - pmCpuTicks) / 1e7 / el / coresLogical * 100) : 0;
                    }
                    if (selfT == DateTime.MinValue || el >= 1.5) { selfT = nowUtc; selfCpuTicks = t; pmCpuTicks = tp; }
                }
            }
            catch { }
            cpu = selfPct; pm = pmPct;
        }

        [StructLayout(LayoutKind.Sequential)]
        struct IO_COUNTERS { public ulong ReadOps, WriteOps, OtherOps, ReadBytes, WriteBytes, OtherBytes; }
        [DllImport("kernel32.dll")] static extern bool GetProcessIoCounters(IntPtr h, out IO_COUNTERS c);

        static string resJson = "[]";
        static DateTime resT = DateTime.MinValue;
        static readonly Dictionary<int, long[]> resPrev = new Dictionary<int, long[]>();   // pid -> cpu, leitura, escrita, instante

        // uma linha da tabela: soma os processos dados (normalmente 1)
        static string ResRow(string name, string desc, List<Process> ps, string offNote, DateTime now, Dictionary<int, long[]> seen)
        {
            if (ps.Count == 0)
                return "{\"name\":" + Str(name) + ",\"desc\":" + Str(desc) + ",\"on\":false,\"note\":" + Str(offNote) + "}";
            double cpu = 0, rd = 0, wr = 0; long mem = 0; int threads = 0, handles = 0;
            foreach (Process p in ps)
            {
                try
                {
                    p.Refresh();
                    long ct = p.TotalProcessorTime.Ticks, r = 0, w = 0;
                    IO_COUNTERS io;
                    try { if (GetProcessIoCounters(p.Handle, out io)) { r = (long)io.ReadBytes; w = (long)io.WriteBytes; } } catch { }
                    mem += p.PrivateMemorySize64; threads += p.Threads.Count; handles += p.HandleCount;
                    long[] prev;
                    if (resPrev.TryGetValue(p.Id, out prev))
                    {
                        double el = (now.Ticks - prev[3]) / 1e7;
                        if (el > 0.2)
                        {
                            cpu += Math.Max(0, (ct - prev[0]) / 1e7 / el / coresLogical * 100);
                            rd += Math.Max(0, (r - prev[1]) / el); wr += Math.Max(0, (w - prev[2]) / el);
                        }
                    }
                    seen[p.Id] = new[] { ct, r, w, now.Ticks };
                }
                catch { }
            }
            return "{\"name\":" + Str(name) + ",\"desc\":" + Str(desc) + ",\"on\":true,\"cpu\":" + N(Math.Round(cpu, 2)) +
                   ",\"mem\":" + mem + ",\"io_r\":" + N(Math.Round(rd)) + ",\"io_w\":" + N(Math.Round(wr)) +
                   ",\"threads\":" + threads + ",\"handles\":" + handles + ",\"count\":" + ps.Count + "}";
        }

        static string ResourcesJson(DateTime now)
        {
            if ((now - resT).TotalSeconds < 1.9) return resJson;
            Dictionary<int, long[]> seen = new Dictionary<int, long[]>();
            List<string> rows = new List<string>();
            List<Process> owned = new List<Process>();
            try
            {
                Process me = Process.GetCurrentProcess(); owned.Add(me);
                rows.Add(ResRow("NEXUS Monitor", FullMode() ? "programa, página e sensores (LibreHardwareMonitor)" : "programa e página",
                                new List<Process> { me }, "", now, seen));

                List<Process> pm = new List<Process>();
                Process pmp = PresentMonReader.Proc;
                try { if (pmp != null && !pmp.HasExited) pm.Add(pmp); } catch { }
                rows.Add(ResRow("PresentMon", "FPS e latência dos jogos", pm,
                                File.Exists(PresentMonReader.ExePath) ? "em espera - só corre com um jogo aberto" : "não instalado", now, seen));

                List<Process> gp = new List<Process>();
                try { if (gpuProc != null && !gpuProc.HasExited) gp.Add(gpuProc); } catch { }
                rows.Add(ResRow("nvidia-smi", "leitura da placa gráfica", gp, gpuName != null ? "em espera - só corre com a GPU à vista" : "sem placa NVIDIA", now, seen));

                List<Process> gd = new List<Process>();
                Process gp2 = DiskScan.Proc;
                try { if (gp2 != null && !gp2.HasExited) gd.Add(gp2); } catch { }
                rows.Add(ResRow("gdu", "motor do Deep Scan (só corre quando analisas)", gd,
                                File.Exists(DiskScan.GduExe) ? "parado - só corre quando analisas um disco" : "não instalado", now, seen));

                List<Process> deck = Process.GetProcessesByName("NexusDeck").ToList(); owned.AddRange(deck);
                if (deck.Count > 0 || Modules.StreamDeck)       // só aparece a quem tem a Stream Deck
                    rows.Add(ResRow("Plugin Stream Deck", "teclas da Stream Deck", deck, "Stream Deck fechada ou sem o plugin", now, seen));
            }
            catch { }
            finally { foreach (Process p in owned) try { p.Dispose(); } catch { } }
            resPrev.Clear();
            foreach (KeyValuePair<int, long[]> kv in seen) resPrev[kv.Key] = kv.Value;
            resJson = "[" + string.Join(",", rows.ToArray()) + "]";
            resT = now;
            return resJson;
        }

        static bool FullMode() { return Program.FullMode; }

        static List<string> ifCache = new List<string>(), diskCache = new List<string>();
        static DateTime ifCacheT = DateTime.MinValue, diskCacheT = DateTime.MinValue;
        static string procTopJson = "", procMemJson = "";
        static int procCount;
        static DateTime procCacheT = DateTime.MinValue;

        public static string Collect()
        {
            lock (sync)
            {
                DateTime nowUtc = DateTime.UtcNow;
                double now = (nowUtc - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalSeconds;
                double boot = now - GetTickCount64() / 1000.0;

                // CPU + disco (PDH)
                // vários clientes (site + Stream Deck): só volta a ler os contadores se passou tempo suficiente
                double cpuTotal; double[] cores; double dRead, dWrite;
                if (pdhCores == null || (nowUtc - lastPdhT).TotalSeconds >= 0.09)
                {
                    if (query != IntPtr.Zero) PdhCollectQueryData(query);
                    pdhCores = ReadCores(out pdhTotal);
                    pdhRead = ReadSingle(cRead); pdhWrite = ReadSingle(cWrite);
                    lastPdhT = nowUtc;
                }
                cores = pdhCores; cpuTotal = pdhTotal; dRead = pdhRead; dWrite = pdhWrite;
                if (cores == null) { cores = new double[coresLogical]; cpuTotal = 0; }

                // memória
                MEMSTATUS m = new MEMSTATUS();
                GlobalMemoryStatusEx(m);
                ulong memUsed = m.ullTotalPhys - m.ullAvailPhys;
                double memPct = m.ullTotalPhys > 0 ? Math.Round(memUsed * 100.0 / m.ullTotalPhys, 1) : 0;
                long swapTotal = (long)m.ullTotalPageFile - (long)m.ullTotalPhys;
                long swapUsed = ((long)m.ullTotalPageFile - (long)m.ullAvailPageFile) - (long)memUsed;
                if (swapTotal < 0) swapTotal = 0;
                if (swapUsed < 0) swapUsed = 0;
                if (swapUsed > swapTotal) swapUsed = swapTotal;
                if (pfTotal >= 0) { swapTotal = pfTotal; swapUsed = Math.Min(pfUsed, pfTotal); }
                double swapPct = swapTotal > 0 ? Math.Round(swapUsed * 100.0 / swapTotal, 1) : 0;

                // rede
                long sent = 0, recv = 0;
                List<string> ifaces = new List<string>();
                bool refreshIf = (nowUtc - ifCacheT).TotalSeconds >= 10;
                try
                {
                    foreach (NetworkInterface ni in NetworkInterface.GetAllNetworkInterfaces())
                    {
                        if (ni.OperationalStatus != OperationalStatus.Up) continue;
                        if (ni.NetworkInterfaceType == NetworkInterfaceType.Loopback ||
                            ni.NetworkInterfaceType == NetworkInterfaceType.Tunnel) continue;
                        try
                        {
                            IPInterfaceStatistics st = ni.GetIPStatistics();
                            sent += st.BytesSent; recv += st.BytesReceived;
                        }
                        catch { }
                        if (!refreshIf) continue;
                        try
                        {
                            IPInterfaceProperties ipp = ni.GetIPProperties();
                            string ip4 = null, mask = null, ip6 = null, gw = null;
                            foreach (UnicastIPAddressInformation ua in ipp.UnicastAddresses)
                            {
                                if (ua.Address.AddressFamily == AddressFamily.InterNetwork && !IPAddress.IsLoopback(ua.Address) && ip4 == null)
                                { ip4 = ua.Address.ToString(); try { mask = ua.IPv4Mask.ToString(); } catch { } }
                                else if (ua.Address.AddressFamily == AddressFamily.InterNetworkV6 && !ua.Address.IsIPv6LinkLocal && ip6 == null)
                                    ip6 = ua.Address.ToString();
                            }
                            if (ip4 == null) continue;
                            foreach (GatewayIPAddressInformation g in ipp.GatewayAddresses)
                                if (g.Address.AddressFamily == AddressFamily.InterNetwork && !g.Address.Equals(IPAddress.Any)) { gw = g.Address.ToString(); break; }
                            List<string> dns = new List<string>();
                            foreach (IPAddress a in ipp.DnsAddresses)
                                if (a.AddressFamily == AddressFamily.InterNetwork) dns.Add(a.ToString());
                            string mac = "";
                            try { mac = string.Join(":", ni.GetPhysicalAddress().GetAddressBytes().Select(b => b.ToString("X2")).ToArray()); } catch { }
                            string js = "{\"name\":" + Str(ni.Name) + ",\"desc\":" + Str(ni.Description) + ",\"type\":" + Str(ni.NetworkInterfaceType.ToString()) +
                                ",\"ip\":" + Str(ip4) + ",\"mask\":" + Str(mask) + ",\"gateway\":" + Str(gw) + ",\"ipv6\":" + Str(ip6) +
                                ",\"dns\":" + Str(string.Join(", ", dns.ToArray())) + ",\"mac\":" + Str(mac) + ",\"speed\":" + (ni.Speed > 0 ? ni.Speed.ToString() : "null") + "}";
                            if (gw != null) ifaces.Insert(0, js); else ifaces.Add(js);
                        }
                        catch { }
                    }
                }
                catch { }
                if (refreshIf) { ifCache = ifaces; ifCacheT = nowUtc; } else ifaces = ifCache;
                double up = 0, down = 0;
                double ndt = lastNetT == DateTime.MinValue ? 0 : (nowUtc - lastNetT).TotalSeconds;
                if (lastNetT != DateTime.MinValue && ndt < 0.7)
                {
                    up = cacheUp; down = cacheDown;            // pedido muito próximo do anterior: reutiliza
                }
                else
                {
                    if (ndt > 0)
                    {
                        up = Math.Max(0, (sent - lastSent) / ndt);
                        down = Math.Max(0, (recv - lastRecv) / ndt);
                    }
                    cacheUp = up; cacheDown = down;
                    lastNetT = nowUtc; lastSent = sent; lastRecv = recv;
                }

                // discos
                List<string> disks = new List<string>();
                if ((nowUtc - diskCacheT).TotalSeconds < 10) disks = diskCache;
                else foreach (DriveInfo d in DriveInfo.GetDrives())
                {
                    try
                    {
                        if (!d.IsReady || (d.DriveType != DriveType.Fixed && d.DriveType != DriveType.Removable)) continue;
                        long total = d.TotalSize, used = d.TotalSize - d.TotalFreeSpace;
                        if (total <= 0) continue;
                        disks.Add("{\"mount\":" + Str(d.Name) + ",\"fs\":" + Str(d.DriveFormat) + ",\"total\":" + total +
                                  ",\"used\":" + used + ",\"percent\":" + N(Math.Round(used * 100.0 / total, 1)) + "}");
                    }
                    catch { }
                }
                if (disks != diskCache) { diskCache = disks; diskCacheT = nowUtc; }

                // processos: lista completa a cada 2 s (é a parte mais pesada da leitura)
                double elapsed = lastProcT == DateTime.MinValue ? 0 : (nowUtc - lastProcT).TotalSeconds;
                if (procCacheT == DateTime.MinValue || (nowUtc - procCacheT).TotalSeconds >= 1.9)
                {
                    List<Proc> procs = new List<Proc>();
                    Dictionary<int, long> curProc = new Dictionary<int, long>();
                    foreach (Process p in Process.GetProcesses())
                    {
                        try
                        {
                            if (p.Id == 0) continue;
                            Proc pr = new Proc();
                            pr.Pid = p.Id;
                            pr.Name = p.ProcessName + (p.Id == 4 ? "" : ".exe");
                            try { pr.Mem = p.WorkingSet64; } catch { }
                            try
                            {
                                long t = p.TotalProcessorTime.Ticks;
                                curProc[p.Id] = t;
                                long prev;
                                if (elapsed > 0 && lastProc.TryGetValue(p.Id, out prev))
                                    pr.Cpu = Math.Max(0, Math.Min(100, (t - prev) / 1e7 / elapsed / coresLogical * 100));
                            }
                            catch { }
                            pr.Cpu = Math.Round(pr.Cpu, 1);
                            procs.Add(pr);
                        }
                        catch { }
                        finally { p.Dispose(); }
                    }
                    lastProc = curProc; lastProcT = nowUtc;
                    procCount = procs.Count;
                    procTopJson = string.Join(",", procs.OrderByDescending(x => x.Cpu).ThenByDescending(x => x.Mem).Take(8)
                        .Select(x => "{\"pid\":" + x.Pid + ",\"name\":" + Str(x.Name) + ",\"cpu\":" + N(x.Cpu) + ",\"mem\":" + x.Mem + "}").ToArray());
                    procMemJson = string.Join(",", procs.OrderByDescending(x => x.Mem).Take(8)
                        .Select(x => "{\"pid\":" + x.Pid + ",\"name\":" + Str(x.Name) + ",\"cpu\":" + N(x.Cpu) + ",\"mem\":" + x.Mem + "}").ToArray());
                    procCacheT = nowUtc;
                }

                // bateria
                string battery = "null";
                POWER pw;
                if (GetSystemPowerStatus(out pw) && pw.Flag != 128 && pw.Flag != 255 && pw.Percent <= 100)
                {
                    battery = "{\"percent\":" + pw.Percent + ",\"plugged\":" + (pw.AC == 1 ? "true" : "false") +
                              ",\"secs\":" + (pw.LifeTime > 0 ? pw.LifeTime.ToString() : "null") + "}";
                }

                // temperaturas (+ GPU)
                Dictionary<string, double> t2 = new Dictionary<string, double>(temps);
                foreach (KeyValuePair<string, double> kv in hwTemps) t2[kv.Key] = kv.Value;
                if (gpuTemp.HasValue && gpuName != null)
                    t2["GPU · " + gpuName.Replace("NVIDIA ", "")] = Math.Round(gpuTemp.Value, 1);
                string tempsJs = "{" + string.Join(",", t2.Select(kv => Str(kv.Key) + ":" + N(kv.Value)).ToArray()) + "}";

                StringBuilder sb = new StringBuilder(4096);
                sb.Append("{\"time\":").Append(N(now));
                sb.Append(",\"system\":{\"hostname\":").Append(Str(hostname))
                  .Append(",\"os\":").Append(Str(os))
                  .Append(",\"arch\":").Append(Str(arch))
                  .Append(",\"cpu_model\":").Append(Str(cpuModel))
                  .Append(",\"python\":").Append(Str(runtime))
                  .Append(",\"boot\":").Append(N(boot)).Append("}");
                sb.Append(",\"cpu\":{\"total\":").Append(N(cpuTotal))
                  .Append(",\"per_core\":[").Append(string.Join(",", cores.Select(x => N(x)).ToArray())).Append("]")
                  .Append(",\"cores_logical\":").Append(coresLogical)
                  .Append(",\"cores_physical\":").Append(coresPhysical.HasValue ? coresPhysical.Value.ToString() : "null")
                  .Append(",\"freq\":").Append(cpuClock.HasValue ? Math.Round(cpuClock.Value).ToString(CultureInfo.InvariantCulture) : freqMhz.HasValue ? freqMhz.Value.ToString() : "null")
                  .Append(",\"freq_max\":null,\"load\":null}");
                sb.Append(",\"memory\":{\"total\":").Append(m.ullTotalPhys)
                  .Append(",\"used\":").Append(memUsed)
                  .Append(",\"percent\":").Append(N(memPct))
                  .Append(",\"available\":").Append(m.ullAvailPhys).Append("}");
                sb.Append(",\"swap\":{\"total\":").Append(swapTotal)
                  .Append(",\"used\":").Append(swapUsed)
                  .Append(",\"percent\":").Append(N(swapPct)).Append("}");
                sb.Append(",\"temps\":").Append(tempsJs);
                sb.Append(",\"gpu\":").Append(gpuJson ?? "null");
                sb.Append(",\"disks\":[").Append(string.Join(",", disks.ToArray())).Append("]");
                sb.Append(",\"disk_io\":{\"read\":").Append(N(dRead)).Append(",\"write\":").Append(N(dWrite)).Append("}");
                sb.Append(",\"net\":{\"up\":").Append(N(up)).Append(",\"down\":").Append(N(down))
                  .Append(",\"sent\":").Append(sent).Append(",\"recv\":").Append(recv)
                  .Append(",\"ifaces\":[").Append(string.Join(",", ifaces.ToArray())).Append("]}");
                sb.Append(",\"processes\":{\"count\":").Append(procCount)
                  .Append(",\"top\":[").Append(procTopJson).Append("]")
                  .Append(",\"top_mem\":[").Append(procMemJson).Append("]}");
                double selfCpu, pmCpu; long selfMem;
                SelfUsage(nowUtc, out selfCpu, out selfMem, out pmCpu);
                sb.Append(",\"res\":").Append(ResourcesJson(nowUtc));
                sb.Append(",\"self\":{\"cpu\":").Append(N(Math.Round(selfCpu, 2))).Append(",\"mem\":").Append(selfMem)
                  .Append(",\"pm_cpu\":").Append(N(Math.Round(pmCpu, 2))).Append("}");
                sb.Append(",\"battery\":").Append(battery);
                sb.Append(",\"cpu_temp\":").Append(N(cpuTemp));
                sb.Append(",\"cpu_temps\":{\"package\":").Append(N(cpuPkg)).Append(",\"max\":").Append(N(cpuMax))
                  .Append(",\"avg\":").Append(N(cpuAvg)).Append(",\"cores\":[")
                  .Append(string.Join(",", cpuCoreTemps.Select(x => N(x)).ToArray())).Append("],\"ccds\":[")
                  .Append(string.Join(",", cpuCcds.Select(x => "{\"n\":" + x.Key + ",\"v\":" + N(x.Value) + "}").ToArray())).Append("]}");
                sb.Append(",\"settings\":").Append(AppSettings.Json());
                sb.Append(",\"theme\":").Append(AppSettings.ThemeJson());
                sb.Append(",\"lang\":\"").Append(Lang.Current).Append('"');
                string gj = PresentMonReader.Json();
                if (gj == "null") gj = Rtss.Json();
                sb.Append(",\"game\":").Append(gj);
                sb.Append(",\"cpu_power\":").Append(N(cpuPower));
                sb.Append(",\"nexus\":{\"bott\":").Append(Str(Analise.Bottleneck)).Append(",\"session\":").Append(N(Historico.SessionMins))
                  .Append(",\"bench\":").Append(Medicao.Recording || Medicao.Waiting ? "true" : "false").Append(",\"stress\":").Append(Stress.Running ? "true" : "false").Append('}');
                sb.Append(",\"sensor_source\":").Append(Str(sensorSource));
                sb.Append(",\"sensor_debug\":").Append(Str(sensorDebug));
                sb.Append(",\"mode\":").Append(Str(Program.FullMode ? "completo" : "normal"));
                sb.Append(",\"driver\":").Append(Str(Program.FullMode ? Embedded.DriverStatus : ""));
                sb.Append(",\"fans\":[").Append(string.Join(",", hwFans.Select(f => "{\"name\":" + Str(f.Key) + ",\"rpm\":" + N(f.Value) + "}").ToArray())).Append("]");
                sb.Append("}");
                return sb.ToString();
            }
        }

        // linhas curtas com o mais importante, para o menu do ícone
        public static List<string> MenuLines()
        {
            WantGpu();
            List<string> l = new List<string>();
            double cpu; double? ct, gu, gt;
            lock (sync)
            {
                DateTime n = DateTime.UtcNow;
                if (pdhCores == null || (n - lastPdhT).TotalSeconds >= 1.5)
                {
                    if (query != IntPtr.Zero) PdhCollectQueryData(query);
                    pdhCores = ReadCores(out pdhTotal);
                    pdhRead = ReadSingle(cRead); pdhWrite = ReadSingle(cWrite);
                    lastPdhT = n;
                }
                cpu = pdhTotal; ct = cpuPkg ?? cpuTemp; gu = gpuUtil; gt = gpuTemp;
            }
            MEMSTATUS m = new MEMSTATUS();
            GlobalMemoryStatusEx(m);
            double used = (m.ullTotalPhys - m.ullAvailPhys) / 1073741824.0, tot = m.ullTotalPhys / 1073741824.0;
            CultureInfo ci = CultureInfo.InvariantCulture;
            l.Add("CPU   " + Math.Round(cpu).ToString().PadLeft(3) + "%" + (ct.HasValue ? "  ·  " + Math.Round(ct.Value) + " °C" : ""));
            l.Add("RAM   " + Math.Round(tot > 0 ? used * 100 / tot : 0).ToString().PadLeft(3) + "%  ·  " + used.ToString("0.0", ci) + " / " + tot.ToString("0", ci) + " GB");
            if (gu.HasValue || gt.HasValue)
                l.Add("GPU   " + (gu.HasValue ? Math.Round(gu.Value).ToString().PadLeft(3) + "%" : "  --") + (gt.HasValue ? "  ·  " + Math.Round(gt.Value) + " °C" : ""));
            string g = PresentMonReader.Json();
            if (g == "null") g = Rtss.Json();
            if (g != "null")
            {
                System.Text.RegularExpressions.Match mn = System.Text.RegularExpressions.Regex.Match(g, "\"name\":\"([^\"]*)\"");
                System.Text.RegularExpressions.Match mf = System.Text.RegularExpressions.Regex.Match(g, "\"fps\":([0-9.]+)");
                if (mn.Success && mf.Success)
                    l.Add(Lang.L("JOGO").PadRight(6) + mn.Groups[1].Value + "  ·  " + Math.Round(double.Parse(mf.Groups[1].Value, ci)) + " FPS");
            }
            return l;
        }

        // valores para o overlay em jogo
        // o núcleo mais ocupado agora (%), para ver se o jogo está preso no processador
        public static double MaxCore()
        {
            lock (sync) { if (pdhCores == null || pdhCores.Length == 0) return 0; double m = 0; foreach (double v in pdhCores) if (v > m) m = v; return m; }
        }
        public static void OverlaySnap(out double cpu, out double? cpuT, out double? gpu, out double? gpuT, out double ramPct, out double ramUsedGb)
        {
            WantGpu();
            lock (sync)
            {
                DateTime n = DateTime.UtcNow;
                if (pdhCores == null || (n - lastPdhT).TotalSeconds >= 1.5)
                {
                    if (query != IntPtr.Zero) PdhCollectQueryData(query);
                    pdhCores = ReadCores(out pdhTotal);
                    pdhRead = ReadSingle(cRead); pdhWrite = ReadSingle(cWrite);
                    lastPdhT = n;
                }
                cpu = pdhTotal; cpuT = cpuPkg ?? cpuTemp; gpu = gpuUtil; gpuT = gpuTemp;
            }
            MEMSTATUS m = new MEMSTATUS();
            GlobalMemoryStatusEx(m);
            ramUsedGb = (m.ullTotalPhys - m.ullAvailPhys) / 1073741824.0;
            ramPct = m.ullTotalPhys > 0 ? ramUsedGb * 1073741824.0 * 100 / m.ullTotalPhys : 0;
        }

        public static string QuickTip()
        {
            lock (sync)
            {
                DateTime nowQ = DateTime.UtcNow;
                if (pdhCores == null || (nowQ - lastPdhT).TotalSeconds >= 1.5)
                {
                    if (query != IntPtr.Zero) PdhCollectQueryData(query);
                    pdhCores = ReadCores(out pdhTotal);
                    pdhRead = ReadSingle(cRead); pdhWrite = ReadSingle(cWrite);
                    lastPdhT = nowQ;
                }
                double cpu = pdhTotal;
                MEMSTATUS m = new MEMSTATUS();
                GlobalMemoryStatusEx(m);
                double mem = m.ullTotalPhys > 0 ? (m.ullTotalPhys - m.ullAvailPhys) * 100.0 / m.ullTotalPhys : 0;
                string tip = "NEXUS · CPU " + Math.Round(cpu) + "% · RAM " + Math.Round(mem) + "%";
                if (cpuTemp.HasValue) tip += " · CPU " + Math.Round(cpuTemp.Value) + "°C";
                if (gpuTemp.HasValue) tip += " · GPU " + Math.Round(gpuTemp.Value) + "°C";
                return tip;
            }
        }

        // ------------------------------------------------------------ JSON
        static string N(double v)
        {
            if (double.IsNaN(v) || double.IsInfinity(v)) return "null";
            return v.ToString("0.###", CultureInfo.InvariantCulture);
        }

        static string N(double? v)
        {
            return v.HasValue ? N(v.Value) : "null";
        }

        static string Str(string s)
        {
            if (s == null) return "null";
            StringBuilder sb = new StringBuilder(s.Length + 2);
            sb.Append('"');
            foreach (char c in s)
            {
                switch (c)
                {
                    case '"': sb.Append("\\\""); break;
                    case '\\': sb.Append("\\\\"); break;
                    case '\n': sb.Append("\\n"); break;
                    case '\r': sb.Append("\\r"); break;
                    case '\t': sb.Append("\\t"); break;
                    default:
                        if (c < 0x20) sb.Append("\\u").Append(((int)c).ToString("x4"));
                        else sb.Append(c);
                        break;
                }
            }
            sb.Append('"');
            return sb.ToString();
        }
    }

    // ---------------------------------------------------------------- modo completo (LibreHardwareMonitorLib, carregada em runtime)
    static class Embedded
    {
        static object computer;
        static Type compType;
        static string initError;
        static bool initDone;

        static System.ServiceProcess.ServiceController driver;
        static bool startedByUs;
        public static string DriverStatus = "";

        static bool driverWasRunning;

        static void FindDriver()
        {
            try
            {
                foreach (System.ServiceProcess.ServiceController sc in System.ServiceProcess.ServiceController.GetDevices())
                {
                    if (sc.ServiceName.IndexOf("PawnIO", StringComparison.OrdinalIgnoreCase) >= 0 ||
                        sc.DisplayName.IndexOf("PawnIO", StringComparison.OrdinalIgnoreCase) >= 0)
                    { driver = sc; break; }
                }
                if (driver == null) { DriverStatus = "PawnIO não instalado"; return; }
                driver.Refresh();
                driverWasRunning = driver.Status == System.ServiceProcess.ServiceControllerStatus.Running;
            }
            catch (Exception ex) { DriverStatus = "PawnIO: " + ex.Message; }
        }

        static bool DriverRunning()
        {
            try { driver.Refresh(); return driver.Status == System.ServiceProcess.ServiceControllerStatus.Running; }
            catch { return false; }
        }

        static void AfterOpen()
        {
            if (driver == null) return;
            if (!DriverRunning())
            {
                // a biblioteca não ligou o driver: liga-o e reabre
                try
                {
                    driver.Start();
                    driver.WaitForStatus(System.ServiceProcess.ServiceControllerStatus.Running, TimeSpan.FromSeconds(8));
                    compType.GetMethod("Close", Type.EmptyTypes).Invoke(computer, null);
                    compType.GetMethod("Open", Type.EmptyTypes).Invoke(computer, null);
                }
                catch (Exception ex) { DriverStatus = "PawnIO não arrancou: " + ex.Message; return; }
            }
            startedByUs = !driverWasRunning && DriverRunning();
            DriverStatus = startedByUs ? "PawnIO ligado pelo NEXUS" : (DriverRunning() ? "PawnIO ativo" : "PawnIO parado");
        }

        public static string Report()
        {
            try
            {
                if (computer == null) return "sem computador: " + initError;
                return DriverStatus + "\r\n\r\n" + Convert.ToString(compType.GetMethod("GetReport", Type.EmptyTypes).Invoke(computer, null));
            }
            catch (Exception ex) { return "erro: " + (ex.InnerException ?? ex).ToString(); }
        }

        public static void Shutdown()
        {
            try { if (computer != null) compType.GetMethod("Close", Type.EmptyTypes).Invoke(computer, null); } catch { }
            computer = null;
            if (driver != null && startedByUs)
            {
                try
                {
                    driver.Refresh();
                    if (driver.Status == System.ServiceProcess.ServiceControllerStatus.Running)
                    {
                        driver.Stop();
                        driver.WaitForStatus(System.ServiceProcess.ServiceControllerStatus.Stopped, TimeSpan.FromSeconds(5));
                    }
                }
                catch { }
            }
        }

        static void Init()
        {
            initDone = true;
            FindDriver();
            AppDomain.CurrentDomain.AssemblyResolve += delegate(object sender, ResolveEventArgs e)
            {
                string name = new AssemblyName(e.Name).Name;
                string p = Path.Combine(Program.LhmDir, name + ".dll");
                return File.Exists(p) ? Assembly.LoadFrom(p) : null;
            };
            Assembly asm = Assembly.LoadFrom(Path.Combine(Program.LhmDir, "LibreHardwareMonitorLib.dll"));
            compType = asm.GetType("LibreHardwareMonitor.Hardware.Computer", true);
            computer = Activator.CreateInstance(compType);
            foreach (string prop in new[] { "IsCpuEnabled", "IsMotherboardEnabled", "IsControllerEnabled", "IsStorageEnabled" })
            {
                PropertyInfo pi = compType.GetProperty(prop);
                if (pi != null) pi.SetValue(computer, true, null);
            }
            compType.GetMethod("Open", Type.EmptyTypes).Invoke(computer, null);
            AfterOpen();
        }

        static object Get(object o, string prop)
        {
            PropertyInfo pi = o.GetType().GetProperty(prop);
            return pi == null ? null : pi.GetValue(o, null);
        }

        static void Walk(object hw, string parentType, List<object[]> outList)
        {
            MethodInfo upd = hw.GetType().GetMethod("Update", Type.EmptyTypes);
            if (upd != null) upd.Invoke(hw, null);
            string hwType = Convert.ToString(Get(hw, "HardwareType"));
            string hwName = Convert.ToString(Get(hw, "Name"));
            string effType = parentType ?? hwType;
            System.Collections.IEnumerable sensors = Get(hw, "Sensors") as System.Collections.IEnumerable;
            if (sensors != null)
                foreach (object sn in sensors)
                {
                    object val = Get(sn, "Value");
                    if (val == null) continue;
                    if (Convert.ToString(Get(sn, "SensorType")) == "Control")
                    {
                        object ctl = Get(sn, "Control");
                        if (ctl != null) ctrls[Convert.ToString(Get(sn, "Identifier"))] = new object[] { ctl, Convert.ToString(Get(sn, "Name")), hwName, Convert.ToDouble(val) };
                    }
                    outList.Add(new object[] { effType, hwName, Convert.ToString(Get(sn, "SensorType")), Convert.ToString(Get(sn, "Name")), Convert.ToDouble(val) });
                }
            System.Collections.IEnumerable subs = Get(hw, "SubHardware") as System.Collections.IEnumerable;
            if (subs != null) foreach (object sub in subs) Walk(sub, effType, outList);
        }

        // ---------- ventoinhas da placa-mãe (controlos do LibreHardwareMonitor)
        static readonly object lk = new object();
        static readonly Dictionary<string, object[]> ctrls = new Dictionary<string, object[]>();   // id -> { IControl, nome, hardware, % }
        public static bool HasControls { get { lock (lk) return ctrls.Count > 0; } }
        public static List<string[]> Controls()
        {
            lock (lk) return ctrls.Select(kv => new[] { kv.Key, Convert.ToString(kv.Value[1]), Convert.ToString(kv.Value[2]), ((double)kv.Value[3]).ToString("0", System.Globalization.CultureInfo.InvariantCulture) }).ToList();
        }
        // pct = null volta ao controlo da BIOS
        public static string SetControl(string id, double? pct)
        {
            lock (lk)
            {
                object[] c;
                if (!ctrls.TryGetValue(id, out c)) return "não existe";
                try
                {
                    object ctl = c[0];
                    if (pct.HasValue)
                    {
                        MethodInfo m = ctl.GetType().GetMethod("SetSoftware");
                        if (m == null) return "não suportado";
                        m.Invoke(ctl, new object[] { (float)Math.Max(0, Math.Min(100, pct.Value)) });
                    }
                    else
                    {
                        MethodInfo m = ctl.GetType().GetMethod("SetDefault");
                        if (m != null) m.Invoke(ctl, null);
                    }
                    return null;
                }
                catch (Exception ex) { return (ex.InnerException ?? ex).Message; }
            }
        }

        public static Stats.HwData Read() { lock (lk) return ReadCore(); }
        static Stats.HwData ReadCore()
        {
            if (!initDone)
            {
                try { Init(); }
                catch (Exception ex)
                {
                    Exception inner = ex.InnerException ?? ex;
                    initError = inner.GetType().Name + ": " + inner.Message;
                }
            }
            if (computer == null) throw new Exception(initError ?? "biblioteca não carregada");

            List<object[]> rows = new List<object[]>();
            System.Collections.IEnumerable hws = compType.GetProperty("Hardware").GetValue(computer, null) as System.Collections.IEnumerable;
            if (hws != null) foreach (object hw in hws) Walk(hw, null, rows);

            Stats.HwData d = new Stats.HwData();
            Dictionary<string, double> cpuCands = new Dictionary<string, double>();
            List<double> clocks = new List<double>();
            foreach (object[] r in rows)
            {
                string hwType = (string)r[0], hwName = (string)r[1], type = (string)r[2], name = (string)r[3];
                double v = (double)r[4];
                bool isCpu = hwType.IndexOf("Cpu", StringComparison.OrdinalIgnoreCase) >= 0;
                bool isMb = hwType.IndexOf("Motherboard", StringComparison.OrdinalIgnoreCase) >= 0 || hwType.IndexOf("SuperIO", StringComparison.OrdinalIgnoreCase) >= 0;
                bool isDisk = hwType.IndexOf("Storage", StringComparison.OrdinalIgnoreCase) >= 0;

                if (type == "Temperature")
                {
                    if (isCpu) { cpuCands[name] = v; Stats.CpuTempLabel(d, name, v); }
                    if (Stats.SkipTempLabel(name)) continue;
                    string key;
                    if (isCpu) key = name.StartsWith("CPU") || name.StartsWith("Core") ? name : "CPU · " + name;
                    else if (isDisk) key = "Disco · " + Stats.ShortHw(hwName);
                    else if (isMb) key = "Placa · " + name;
                    else key = Stats.ShortHw(hwName) + " · " + name;
                    Stats.AddTemp(d, key, v);
                }
                else if (type == "Fan")
                {
                    if (v > 0 && d.Fans.Count < 12 && !d.Fans.Any(f => f.Key == name))
                        d.Fans.Add(new KeyValuePair<string, double>(name, v));
                }
                else if (type == "Power")
                {
                    if (isCpu && !d.CpuPower.HasValue && (name == "CPU Package" || name == "Package")) d.CpuPower = v;
                }
                else if (type == "Clock")
                {
                    if (isCpu && System.Text.RegularExpressions.Regex.IsMatch(name, @"^(CPU )?([PE]-)?Core ?#?\d+$")) clocks.Add(v);
                }
            }
            foreach (string pr in Stats.CpuTempPriority)
            {
                double cv;
                if (cpuCands.TryGetValue(pr, out cv) && cv > 0 && cv < 150) { d.CpuTemp = Math.Round(cv, 1); break; }
            }
            if (clocks.Count > 0) d.CpuClock = clocks.Average();
            Stats.FinishCpu(d);
            return (d.Temps.Count > 0 || d.Fans.Count > 0) ? d : null;
        }
    }

    // ---------------------------------------------------------------- RivaTuner Statistics Server (FPS / frametime)
    static class Rtss
    {
        [DllImport("kernel32.dll")] static extern uint GetTickCount();
        static double? lastFps;

        static readonly string[] NonGames = {
            "streamdeck", "vivaldi", "chrome", "msedge", "msedgewebview2", "firefox", "opera", "opera_gx", "brave", "discord",
            "spotify", "explorer", "steamwebhelper", "steam", "nexus monitor", "nexusdeck", "dwm", "obs64", "obs32",
            "epicgameslauncher", "eadesktop", "battle.net", "origin", "ubisoftconnect", "upc", "signalrgb", "nvidia overlay",
            "nvcontainer", "claude", "code", "devenv", "teams", "ms-teams", "slack", "whatsapp", "telegram", "hwinfo64",
            "librehardwaremonitor", "msiafterburner", "rtss", "lghub", "icue", "razer synapse", "searchhost", "startmenuexperiencehost",
            "applicationframehost", "textinputhost", "shellexperiencehost", "widgets", "lockapp", "photos", "mpc-hc64", "vlc",
            "wallpaper32", "wallpaper64", "wallpaperengine", "webwallpaper32", "lively", "livelywpf", "rainmeter", "nvidia share", "gamebar", "xboxgamebar" };

        internal static bool NotAGame(string name)
        {
            string n = (name ?? "").ToLowerInvariant();
            foreach (string x in NonGames) if (n == x) return true;
            return false;
        }

        public static string Json()
        {
            try
            {
                MemoryMappedFile mmf;
                try { mmf = MemoryMappedFile.OpenExisting("RTSSSharedMemoryV2", MemoryMappedFileRights.Read); }
                catch { return "null"; }
                using (mmf)
                using (MemoryMappedViewAccessor a = mmf.CreateViewAccessor(0, 0, MemoryMappedFileAccess.Read))
                {
                    uint sig = a.ReadUInt32(0);
                    if (sig != 0x52545353 && sig != 0x53535452) return "null";      // "RTSS"
                    uint ver = a.ReadUInt32(4);
                    if (ver < 0x00020000) return "null";
                    long entSize = a.ReadUInt32(8), arrOff = a.ReadUInt32(12), arrSize = a.ReadUInt32(16);
                    if (entSize < 284 || arrSize == 0 || arrSize > 1024) return "null";
                    uint now = GetTickCount();
                    string bestName = null; double bestFps = 0, bestFt = 0;
                    for (long i = 0; i < arrSize; i++)
                    {
                        long b = arrOff + i * entSize;
                        uint pid = a.ReadUInt32(b);
                        if (pid == 0) continue;
                        uint t0 = a.ReadUInt32(b + 268), t1 = a.ReadUInt32(b + 272), frames = a.ReadUInt32(b + 276), ft = a.ReadUInt32(b + 280);
                        if (t1 <= t0 || frames == 0) continue;
                        if (unchecked(now - t1) > 3000) continue;                     // sem frames recentes
                        byte[] nb = new byte[260];
                        a.ReadArray(b + 4, nb, 0, 260);
                        int z = Array.IndexOf(nb, (byte)0);
                        string path = Encoding.Default.GetString(nb, 0, z < 0 ? 260 : z);
                        string name;
                        try { name = Path.GetFileNameWithoutExtension(path); } catch { name = path; }
                        if (NotAGame(name)) continue;                                  // apps que não são jogos
                        double fps = 1000.0 * frames / (t1 - t0);
                        if (fps <= bestFps) continue;                                  // fica com o que tem mais FPS
                        bestFps = fps;
                        bestFt = ft / 1000.0;
                        bestName = name;
                    }
                    if (bestName == null) return "null";
                    lastFps = bestFps;
                    return "{\"source\":\"RivaTuner\",\"latency\":null,\"name\":\"" + bestName.Replace("\\", "\\\\").Replace("\"", "\\\"") + "\",\"fps\":" +
                           bestFps.ToString("0.0", System.Globalization.CultureInfo.InvariantCulture) + ",\"frametime\":" +
                           bestFt.ToString("0.00", System.Globalization.CultureInfo.InvariantCulture) + "}";
                }
            }
            catch { return "null"; }
        }
    }

    // ---------------------------------------------------------------- Intel PresentMon (FPS, frametime e latência sem o RivaTuner)
    static class PresentMonReader
    {
        public static string Status = "sem PresentMon";
        static Process proc;
        static readonly object lk = new object();
        // por app: 8 blocos de 250 ms com contagem e somas (sem guardar cada frame - jogos podem ter milhares por segundo)
        class Agg
        {
            public readonly long[] Slot = new long[8];
            public readonly int[] Cnt = new int[8], LatN = new int[8];
            public readonly double[] Ft = new double[8], Lat = new double[8];
            public bool Skip;
        }
        static readonly Dictionary<string, Agg> aggs = new Dictionary<string, Agg>(StringComparer.OrdinalIgnoreCase);
        static readonly Stopwatch clock = Stopwatch.StartNew();

        public static Process Proc { get { return proc; } }
        public static string ExePath { get { return Exe; } }

        public static long CpuTicks()
        {
            try { Process p = proc; if (p != null && !p.HasExited) { p.Refresh(); return p.TotalProcessorTime.Ticks; } } catch { }
            return 0;
        }

        static void Add(string app, double ft, double lat)
        {
            Medicao.Frame(app, ft);      // medição de FPS (só faz alguma coisa enquanto está a gravar)
            Analise.Frame((float)ft);
            long slot = clock.ElapsedMilliseconds / 250;
            int k = (int)(slot % 8);
            lock (lk)
            {
                Agg a;
                if (!aggs.TryGetValue(app, out a))
                {
                    a = new Agg();
                    string n = Path.GetFileNameWithoutExtension(app);
                    a.Skip = n == "<unknown>" || Rtss.NotAGame(n) || string.Equals(n, "dwm", StringComparison.OrdinalIgnoreCase);
                    aggs[app] = a;
                }
                if (a.Skip) return;
                if (a.Slot[k] != slot) { a.Slot[k] = slot; a.Cnt[k] = 0; a.Ft[k] = 0; a.Lat[k] = 0; a.LatN[k] = 0; }
                a.Cnt[k]++; a.Ft[k] += ft;
                if (!double.IsNaN(lat) && lat > 0) { a.Lat[k] += lat; a.LatN[k]++; }
            }
        }

        static double ParseD(string line, int start, int len)
        {
            double v;
            return len > 0 && double.TryParse(line.Substring(start, len), System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out v) ? v : double.NaN;
        }
        static string Exe { get { return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "presentmon", "PresentMon.exe"); } }

        // só corre enquanto houver um jogo (o Optimizer liga/desliga)
        static volatile bool want;
        public const string Idle = "PresentMon em espera";
        public static bool Active { get { return want; } }
        public static void SetActive(bool on)
        {
            if (!File.Exists(Exe) || on == want) return;
            want = on;
            if (!on)
            {
                Stop();
                lock (lk) aggs.Clear();
                Status = Idle;
            }
        }

        public static void Start()
        {
            if (!File.Exists(Exe)) { Status = "sem PresentMon"; return; }
            Status = Idle;
            // fecha cópias antigas (ex.: o NEXUS foi fechado à força)
            try
            {
                foreach (Process p in Process.GetProcessesByName("PresentMon"))
                {
                    try { if (string.Equals(p.MainModule.FileName, Exe, StringComparison.OrdinalIgnoreCase)) p.Kill(); } catch { }
                }
            }
            catch { }
            Thread t = new Thread(Loop);
            t.IsBackground = true;
            t.Start();
        }

        public static void Stop()
        {
            try { if (proc != null && !proc.HasExited) proc.Kill(); } catch { }
        }

        static int Col(string[] header, params string[] names)
        {
            foreach (string n in names)
                for (int i = 0; i < header.Length; i++)
                    if (string.Equals(header[i].Trim(), n, StringComparison.OrdinalIgnoreCase)) return i;
            return -1;
        }

        static double Val(string[] c, int i)
        {
            if (i < 0 || i >= c.Length) return double.NaN;
            double v;
            return double.TryParse(c[i], System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out v) ? v : double.NaN;
        }

        static void Loop()
        {
            string[] variants = {
                "--output_stdout --stop_existing_session --session_name NEXUS_PresentMon",
                "--output_stdout --session_name NEXUS_PresentMon",
                "--output_stdout" };
            int vi = 0, fails = 0;
            while (!Program.Quitting)
            {
                if (!want) { if (Status != Idle && !Status.StartsWith("PresentMon n") && !Status.StartsWith("PresentMon p")) Status = Idle; Thread.Sleep(1000); continue; }
                DateTime started = DateTime.UtcNow;
                bool gotHeader = false;
                try
                {
                    ProcessStartInfo psi = new ProcessStartInfo(Exe, variants[vi]);
                    psi.UseShellExecute = false; psi.CreateNoWindow = true;
                    psi.RedirectStandardOutput = true; psi.RedirectStandardError = true;
                    psi.WorkingDirectory = Path.GetDirectoryName(Exe);
                    proc = Process.Start(psi);
                    proc.ErrorDataReceived += delegate { };
                    proc.BeginErrorReadLine();
                    Status = "PresentMon a arrancar";

                    string line; string[] header = null;
                    int iApp = -1, iFt = -1;
                    // várias colunas de latência por ordem de preferência; muitas vêm vazias ("NA") conforme o jogo/placa,
                    // por isso usa-se a primeira que trouxer valores a sério
                    string[] latNames = { "MsPCLatency", "MsClickToPhotonLatency", "MsAllInputToPhotonLatency", "DisplayLatency", "MsUntilDisplayed" };
                    int[] latCols = new int[0]; long[] latGood = new long[0]; double[] latVal = new double[0];
                    while ((line = proc.StandardOutput.ReadLine()) != null)
                    {
                        if (header == null)
                        {
                            if (line.IndexOf("Application", StringComparison.OrdinalIgnoreCase) < 0 || line.IndexOf(',') < 0) continue;
                            header = line.Split(',');
                            iApp = Col(header, "Application", "ProcessName");
                            iFt = Col(header, "MsBetweenPresents", "MsBetweenAppStart", "FrameTime", "MsBetweenDisplayChange");
                            latCols = latNames.Select(n => Col(header, n)).Where(i => i >= 0).ToArray();
                            latGood = new long[latCols.Length]; latVal = new double[latCols.Length];
                            gotHeader = iApp >= 0 && iFt >= 0;
                            Status = gotHeader ? "PresentMon" : "PresentMon: formato desconhecido";
                            if (!gotHeader) break;
                            continue;
                        }
                        // lê só as 3 colunas precisas, sem partir a linha toda
                        string app = null; double ft = double.NaN, lat = double.NaN;
                        for (int k = 0; k < latVal.Length; k++) latVal[k] = double.NaN;
                        int field = 0, start = 0, maxI = Math.Max(iApp, iFt);
                        foreach (int c in latCols) maxI = Math.Max(maxI, c);
                        for (int pos = 0; pos <= line.Length && field <= maxI; pos++)
                        {
                            if (pos < line.Length && line[pos] != ',') continue;
                            if (field == iApp) app = line.Substring(start, pos - start);
                            else if (field == iFt) ft = ParseD(line, start, pos - start);
                            else for (int k = 0; k < latCols.Length; k++) if (field == latCols[k]) { latVal[k] = ParseD(line, start, pos - start); break; }
                            field++; start = pos + 1;
                        }
                        for (int k = 0; k < latVal.Length; k++)
                            if (!double.IsNaN(latVal[k]) && latVal[k] > 0 && latVal[k] < 1000) latGood[k]++;
                        for (int k = 0; k < latVal.Length; k++)
                            if (latGood[k] > 0) { lat = latVal[k]; break; }   // a melhor coluna que já deu valores
                        if (app == null || double.IsNaN(ft) || ft <= 0 || ft > 1000) continue;
                        Add(app, ft, lat);
                    }
                    try { proc.WaitForExit(2000); } catch { }
                }
                catch (Exception ex) { Status = "PresentMon: " + ex.Message; }

                if (Program.Quitting) break;
                if (!want) { Status = Idle; continue; }
                if (!gotHeader && (DateTime.UtcNow - started).TotalSeconds < 10)
                {
                    // não arrancou: tenta outra combinação de opções; depois desiste durante 1 minuto
                    if (vi < variants.Length - 1) { vi++; continue; }
                    fails++;
                    Status = Program.IsAdmin() ? "PresentMon não arrancou" : "PresentMon precisa de administrador";
                    Thread.Sleep(Math.Min(60000, 5000 * fails));
                    vi = 0;
                }
                else Thread.Sleep(2000);
            }
        }

        public static string Json()
        {
            if (Status != "PresentMon") return "null";
            long cur = clock.ElapsedMilliseconds / 250;
            string best = null; int bestN = 0; double bestFt = 0, bestLat = 0; int bestLatN = 0;
            lock (lk)
            {
                List<string> dead = null;
                foreach (KeyValuePair<string, Agg> kv in aggs)
                {
                    Agg a = kv.Value;
                    int n = 0, ln = 0; double ft = 0, lat = 0; long newest = 0;
                    for (int k = 0; k < 8; k++)
                    {
                        newest = Math.Max(newest, a.Slot[k]);
                        if (a.Slot[k] < cur - 4 || a.Slot[k] >= cur) continue;   // último segundo completo
                        n += a.Cnt[k]; ft += a.Ft[k]; lat += a.Lat[k]; ln += a.LatN[k];
                    }
                    if (!a.Skip && newest < cur - 40) { if (dead == null) dead = new List<string>(); dead.Add(kv.Key); continue; }
                    if (a.Skip || n < 5 || n <= bestN) continue;
                    best = Path.GetFileNameWithoutExtension(kv.Key); bestN = n; bestFt = ft; bestLat = lat; bestLatN = ln;
                }
                if (dead != null) foreach (string d in dead) aggs.Remove(d);
            }
            if (best == null) return "null";
            double avgFt = bestFt / bestN;
            System.Globalization.CultureInfo ci = System.Globalization.CultureInfo.InvariantCulture;
            return "{\"source\":\"PresentMon\",\"name\":\"" + best.Replace("\\", "\\\\").Replace("\"", "\\\"") + "\",\"fps\":" +
                   (1000.0 / avgFt).ToString("0.0", ci) + ",\"frametime\":" + avgFt.ToString("0.00", ci) +
                   ",\"latency\":" + (bestLatN > 0 ? (bestLat / bestLatN).ToString("0.0", ci) : "null") + "}";
        }
    }
}
