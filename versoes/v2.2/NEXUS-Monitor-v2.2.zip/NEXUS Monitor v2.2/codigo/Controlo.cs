// NEXUS // MONITOR - análise em jogo (gargalo CPU/GPU e alertas no overlay), limite de FPS por jogo (RivaTuner),
// limite de energia da placa NVIDIA, programas que arrancam com o Windows e teste de estabilidade do processador.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using Microsoft.Win32;

namespace Nexus
{
    // ------------------------------------------------------------ gargalo e alertas (alimentado pelo Historico a cada 2 s)
    static class Analise
    {
        static readonly object lk = new object();
        static readonly Queue<double[]> win = new Queue<double[]>();     // [gpu, maxCore, fps]  ~30 s
        static readonly List<float> fpsLong = new List<float>();          // ~60 s, para ver quedas
        static string bott = "", alert = "", lastGame;
        static DateTime alertUntil = DateTime.MinValue;
        static readonly Dictionary<string, int> sessCount = new Dictionary<string, int>();

        public static string Bottleneck { get { lock (lk) return bott; } }

        // últimos frames do jogo (para o mini gráfico do overlay)
        static readonly float[] ring = new float[160]; static int ringN, ringPos;
        public static void Frame(float ft) { lock (ring) { ring[ringPos] = ft; ringPos = (ringPos + 1) % ring.Length; if (ringN < ring.Length) ringN++; } }
        public static float[] LastFrames()
        {
            lock (ring)
            {
                float[] r = new float[ringN];
                for (int i = 0; i < ringN; i++) r[i] = ring[(ringPos - ringN + i + ring.Length) % ring.Length];
                return r;
            }
        }
        // texto do aviso para o overlay (fica 6 s)
        public static string Alert { get { lock (lk) return DateTime.UtcNow < alertUntil ? alert : null; } }

        public static void Feed(string game, double cpu, double? cpuT, double? gpu, double? gpuT, double ram, double fps)
        {
            double maxCore = Stats.MaxCore();
            lock (lk)
            {
                if (game != lastGame) { win.Clear(); fpsLong.Clear(); bott = ""; lastGame = game; }
                if (game == null) return;
                win.Enqueue(new[] { gpu ?? double.NaN, maxCore, fps });
                while (win.Count > 15) win.Dequeue();
                if (!double.IsNaN(fps) && fps > 0) { fpsLong.Add((float)fps); if (fpsLong.Count > 30) fpsLong.RemoveAt(0); }

                // gargalo: média dos últimos ~30 s
                if (win.Count >= 5)
                {
                    double[] g = win.Select(x => x[0]).Where(x => !double.IsNaN(x)).ToArray();
                    double ga = g.Length > 0 ? g.Average() : double.NaN, ca = win.Average(x => x[1]);
                    string b;
                    if (double.IsNaN(ga)) b = "";
                    else if (ga >= 92) b = "GPU";
                    else if (ga < 82 && ca >= 88) b = "CPU";
                    else if (ga < 70 && ca < 70) b = "LIMITE";
                    else b = "OK";
                    bott = b;
                    if (b != "") { int n; sessCount.TryGetValue(b, out n); sessCount[b] = n + 1; }
                }

                // alertas inteligentes
                string a = null;
                if (cpuT.HasValue && cpuT.Value >= AppSettings.AlertCpu) a = Lang.L("CPU QUENTE") + " " + Math.Round(cpuT.Value) + "°";
                else if (gpuT.HasValue && gpuT.Value >= AppSettings.AlertGpu) a = Lang.L("GPU QUENTE") + " " + Math.Round(gpuT.Value) + "°";
                else if (ram >= AppSettings.AlertRam) a = Lang.L("RAM CHEIA") + " " + Math.Round(ram) + "%";
                else if (!double.IsNaN(fps) && fpsLong.Count >= 10)
                {
                    float[] o = fpsLong.ToArray(); Array.Sort(o); float med = o[o.Length / 2];
                    if (med >= 30 && fps < med * 0.6) { a = Lang.L("QUEDA DE FPS") + " " + Math.Round(fps) + " / " + Math.Round(med); Ladroes.OnDrop(game); }
                }
                if (a != null) { alert = a; alertUntil = DateTime.UtcNow.AddSeconds(6); }
            }
        }
        // o gargalo mais visto na sessão (e limpa a contagem)
        public static string TakeSession()
        {
            lock (lk)
            {
                string r = sessCount.Count == 0 ? "" : sessCount.OrderByDescending(x => x.Value).First().Key;
                sessCount.Clear();
                return r;
            }
        }
        public static string Json()
        {
            lock (lk) return "{\"bottleneck\":" + Js.S(bott) + ",\"alert\":" + Js.S(DateTime.UtcNow < alertUntil ? alert : null) + ",\"thieves\":" + Ladroes.Json() + "}";
        }
    }

    // ------------------------------------------------------------ limite de FPS por jogo, pelo RivaTuner Statistics Server (se estiver instalado)
    static class FpsLimite
    {
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] static extern IntPtr LoadLibrary(string f);
        [DllImport("kernel32.dll", CharSet = CharSet.Ansi)] static extern IntPtr GetProcAddress(IntPtr h, string n);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl, CharSet = CharSet.Ansi)] delegate bool LoadProfileD(string profile);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl, CharSet = CharSet.Ansi)] delegate bool SaveProfileD(string profile);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl, CharSet = CharSet.Ansi)] delegate bool SetPropD(string prop, IntPtr data, uint size);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate void UpdateD();
        static readonly object lk = new object();

        public static string Dir
        {
            get
            {
                foreach (string k in new[] { @"SOFTWARE\WOW6432Node\Unwinder\RTSS", @"SOFTWARE\Unwinder\RTSS" })
                    try
                    {
                        using (RegistryKey r = Registry.LocalMachine.OpenSubKey(k))
                        {
                            string d = r == null ? null : Convert.ToString(r.GetValue("InstallDir"));
                            if (!string.IsNullOrEmpty(d) && File.Exists(Path.Combine(d, "RTSSHooks64.dll"))) return d;
                        }
                    }
                    catch { }
                string def = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "RivaTuner Statistics Server");
                return File.Exists(Path.Combine(def, "RTSSHooks64.dll")) ? def : null;
            }
        }
        public static bool Available { get { return Environment.Is64BitProcess && Dir != null; } }

        // fps = 0 tira o limite. exe sem ".exe"
        public static string Set(string exe, int fps)
        {
            string d = Dir;
            if (d == null || !Environment.Is64BitProcess) return Lang.L("precisa do RivaTuner Statistics Server");
            lock (lk)
            {
                try
                {
                    IntPtr h = LoadLibrary(Path.Combine(d, "RTSSHooks64.dll"));
                    if (h == IntPtr.Zero) return Lang.L("não consegui abrir o RivaTuner");
                    IntPtr pl = GetProcAddress(h, "LoadProfile"), ps = GetProcAddress(h, "SaveProfile"), pp = GetProcAddress(h, "SetProfileProperty"), pu = GetProcAddress(h, "UpdateProfiles");
                    if (pl == IntPtr.Zero || ps == IntPtr.Zero || pp == IntPtr.Zero || pu == IntPtr.Zero) return Lang.L("versão do RivaTuner não suportada");
                    LoadProfileD load = (LoadProfileD)Marshal.GetDelegateForFunctionPointer(pl, typeof(LoadProfileD));
                    SaveProfileD save = (SaveProfileD)Marshal.GetDelegateForFunctionPointer(ps, typeof(SaveProfileD));
                    SetPropD prop = (SetPropD)Marshal.GetDelegateForFunctionPointer(pp, typeof(SetPropD));
                    UpdateD upd = (UpdateD)Marshal.GetDelegateForFunctionPointer(pu, typeof(UpdateD));
                    string name = exe.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) ? exe : exe + ".exe";
                    IntPtr buf = Marshal.AllocHGlobal(4);
                    try
                    {
                        Marshal.WriteInt32(buf, Math.Max(0, Math.Min(1000, fps)));
                        load(name);
                        if (!prop("FramerateLimit", buf, 4)) return Lang.L("o RivaTuner não aceitou o limite");
                        save(name);
                        upd();
                    }
                    finally { Marshal.FreeHGlobal(buf); }
                    return null;
                }
                catch (Exception e) { return e.Message; }
            }
        }
    }

    // ------------------------------------------------------------ placa NVIDIA: consumo e limite de energia (nvidia-smi, vem com o driver)
    static class GpuCtl
    {
        static string Smi()
        {
            string s = Path.Combine(Environment.SystemDirectory, "nvidia-smi.exe");
            if (File.Exists(s)) return s;
            s = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), @"NVIDIA Corporation\NVSMI\nvidia-smi.exe");
            return File.Exists(s) ? s : null;
        }
        static string Run(string args, out int code)
        {
            code = -1; string exe = Smi();
            if (exe == null) return null;
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo(exe, args) { UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true, RedirectStandardError = true };
                using (Process p = Process.Start(psi))
                {
                    string o = p.StandardOutput.ReadToEnd() + p.StandardError.ReadToEnd();
                    p.WaitForExit(10000); code = p.ExitCode; return o.Trim();
                }
            }
            catch { return null; }
        }
        static string F(string s) { double v; return double.TryParse(s.Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out v) ? Js.N(v) : "null"; }

        public static string Json()
        {
            int code;
            string o = Run("--query-gpu=name,power.draw,power.limit,power.min_limit,power.max_limit,power.default_limit,clocks.gr,clocks.mem,clocks.max.gr,fan.speed --format=csv,noheader,nounits", out code);
            if (o == null) return "{\"ok\":true,\"nvidia\":false}";
            string[] c = o.Split('\n')[0].Split(',');
            if (code != 0 || c.Length < 10) return "{\"ok\":true,\"nvidia\":false,\"error\":" + Js.S(o) + "}";
            return "{\"ok\":true,\"nvidia\":true,\"name\":" + Js.S(c[0].Trim()) + ",\"draw\":" + F(c[1]) + ",\"limit\":" + F(c[2]) + ",\"min\":" + F(c[3]) + ",\"max\":" + F(c[4]) +
                   ",\"def\":" + F(c[5]) + ",\"clock\":" + F(c[6]) + ",\"mem\":" + F(c[7]) + ",\"maxclock\":" + F(c[8]) + ",\"fan\":" + F(c[9]) + "}";
        }
        // muda o limite de energia (em watts). Fica até reiniciar o PC; "reset" volta ao valor de fábrica
        public static string SetPower(string w)
        {
            double v;
            if (w == "reset")
            {
                string j = Json();
                System.Text.RegularExpressions.Match m = System.Text.RegularExpressions.Regex.Match(j, "\"def\":([0-9.]+)");
                if (!m.Success) return "{\"ok\":false,\"error\":" + Js.S(Lang.L("Sem placa NVIDIA.")) + "}";
                w = m.Groups[1].Value;
            }
            if (!double.TryParse(w, NumberStyles.Float, CultureInfo.InvariantCulture, out v) || v < 10 || v > 1000) return "{\"ok\":false,\"error\":\"valor\"}";
            int code;
            string o = Run("-pl " + Math.Round(v).ToString(CultureInfo.InvariantCulture), out code);
            if (o == null) return "{\"ok\":false,\"error\":" + Js.S(Lang.L("Sem placa NVIDIA.")) + "}";
            if (code != 0) return "{\"ok\":false,\"error\":" + Js.S(o.Split('\n')[0]) + "}";
            return Json();
        }
    }

    // ------------------------------------------------------------ programas que arrancam com o Windows (o mesmo sítio que o Gestor de Tarefas usa para ligar/desligar)
    static class Arranque
    {
        const string RUN = @"Software\Microsoft\Windows\CurrentVersion\Run", RUN32 = @"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run";
        const string APP = @"Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\";
        class E { public string Id, Name, Cmd, Where, ApprovedKey; public RegistryKey Hive; public bool On; }

        static bool Approved(RegistryKey hive, string sub, string name)
        {
            try
            {
                using (RegistryKey k = hive.OpenSubKey(APP + sub))
                {
                    byte[] b = k == null ? null : k.GetValue(name) as byte[];
                    return b == null || b.Length == 0 || (b[0] & 1) == 0;    // 02/06 = ligado, 03/07 = desligado
                }
            }
            catch { return true; }
        }
        static List<E> All()
        {
            List<E> l = new List<E>();
            Action<RegistryKey, string, string, string> reg = (hive, key, sub, where) =>
            {
                try
                {
                    using (RegistryKey k = hive.OpenSubKey(key))
                        if (k != null)
                            foreach (string n in k.GetValueNames())
                            {
                                if (n == "") continue;
                                l.Add(new E { Id = where + "|" + n, Name = n, Cmd = Convert.ToString(k.GetValue(n)), Where = where, Hive = hive, ApprovedKey = sub, On = Approved(hive, sub, n) });
                            }
                }
                catch { }
            };
            reg(Registry.CurrentUser, RUN, "Run", "user");
            reg(Registry.LocalMachine, RUN, "Run", "machine");
            reg(Registry.LocalMachine, RUN32, "Run32", "machine32");
            Action<string, RegistryKey, string> folder = (dir, hive, where) =>
            {
                try
                {
                    if (!Directory.Exists(dir)) return;
                    foreach (string f in Directory.GetFiles(dir))
                    {
                        string n = Path.GetFileName(f);
                        if (n.Equals("desktop.ini", StringComparison.OrdinalIgnoreCase)) continue;
                        l.Add(new E { Id = where + "|" + n, Name = Path.GetFileNameWithoutExtension(f), Cmd = f, Where = where, Hive = hive, ApprovedKey = "StartupFolder", On = Approved(hive, "StartupFolder", n) });
                    }
                }
                catch { }
            };
            folder(Environment.GetFolderPath(Environment.SpecialFolder.Startup), Registry.CurrentUser, "folder");
            folder(Environment.GetFolderPath(Environment.SpecialFolder.CommonStartup), Registry.LocalMachine, "commonfolder");
            return l;
        }
        static string ExeOf(string cmd)
        {
            if (string.IsNullOrEmpty(cmd)) return "";
            cmd = Environment.ExpandEnvironmentVariables(cmd.Trim());
            if (cmd.StartsWith("\"")) { int e = cmd.IndexOf('"', 1); return e > 1 ? cmd.Substring(1, e - 1) : cmd.Trim('"'); }
            int x = cmd.IndexOf(".exe", StringComparison.OrdinalIgnoreCase);
            return x > 0 ? cmd.Substring(0, x + 4) : cmd.Split(' ')[0];
        }
        public static string Json()
        {
            StringBuilder sb = new StringBuilder("{\"ok\":true,\"items\":[");
            bool first = true;
            foreach (E e in All().OrderBy(x => x.Name, StringComparer.OrdinalIgnoreCase))
            {
                string exe = ExeOf(e.Cmd), desc = "", company = "";
                try
                {
                    if (exe.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) && File.Exists(exe))
                    { FileVersionInfo fv = FileVersionInfo.GetVersionInfo(exe); desc = fv.FileDescription ?? ""; company = fv.CompanyName ?? ""; }
                }
                catch { }
                if (!first) sb.Append(','); first = false;
                sb.Append("{\"id\":").Append(Js.S(e.Id)).Append(",\"name\":").Append(Js.S(e.Name)).Append(",\"cmd\":").Append(Js.S(e.Cmd)).Append(",\"where\":").Append(Js.S(e.Where))
                  .Append(",\"on\":").Append(e.On ? "true" : "false").Append(",\"desc\":").Append(Js.S(desc.Trim())).Append(",\"company\":").Append(Js.S(company.Trim()))
                  .Append(",\"nexus\":").Append(e.Name.IndexOf("NEXUS", StringComparison.OrdinalIgnoreCase) >= 0 ? "true" : "false").Append('}');
            }
            return sb.Append("]}").ToString();
        }
        // liga/desliga como o Gestor de Tarefas: não apaga nada, só marca em StartupApproved
        public static string Set(string id, bool on)
        {
            E e = All().FirstOrDefault(x => x.Id == id);
            if (e == null) return "{\"ok\":false,\"error\":" + Js.S(Lang.L("Já não existe.")) + "}";
            try
            {
                string valName = e.ApprovedKey == "StartupFolder" ? id.Substring(id.IndexOf('|') + 1) : e.Name;
                byte[] b = new byte[12];
                b[0] = (byte)(on ? 2 : 3);
                if (!on) BitConverter.GetBytes(DateTime.UtcNow.ToFileTimeUtc()).CopyTo(b, 4);
                using (RegistryKey k = e.Hive.CreateSubKey(APP + e.ApprovedKey)) k.SetValue(valName, b, RegistryValueKind.Binary);
            }
            catch (Exception ex) { return "{\"ok\":false,\"error\":" + Js.S(ex.Message) + "}"; }
            return Json();
        }
    }

    // ------------------------------------------------------------ teste de estabilidade: processador (e RAM) e/ou placa gráfica a 100 %, a ver temperaturas e erros
    // A placa gráfica é posta a trabalhar pela página (WebGL, no browser); aqui só se vigia e se decide quando parar.
    static class Stress
    {
        static readonly object lk = new object();
        static volatile bool run;
        static DateTime start, end, lastGpuPing;
        static int secs, errors, threads, gpuErrors;
        static bool ram, cpuOn, gpuOn;
        static double tMax = double.NaN, tSum, cpuSum, gMax = double.NaN, gSum, gLoadSum, gFps; static int n, gn;
        static List<double> temps = new List<double>(), gtemps = new List<double>();
        static string verdict, stopReason, lastWhen;
        static Timer mon;

        public static bool Running { get { return run; } }
        public static bool GpuRunning { get { return run && gpuOn; } }

        public static string Start(int s, bool withRam) { return Start(s, withRam, true, false); }
        public static string Start(int s, bool withRam, bool cpu, bool gpu)
        {
            lock (lk)
            {
                if (run) return Json();
                if (!cpu && !gpu) cpu = true;
                if (Optimizer.GameName != null) return "{\"ok\":false,\"error\":" + Js.S(Lang.L("fecha o jogo primeiro")) + "}";
                secs = Math.Max(30, Math.Min(900, s)); ram = withRam && cpu; cpuOn = cpu; gpuOn = gpu;
                errors = 0; gpuErrors = 0; tMax = double.NaN; tSum = 0; cpuSum = 0; n = 0; temps.Clear();
                gMax = double.NaN; gSum = 0; gLoadSum = 0; gn = 0; gFps = 0; gtemps.Clear();
                verdict = null; stopReason = null; start = DateTime.Now; end = start.AddSeconds(secs); lastGpuPing = DateTime.Now; run = true;
                threads = cpu ? Environment.ProcessorCount : 0;
            }
            for (int i = 0; i < threads; i++) { Thread t = new Thread(Work) { IsBackground = true, Priority = ThreadPriority.BelowNormal }; t.Start(); }
            if (ram) { Thread t = new Thread(RamWork) { IsBackground = true, Priority = ThreadPriority.BelowNormal }; t.Start(); }
            mon = new Timer(delegate { try { Watch(); } catch { } }, null, 1000, 2000);
            return Json();
        }
        public static string Stop() { Finish(Lang.L("parado por ti")); return Json(); }

        // a página manda, a cada segundo, os FPS do teste e os erros (imagens que não batem certo)
        public static string GpuReport(string fps, string errs)
        {
            lock (lk)
            {
                if (!run || !gpuOn) return Json();
                double f; if (double.TryParse(fps, NumberStyles.Float, CultureInfo.InvariantCulture, out f)) gFps = f;
                int e; if (int.TryParse(errs, out e) && e > gpuErrors) gpuErrors = e;
                lastGpuPing = DateTime.Now;
            }
            return Json();
        }

        // conta sempre o mesmo resultado: se um núcleo errar as contas, o PC não está estável
        static void Work()
        {
            double expect = Calc(1);
            while (run)
            {
                double r = Calc(1);
                if (Math.Abs(r - expect) > 1e-9) Interlocked.Increment(ref errors);
            }
        }
        static double Calc(int seed)
        {
            double a = seed, s = 0;
            for (int i = 1; i < 400000; i++) { a = Math.Sqrt(a * 1.000001 + i) * Math.Sin(i * 0.001) + Math.Cos(a * 0.0001); s += a / i; }
            return s;
        }
        const long GOLD = unchecked((long)0x9E3779B97F4A7C15UL);
        static void RamWork()
        {
            ulong freeMb = 0;
            try { freeMb = new Microsoft.VisualBasic.Devices.ComputerInfo().AvailablePhysicalMemory / 1048576; } catch { }
            int mb = (int)Math.Max(256, Math.Min(4096, freeMb / 3));
            List<long[]> blocks = new List<long[]>();
            try { for (int i = 0; i < mb / 64 && run; i++) blocks.Add(new long[64 * 1024 * 1024 / 8]); } catch (OutOfMemoryException) { }
            long pass = 0;
            while (run)
            {
                pass++;
                foreach (long[] b in blocks) { long v = pass * GOLD; for (int i = 0; i < b.Length; i++) b[i] = v ^ i; }
                foreach (long[] b in blocks) { long v = pass * GOLD; for (int i = 0; i < b.Length; i++) if (b[i] != (v ^ i)) { Interlocked.Increment(ref errors); break; } }
                if (!run) break;
            }
            blocks.Clear(); GC.Collect();
        }
        static void Watch()
        {
            double cpu, ramP, ramG; double? cpuT, gpu, gpuT;
            Stats.OverlaySnap(out cpu, out cpuT, out gpu, out gpuT, out ramP, out ramG);
            bool gpuLost;
            lock (lk)
            {
                if (!run) return;
                n++; cpuSum += cpu;
                if (cpuT.HasValue) { temps.Add(cpuT.Value); tSum += cpuT.Value; if (double.IsNaN(tMax) || cpuT.Value > tMax) tMax = cpuT.Value; }
                if (gpuOn && gpuT.HasValue) { gtemps.Add(gpuT.Value); gSum += gpuT.Value; gn++; if (double.IsNaN(gMax) || gpuT.Value > gMax) gMax = gpuT.Value; }
                if (gpuOn && gpu.HasValue) gLoadSum += gpu.Value;
                gpuLost = gpuOn && (DateTime.Now - lastGpuPing).TotalSeconds > 12;
            }
            if (cpuOn && cpuT.HasValue && cpuT.Value >= 98) { Finish(Lang.L("parado: o processador chegou aos 98 °C")); return; }
            if (gpuOn && gpuT.HasValue && gpuT.Value >= 92) { Finish(Lang.L("parado: a placa gráfica chegou aos 92 °C")); return; }
            if (gpuLost) { Finish(Lang.L("parado: a página do teste fechou ou ficou escondida")); return; }
            // o teste da placa corre no browser, que pode parecer um jogo: aí não se para por isso
            if (!gpuOn && Optimizer.GameName != null) { Finish(Lang.L("parado: abriste um jogo")); return; }
            if (DateTime.Now >= end) Finish(null);
        }
        static void Finish(string why)
        {
            lock (lk)
            {
                if (!run) return;
                run = false; stopReason = why; lastWhen = DateTime.Now.ToString("dd/MM HH:mm");
                try { if (mon != null) mon.Dispose(); } catch { }
                List<string> v = new List<string>();
                if (cpuOn)
                {
                    if (errors > 0) v.Add(Lang.L("PROCESSADOR/RAM INSTÁVEL: houve erros de cálculo. Se tens overclock ou undervolt, baixa-o."));
                    else if (!double.IsNaN(tMax) && tMax >= 95) v.Add(Lang.L("PROCESSADOR SEM ERROS, MAS MUITO QUENTE: vê a pasta térmica, o cooler e o pó."));
                    else if (!double.IsNaN(tMax) && tMax >= 85) v.Add(Lang.L("PROCESSADOR ESTÁVEL, mas quente. Está dentro do normal para muitos processadores."));
                    else v.Add(Lang.L("PROCESSADOR ESTÁVEL e com temperaturas boas."));
                }
                if (gpuOn)
                {
                    if (gpuErrors > 0) v.Add(Lang.L("PLACA GRÁFICA INSTÁVEL: apareceram imagens erradas (artefactos). Se tens overclock na placa, baixa-o."));
                    else if (!double.IsNaN(gMax) && gMax >= 88) v.Add(Lang.L("PLACA GRÁFICA SEM ERROS, MAS MUITO QUENTE: vê a ventilação da caixa e o pó."));
                    else if (!double.IsNaN(gMax) && gMax >= 80) v.Add(Lang.L("PLACA GRÁFICA ESTÁVEL, mas quente. Normal em placas potentes."));
                    else v.Add(Lang.L("PLACA GRÁFICA ESTÁVEL e com temperaturas boas."));
                }
                verdict = string.Join(" ", v.ToArray());
            }
            ThreadPool.QueueUserWorkItem(delegate { try { Program.Notify("NEXUS · " + Lang.L("Teste de estabilidade"), verdict); } catch { } });
        }
        public static string Json()
        {
            lock (lk)
            {
                double left = run ? Math.Max(0, (end - DateTime.Now).TotalSeconds) : 0;
                return "{\"ok\":true,\"running\":" + (run ? "true" : "false") + ",\"secs\":" + secs + ",\"left\":" + Math.Round(left) + ",\"ram\":" + (ram ? "true" : "false") +
                       ",\"cpuon\":" + (cpuOn ? "true" : "false") + ",\"gpuon\":" + (gpuOn ? "true" : "false") +
                       ",\"threads\":" + threads + ",\"errors\":" + errors + ",\"tmax\":" + Js.N(tMax) + ",\"tavg\":" + Js.N(temps.Count > 0 ? tSum / temps.Count : double.NaN) +
                       ",\"cpu\":" + Js.N(n > 0 ? cpuSum / n : double.NaN) +
                       ",\"gerrors\":" + gpuErrors + ",\"gmax\":" + Js.N(gMax) + ",\"gavg\":" + Js.N(gn > 0 ? gSum / gn : double.NaN) + ",\"gload\":" + Js.N(gn > 0 ? gLoadSum / gn : double.NaN) +
                       ",\"gfps\":" + Js.N(gFps) + ",\"verdict\":" + Js.S(verdict) + ",\"why\":" + Js.S(stopReason) + ",\"when\":" + Js.S(lastWhen) +
                       ",\"temps\":[" + string.Join(",", temps.Select(x => Js.N(x)).ToArray()) + "],\"gtemps\":[" + string.Join(",", gtemps.Select(x => Js.N(x)).ToArray()) + "]}";
            }
        }
    }
}
