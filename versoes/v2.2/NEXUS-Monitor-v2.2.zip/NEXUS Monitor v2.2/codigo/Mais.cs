// NEXUS // MONITOR - ventoinhas (curvas), ladrões de FPS, ping, DNS mais rápido, limpeza automática, BIOS e drivers antigos,
// notificações no telemóvel (ntfy) e Wake-on-LAN.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Management;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using Microsoft.Win32;

namespace Nexus
{
    // ------------------------------------------------------------ ventoinhas da placa-mãe: automático (BIOS), fixo ou curva pela temperatura
    // Só no modo Completo (LibreHardwareMonitor). Ao fechar o NEXUS, tudo volta ao controlo da BIOS.
    static class Ventoinhas
    {
        public class Cfg { public string Id, Mode = "auto", Src = "cpu"; public int Fixed = 60; public int[] T = { 40, 55, 70, 85 }, P = { 30, 45, 70, 100 }; }
        static readonly object lk = new object();
        static Dictionary<string, Cfg> cfg;
        static readonly Dictionary<string, double> applied = new Dictionary<string, double>();
        static Timer timer;
        static string FileV { get { return Path.Combine(AppSettings.Dir, "ventoinhas.txt"); } }

        static void Load()
        {
            if (cfg != null) return;
            cfg = new Dictionary<string, Cfg>();
            try
            {
                if (File.Exists(FileV))
                    foreach (string line in File.ReadAllLines(FileV, Encoding.UTF8))
                    {
                        string[] c = line.Split('|');
                        if (c.Length < 5) continue;
                        Cfg x = new Cfg { Id = c[0], Mode = c[1], Src = c[2] };
                        int.TryParse(c[3], out x.Fixed);
                        string[] pts = c[4].Split(',');
                        if (pts.Length == 4)
                            for (int i = 0; i < 4; i++) { string[] tp = pts[i].Split(':'); if (tp.Length == 2) { int.TryParse(tp[0], out x.T[i]); int.TryParse(tp[1], out x.P[i]); } }
                        cfg[x.Id] = x;
                    }
            }
            catch { }
        }
        static void SaveCfg()
        {
            try
            {
                Directory.CreateDirectory(AppSettings.Dir);
                File.WriteAllLines(FileV, cfg.Values.Select(x => x.Id + "|" + x.Mode + "|" + x.Src + "|" + x.Fixed + "|" +
                    string.Join(",", Enumerable.Range(0, 4).Select(i => x.T[i] + ":" + x.P[i]).ToArray())).ToArray(), new UTF8Encoding(false));
            }
            catch { }
        }
        public static void Start() { timer = new Timer(delegate { try { Tick(); } catch { } }, null, 8000, 2000); }
        public static void Shutdown()
        {
            lock (lk) { foreach (string id in applied.Keys.ToList()) Embedded.SetControl(id, null); applied.Clear(); }
        }
        static double Curve(Cfg c, double t)
        {
            if (t <= c.T[0]) return c.P[0];
            for (int i = 1; i < 4; i++) if (t <= c.T[i]) return c.P[i - 1] + (c.P[i] - c.P[i - 1]) * (t - c.T[i - 1]) / Math.Max(1, c.T[i] - c.T[i - 1]);
            return c.P[3];
        }
        static void Tick()
        {
            lock (lk)
            {
                Load();
                if (cfg.Count == 0 || !Embedded.HasControls) return;
                double cpu, ram, ramG; double? cpuT, gpu, gpuT;
                Stats.OverlaySnap(out cpu, out cpuT, out gpu, out gpuT, out ram, out ramG);
                foreach (Cfg c in cfg.Values)
                {
                    double? want = null;
                    if (c.Mode == "fixed") want = c.Fixed;
                    else if (c.Mode == "curve")
                    {
                        double? t = c.Src == "gpu" ? gpuT : c.Src == "max" ? (cpuT.HasValue && gpuT.HasValue ? Math.Max(cpuT.Value, gpuT.Value) : cpuT ?? gpuT) : cpuT;
                        if (!t.HasValue) want = null;                          // sem sensor: deixa a BIOS decidir
                        else if (t.Value >= 90) want = 100;                     // segurança
                        else
                        {
                            double v = Curve(c, t.Value), prev;
                            // não sobe e desce por 1 °C: só muda se a diferença for de 3 % ou mais
                            if (applied.TryGetValue(c.Id, out prev) && Math.Abs(prev - v) < 3) continue;
                            want = v;
                        }
                    }
                    if (want.HasValue)
                    {
                        double w = Math.Max(c.Mode == "fixed" ? 0 : 20, Math.Min(100, want.Value));
                        double prev2;
                        if (applied.TryGetValue(c.Id, out prev2) && Math.Abs(prev2 - w) < 0.5) continue;
                        if (Embedded.SetControl(c.Id, w) == null) applied[c.Id] = w;
                    }
                    else if (applied.ContainsKey(c.Id)) { Embedded.SetControl(c.Id, null); applied.Remove(c.Id); }
                }
            }
        }
        public static string Json()
        {
            lock (lk)
            {
                Load();
                StringBuilder sb = new StringBuilder("{\"ok\":true,\"full\":" + (Program.FullMode ? "true" : "false") + ",\"fans\":[");
                bool first = true;
                foreach (string[] c in Embedded.Controls())
                {
                    Cfg x; if (!cfg.TryGetValue(c[0], out x)) x = new Cfg { Id = c[0] };
                    if (!first) sb.Append(','); first = false;
                    sb.Append("{\"id\":").Append(Js.S(c[0])).Append(",\"name\":").Append(Js.S(c[1])).Append(",\"hw\":").Append(Js.S(c[2])).Append(",\"pct\":").Append(c[3])
                      .Append(",\"mode\":").Append(Js.S(x.Mode)).Append(",\"src\":").Append(Js.S(x.Src)).Append(",\"fixed\":").Append(x.Fixed)
                      .Append(",\"t\":[").Append(string.Join(",", x.T.Select(v => v.ToString()).ToArray())).Append("],\"p\":[").Append(string.Join(",", x.P.Select(v => v.ToString()).ToArray())).Append("]}");
                }
                return sb.Append("]}").ToString();
            }
        }
        // mode=auto|fixed|curve, src=cpu|gpu|max, fixed=N, t=40,55,70,85, p=30,45,70,100
        public static string Set(string id, string mode, string src, string fx, string t, string p)
        {
            lock (lk)
            {
                Load();
                if (string.IsNullOrEmpty(id)) return "{\"ok\":false}";
                Cfg x; if (!cfg.TryGetValue(id, out x)) { x = new Cfg { Id = id }; cfg[id] = x; }
                if (mode == "auto" || mode == "fixed" || mode == "curve") x.Mode = mode;
                if (src == "cpu" || src == "gpu" || src == "max") x.Src = src;
                int f; if (int.TryParse(fx, out f)) x.Fixed = Math.Max(0, Math.Min(100, f));
                int[] tt = Ints(t), pp = Ints(p);
                if (tt != null && pp != null)
                {
                    for (int i = 0; i < 4; i++) { x.T[i] = Math.Max(20, Math.Min(100, tt[i])); x.P[i] = Math.Max(20, Math.Min(100, pp[i])); }
                    for (int i = 1; i < 4; i++) { if (x.T[i] <= x.T[i - 1]) x.T[i] = Math.Min(100, x.T[i - 1] + 1); if (x.P[i] < x.P[i - 1]) x.P[i] = x.P[i - 1]; }
                }
                if (x.Mode == "auto") { cfg.Remove(id); if (applied.ContainsKey(id)) { Embedded.SetControl(id, null); applied.Remove(id); } }
                else applied.Remove(id);   // aplica já no próximo ciclo
                SaveCfg();
            }
            ThreadPool.QueueUserWorkItem(delegate { try { Tick(); } catch { } });
            return Json();
        }
        static int[] Ints(string s)
        {
            if (string.IsNullOrEmpty(s)) return null;
            string[] a = s.Split(',');
            if (a.Length != 4) return null;
            int[] r = new int[4];
            for (int i = 0; i < 4; i++) if (!int.TryParse(a[i], out r[i])) return null;
            return r;
        }
    }

    // ------------------------------------------------------------ ladrões de FPS: que programas gastam processador quando os FPS caem
    static class Ladroes
    {
        static readonly object lk = new object();
        static readonly Dictionary<string, int> count = new Dictionary<string, int>();
        static readonly List<string[]> recent = new List<string[]>();   // { hora, nome, % }
        static int busy;
        static readonly HashSet<string> skip = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "Idle", "System", "NEXUS Monitor", "PresentMon", "Memory Compression", "Registry", "audiodg" };

        // chamado quando o Analise vê uma queda de FPS
        public static void OnDrop(string game)
        {
            if (Interlocked.Exchange(ref busy, 1) == 1) return;
            ThreadPool.QueueUserWorkItem(delegate
            {
                try
                {
                    string g = (game ?? "").Replace(".exe", "");
                    Dictionary<int, KeyValuePair<string, TimeSpan>> a = Snap();
                    Thread.Sleep(800);
                    Dictionary<int, KeyValuePair<string, TimeSpan>> b = Snap();
                    int cores = Environment.ProcessorCount;
                    Dictionary<string, double> pct = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
                    foreach (KeyValuePair<int, KeyValuePair<string, TimeSpan>> kv in b)
                    {
                        KeyValuePair<string, TimeSpan> old;
                        if (!a.TryGetValue(kv.Key, out old) || old.Key != kv.Value.Key) continue;
                        string n = kv.Value.Key;
                        if (skip.Contains(n) || n.Equals(g, StringComparison.OrdinalIgnoreCase)) continue;
                        double p = (kv.Value.Value - old.Value).TotalMilliseconds / 800.0 / cores * 100;
                        double cur; pct.TryGetValue(n, out cur); pct[n] = cur + p;
                    }
                    lock (lk)
                        foreach (KeyValuePair<string, double> kv in pct.Where(x => x.Value >= 3).OrderByDescending(x => x.Value).Take(3))
                        {
                            int c; count.TryGetValue(kv.Key, out c); count[kv.Key] = c + 1;
                            recent.Insert(0, new[] { DateTime.Now.ToString("HH:mm:ss"), kv.Key, Math.Round(kv.Value).ToString() });
                            if (recent.Count > 20) recent.RemoveAt(recent.Count - 1);
                        }
                }
                catch { }
                finally { Interlocked.Exchange(ref busy, 0); }
            });
        }
        static Dictionary<int, KeyValuePair<string, TimeSpan>> Snap()
        {
            Dictionary<int, KeyValuePair<string, TimeSpan>> d = new Dictionary<int, KeyValuePair<string, TimeSpan>>();
            foreach (Process p in Process.GetProcesses())
            {
                try { d[p.Id] = new KeyValuePair<string, TimeSpan>(p.ProcessName, p.TotalProcessorTime); } catch { }
                finally { p.Dispose(); }
            }
            return d;
        }
        // os 3 mais vistos na sessão (e limpa)
        public static string TakeSession()
        {
            lock (lk)
            {
                string r = string.Join(", ", count.OrderByDescending(x => x.Value).Take(3).Select(x => x.Key).ToArray());
                count.Clear();
                return r;
            }
        }
        public static string Json()
        {
            lock (lk)
                return "[" + string.Join(",", recent.Select(r => "{\"t\":" + Js.S(r[0]) + ",\"name\":" + Js.S(r[1]) + ",\"pct\":" + r[2] + "}").ToArray()) + "]";
        }
    }

    // ------------------------------------------------------------ ping: latência, variação (jitter) e pacotes perdidos
    static class PingMon
    {
        static readonly object lk = new object();
        static readonly List<double> last = new List<double>();   // -1 = perdido; últimos 120 s
        static Thread th;
        static string target = "", resolved = "";
        public static void Start() { th = new Thread(Loop) { IsBackground = true, Priority = ThreadPriority.BelowNormal }; th.Start(); }
        static string Gateway()
        {
            try
            {
                foreach (NetworkInterface ni in NetworkInterface.GetAllNetworkInterfaces())
                {
                    if (ni.OperationalStatus != OperationalStatus.Up) continue;
                    foreach (GatewayIPAddressInformation g in ni.GetIPProperties().GatewayAddresses)
                        if (g.Address.AddressFamily == AddressFamily.InterNetwork && !g.Address.Equals(IPAddress.Any)) return g.Address.ToString();
                }
            }
            catch { }
            return "";
        }
        static void Loop()
        {
            using (Ping p = new Ping())
                while (true)
                {
                    if (!AppSettings.PingOn) { lock (lk) { last.Clear(); target = ""; } Thread.Sleep(2000); continue; }
                    string t = AppSettings.PingTarget == "" ? Gateway() : AppSettings.PingTarget;
                    lock (lk) { if (t != target) { last.Clear(); target = t; } resolved = t; }
                    double v = -1;
                    DateTime st = DateTime.UtcNow;
                    if (t != "")
                        try { PingReply r = p.Send(t, 1000); if (r.Status == IPStatus.Success) v = r.RoundtripTime; } catch { }
                    lock (lk) { last.Add(v); if (last.Count > 120) last.RemoveAt(0); }
                    int wait = 1000 - (int)(DateTime.UtcNow - st).TotalMilliseconds;
                    if (wait > 0) Thread.Sleep(wait);
                }
        }
        public static double? Now { get { lock (lk) return last.Count == 0 || last[last.Count - 1] < 0 ? (double?)null : last[last.Count - 1]; } }
        public static string Json()
        {
            lock (lk)
            {
                List<double> ok = last.Where(x => x >= 0).ToList();
                double loss = last.Count == 0 ? double.NaN : (last.Count - ok.Count) * 100.0 / last.Count;
                double jit = double.NaN;
                if (ok.Count >= 2) { double s = 0; for (int i = 1; i < ok.Count; i++) s += Math.Abs(ok[i] - ok[i - 1]); jit = s / (ok.Count - 1); }
                return "{\"ok\":true,\"on\":" + (AppSettings.PingOn ? "true" : "false") + ",\"target\":" + Js.S(resolved) + ",\"custom\":" + Js.S(AppSettings.PingTarget) +
                       ",\"now\":" + Js.N(last.Count > 0 && last[last.Count - 1] >= 0 ? last[last.Count - 1] : double.NaN) +
                       ",\"avg\":" + Js.N(ok.Count > 0 ? ok.Average() : double.NaN) + ",\"min\":" + Js.N(ok.Count > 0 ? ok.Min() : double.NaN) + ",\"max\":" + Js.N(ok.Count > 0 ? ok.Max() : double.NaN) +
                       ",\"jitter\":" + Js.N(jit) + ",\"loss\":" + Js.N(loss) + ",\"hist\":[" + string.Join(",", last.Select(x => x < 0 ? "null" : Js.N(x)).ToArray()) + "]}";
            }
        }
    }

    // ------------------------------------------------------------ DNS: mede servidores públicos e muda o da placa de rede (com volta ao automático)
    static class DnsBench
    {
        static readonly string[][] Servers = {
            new[] { "Cloudflare", "1.1.1.1", "1.0.0.1" }, new[] { "Google", "8.8.8.8", "8.8.4.4" }, new[] { "Quad9", "9.9.9.9", "149.112.112.112" },
            new[] { "OpenDNS", "208.67.222.222", "208.67.220.220" }, new[] { "AdGuard", "94.140.14.14", "94.140.15.15" } };
        static readonly string[] Domains = { "google.com", "youtube.com", "discord.com", "steampowered.com", "epicgames.com", "riotgames.com", "twitch.tv", "microsoft.com" };
        static string last;
        static int running;

        static double Query(string server, string domain)
        {
            try
            {
                using (UdpClient u = new UdpClient())
                {
                    u.Client.ReceiveTimeout = 1500;
                    List<byte> q = new List<byte> { (byte)Environment.TickCount, 0x2A, 0x01, 0x00, 0, 1, 0, 0, 0, 0, 0, 0 };
                    foreach (string part in domain.Split('.')) { q.Add((byte)part.Length); q.AddRange(Encoding.ASCII.GetBytes(part)); }
                    q.AddRange(new byte[] { 0, 0, 1, 0, 1 });
                    Stopwatch sw = Stopwatch.StartNew();
                    u.Send(q.ToArray(), q.Count, new IPEndPoint(IPAddress.Parse(server), 53));
                    IPEndPoint from = new IPEndPoint(IPAddress.Any, 0);
                    byte[] r = u.Receive(ref from);
                    sw.Stop();
                    return r.Length > 12 ? sw.Elapsed.TotalMilliseconds : -1;
                }
            }
            catch { return -1; }
        }
        static List<string> CurrentDns(out bool dhcp, out string adapter)
        {
            dhcp = true; adapter = "";
            List<string> l = new List<string>();
            try
            {
                using (ManagementObjectSearcher s = new ManagementObjectSearcher("SELECT Description, DNSServerSearchOrder, DefaultIPGateway, SettingID FROM Win32_NetworkAdapterConfiguration WHERE IPEnabled = TRUE"))
                    foreach (ManagementObject m in s.Get())
                    {
                        string[] gw = m["DefaultIPGateway"] as string[];
                        if (gw == null || gw.Length == 0) continue;
                        adapter = Convert.ToString(m["Description"]);
                        string[] d = m["DNSServerSearchOrder"] as string[];
                        if (d != null) l.AddRange(d.Where(x => x.Contains('.')));
                        // DNS escolhido à mão fica no registo em NameServer; vazio = automático (DHCP)
                        using (RegistryKey k = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\" + Convert.ToString(m["SettingID"])))
                            dhcp = k == null || string.IsNullOrEmpty(Convert.ToString(k.GetValue("NameServer")));
                        break;
                    }
            }
            catch { }
            return l;
        }
        public static string Json()
        {
            bool dhcp; string ad;
            List<string> cur = CurrentDns(out dhcp, out ad);
            return "{\"ok\":true,\"adapter\":" + Js.S(ad) + ",\"current\":[" + string.Join(",", cur.Select(x => Js.S(x)).ToArray()) + "],\"auto\":" + (dhcp ? "true" : "false") +
                   ",\"running\":" + (running == 1 ? "true" : "false") + ",\"results\":" + (last ?? "null") + "}";
        }
        public static string Run()
        {
            if (Interlocked.Exchange(ref running, 1) == 1) return Json();
            ThreadPool.QueueUserWorkItem(delegate
            {
                try
                {
                    bool dhcp; string ad;
                    List<string> cur = CurrentDns(out dhcp, out ad);
                    List<string[]> list = new List<string[]>();
                    if (cur.Count > 0 && !Servers.Any(x => x[1] == cur[0])) list.Add(new[] { "Atual", cur[0], cur.Count > 1 ? cur[1] : "" });
                    list.AddRange(Servers);
                    StringBuilder sb = new StringBuilder("[");
                    bool first = true;
                    foreach (string[] sv in list)
                    {
                        List<double> t = new List<double>(); int fail = 0;
                        foreach (string d in Domains) { double v = Query(sv[1], d); if (v < 0) fail++; else t.Add(v); }
                        t.Sort();
                        double med = t.Count == 0 ? double.NaN : t[t.Count / 2];
                        if (!first) sb.Append(','); first = false;
                        sb.Append("{\"name\":").Append(Js.S(sv[0])).Append(",\"ip\":").Append(Js.S(sv[1])).Append(",\"ip2\":").Append(Js.S(sv[2]))
                          .Append(",\"ms\":").Append(Js.N(med)).Append(",\"fail\":").Append(fail).Append(",\"current\":").Append(cur.Contains(sv[1]) ? "true" : "false").Append('}');
                    }
                    last = sb.Append(']').ToString();
                }
                catch { }
                finally { Interlocked.Exchange(ref running, 0); }
            });
            return Json();
        }
        // ip vazio = automático (o do router/fornecedor)
        public static string Apply(string ip, string ip2)
        {
            try
            {
                IPAddress tmp;
                if (!string.IsNullOrEmpty(ip) && !IPAddress.TryParse(ip, out tmp)) return "{\"ok\":false,\"error\":\"ip\"}";
                if (!string.IsNullOrEmpty(ip2) && !IPAddress.TryParse(ip2, out tmp)) ip2 = "";
                bool done = false;
                using (ManagementObjectSearcher s = new ManagementObjectSearcher("SELECT * FROM Win32_NetworkAdapterConfiguration WHERE IPEnabled = TRUE"))
                    foreach (ManagementObject m in s.Get())
                    {
                        string[] gw = m["DefaultIPGateway"] as string[];
                        if (gw == null || gw.Length == 0) continue;
                        ManagementBaseObject p = m.GetMethodParameters("SetDNSServerSearchOrder");
                        p["DNSServerSearchOrder"] = string.IsNullOrEmpty(ip) ? null : (string.IsNullOrEmpty(ip2) ? new[] { ip } : new[] { ip, ip2 });
                        ManagementBaseObject r = m.InvokeMethod("SetDNSServerSearchOrder", p, null);
                        uint code = Convert.ToUInt32(r["ReturnValue"]);
                        if (code != 0 && code != 1) return "{\"ok\":false,\"error\":" + Js.S(Lang.L("o Windows recusou (código") + " " + code + ")") + "}";
                        done = true;
                    }
                if (!done) return "{\"ok\":false,\"error\":" + Js.S(Lang.L("Sem placa de rede ligada.")) + "}";
                try { Process.Start(new ProcessStartInfo("ipconfig", "/flushdns") { CreateNoWindow = true, UseShellExecute = false }); } catch { }
            }
            catch (Exception ex) { return "{\"ok\":false,\"error\":" + Js.S(ex.Message) + "}"; }
            return Json();
        }
    }

    // ------------------------------------------------------------ limpeza automática (um dia por semana ou todos os dias, a uma hora)
    static class LimpezaAuto
    {
        static Timer timer;
        public static void Start() { timer = new Timer(delegate { try { Check(); } catch { } }, null, 120000, 300000); }
        static void Check()
        {
            if (!AppSettings.CleanAuto) return;
            DateTime n = DateTime.Now;
            string today = n.ToString("yyyy-MM-dd");
            if (AppSettings.CleanLast == today) return;
            if (AppSettings.CleanDay < 7 && (int)n.DayOfWeek != AppSettings.CleanDay) return;
            if (n.Hour < AppSettings.CleanHour) return;
            if (Optimizer.Playing || Optimizer.GameName != null || Stress.Running) return;     // nunca a meio de um jogo
            AppSettings.CleanLast = today;
            try { AppSettings.Save(); } catch { }
            string r = "";
            try { if (AppSettings.CleanIds != "") r = Cleaner.Run(AppSettings.CleanIds); } catch { }
            if (AppSettings.CleanRam) try { Optimizer.Clean(true); } catch { }
            System.Text.RegularExpressions.Match m = System.Text.RegularExpressions.Regex.Match(r ?? "", "\"freed\":([0-9.]+)");
            double mb = 0;
            if (m.Success) double.TryParse(m.Groups[1].Value, NumberStyles.Float, CultureInfo.InvariantCulture, out mb);
            Program.Notify("NEXUS · " + Lang.L("Limpeza automática"), mb > 0 ? Lang.L("Libertado:") + " " + (mb >= 1073741824 ? (mb / 1073741824).ToString("0.0", CultureInfo.InvariantCulture) + " GB" : Math.Round(mb / 1048576) + " MB") : Lang.L("Feita."));
        }
    }

    // ------------------------------------------------------------ BIOS e drivers antigos
    static class Bios
    {
        static string cache; static DateTime at = DateTime.MinValue;
        static string Wmi(string cls, string prop)
        {
            try { using (ManagementObjectSearcher s = new ManagementObjectSearcher("SELECT " + prop + " FROM " + cls)) foreach (ManagementObject m in s.Get()) return Convert.ToString(m[prop]) ?? ""; } catch { }
            return "";
        }
        static string Support(string maker)
        {
            string m = maker.ToLowerInvariant();
            if (m.Contains("asus")) return "https://www.asus.com/support/download-center/";
            if (m.Contains("micro-star") || m.Contains("msi")) return "https://www.msi.com/support/download";
            if (m.Contains("gigabyte")) return "https://www.gigabyte.com/Support";
            if (m.Contains("asrock")) return "https://www.asrock.com/support/index.asp";
            if (m.Contains("dell")) return "https://www.dell.com/support/home";
            if (m.Contains("hp") || m.Contains("hewlett")) return "https://support.hp.com/drivers";
            if (m.Contains("lenovo")) return "https://pcsupport.lenovo.com/";
            if (m.Contains("acer")) return "https://www.acer.com/support";
            if (m.Contains("biostar")) return "https://www.biostar.com.tw/app/en/support/download.php";
            return "";
        }
        public static string Json()
        {
            lock (typeof(Bios))
            {
                if (cache != null && (DateTime.Now - at).TotalMinutes < 30) return cache;
                string maker = Wmi("Win32_BaseBoard", "Manufacturer"), board = Wmi("Win32_BaseBoard", "Product");
                string bver = Wmi("Win32_BIOS", "SMBIOSBIOSVersion"), bdate = Wmi("Win32_BIOS", "ReleaseDate");
                int days = -1; string date = "";
                if (bdate.Length >= 8) { DateTime d; if (DateTime.TryParseExact(bdate.Substring(0, 8), "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out d)) { days = (int)(DateTime.Now - d).TotalDays; date = d.ToString("dd/MM/yyyy"); } }
                StringBuilder sb = new StringBuilder("{\"ok\":true,\"maker\":" + Js.S(maker.Trim()) + ",\"board\":" + Js.S(board.Trim()) + ",\"bios\":" + Js.S(bver.Trim()) +
                    ",\"date\":" + Js.S(date) + ",\"days\":" + days + ",\"url\":" + Js.S(Support(maker)) + ",\"old\":[");
                // drivers de terceiros com mais de 3 anos (os da Microsoft vêm com o Windows e atualizam-se pelo Windows Update)
                try
                {
                    bool first = true; int n = 0;
                    using (ManagementObjectSearcher s = new ManagementObjectSearcher("SELECT DeviceName, DriverVersion, DriverDate, DriverProviderName, DeviceClass FROM Win32_PnPSignedDriver"))
                        foreach (ManagementObject m in s.Get())
                        {
                            string prov = Convert.ToString(m["DriverProviderName"]) ?? "", cls = (Convert.ToString(m["DeviceClass"]) ?? "").ToUpperInvariant(), dd = Convert.ToString(m["DriverDate"]) ?? "";
                            if (prov == "" || prov.IndexOf("Microsoft", StringComparison.OrdinalIgnoreCase) >= 0) continue;
                            if (!(cls == "NET" || cls == "MEDIA" || cls == "SYSTEM" || cls == "HDC" || cls == "SCSIADAPTER" || cls == "BLUETOOTH" || cls == "USB")) continue;
                            DateTime dt;
                            if (dd.Length < 8 || !DateTime.TryParseExact(dd.Substring(0, 8), "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out dt)) continue;
                            int age = (int)(DateTime.Now - dt).TotalDays;
                            if (age < 3 * 365 || dt.Year < 2000) continue;
                            if (++n > 25) break;
                            if (!first) sb.Append(','); first = false;
                            sb.Append("{\"name\":").Append(Js.S(Convert.ToString(m["DeviceName"]))).Append(",\"ver\":").Append(Js.S(Convert.ToString(m["DriverVersion"])))
                              .Append(",\"date\":").Append(Js.S(dt.ToString("dd/MM/yyyy"))).Append(",\"days\":").Append(age).Append(",\"prov\":").Append(Js.S(prov)).Append(",\"cls\":").Append(Js.S(cls)).Append('}');
                        }
                }
                catch { }
                cache = sb.Append("]}").ToString(); at = DateTime.Now;
                return cache;
            }
        }
    }

    // ------------------------------------------------------------ notificações no telemóvel pela app ntfy (opcional; passam pelo servidor ntfy escolhido)
    static class Ntfy
    {
        public static void Send(string title, string text) { Send(title, text, false); }
        public static void Send(string title, string text, bool force)
        {
            if (!force && (!AppSettings.NtfyOn || AppSettings.NtfyTopic.Length < 6)) return;
            if (AppSettings.NtfyTopic.Length < 6) return;
            string url = AppSettings.NtfyServer.TrimEnd('/') + "/" + AppSettings.NtfyTopic;
            ThreadPool.QueueUserWorkItem(delegate
            {
                try
                {
                    ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
                    HttpWebRequest rq = (HttpWebRequest)WebRequest.Create(url);
                    rq.Method = "POST"; rq.Timeout = 10000; rq.UserAgent = "NEXUS-Monitor";
                    rq.Headers["Title"] = Ascii(title);
                    rq.Headers["Tags"] = "desktop_computer";
                    byte[] b = Encoding.UTF8.GetBytes(text ?? "");
                    rq.ContentType = "text/plain; charset=utf-8"; rq.ContentLength = b.Length;
                    using (Stream s = rq.GetRequestStream()) s.Write(b, 0, b.Length);
                    using (WebResponse r = rq.GetResponse()) { }
                }
                catch { }
            });
        }
        // os cabeçalhos HTTP só aceitam ASCII: tira os acentos
        static string Ascii(string s)
        {
            string n = (s ?? "").Normalize(NormalizationForm.FormD);
            StringBuilder sb = new StringBuilder();
            foreach (char c in n) if (c < 128) sb.Append(c); else if (char.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark) sb.Append('?');
            return sb.ToString();
        }
        public static string NewTopic()
        {
            const string a = "abcdefghijkmnpqrstuvwxyz23456789";
            byte[] r = new byte[16];
            using (System.Security.Cryptography.RandomNumberGenerator g = System.Security.Cryptography.RandomNumberGenerator.Create()) g.GetBytes(r);
            return "nexus-" + new string(r.Select(x => a[x % a.Length]).ToArray());
        }
    }

    // ------------------------------------------------------------ Wake-on-LAN: ligar este PC a partir de outro aparelho (ou acordar outro PC daqui)
    static class Wol
    {
        static string Ps(string script) { return PsFile.Run(script.Contains("Set-NetAdapter") ? "wol_ligar" : "wol", script, 30000); }
        public static string Json()
        {
            // a placa de rede com gateway (a que liga à internet)
            string o = Ps("$a = Get-NetAdapter -Physical | Where-Object Status -eq 'Up' | Select-Object -First 1; if(-not $a){ '[]'; exit }; " +
                          "$p = Get-NetAdapterPowerManagement -Name $a.Name -ErrorAction SilentlyContinue; " +
                          "$m = Get-NetAdapterAdvancedProperty -Name $a.Name -RegistryKeyword '*WakeOnMagicPacket' -ErrorAction SilentlyContinue; " +
                          "$ip = (Get-NetIPAddress -InterfaceIndex $a.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue | Select-Object -First 1); " +
                          "[pscustomobject]@{ name=$a.Name; desc=$a.InterfaceDescription; mac=$a.MacAddress; wired=($a.MediaType -like '*802.3*'); ip=$ip.IPAddress; prefix=$ip.PrefixLength; " +
                          "pm=[string]$p.WakeOnMagicPacket; adv=[string]$m.RegistryValue; armed=(powercfg /devicequery wake_armed) -join ';' } | ConvertTo-Json -Compress");
            if (!o.StartsWith("{")) o = "null";
            bool fast = false;
            try { using (RegistryKey k = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\Session Manager\Power")) fast = Convert.ToInt32(k.GetValue("HiberbootEnabled", 0)) == 1; } catch { }
            return "{\"ok\":true,\"adapter\":" + o + ",\"fastboot\":" + (fast ? "true" : "false") + "}";
        }
        public static string Enable()
        {
            Ps("$a = Get-NetAdapter -Physical | Where-Object Status -eq 'Up' | Select-Object -First 1; if(-not $a){ exit }; " +
               "Set-NetAdapterAdvancedProperty -Name $a.Name -RegistryKeyword '*WakeOnMagicPacket' -RegistryValue 1 -ErrorAction SilentlyContinue; " +
               "Set-NetAdapterPowerManagement -Name $a.Name -WakeOnMagicPacket Enabled -ErrorAction SilentlyContinue; " +
               "powercfg /deviceenablewake \"$($a.InterfaceDescription)\" | Out-Null");
            return Json();
        }
        // pacote mágico para outro PC: 6 x FF + 16 x MAC, em broadcast
        public static string Wake(string mac)
        {
            string h = new string((mac ?? "").Where(Uri.IsHexDigit).ToArray());
            if (h.Length != 12) return "{\"ok\":false,\"error\":\"mac\"}";
            byte[] m = Enumerable.Range(0, 6).Select(i => Convert.ToByte(h.Substring(i * 2, 2), 16)).ToArray();
            byte[] pkt = new byte[102];
            for (int i = 0; i < 6; i++) pkt[i] = 0xFF;
            for (int i = 1; i <= 16; i++) Array.Copy(m, 0, pkt, i * 6, 6);
            try
            {
                using (UdpClient u = new UdpClient())
                {
                    u.EnableBroadcast = true;
                    u.Send(pkt, pkt.Length, new IPEndPoint(IPAddress.Broadcast, 9));
                    u.Send(pkt, pkt.Length, new IPEndPoint(IPAddress.Broadcast, 7));
                }
            }
            catch (Exception ex) { return "{\"ok\":false,\"error\":" + Js.S(ex.Message) + "}"; }
            return "{\"ok\":true}";
        }
    }
}
