﻿// NEXUS // Stream Deck plugin - mostra estatísticas do NEXUS Monitor nas teclas (C# 5, .NET Framework 4.x)
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.WebSockets;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;

[assembly: AssemblyTitle("NEXUS Deck")]
[assembly: AssemblyProduct("NEXUS Monitor")]
[assembly: AssemblyVersion("1.8.0.0")]
[assembly: AssemblyFileVersion("1.8.0.0")]

namespace NexusDeck
{
    // uma leitura pronta a desenhar
    class Reading
    {
        public string Label = "";        // o que é (ex.: "CPU TEMP")
        public string Sub;               // detalhe por baixo (ex.: nome do jogo, "de 32 GB")
        public double? Value;            // valor numérico (para o gráfico)
        public string Text = "--";       // valor como texto
        public string Unit = "";
        public double? Min = 0, Max;     // escala do gráfico/anel (Max null = automático)
        public string Tone = "c1";       // c1, c2, ok, warn, crit
        public bool NoGraph;             // relógio, tempo ligado...
    }

    class Sensor
    {
        public string Id, Name, Group;
        public Sensor(string id, string name, string group) { Id = id; Name = name; Group = group; }
    }

    static class Program
    {
        const string STATS = "http://127.0.0.1:8765/api/stats";
        static string lastThemeKey = "";
        const string PAGE = "http://localhost:8765/";
        const string ACTION = "com.nexus.monitor.stat";      // estatísticas
        const string A_MUSIC = "com.nexus.monitor.music";    // música
        const string A_BUTTON = "com.nexus.monitor.button";  // botões do NEXUS
        const string A_GAME = "com.nexus.monitor.game";      // abrir um jogo
        const string A_BAT = "com.nexus.monitor.battery";    // bateria de um aparelho (rato, teclado, auscultadores)
        static readonly string[] MUSIC = { "act:media", "act:next", "act:prev", "act:vol" };
        const int HIST = 48;

        static ClientWebSocket ws;
        static readonly object sendLock = new object();
        static readonly Dictionary<string, string[]> keys = new Dictionary<string, string[]>();   // context -> {métrica, estilo}
        static readonly Dictionary<string, string> keyDev = new Dictionary<string, string>();       // context -> dispositivo
        static readonly Dictionary<string, string> keyAct = new Dictionary<string, string>();       // context -> ação (estatística, música, botões, jogo)
        static readonly ManualResetEvent wake = new ManualResetEvent(false);                          // acorda quando aparece uma tecla
        static readonly Dictionary<string, string> lastImg = new Dictionary<string, string>();
        static readonly Dictionary<string, List<double>> hist = new Dictionary<string, List<double>>();
        static readonly JavaScriptSerializer js = new JavaScriptSerializer { MaxJsonLength = 8 * 1024 * 1024 };
        static Dictionary<string, object> lastData;
        static string nexusExe;
        static readonly CultureInfo IC = CultureInfo.InvariantCulture;

        static void Main(string[] args)
        {
            try { Main2(args); }
            catch (Exception ex) { try { File.WriteAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "nexus_erro.txt"), DateTime.Now + "\r\n" + ex); } catch { } throw; }
        }

        static void Main2(string[] args)
        {
            if (args.Length >= 2 && args[0] == "--render") { RenderTest(args[1]); return; }

            string port = null, uuid = null, reg = null;
            for (int i = 0; i < args.Length - 1; i++)
            {
                if (args[i] == "-port") port = args[i + 1];
                else if (args[i] == "-pluginUUID") uuid = args[i + 1];
                else if (args[i] == "-registerEvent") reg = args[i + 1];
            }
            if (port == null || uuid == null || reg == null) return;

            try
            {
                string pf = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "nexus_path.txt");
                if (File.Exists(pf)) nexusExe = File.ReadAllText(pf).Trim();
            }
            catch { }

            ws = new ClientWebSocket();
            ws.ConnectAsync(new Uri("ws://127.0.0.1:" + port), CancellationToken.None).Wait();
            Send(new Dictionary<string, object> { { "event", reg }, { "uuid", uuid } });

            Thread t = new Thread(RenderLoop);
            t.IsBackground = true;
            t.Start();

            ReceiveLoop();
        }

        // ------------------------------------------------------------ comunicação com a app Stream Deck
        static void Send(object o)
        {
            byte[] b = Encoding.UTF8.GetBytes(js.Serialize(o));
            lock (sendLock)
            {
                if (ws == null || ws.State != WebSocketState.Open) return;
                ws.SendAsync(new ArraySegment<byte>(b), WebSocketMessageType.Text, true, CancellationToken.None).Wait();
            }
        }

        static void ReceiveLoop()
        {
            byte[] buf = new byte[65536];
            MemoryStream msg = new MemoryStream();
            while (ws.State == WebSocketState.Open)
            {
                WebSocketReceiveResult r;
                try { r = ws.ReceiveAsync(new ArraySegment<byte>(buf), CancellationToken.None).Result; }
                catch { break; }
                if (r.MessageType == WebSocketMessageType.Close) break;
                msg.Write(buf, 0, r.Count);
                if (!r.EndOfMessage) continue;
                string text = Encoding.UTF8.GetString(msg.ToArray());
                msg.SetLength(0);
                try { Handle(js.Deserialize<Dictionary<string, object>>(text)); } catch { }
            }
        }

        static object Get(object o, params string[] path)
        {
            foreach (string p in path)
            {
                Dictionary<string, object> d = o as Dictionary<string, object>;
                if (d == null || !d.TryGetValue(p, out o)) return null;
            }
            return o;
        }

        static void Handle(Dictionary<string, object> m)
        {
            string ev = Get(m, "event") as string;
            string ctx = Get(m, "context") as string;
            if (ev == null) return;
            switch (ev)
            {
                case "willAppear":
                case "didReceiveSettings":
                    {
                        string act = Get(m, "action") as string ?? ACTION;
                        string metric = Get(m, "payload", "settings", "metric") as string;
                        if (string.IsNullOrEmpty(metric))   // tecla nova: começa com o botão mais óbvio de cada ação
                            metric = act == A_MUSIC ? "act:media" : act == A_BUTTON ? "act:overlay" : act == A_GAME ? FirstGame() : act == A_BAT ? "devbat" : "cpu";
                        string style = Get(m, "payload", "settings", "style") as string ?? "graph";
                        string dev = Get(m, "device") as string;
                        lock (keys) { keys[ctx] = new[] { metric, style }; keyAct[ctx] = act; if (dev != null) keyDev[ctx] = dev; lastImg.Remove(ctx); lastSig.Remove(ctx); }
                        wake.Set();
                        Render(ctx, metric, style, lastData);
                        break;
                    }
                case "willDisappear":
                    lock (keys) { keys.Remove(ctx); keyDev.Remove(ctx); keyAct.Remove(ctx); lastImg.Remove(ctx); lastSig.Remove(ctx); }
                    break;
                case "deviceDidDisconnect":   // Stream Deck desligada: esquece as teclas dela
                    {
                        string dev = Get(m, "device") as string;
                        lock (keys)
                            foreach (string c in keyDev.Where(kv => kv.Value == dev).Select(kv => kv.Key).ToList())
                            { keys.Remove(c); keyDev.Remove(c); keyAct.Remove(c); lastImg.Remove(c); lastSig.Remove(c); }
                        break;
                    }
                case "propertyInspectorDidAppear":
                    SendSensorList(ctx);
                    break;
                case "sendToPlugin":
                    if (Get(m, "payload", "request") as string == "sensors") SendSensorList(ctx);
                    break;
                case "keyDown":
                    {
                        string km = null;
                        lock (keys) { string[] kv; if (keys.TryGetValue(ctx, out kv)) km = kv[0]; }
                        if (km != null && (km.StartsWith("act:") || km.StartsWith("game:") || km.StartsWith("macro:") || km == "bott" || km == "session") && lastData != null)
                        {
                            DoAction(ctx, km);
                            break;
                        }
                    }
                    if (lastData != null)
                        Send(new Dictionary<string, object> { { "event", "openUrl" }, { "payload", new Dictionary<string, object> { { "url", PAGE } } } });
                    else if (!string.IsNullOrEmpty(nexusExe) && File.Exists(nexusExe))
                    {
                        try { Process.Start(new ProcessStartInfo(nexusExe) { UseShellExecute = true, WorkingDirectory = Path.GetDirectoryName(nexusExe) }); } catch { }
                    }
                    else
                        Send(new Dictionary<string, object> { { "event", "showAlert" }, { "context", ctx } });
                    break;
            }
        }

        static void SendSensorList(string ctx)
        {
            Dictionary<string, object> d = lastData ?? Fetch();
            string act, cur = "";
            lock (keys) { if (!keyAct.TryGetValue(ctx, out act)) act = ACTION; string[] kv; if (keys.TryGetValue(ctx, out kv)) cur = kv[0]; }
            List<object> list = new List<object>();
            if (act == A_GAME)
            {
                foreach (string[] g in Games()) list.Add(new Dictionary<string, object> { { "id", "game:" + g[0] }, { "name", g[1] }, { "group", g[2] } });
            }
            if (act == A_BUTTON)
            {
                System.Collections.IList ms = Arr(Get(J("/api/x/ctl", 0), "macros"));
                if (ms != null) foreach (object o in ms) { Dictionary<string, object> m = o as Dictionary<string, object>; if (m != null) list.Add(new Dictionary<string, object> { { "id", "macro:" + Get(m, "id") }, { "name", "⌨ " + Get(m, "name") }, { "group", "Macros" } }); }
            }
            if (act == A_BAT || (act == ACTION && cur.StartsWith("devbat")))
            {
                List<Dictionary<string, object>> dv = Devs().ToList();
                list.Add(new Dictionary<string, object> { { "id", "devbat" }, { "name", L("Bateria mais fraca (rato, teclado, auscultadores)") }, { "group", L("Aparelhos") } });
                foreach (var x in dv) list.Add(new Dictionary<string, object> { { "id", "devbat:" + Get(x, "id") }, { "name", (Get(x, "battery") != null ? "🔋 " : "") + Get(x, "name") }, { "group", L("Aparelhos") } });
            }
            if (act != A_BAT && act != A_GAME)
                foreach (Sensor s in Sensors(d))
                {
                    bool music = MUSIC.Contains(s.Id), button = s.Id.StartsWith("act:") && !music;
                    // cada ação mostra só o que é dela (as teclas antigas com música/botões na "Estatística" continuam a aparecer)
                    bool show = act == A_MUSIC ? music : act == A_BUTTON ? button : (!music && !button) || s.Id == cur;
                    if (show) list.Add(new Dictionary<string, object> { { "id", s.Id }, { "name", s.Name }, { "group", s.Group } });
                }
            string kind = act == A_MUSIC ? "music" : act == A_BUTTON ? "button" : act == A_GAME ? "game" : act == A_BAT ? "battery" : "stat";
            Send(new Dictionary<string, object> {
                { "action", act }, { "event", "sendToPropertyInspector" }, { "context", ctx },
                { "payload", new Dictionary<string, object> { { "sensors", list }, { "online", d != null }, { "lang", lang }, { "kind", kind } } } });
        }

        // jogos instalados (Steam e os já jogados), para a ação "Abrir jogo": {id, nome, origem}
        static List<string[]> games = new List<string[]>(); static DateTime gamesT = DateTime.MinValue;
        static List<string[]> Games()
        {
            if ((DateTime.Now - gamesT).TotalMinutes < 5 && games.Count > 0) return games;
            gamesT = DateTime.Now;
            try
            {
                HttpWebRequest req = (HttpWebRequest)WebRequest.Create("http://127.0.0.1:8765/api/x/games"); req.Timeout = 4000; req.Proxy = null;
                using (WebResponse resp = req.GetResponse())
                using (StreamReader sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8))
                {
                    Dictionary<string, object> j = js.Deserialize<Dictionary<string, object>>(sr.ReadToEnd());
                    List<string[]> l = new List<string[]>();
                    System.Collections.IList it = Arr(Get(j, "items"));
                    if (it != null) foreach (object o in it)
                    {
                        string id = Get(o, "id") as string, n = Get(o, "name") as string;
                        if (id != null && n != null) l.Add(new[] { id, n, Get(o, "src") as string ?? "PC" });
                    }
                    games = l;
                }
            }
            catch { }
            return games;
        }
        static string FirstGame() { List<string[]> g = Games(); return g.Count > 0 ? "game:" + g[0][0] : "game:"; }
        static string GameName(string id) { foreach (string[] g in Games()) if (g[0] == id) return g[1]; return null; }

        // estado da rota para jogos (Cloudflare), para o botão "Rota"
        static Dictionary<string, object> route; static DateTime routeT = DateTime.MinValue;
        // aparelhos (bateria, DPI), som (microfone) e macros do NEXUS, com cache para não perguntar a cada desenho
        static readonly Dictionary<string, Dictionary<string, object>> jc = new Dictionary<string, Dictionary<string, object>>();
        static readonly Dictionary<string, DateTime> jt = new Dictionary<string, DateTime>();
        static Dictionary<string, object> J(string path, int secs)
        {
            lock (jc)
            {
                DateTime t; if (jt.TryGetValue(path, out t) && (DateTime.Now - t).TotalSeconds < secs) { Dictionary<string, object> c; jc.TryGetValue(path, out c); return c; }
                jt[path] = DateTime.Now;
            }
            Dictionary<string, object> r = null;
            try
            {
                HttpWebRequest req = (HttpWebRequest)WebRequest.Create("http://127.0.0.1:8765" + path); req.Timeout = 2500; req.Proxy = null;
                using (WebResponse resp = req.GetResponse())
                using (StreamReader sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8)) r = js.Deserialize<Dictionary<string, object>>(sr.ReadToEnd());
            }
            catch { }
            lock (jc) jc[path] = r;
            return r;
        }
        static void JReset(string path) { lock (jc) jt.Remove(path); }
        static List<Dictionary<string, object>> Devs()
        {
            List<Dictionary<string, object>> l = new List<Dictionary<string, object>>();
            System.Collections.IList a = Arr(Get(J("/api/x/dev", 15), "devs"));
            if (a != null) foreach (object o in a) { Dictionary<string, object> d = o as Dictionary<string, object>; if (d != null) l.Add(d); }
            return l;
        }
        static Dictionary<string, object> Route()
        {
            if ((DateTime.Now - routeT).TotalSeconds < 3) return route;
            routeT = DateTime.Now;
            try
            {
                HttpWebRequest req = (HttpWebRequest)WebRequest.Create("http://127.0.0.1:8765/api/x/route"); req.Timeout = 2500; req.Proxy = null;
                using (WebResponse resp = req.GetResponse())
                using (StreamReader sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8)) route = js.Deserialize<Dictionary<string, object>>(sr.ReadToEnd());
            }
            catch { }
            return route;
        }

        static void RenderLoop()
        {
            while (true)
            {
                List<KeyValuePair<string, string[]>> list;
                lock (keys) list = keys.ToList();
                if (list.Count == 0)   // nenhuma tecla do NEXUS no ecrã: dorme sem gastar nada até aparecer uma
                {
                    wake.Reset();
                    lock (keys) if (keys.Count > 0) continue;
                    lastData = null;
                    wake.WaitOne();
                    continue;
                }
                lastData = Fetch(list.Any(kv => kv.Value[0].IndexOf("gpu", StringComparison.OrdinalIgnoreCase) >= 0 || kv.Value[0] == "vram" || kv.Value[0] == "power"));
                Sample(lastData, list.Select(kv => kv.Value[0]).Distinct());
                foreach (KeyValuePair<string, string[]> kv in list)
                {
                    try { Render(kv.Key, kv.Value[0], kv.Value[1], lastData); } catch { }
                }
                // cores do tema a mudar (SignalRGB): atualiza 3 vezes por segundo; o resto do tempo, 1 vez
                string tk = Convert.ToString(Get(lastData, "theme", "c1")) + Convert.ToString(Get(lastData, "theme", "c2"));
                bool themeMoving = tk != lastThemeKey; lastThemeKey = tk;
                Thread.Sleep(themeMoving ? 330 : 1000);
            }
        }

        static void Sample(Dictionary<string, object> d, IEnumerable<string> metrics)
        {
            if (d == null) return;
            foreach (string mt in metrics)
            {
                Reading r = Read(mt, d);
                if (!r.Value.HasValue || r.NoGraph) continue;
                List<double> h;
                lock (hist)
                {
                    if (!hist.TryGetValue(mt, out h)) hist[mt] = h = new List<double>();
                    h.Add(r.Value.Value);
                    if (h.Count > HIST) h.RemoveAt(0);
                }
            }
        }

        // botões do NEXUS: fazem uma ação no NEXUS do PC (só em localhost)
        static bool Post(string path)
        {
            try
            {
                HttpWebRequest req = (HttpWebRequest)WebRequest.Create("http://127.0.0.1:8765" + path);
                req.Method = "POST"; req.ContentLength = 0; req.Timeout = 5000; req.Proxy = null;
                using (WebResponse resp = req.GetResponse()) { }
                return true;
            }
            catch { return false; }
        }
        static void DoAction(string ctx, string km)
        {
            Dictionary<string, object> d = lastData;
            bool ok = true;
            Func<string, bool> on = k => Get(d, "settings", k) is bool && (bool)Get(d, "settings", k);
            switch (km)
            {
                case "act:overlay": ok = Post("/api/settings?overlay=" + (on("overlay") ? "0" : "1")); break;
                case "act:boost": ok = Post("/api/settings?gamemode=" + (on("gamemode") ? "0" : "1")); break;
                case "act:ram": ok = Post("/api/ramclean"); break;
                case "act:media": ok = Post("/api/x/media/do?a=play"); mediaT = DateTime.MinValue; break;
                case "act:next": ok = Post("/api/x/media/do?a=next"); mediaT = DateTime.MinValue; break;
                case "act:prev": ok = Post("/api/x/media/do?a=prev"); mediaT = DateTime.MinValue; break;
                case "act:vol": ok = Post("/api/x/media/do?a=mute"); mediaT = DateTime.MinValue; break;
                case "act:bench":
                    ok = Get(d, "nexus", "bench") is bool && (bool)Get(d, "nexus", "bench") ? Post("/api/bench/stop") : Post("/api/bench/start?secs=60&delay=3&label=Stream%20Deck");
                    break;
                case "act:disk":
                    Send(new Dictionary<string, object> { { "event", "openUrl" }, { "payload", new Dictionary<string, object> { { "url", PAGE + "disk" } } } });
                    return;
                case "act:route":
                    {
                        Dictionary<string, object> rt = Route();
                        bool consent = Get(rt, "consent") is bool && (bool)Get(rt, "consent"), onv = Get(rt, "on") is bool && (bool)Get(rt, "on");
                        if (!consent)   // a autorização tem de ser dada na página (lá explica que o tráfego passa pela Cloudflare)
                        {
                            Send(new Dictionary<string, object> { { "event", "openUrl" }, { "payload", new Dictionary<string, object> { { "url", PAGE + "perf#rede" } } } });
                            return;
                        }
                        ok = Post("/api/x/route/on?on=" + (onv ? "0" : "1")); routeT = DateTime.MinValue;
                        break;
                    }
                case "act:dpi": ok = Post("/api/x/dev/cycle?dir=1"); JReset("/api/x/dev"); break;
                case "act:mic": ok = Post("/api/x/dev/soundset?flow=1&w=togglemute"); JReset("/api/x/dev/sound"); break;
                default:
                    if (km.StartsWith("macro:") && km.Length > 6) { ok = Post("/api/x/ctl/play?now=1&id=" + Uri.EscapeDataString(km.Substring(6))); break; }
                    if (km.StartsWith("game:") && km.Length > 5) { ok = Post("/api/x/games/launch?id=" + Uri.EscapeDataString(km.Substring(5))); break; }
                    Send(new Dictionary<string, object> { { "event", "openUrl" }, { "payload", new Dictionary<string, object> { { "url", PAGE + "perf" } } } });
                    return;
            }
            Send(new Dictionary<string, object> { { "event", ok ? "showOk" : "showAlert" }, { "context", ctx } });
            lastData = Fetch() ?? lastData;
            lock (keys) { lastSig.Remove(ctx); }
            wake.Set();
        }

        static Dictionary<string, object> Fetch() { return Fetch(true); }
        // gpu=false: nenhuma tecla visível mostra a GPU, por isso o NEXUS não precisa de a ler
        static Dictionary<string, object> Fetch(bool gpu)
        {
            try
            {
                HttpWebRequest req = (HttpWebRequest)WebRequest.Create(gpu ? STATS + "?deck=1" : STATS + "?nogpu=1&deck=1");
                req.Timeout = 2500;
                req.Proxy = null;
                using (WebResponse resp = req.GetResponse())
                using (StreamReader sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8))
                    return js.Deserialize<Dictionary<string, object>>(sr.ReadToEnd());
            }
            catch { return null; }
        }

        // "assinatura" do que a tecla mostra: se não mudou, não volta a desenhar nem a enviar

        // ---------- alertas (quando estão ligados no NEXUS): sinal discreto nas teclas
        // 0 = nada; 1 = há um alerta noutro sensor (só um ⚠ pequeno a piscar); 2 = esta tecla é o sensor em alerta (contorno a pulsar)
        static int AlertState(string metric, Dictionary<string, object> d)
        {
            if (d == null || !(Get(d, "settings", "alerts") is bool) || !(bool)Get(d, "settings", "alerts")) return 0;
            double lc = Num(Get(d, "settings", "alert_cpu")) ?? 999, lg = Num(Get(d, "settings", "alert_gpu")) ?? 999, lr = Num(Get(d, "settings", "alert_ram")) ?? 999;
            double? ct = Num(Get(d, "cpu_temps", "package")) ?? Num(Get(d, "cpu_temp")), gt = Num(Get(d, "gpu", "temp")), rp = Num(Get(d, "memory", "percent"));
            bool cpu = ct.HasValue && ct.Value >= lc, gpu = gt.HasValue && gt.Value >= lg, ram = rp.HasValue && rp.Value >= lr;
            if (!cpu && !gpu && !ram) return 0;
            if (cpu && (metric == "cputemp" || metric == "cpumax" || metric.StartsWith("core:"))) return 2;
            if (gpu && (metric == "gputemp" || metric == "gpu")) return 2;
            if (ram && (metric == "ram" || metric == "ramgb")) return 2;
            return 1;
        }
        static bool BlinkOn { get { return (DateTime.Now.Second & 1) == 0; } }

        static void DrawAlert(Graphics g, int state, Color crit)
        {
            if (state == 0) return;
            bool on = BlinkOn;
            if (state == 2)
                using (Pen p = new Pen(Color.FromArgb(on ? 230 : 90, crit), on ? 4f : 2.5f))
                using (GraphicsPath gp = new GraphicsPath())
                {
                    int r = 18; Rectangle b = new Rectangle(3, 3, 137, 137);
                    gp.AddArc(b.X, b.Y, r, r, 180, 90); gp.AddArc(b.Right - r, b.Y, r, r, 270, 90);
                    gp.AddArc(b.Right - r, b.Bottom - r, r, r, 0, 90); gp.AddArc(b.X, b.Bottom - r, r, r, 90, 90); gp.CloseFigure();
                    g.DrawPath(p, gp);
                }
            if (state == 2 || on)
            {
                // triângulo ⚠ pequeno no canto de cima à direita
                PointF[] tri = { new PointF(124, 10), new PointF(135, 29), new PointF(113, 29) };
                using (SolidBrush b = new SolidBrush(Color.FromArgb(state == 2 ? 255 : 200, crit))) g.FillPolygon(b, tri);
                using (SolidBrush b = new SolidBrush(Color.FromArgb(20, 10, 14))) { g.FillRectangle(b, 123, 15.5f, 2.2f, 7); g.FillRectangle(b, 123, 24, 2.2f, 2.2f); }
            }
        }

        static string Signature(string metric, string style, Dictionary<string, object> d)
        {
            if (d == null) return "off|" + style;
            Reading r = Read(metric, d);
            StringBuilder sb = new StringBuilder();
            sb.Append(style).Append('|').Append(r.Label).Append('|').Append(r.Text).Append('|').Append(r.Unit).Append('|').Append(r.Sub).Append('|').Append(r.Tone);
            foreach (string k in new[] { "bg", "panel", "txt", "dim", "c1", "c2", "warn", "ok", "crit" }) sb.Append('|').Append(Get(d, "theme", k));
            int al = AlertState(metric, d);
            if (al > 0) sb.Append("|alert").Append(al).Append(BlinkOn ? "+" : "-");   // muda a cada segundo: pisca devagar
            if (!r.NoGraph && style != "number")
                lock (hist)
                {
                    List<double> h;
                    if (hist.TryGetValue(metric, out h)) foreach (double v in h) sb.Append(',').Append(v.ToString("0.#", IC));
                }
            return sb.ToString();
        }

        static readonly Dictionary<string, string> lastSig = new Dictionary<string, string>();
        static readonly object drawLock = new object();

        static void Render(string ctx, string metric, string style, Dictionary<string, object> d)
        {
            string sig = Signature(metric, style, d), prevSig;
            lock (keys) { if (lastSig.TryGetValue(ctx, out prevSig) && prevSig == sig && lastImg.ContainsKey(ctx)) return; }
            string img;
            lock (drawLock) img = "data:image/png;base64," + Convert.ToBase64String(Png(metric, style, d));   // GDI+ não gosta de 2 threads no mesmo bitmap
            lock (keys)
            {
                lastSig[ctx] = sig;
                string prev;
                if (lastImg.TryGetValue(ctx, out prev) && prev == img) return;
                lastImg[ctx] = img;
            }
            Send(new Dictionary<string, object> {
                { "event", "setImage" }, { "context", ctx },
                { "payload", new Dictionary<string, object> { { "image", img }, { "target", 0 } } } });
        }

        // ------------------------------------------------------------ sensores disponíveis
        static double? Num(object o)
        {
            if (o == null) return null;
            try { return Convert.ToDouble(o, IC); } catch { return null; }
        }

        static System.Collections.IList Arr(object o) { return o as System.Collections.IList; }

        static readonly string[][] Fixed = {
            new[] { "cpu", "Uso do CPU", "Processador" },
            new[] { "cputemp", "Temperatura do CPU", "Processador" },
            new[] { "cpuhot", "Núcleo mais quente", "Processador" },
            new[] { "cpuclock", "Frequência do CPU", "Processador" },
            new[] { "cpupower", "Consumo do CPU", "Processador" },
            new[] { "gpu", "Uso da GPU", "Placa gráfica" },
            new[] { "gputemp", "Temperatura da GPU", "Placa gráfica" },
            new[] { "vram", "Memória da GPU (VRAM)", "Placa gráfica" },
            new[] { "gpupower", "Consumo da GPU", "Placa gráfica" },
            new[] { "power", "Consumo CPU + GPU", "Placa gráfica" },
            new[] { "ram", "Uso da RAM (%)", "Memória" },
            new[] { "ramused", "RAM em uso (GB)", "Memória" },
            new[] { "swap", "Memória virtual", "Memória" },
            new[] { "fps", "FPS", "Jogo" },
            new[] { "frametime", "Frametime", "Jogo" },
            new[] { "latency", "Latência (PresentMon)", "Jogo" },
            new[] { "netdown", "Download", "Rede" },
            new[] { "netup", "Upload", "Rede" },
            new[] { "diskread", "Leitura dos discos", "Discos" },
            new[] { "diskwrite", "Escrita dos discos", "Discos" },
            new[] { "procs", "Processos abertos", "Sistema" },
            new[] { "uptime", "Tempo ligado", "Sistema" },
            new[] { "clock", "Relógio", "Sistema" },
            new[] { "battery", "Bateria", "Sistema" },
            new[] { "bott", "Gargalo (CPU ou GPU)", "Jogo" },
            new[] { "session", "Tempo de jogo (sessão)", "Jogo" },
            new[] { "act:overlay", "Overlay: ligar / desligar", "Botões do NEXUS" },
            new[] { "act:bench", "Medir FPS (60 s)", "Botões do NEXUS" },
            new[] { "act:ram", "Limpar a RAM", "Botões do NEXUS" },
            new[] { "act:boost", "Boost de jogo: ligar / desligar", "Botões do NEXUS" },
            new[] { "act:perf", "Abrir a Performance", "Botões do NEXUS" },
            new[] { "act:disk", "Abrir o Deep Scan", "Botões do NEXUS" },
            new[] { "act:route", "Rota Cloudflare: ligar / desligar", "Botões do NEXUS" },
            new[] { "act:dpi", "DPI do rato: nível seguinte", "Botões do NEXUS" },
            new[] { "act:mic", "Microfone: silenciar / ligar", "Botões do NEXUS" },
            new[] { "act:media", "Música: capa e tocar / pausar", "Música" },
            new[] { "act:next", "Música: seguinte", "Música" },
            new[] { "act:prev", "Música: anterior", "Música" },
            new[] { "act:vol", "Volume (carrega para silenciar)", "Música" },
        };

        static List<Sensor> Sensors(Dictionary<string, object> d)
        {
            string lg = Get(d, "lang") as string;
            if (!string.IsNullOrEmpty(lg)) lang = lg;
            List<Sensor> l = Fixed.Select(f => new Sensor(f[0], L(f[1]), L(f[2]))).ToList();
            if (d == null) return l;
            System.Collections.IList disks = Arr(Get(d, "disks"));
            if (disks != null) foreach (object o in disks)
            {
                string mnt = Get(o, "mount") as string;
                if (mnt != null) l.Add(new Sensor("disk:" + mnt, L("Disco " + mnt.TrimEnd('\\') + " (espaço usado)"), L("Discos")));
            }
            Dictionary<string, object> temps = Get(d, "temps") as Dictionary<string, object>;
            if (temps != null) foreach (string k in temps.Keys) l.Add(new Sensor("temp:" + k, k, L("Temperaturas")));
            System.Collections.IList cores = Arr(Get(d, "cpu_temps", "cores"));
            if (cores != null) for (int i = 0; i < cores.Count; i++) l.Add(new Sensor("core:" + i, L("Núcleo " + (i + 1) + " (temperatura)"), L("Temperaturas")));
            System.Collections.IList fans = Arr(Get(d, "fans"));
            if (fans != null) foreach (object o in fans)
            {
                string n = Get(o, "name") as string;
                if (n != null) l.Add(new Sensor("fan:" + n, n, L("Ventoinhas")));
            }
            System.Collections.IList per = Arr(Get(d, "cpu", "per_core"));
            if (per != null) for (int i = 0; i < per.Count; i++) l.Add(new Sensor("thread:" + i, L("Thread " + (i + 1) + " (uso)"), L("Uso por thread")));
            return l;
        }

        static string Rate(double b, out string unit)
        {
            if (b >= 1073741824) { unit = "GB/s"; return (b / 1073741824).ToString("0.0", IC); }
            if (b >= 1048576) { unit = "MB/s"; return (b / 1048576).ToString(b >= 104857600 ? "0" : "0.0", IC); }
            if (b >= 1024) { unit = "KB/s"; return (b / 1024).ToString("0", IC); }
            unit = "B/s"; return b.ToString("0", IC);
        }

        static string F(double v, int dec) { return v.ToString(dec == 0 ? "0" : dec == 1 ? "0.0" : "0.00", IC); }

        static string ShortName(string n)
        {
            int i = n.IndexOf(" · ");
            if (i >= 0) n = n.Substring(i + 3);
            n = n.Replace("Temperature", "").Replace("Temperatura", "").Replace("GeForce ", "").Trim();
            return n.ToUpperInvariant();
        }

        static string Group(string n)
        {
            int i = n.IndexOf(" · ");
            return i >= 0 ? n.Substring(0, i) : null;
        }

        static void Temp(Reading r, double? v)
        {
            r.Unit = "°C"; r.Tone = "ok"; r.Min = null; r.Max = null;
            if (v.HasValue) { r.Value = v; r.Text = F(v.Value, 0); r.Tone = v < 60 ? "ok" : v < 80 ? "warn" : "crit"; }
        }

        // bateria de um aparelho (rato, teclado, auscultadores)
        static void DevBat(Reading r, Dictionary<string, object> x)
        {
            r.Label = "BATERIA"; r.Unit = "%"; r.Max = 100; r.Tone = "ok";
            double? b = x != null ? Num(Get(x, "battery")) : null;
            if (!b.HasValue) { r.Sub = "sem aparelho"; r.Text = "--"; return; }
            string n = Get(x, "name") as string ?? "";
            foreach (string p in new[] { "Razer ", "Logitech " }) if (n.StartsWith(p)) n = n.Substring(p.Length);
            r.Value = b; r.Text = F(b.Value, 0); r.Sub = (Get(x, "charging") is bool && (bool)Get(x, "charging") ? "⚡ " : "") + (n.Length > 18 ? n.Substring(0, 18) : n);
            r.Tone = b < 15 ? "crit" : b < 30 ? "warn" : "ok";
        }

        static void Pct(Reading r, double? v, string tone)
        {
            r.Unit = "%"; r.Max = 100; r.Tone = tone;
            if (v.HasValue) { r.Value = v; r.Text = F(v.Value, 0); if (v > 85) r.Tone = "crit"; else if (v > 60 && tone == "c1") r.Tone = "warn"; }
        }


        // ------------------------------------------------------------ idioma: segue a língua escolhida no NEXUS (browser)
        static volatile string lang = "pt";
        static readonly Dictionary<string, string[]> TR = Tr(new object[] {
            // { pt, { en, es, fr, de } }
            "CPU USO", new[] { "CPU USE", "USO CPU", "CPU UTIL.", "CPU LAST" },
            "ROTA", new[] { "ROUTE", "RUTA", "ROUTE", "ROUTE" },
            "DPI do rato: nível seguinte", new[] { "Mouse DPI: next stage", "DPI del ratón: nivel siguiente", "DPI souris : niveau suivant", "Maus-DPI: nächste Stufe" },
            "Microfone: silenciar / ligar", new[] { "Microphone: mute / unmute", "Micrófono: silenciar / activar", "Micro : couper / activer", "Mikrofon: stumm / an" },
            "MICROFONE", new[] { "MICROPHONE", "MICRÓFONO", "MICRO", "MIKROFON" },
            "MUDO", new[] { "MUTED", "MUDO", "COUPÉ", "STUMM" },
            "carrega para silenciar", new[] { "press to mute", "pulsa para silenciar", "appuie pour couper", "drücken zum Stummschalten" },
            "carrega: nível seguinte", new[] { "press: next stage", "pulsa: nivel siguiente", "appuie : niveau suivant", "drücken: nächste Stufe" },
            "sem rato compatível", new[] { "no compatible mouse", "sin ratón compatible", "pas de souris compatible", "keine kompatible Maus" },
            "sem aparelho", new[] { "no device", "sin dispositivo", "pas d'appareil", "kein Gerät" },
            "MACRO", new[] { "MACRO", "MACRO", "MACRO", "MAKRO" },
            "macro apagada", new[] { "macro deleted", "macro borrada", "macro supprimée", "Makro gelöscht" },
            "carrega para correr", new[] { "press to run", "pulsa para ejecutar", "appuie pour lancer", "drücken zum Ausführen" },
            "Bateria mais fraca (rato, teclado, auscultadores)", new[] { "Lowest battery (mouse, keyboard, headset)", "Batería más baja (ratón, teclado, auriculares)", "Batterie la plus faible (souris, clavier, casque)", "Schwächster Akku (Maus, Tastatur, Headset)" },
            "Aparelhos", new[] { "Devices", "Dispositivos", "Appareils", "Geräte" },
            "Macros", new[] { "Macros", "Macros", "Macros", "Makros" },
            "JOGAR", new[] { "PLAY", "JUGAR", "JOUER", "SPIELEN" },
            "sem NEXUS", new[] { "no NEXUS", "sin NEXUS", "pas de NEXUS", "kein NEXUS" },
            "ligar na Performance", new[] { "turn on in Performance", "activar en Rendimiento", "activer dans Performance", "in Leistung einschalten" },
            "Cloudflare ativa", new[] { "Cloudflare on", "Cloudflare activa", "Cloudflare actif", "Cloudflare aktiv" },
            "à espera de jogo", new[] { "waiting for a game", "esperando un juego", "en attente d'un jeu", "wartet auf Spiel" },
            "carrega para ligar", new[] { "press to turn on", "pulsa para activar", "appuie pour activer", "drücken zum Einschalten" },
            "escolhe o jogo", new[] { "pick the game", "elige el juego", "choisis le jeu", "Spiel wählen" },
            "carrega para abrir", new[] { "press to open", "pulsa para abrir", "appuie pour ouvrir", "drücken zum Öffnen" },
            "Abrir o Deep Scan", new[] { "Open Deep Scan", "Abrir el Deep Scan", "Ouvrir Deep Scan", "Deep Scan öffnen" },
            "Rota Cloudflare: ligar / desligar", new[] { "Cloudflare route: on / off", "Ruta Cloudflare: activar / desactivar", "Itinéraire Cloudflare : activer / désactiver", "Cloudflare-Route: an / aus" },
            "CPU MÁX", new[] { "CPU MAX", "CPU MÁX", "CPU MAX", "CPU MAX" },
            "GPU USO", new[] { "GPU USE", "USO GPU", "GPU UTIL.", "GPU LAST" },
            "RAM USO", new[] { "RAM USE", "USO RAM", "RAM UTIL.", "RAM LAST" },
            "VIRTUAL", new[] { "VIRTUAL", "VIRTUAL", "VIRTUELLE", "VIRTUELL" },
            "LATÊNCIA", new[] { "LATENCY", "LATENCIA", "LATENCE", "LATENZ" },
            "LEITURA", new[] { "READ", "LECTURA", "LECTURE", "LESEN" },
            "ESCRITA", new[] { "WRITE", "ESCRITURA", "ÉCRITURE", "SCHREIBEN" },
            "PROCESSOS", new[] { "PROCESSES", "PROCESOS", "PROCESSUS", "PROZESSE" },
            "LIGADO HÁ", new[] { "UPTIME", "ENCENDIDO", "ALLUMÉ", "LAUFZEIT" },
            "HORA", new[] { "TIME", "HORA", "HEURE", "UHRZEIT" },
            "BATERIA", new[] { "BATTERY", "BATERÍA", "BATTERIE", "AKKU" },
            "NÚCLEO #", new[] { "CORE #", "NÚCLEO #", "CŒUR #", "KERN #" },
            "DISCO #", new[] { "DISK #", "DISCO #", "DISQUE #", "DISK #" },
            "TOTAL WATTS", new[] { "TOTAL WATTS", "WATTS TOTAL", "WATTS TOTAL", "WATT GESAMT" },
            "sem sensor", new[] { "no sensor", "sin sensor", "pas de capteur", "kein Sensor" },
            "de # GB", new[] { "of # GB", "de # GB", "sur # Go", "von # GB" },
            "sem jogo", new[] { "no game", "sin juego", "aucun jeu", "kein Spiel" },
            "sem dados", new[] { "no data", "sin datos", "aucune donnée", "keine Daten" },
            "sem bateria", new[] { "no battery", "sin batería", "pas de batterie", "kein Akku" },
            "a carregar", new[] { "charging", "cargando", "en charge", "lädt" },
            "sem leitura", new[] { "no reading", "sin lectura", "aucune lecture", "kein Wert" },
            "temperatura", new[] { "temperature", "temperatura", "température", "Temperatur" },
            "ventoinha", new[] { "fan", "ventilador", "ventilateur", "Lüfter" },
            "toca p/ abrir", new[] { "tap to open", "toca p/ abrir", "appuie : ouvrir", "tippen: öffnen" },
            // lista de sensores (Stream Deck → definições da tecla)
            "Uso do CPU", new[] { "CPU usage", "Uso del CPU", "Utilisation CPU", "CPU-Auslastung" },
            "Temperatura do CPU", new[] { "CPU temperature", "Temperatura del CPU", "Température CPU", "CPU-Temperatur" },
            "Núcleo mais quente", new[] { "Hottest core", "Núcleo más caliente", "Cœur le plus chaud", "Heißester Kern" },
            "Frequência do CPU", new[] { "CPU frequency", "Frecuencia del CPU", "Fréquence CPU", "CPU-Takt" },
            "Consumo do CPU", new[] { "CPU power", "Consumo del CPU", "Consommation CPU", "CPU-Verbrauch" },
            "Uso da GPU", new[] { "GPU usage", "Uso de la GPU", "Utilisation GPU", "GPU-Auslastung" },
            "Temperatura da GPU", new[] { "GPU temperature", "Temperatura de la GPU", "Température GPU", "GPU-Temperatur" },
            "Memória da GPU (VRAM)", new[] { "GPU memory (VRAM)", "Memoria de la GPU (VRAM)", "Mémoire GPU (VRAM)", "GPU-Speicher (VRAM)" },
            "Consumo da GPU", new[] { "GPU power", "Consumo de la GPU", "Consommation GPU", "GPU-Verbrauch" },
            "Consumo CPU + GPU", new[] { "CPU + GPU power", "Consumo CPU + GPU", "Consommation CPU + GPU", "Verbrauch CPU + GPU" },
            "Uso da RAM (%)", new[] { "RAM usage (%)", "Uso de la RAM (%)", "Utilisation RAM (%)", "RAM-Auslastung (%)" },
            "RAM em uso (GB)", new[] { "RAM in use (GB)", "RAM en uso (GB)", "RAM utilisée (Go)", "Belegter RAM (GB)" },
            "Memória virtual", new[] { "Virtual memory", "Memoria virtual", "Mémoire virtuelle", "Virtueller Speicher" },
            "Latência (PresentMon)", new[] { "Latency (PresentMon)", "Latencia (PresentMon)", "Latence (PresentMon)", "Latenz (PresentMon)" },
            "Leitura dos discos", new[] { "Disk read", "Lectura de discos", "Lecture disques", "Festplatten lesen" },
            "Escrita dos discos", new[] { "Disk write", "Escritura de discos", "Écriture disques", "Festplatten schreiben" },
            "Processos abertos", new[] { "Open processes", "Procesos abiertos", "Processus ouverts", "Offene Prozesse" },
            "Tempo ligado", new[] { "Uptime", "Tiempo encendido", "Temps allumé", "Laufzeit" },
            "Relógio", new[] { "Clock", "Reloj", "Horloge", "Uhr" },
            "Bateria", new[] { "Battery", "Batería", "Batterie", "Akku" },
            "Processador", new[] { "Processor", "Procesador", "Processeur", "Prozessor" },
            "Placa gráfica", new[] { "Graphics card", "Tarjeta gráfica", "Carte graphique", "Grafikkarte" },
            "Memória", new[] { "Memory", "Memoria", "Mémoire", "Speicher" },
            "Jogo", new[] { "Game", "Juego", "Jeu", "Spiel" },
            "Gargalo (CPU ou GPU)", new[] { "Bottleneck (CPU or GPU)", "Cuello de botella (CPU o GPU)", "Goulot (CPU ou GPU)", "Engpass (CPU oder GPU)" },
            "Tempo de jogo (sessão)", new[] { "Play time (session)", "Tiempo de juego (sesión)", "Temps de jeu (session)", "Spielzeit (Sitzung)" },
            "Overlay: ligar / desligar", new[] { "Overlay: on / off", "Overlay: activar / desactivar", "Overlay : activer / désactiver", "Overlay: an / aus" },
            "Medir FPS (60 s)", new[] { "Measure FPS (60 s)", "Medir FPS (60 s)", "Mesurer les FPS (60 s)", "FPS messen (60 s)" },
            "Limpar a RAM", new[] { "Clean RAM", "Limpiar la RAM", "Nettoyer la RAM", "RAM bereinigen" },
            "Boost de jogo: ligar / desligar", new[] { "Game boost: on / off", "Boost de juego: activar / desactivar", "Boost de jeu : activer / désactiver", "Spiel-Boost: an / aus" },
            "Abrir a Performance", new[] { "Open Performance", "Abrir Rendimiento", "Ouvrir Performance", "Performance öffnen" },
            "Botões do NEXUS", new[] { "NEXUS buttons", "Botones de NEXUS", "Boutons NEXUS", "NEXUS-Tasten" },
            "GARGALO", new[] { "BOTTLENECK", "CUELLO", "GOULOT", "ENGPASS" },
            "SESSÃO", new[] { "SESSION", "SESIÓN", "SESSION", "SITZUNG" },
            "MEDIR FPS", new[] { "MEASURE FPS", "MEDIR FPS", "MESURER FPS", "FPS MESSEN" },
            "LIMPAR RAM", new[] { "CLEAN RAM", "LIMPIAR RAM", "NETTOYER RAM", "RAM BEREINIGEN" },
            "processador", new[] { "processor", "procesador", "processeur", "Prozessor" },
            "placa gráfica", new[] { "graphics card", "tarjeta gráfica", "carte graphique", "Grafikkarte" },
            "limite/vsync", new[] { "cap/vsync", "límite/vsync", "limite/vsync", "Limit/VSync" },
            "equilibrado", new[] { "balanced", "equilibrado", "équilibré", "ausgewogen" },
            "carrega para mudar", new[] { "press to toggle", "pulsa para cambiar", "appuyez pour changer", "drücken zum Umschalten" },
            "carrega para parar", new[] { "press to stop", "pulsa para parar", "appuyez pour arrêter", "drücken zum Stoppen" },
            "carrega para limpar", new[] { "press to clean", "pulsa para limpiar", "appuyez pour nettoyer", "drücken zum Bereinigen" },
            "abre o jogo", new[] { "open the game", "abre el juego", "ouvrez le jeu", "Spiel öffnen" },
            "abrir", new[] { "open", "abrir", "ouvrir", "öffnen" },
            "Rede", new[] { "Network", "Red", "Réseau", "Netzwerk" },
            "Discos", new[] { "Disks", "Discos", "Disques", "Festplatten" },
            "Sistema", new[] { "System", "Sistema", "Système", "System" },
            "Temperaturas", new[] { "Temperatures", "Temperaturas", "Températures", "Temperaturen" },
            "Ventoinhas", new[] { "Fans", "Ventiladores", "Ventilateurs", "Lüfter" },
            "Uso por thread", new[] { "Usage per thread", "Uso por hilo", "Utilisation par thread", "Auslastung pro Thread" },
            "Disco # (espaço usado)", new[] { "Disk # (space used)", "Disco # (espacio usado)", "Disque # (espace utilisé)", "Festplatte # (belegt)" },
            "Núcleo # (temperatura)", new[] { "Core # (temperature)", "Núcleo # (temperatura)", "Cœur # (température)", "Kern # (Temperatur)" },
            "Thread # (uso)", new[] { "Thread # (usage)", "Hilo # (uso)", "Thread # (utilisation)", "Thread # (Auslastung)" },
            "Música: capa e tocar / pausar", new[] { "Music: cover and play / pause", "Música: portada y reproducir / pausar", "Musique : pochette et lecture / pause", "Musik: Cover und Wiedergabe / Pause" },
            "Música: seguinte", new[] { "Music: next", "Música: siguiente", "Musique : suivant", "Musik: weiter" },
            "Música: anterior", new[] { "Music: previous", "Música: anterior", "Musique : précédent", "Musik: zurück" },
            "Volume (carrega para silenciar)", new[] { "Volume (press to mute)", "Volumen (pulsa para silenciar)", "Volume (appuie pour couper)", "Lautstärke (drücken: stumm)" },
            "Música", new[] { "Music", "Música", "Musique", "Musik" },
            "MÚSICA", new[] { "MUSIC", "MÚSICA", "MUSIQUE", "MUSIK" },
            "▶ A TOCAR", new[] { "▶ PLAYING", "▶ SONANDO", "▶ EN COURS", "▶ LÄUFT" },
            "❚❚ PAUSA", new[] { "❚❚ PAUSED", "❚❚ PAUSA", "❚❚ PAUSE", "❚❚ PAUSE" },
            "SEGUINTE", new[] { "NEXT", "SIGUIENTE", "SUIVANT", "WEITER" },
            "ANTERIOR", new[] { "PREVIOUS", "ANTERIOR", "PRÉCÉDENT", "ZURÜCK" },
            "sem música", new[] { "no music", "sin música", "pas de musique", "keine Musik" },
            "VOLUME", new[] { "VOLUME", "VOLUMEN", "VOLUME", "LAUTSTÄRKE" },
            "silenciado", new[] { "muted", "silenciado", "coupé", "stumm" },
            "carrega: silenciar", new[] { "press: mute", "pulsa: silenciar", "appuie : couper", "drücken: stumm" },
        });
        // chaves repetidas já não rebentam o plugin: a última ganha
        static Dictionary<string, string[]> Tr(object[] a) { var d = new Dictionary<string, string[]>(); for (int i = 0; i + 1 < a.Length; i += 2) d[(string)a[i]] = (string[])a[i + 1]; return d; }
        static readonly System.Text.RegularExpressions.Regex TNum = new System.Text.RegularExpressions.Regex(@"\d+(?:[.,]\d+)?|[A-Z]:");
        static string L(string pt)
        {
            if (string.IsNullOrEmpty(pt) || lang == "pt") return pt;
            int li = Array.IndexOf(new[] { "en", "es", "fr", "de" }, lang);
            if (li < 0) return pt;
            string[] t;
            if (TR.TryGetValue(pt, out t)) return t[li];
            System.Text.RegularExpressions.MatchCollection ms = TNum.Matches(pt);
            if (ms.Count == 0 || !TR.TryGetValue(TNum.Replace(pt, "#"), out t)) return pt;
            int k = 0;
            return System.Text.RegularExpressions.Regex.Replace(t[li], "#", delegate { return k < ms.Count ? ms[k++].Value : "#"; });
        }
        static CultureInfo LangCulture { get { switch (lang) { case "en": return new CultureInfo("en-GB"); case "es": return new CultureInfo("es-ES"); case "fr": return new CultureInfo("fr-FR"); case "de": return new CultureInfo("de-DE"); default: return new CultureInfo("pt-PT"); } } }

        static Reading Read(string metric, Dictionary<string, object> d)
        {
            string lg = Get(d, "lang") as string;
            if (!string.IsNullOrEmpty(lg)) lang = lg;
            Reading r = new Reading();
            string game = Get(d, "game", "name") as string;
            switch (metric)
            {
                case "cpu": r.Label = "CPU USO"; Pct(r, Num(Get(d, "cpu", "total")), "c1"); break;
                case "cputemp": r.Label = "CPU TEMP"; Temp(r, Num(Get(d, "cpu_temps", "package")) ?? Num(Get(d, "cpu_temp"))); if (!r.Value.HasValue) r.Sub = "sem sensor"; break;
                case "cpuhot": r.Label = "CPU MÁX"; Temp(r, Num(Get(d, "cpu_temps", "max"))); if (!r.Value.HasValue) r.Sub = "sem sensor"; break;
                case "cpuclock":
                    {
                        r.Label = "CPU CLOCK"; r.Unit = "GHz"; r.Tone = "c1"; r.Min = null;
                        double? v = Num(Get(d, "cpu", "freq"));
                        if (v.HasValue) { r.Value = v / 1000; r.Text = F(v.Value / 1000, 2); }
                        break;
                    }
                case "cpupower":
                    { r.Label = "CPU WATTS"; r.Unit = "W"; r.Tone = "warn"; double? v = Num(Get(d, "cpu_power")); if (v.HasValue) { r.Value = v; r.Text = F(v.Value, 0); } else r.Sub = "sem sensor"; break; }
                case "gpu": r.Label = "GPU USO"; Pct(r, Num(Get(d, "gpu", "util")), "ok"); break;
                case "gputemp": r.Label = "GPU TEMP"; Temp(r, Num(Get(d, "gpu", "temp"))); break;
                case "vram":
                    {
                        r.Label = "VRAM"; r.Unit = "GB"; r.Tone = "c2";
                        double? u = Num(Get(d, "gpu", "mem_used")), t = Num(Get(d, "gpu", "mem_total"));
                        if (u.HasValue) { r.Value = u / 1024; r.Text = F(u.Value / 1024, 1); }
                        if (t.HasValue && t > 0) { r.Max = t / 1024; r.Sub = "de " + F(t.Value / 1024, 0) + " GB"; if (u > t * 0.9) r.Tone = "crit"; }
                        break;
                    }
                case "gpupower":
                    { r.Label = "GPU WATTS"; r.Unit = "W"; r.Tone = "warn"; double? v = Num(Get(d, "gpu", "power")); if (v.HasValue) { r.Value = v; r.Text = F(v.Value, 0); } break; }
                case "power":
                    {
                        r.Label = "TOTAL WATTS"; r.Unit = "W"; r.Tone = "warn";
                        double? a = Num(Get(d, "cpu_power")), b = Num(Get(d, "gpu", "power"));
                        if (a.HasValue || b.HasValue) { r.Value = (a ?? 0) + (b ?? 0); r.Text = F(r.Value.Value, 0); r.Sub = "CPU + GPU"; }
                        break;
                    }
                case "ram": r.Label = "RAM USO"; Pct(r, Num(Get(d, "memory", "percent")), "c2"); break;
                case "ramused":
                    {
                        r.Label = "RAM"; r.Unit = "GB"; r.Tone = "c2";
                        double? u = Num(Get(d, "memory", "used")), t = Num(Get(d, "memory", "total"));
                        if (u.HasValue) { r.Value = u / 1073741824; r.Text = F(u.Value / 1073741824, 1); }
                        if (t.HasValue) { r.Max = t / 1073741824; r.Sub = "de " + F(t.Value / 1073741824, 0) + " GB"; }
                        break;
                    }
                case "swap": r.Label = "VIRTUAL"; Pct(r, Num(Get(d, "swap", "percent")), "c2"); break;
                case "fps":
                    {
                        r.Label = "FPS"; r.Tone = "ok"; r.Min = 0;
                        double? v = Num(Get(d, "game", "fps"));
                        if (v.HasValue) { r.Value = v; r.Text = F(v.Value, 0); r.Sub = game; } else r.Sub = "sem jogo";
                        break;
                    }
                case "frametime":
                    {
                        r.Label = "FRAMETIME"; r.Unit = "ms"; r.Tone = "c1";
                        double? v = Num(Get(d, "game", "frametime"));
                        if (v.HasValue) { r.Value = v; r.Text = F(v.Value, v.Value < 10 ? 1 : 0); r.Sub = game; } else r.Sub = "sem jogo";
                        break;
                    }
                case "latency":
                    {
                        r.Label = "LATÊNCIA"; r.Unit = "ms"; r.Tone = "c2";
                        double? v = Num(Get(d, "game", "latency"));
                        if (v.HasValue) { r.Value = v; r.Text = F(v.Value, v.Value < 10 ? 1 : 0); r.Sub = game; }
                        else r.Sub = Get(d, "game") != null ? "sem dados" : "sem jogo";
                        break;
                    }
                case "netdown":
                    { r.Label = "DOWNLOAD"; r.Tone = "c1"; double? v = Num(Get(d, "net", "down")); if (v.HasValue) { r.Value = v; r.Text = Rate(v.Value, out r.Unit); } break; }
                case "netup":
                    { r.Label = "UPLOAD"; r.Tone = "c2"; double? v = Num(Get(d, "net", "up")); if (v.HasValue) { r.Value = v; r.Text = Rate(v.Value, out r.Unit); } break; }
                case "diskread":
                    { r.Label = "LEITURA"; r.Tone = "c1"; double? v = Num(Get(d, "disk_io", "read")); if (v.HasValue) { r.Value = v; r.Text = Rate(v.Value, out r.Unit); } break; }
                case "diskwrite":
                    { r.Label = "ESCRITA"; r.Tone = "c2"; double? v = Num(Get(d, "disk_io", "write")); if (v.HasValue) { r.Value = v; r.Text = Rate(v.Value, out r.Unit); } break; }
                case "procs":
                    { r.Label = "PROCESSOS"; r.Tone = "c1"; r.Min = null; double? v = Num(Get(d, "processes", "count")); if (v.HasValue) { r.Value = v; r.Text = F(v.Value, 0); } break; }
                case "uptime":
                    {
                        r.Label = "LIGADO HÁ"; r.Tone = "c1"; r.NoGraph = true;
                        double? boot = Num(Get(d, "system", "boot")), now = Num(Get(d, "time"));
                        if (boot.HasValue && now.HasValue)
                        {
                            TimeSpan ts = TimeSpan.FromSeconds(Math.Max(0, now.Value - boot.Value));
                            r.Value = ts.TotalHours;
                            if (ts.TotalDays >= 1) { r.Text = ((int)ts.TotalDays) + "d"; r.Unit = ts.Hours + "h"; }
                            else { r.Text = ts.Hours + "h"; r.Unit = ts.Minutes.ToString("00") + "m"; }
                        }
                        break;
                    }
                case "clock":
                    {
                        DateTime n = DateTime.Now;
                        r.Label = "HORA"; r.Tone = "c1"; r.NoGraph = true; r.Value = 0;
                        r.Text = n.ToString("HH:mm"); r.Sub = n.ToString("ddd dd/MM", LangCulture).ToUpperInvariant();
                        break;
                    }
                case "bott":
                    {
                        string b = Get(d, "nexus", "bott") as string ?? "";
                        r.Label = "GARGALO"; r.NoGraph = true; r.Value = 0;
                        r.Text = b == "" ? "--" : b == "LIMITE" ? "FPS" : b;
                        r.Tone = b == "CPU" ? "warn" : b == "GPU" ? "ok" : "c1";
                        r.Sub = b == "" ? "sem jogo" : b == "CPU" ? "processador" : b == "GPU" ? "placa gráfica" : b == "LIMITE" ? "limite/vsync" : "equilibrado";
                        break;
                    }
                case "session":
                    {
                        double? mn = Num(Get(d, "nexus", "session"));
                        r.Label = "SESSÃO"; r.NoGraph = true; r.Value = 0; r.Tone = "c2";
                        if (mn.HasValue) { int t = (int)mn.Value; r.Text = t >= 60 ? (t / 60) + "h" : t.ToString(); r.Unit = t >= 60 ? (t % 60).ToString("00") + "m" : "min"; r.Sub = game ?? ""; }
                        else r.Sub = "sem jogo";
                        break;
                    }
                case "act:overlay":
                case "act:boost":
                    {
                        string k = metric == "act:overlay" ? "overlay" : "gamemode";
                        bool v = Get(d, "settings", k) is bool && (bool)Get(d, "settings", k);
                        r.Label = metric == "act:overlay" ? "OVERLAY" : "BOOST"; r.NoGraph = true; r.Value = 0;
                        r.Text = v ? "ON" : "OFF"; r.Tone = v ? "ok" : "c2"; r.Sub = "carrega para mudar";
                        break;
                    }
                case "act:bench":
                    {
                        bool v = Get(d, "nexus", "bench") is bool && (bool)Get(d, "nexus", "bench");
                        r.Label = "MEDIR FPS"; r.NoGraph = true; r.Value = 0;
                        r.Text = v ? "REC" : "60s"; r.Tone = v ? "crit" : "c1"; r.Sub = v ? "carrega para parar" : (game ?? "abre o jogo");
                        break;
                    }
                case "act:ram":
                    r.Label = "LIMPAR RAM"; r.NoGraph = true; Pct(r, Num(Get(d, "memory", "percent")), "c2"); r.NoGraph = true; r.Sub = "carrega para limpar";
                    break;
                case "act:media":
                case "act:next":
                case "act:prev":
                    {
                        Dictionary<string, object> m = Media();
                        string title = Get(m, "now", "title") as string ?? "", artist = Get(m, "now", "artist") as string ?? "";
                        double st = Num(Get(m, "now", "status")) ?? 0;
                        r.NoGraph = true; r.Value = 0; r.Tone = "c2";
                        r.Label = metric == "act:media" ? (st == 4 ? "▶ A TOCAR" : title != "" ? "❚❚ PAUSA" : "MÚSICA") : metric == "act:next" ? "SEGUINTE" : "ANTERIOR";
                        r.Text = metric == "act:next" ? "⏭" : metric == "act:prev" ? "⏮" : title == "" ? "♪" : title;
                        r.Sub = title == "" ? "sem música" : metric == "act:media" ? artist : title;
                        r.Unit = metric == "act:media" ? (coverId ?? "") : "";
                        break;
                    }
                case "act:vol":
                    {
                        Dictionary<string, object> m = Media();
                        double? v = Num(Get(m, "volume")); bool mu = Get(m, "mute") is bool && (bool)Get(m, "mute");
                        r.Label = "VOLUME"; r.NoGraph = true; r.Value = v ?? 0; r.Tone = mu ? "crit" : "c1";
                        r.Text = mu ? "🔇" : v.HasValue ? Math.Round(v.Value).ToString(IC) : "--"; r.Unit = mu || !v.HasValue ? "" : "%";
                        r.Sub = mu ? "silenciado" : "carrega: silenciar";
                        break;
                    }
                case "act:perf":
                    r.Label = "PERFORMANCE"; r.NoGraph = true; r.Value = 0; r.Text = "▶"; r.Tone = "c1"; r.Sub = "abrir";
                    break;
                case "act:disk":
                    r.Label = "DEEP SCAN"; r.NoGraph = true; r.Value = 0; r.Text = "▶"; r.Tone = "c1"; r.Sub = "abrir";
                    break;
                case "act:route":
                    {
                        Dictionary<string, object> rt = Route();
                        bool consent = Get(rt, "consent") is bool && (bool)Get(rt, "consent"), onv = Get(rt, "on") is bool && (bool)Get(rt, "on"), live = Get(rt, "active") is bool && (bool)Get(rt, "active");
                        r.Label = "ROTA"; r.NoGraph = true; r.Value = 0;
                        r.Text = live ? "CF" : onv ? "AUTO" : "OFF"; r.Tone = live ? "c2" : onv ? "ok" : "c1";
                        r.Sub = rt == null ? "sem NEXUS" : !consent ? "ligar na Performance" : live ? "Cloudflare ativa" : onv ? "à espera de jogo" : "carrega para ligar";
                        break;
                    }
                case "act:dpi":
                    {
                        Dictionary<string, object> m = Devs().FirstOrDefault(x => Get(x, "kind") as string == "mouse" && Num(Get(x, "dpi")).HasValue);
                        r.Label = "DPI"; r.NoGraph = true; r.Value = 0; r.Tone = "c1";
                        r.Text = m != null ? ((int)Num(Get(m, "dpi")).Value).ToString() : "--"; r.Sub = m != null ? "carrega: nível seguinte" : "sem rato compatível";
                        break;
                    }
                case "act:mic":
                    {
                        Dictionary<string, object> sd = J("/api/x/dev/sound", 3);
                        bool mm = Get(sd, "in", "mute") is bool && (bool)Get(sd, "in", "mute");
                        r.Label = "MICROFONE"; r.NoGraph = true; r.Value = 0;
                        r.Text = sd == null ? "--" : mm ? "MUDO" : "ON"; r.Tone = mm ? "crit" : "ok"; r.Sub = mm ? "carrega para ligar" : "carrega para silenciar";
                        break;
                    }
                case "devbat":
                    {
                        Dictionary<string, object> lo = Devs().Where(x => Num(Get(x, "battery")).HasValue).OrderBy(x => Num(Get(x, "battery")).Value).FirstOrDefault();
                        DevBat(r, lo);
                        break;
                    }
                case "battery":
                    {
                        r.Label = "BATERIA"; Pct(r, Num(Get(d, "battery", "percent")), "ok");
                        if (!r.Value.HasValue) r.Sub = "sem bateria";
                        else if (Get(d, "battery", "plugged") is bool && (bool)Get(d, "battery", "plugged")) r.Sub = "a carregar";
                        if (r.Value < 20) r.Tone = "crit"; else r.Tone = "ok";
                        break;
                    }
                default:
                    if (metric.StartsWith("devbat:"))
                    {
                        string id = metric.Substring(7);
                        DevBat(r, Devs().FirstOrDefault(x => Get(x, "id") as string == id));
                    }
                    else if (metric.StartsWith("macro:"))
                    {
                        string id = metric.Substring(6), nm = null;
                        System.Collections.IList ms = Arr(Get(J("/api/x/ctl", 20), "macros"));
                        if (ms != null) foreach (object o in ms) { Dictionary<string, object> m = o as Dictionary<string, object>; if (m != null && Get(m, "id") as string == id) nm = Get(m, "name") as string; }
                        r.Label = "MACRO"; r.NoGraph = true; r.Value = 0; r.Tone = "c2";
                        r.Text = nm ?? "?"; r.Sub = nm == null ? "macro apagada" : "carrega para correr";
                    }
                    else if (metric.StartsWith("game:"))
                    {
                        string gid = metric.Substring(5), gn = gid == "" ? null : GameName(gid);
                        r.Label = "JOGAR"; r.NoGraph = true; r.Value = 0; r.Tone = "c1";
                        r.Text = gn ?? "?"; r.Sub = gn == null ? "escolhe o jogo" : (game != null ? game : "carrega para abrir");
                    }
                    else if (metric.StartsWith("temp:"))
                    {
                        string n = metric.Substring(5);
                        r.Label = ShortName(n); Temp(r, Num(Get(d, "temps", n)));
                        r.Sub = Group(n);
                        if (!r.Value.HasValue) r.Sub = "sem leitura";
                    }
                    else if (metric.StartsWith("core:"))
                    {
                        int i; int.TryParse(metric.Substring(5), out i);
                        r.Label = "NÚCLEO " + (i + 1); r.Sub = "temperatura";
                        System.Collections.IList c = Arr(Get(d, "cpu_temps", "cores"));
                        Temp(r, c != null && i < c.Count ? Num(c[i]) : null);
                    }
                    else if (metric.StartsWith("thread:"))
                    {
                        int i; int.TryParse(metric.Substring(7), out i);
                        r.Label = "THREAD " + (i + 1);
                        System.Collections.IList c = Arr(Get(d, "cpu", "per_core"));
                        Pct(r, c != null && i < c.Count ? Num(c[i]) : null, "c1");
                    }
                    else if (metric.StartsWith("fan:"))
                    {
                        string n = metric.Substring(4);
                        r.Label = n.ToUpperInvariant().Replace("SYSTEM FAN", "FAN").Replace("CPU FAN", "CPU FAN"); r.Unit = "RPM"; r.Tone = "c1"; r.Min = null;
                        System.Collections.IList fans = Arr(Get(d, "fans"));
                        if (fans != null) foreach (object o in fans)
                            if (Get(o, "name") as string == n) { double? v = Num(Get(o, "rpm")); if (v.HasValue) { r.Value = v; r.Text = F(v.Value, 0); } }
                        r.Sub = "ventoinha";
                    }
                    else if (metric.StartsWith("disk:"))
                    {
                        string mnt = metric.Substring(5);
                        r.Label = "DISCO " + mnt.TrimEnd('\\');
                        System.Collections.IList disks = Arr(Get(d, "disks"));
                        if (disks != null) foreach (object o in disks)
                            if (Get(o, "mount") as string == mnt)
                            {
                                Pct(r, Num(Get(o, "percent")), "c1");
                                double? u = Num(Get(o, "used")), t = Num(Get(o, "total"));
                                if (u.HasValue && t.HasValue) r.Sub = Size(u.Value) + " / " + Size(t.Value);
                            }
                    }
                    else r.Label = metric.ToUpperInvariant();
                    break;
            }
            r.Label = L(r.Label);
            if (r.Sub != null && r.Sub != game) r.Sub = L(r.Sub);
            return r;
        }

        static string Size(double b)
        {
            if (b >= 1e12) return F(b / 1e12, 1) + "T";
            return F(b / 1e9, 0) + "G";
        }

        // ------------------------------------------------------------ desenho das teclas (144x144)
        static Color Col(Dictionary<string, object> d, string k, string def)
        {
            string h = Get(d, "theme", k) as string ?? def;
            try { return ColorTranslator.FromHtml(h); } catch { return ColorTranslator.FromHtml(def); }
        }

        static Color Mix(Color a, Color b, double t)
        {
            return Color.FromArgb((int)(a.R * (1 - t) + b.R * t), (int)(a.G * (1 - t) + b.G * t), (int)(a.B * (1 - t) + b.B * t));
        }

        static readonly StringFormat TF = MakeTF();
        static readonly string LabelFont = PickFont("Bahnschrift SemiCondensed", "Bahnschrift", "Segoe UI");
        static string PickFont(params string[] names)
        {
            try
            {
                using (InstalledFontCollection fc = new InstalledFontCollection())
                    foreach (string n in names)
                        if (fc.Families.Any(f => string.Equals(f.Name, n, StringComparison.OrdinalIgnoreCase))) return n;
            }
            catch { }
            return "Segoe UI";
        }
        static StringFormat MakeTF()
        {
            StringFormat f = (StringFormat)StringFormat.GenericTypographic.Clone();
            f.FormatFlags |= StringFormatFlags.NoWrap | StringFormatFlags.MeasureTrailingSpaces;
            return f;
        }

        static float W(Graphics g, string s, Font f) { return s == "" ? 0 : g.MeasureString(s, f, PointF.Empty, TF).Width; }

        static float Ascent(Font f)
        {
            FontFamily ff = f.FontFamily;
            return f.Size * ff.GetCellAscent(f.Style) / ff.GetEmHeight(f.Style);
        }

        // texto numa linha, centrado, a encolher até caber
        static void Line(Graphics g, string s, string family, FontStyle st, float maxPx, float minPx, RectangleF area, Color c)
        {
            Line(g, s, family, st, maxPx, minPx, area, c, Color.Empty);
        }

        // texto com "neon": cópias desfocadas à volta, depois o texto por cima
        static void Glow(Graphics g, string s, Font f, float x, float y, Color glow)
        {
            if (glow.IsEmpty) return;
            using (SolidBrush gb = new SolidBrush(Color.FromArgb(16, glow)))
                for (int i = 0; i < 8; i++)
                {
                    double a = i * Math.PI / 4;
                    float rr = i % 2 == 0 ? 2.2f : 1.2f;
                    g.DrawString(s, f, gb, x + (float)Math.Cos(a) * rr, y + (float)Math.Sin(a) * rr, TF);
                }
        }

        static void Line(Graphics g, string s, string family, FontStyle st, float maxPx, float minPx, RectangleF area, Color c, Color glow)
        {
            if (string.IsNullOrEmpty(s)) return;
            float sz = maxPx;
            Font f = new Font(family, sz, st, GraphicsUnit.Pixel);
            while (sz > minPx && W(g, s, f) > area.Width) { f.Dispose(); sz -= 0.5f; f = new Font(family, sz, st, GraphicsUnit.Pixel); }
            string t = s;
            while (t.Length > 2 && W(g, t, f) > area.Width) t = t.Substring(0, t.Length - 1);
            if (t != s) t = t.Substring(0, t.Length - 1) + "…";
            float w = W(g, t, f), capH = sz * 0.70f;
            float baseline = area.Y + area.Height / 2 + capH / 2;
            Glow(g, t, f, area.X + (area.Width - w) / 2, baseline - Ascent(f), glow);
            using (SolidBrush b = new SolidBrush(c)) g.DrawString(t, f, b, area.X + (area.Width - w) / 2, baseline - Ascent(f), TF);
            f.Dispose();
        }

        // valor grande + unidade pequena alinhados pela base
        static void Value(Graphics g, string val, string unit, RectangleF area, float maxPx, Color vc, Color uc)
        {
            float sz = maxPx;
            Font vf = null, uf = null;
            float w = 0, gap = 0;
            while (true)
            {
                if (vf != null) { vf.Dispose(); uf.Dispose(); }
                vf = new Font(NumFont, sz, FontStyle.Bold, GraphicsUnit.Pixel);
                uf = new Font(LabelFont, Math.Max(18f, sz * 0.42f), FontStyle.Bold, GraphicsUnit.Pixel);
                gap = unit == "" ? 0 : Math.Max(2f, sz * 0.06f);
                w = W(g, val, vf) + gap + W(g, unit, uf);
                if (w <= area.Width || sz <= 16) break;
                sz -= 1f;
            }
            float capH = sz * 0.70f;
            float baseline = area.Y + area.Height / 2 + capH / 2;
            float x = area.X + (area.Width - w) / 2;
            Glow(g, val, vf, x, baseline - Ascent(vf), uc);
            using (SolidBrush b = new SolidBrush(vc)) g.DrawString(val, vf, b, x, baseline - Ascent(vf), TF);
            if (unit != "")
                using (SolidBrush b = new SolidBrush(uc)) g.DrawString(unit, uf, b, x + W(g, val, vf) + gap, baseline - Ascent(uf), TF);
            vf.Dispose(); uf.Dispose();
        }

        static void Range(Reading r, List<double> h, out double lo, out double hi)
        {
            double cur = r.Value ?? 0;
            double mn = h.Count > 0 ? h.Min() : cur, mx = h.Count > 0 ? h.Max() : cur;
            lo = r.Min.HasValue ? r.Min.Value : mn;
            hi = r.Max.HasValue ? r.Max.Value : mx;
            if (!r.Max.HasValue)
            {
                double span = Math.Max(hi - lo, Math.Max(Math.Abs(hi) * 0.15, r.Unit == "°C" ? 8 : 1));
                if (!r.Min.HasValue) lo = Math.Max(0, mn - span * 0.25);
                hi = lo + span * 1.25 + (mx - lo > span ? mx - lo - span : 0);
                if (hi < mx) hi = mx * 1.1;
            }
            if (hi <= lo) hi = lo + 1;
        }

        static readonly string NumFont = PickFont("Bahnschrift", "Segoe UI");

        static byte[] Png(string metric, string style, Dictionary<string, object> d)
        {
            Color bg = Col(d, "bg", "#05070d"), panel = Col(d, "panel", "#0c1322"), txt = Col(d, "txt", "#d4e8ff"), dim = Col(d, "dim", "#5f7896");
            Color crit = Col(d, "crit", "#ff4e6a");
            Reading r = d != null ? Read(metric, d) : null;
            Color accent = r == null ? crit : Col(d, r.Tone, "#3ee8ff");
            List<double> h;
            lock (hist) h = hist.ContainsKey(metric) ? hist[metric].ToList() : new List<double>();

            using (Bitmap bmp = new Bitmap(144, 144, PixelFormat.Format32bppArgb))
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.TextRenderingHint = TextRenderingHint.AntiAlias;
                g.PixelOffsetMode = PixelOffsetMode.HighQuality;

                g.DrawImageUnscaled(Background(bg, panel, accent), 0, 0);

                if (r == null)
                {
                    Line(g, "NEXUS", LabelFont, FontStyle.Bold, 26, 14, new RectangleF(4, 14, 136, 30), dim);
                    Line(g, "OFF", NumFont, FontStyle.Bold, 70, 30, new RectangleF(4, 46, 136, 56), crit);
                    Line(g, L("toca p/ abrir"), LabelFont, FontStyle.Regular, 22, 12, new RectangleF(4, 108, 136, 26), dim);
                }
                else
                {
                    // nome do sensor, na cor do tema
                    Line(g, r.Label, LabelFont, FontStyle.Bold, 28, 16, new RectangleF(15, 8, 114, 29), accent);
                    // traço HUD por baixo do nome
                    using (Pen hp = new Pen(Color.FromArgb(150, accent), 1.5f)) g.DrawLine(hp, 46, 37, 98, 37);
                    using (SolidBrush hb = new SolidBrush(accent)) { g.FillRectangle(hb, 66, 35.5f, 12, 3); }
                    if (metric == "act:media") DrawMedia(g, r, accent, txt, dim, bg);
                    else if (style == "ring" && !r.NoGraph) DrawRing(g, r, h, accent, txt, dim, bg);
                    else if (style == "number" || r.NoGraph) DrawNumber(g, r, accent, txt, dim);
                    else DrawGraph(g, r, h, accent, txt, dim, bg);
                    DrawAlert(g, AlertState(metric, d), crit);
                }

                using (MemoryStream ms = new MemoryStream())
                {
                    bmp.Save(ms, ImageFormat.Png);
                    return ms.ToArray();
                }
            }
        }

        // fundo da tecla: igual enquanto o tema e a cor não mudam, por isso desenha-se uma vez só
        static readonly Dictionary<string, Bitmap> bgCache = new Dictionary<string, Bitmap>();
        static Bitmap Background(Color bg, Color panel, Color accent)
        {
            string key = bg.ToArgb() + "|" + panel.ToArgb() + "|" + accent.ToArgb();
            lock (bgCache)
            {
                Bitmap b;
                if (bgCache.TryGetValue(key, out b)) return b;
                if (bgCache.Count > 40) { foreach (Bitmap old in bgCache.Values) old.Dispose(); bgCache.Clear(); }
                b = new Bitmap(144, 144, PixelFormat.Format32bppArgb);
                using (Graphics g = Graphics.FromImage(b))
                {
                    g.SmoothingMode = SmoothingMode.AntiAlias;
                    g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                    using (LinearGradientBrush lb = new LinearGradientBrush(new Rectangle(0, 0, 144, 145), Mix(panel, bg, 0.15), bg, LinearGradientMode.Vertical))
                        g.FillRectangle(lb, 0, 0, 144, 144);
                    using (GraphicsPath gp = new GraphicsPath())
                    {
                        gp.AddEllipse(-40, 70, 224, 150);
                        using (PathGradientBrush pgb = new PathGradientBrush(gp))
                        {
                            pgb.CenterColor = Color.FromArgb(42, accent);
                            pgb.SurroundColors = new[] { Color.FromArgb(0, accent) };
                            g.FillPath(pgb, gp);
                        }
                    }
                    using (SolidBrush sl = new SolidBrush(Color.FromArgb(55, 0, 0, 0)))
                        for (int y = 1; y < 144; y += 3) g.FillRectangle(sl, 0, y, 144, 1);
                    Corners(g, accent);
                }
                bgCache[key] = b;
                return b;
            }
        }

        // cantos tipo HUD, arredondados para acompanhar a forma da tecla
        static void Corners(Graphics g, Color accent)
        {
            const float M = 7, R = 17, E = 8;
            float lo = M, hi = 144 - M, d = R * 2;
            using (Pen p = new Pen(Color.FromArgb(230, accent), 3f) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            using (GraphicsPath gp = new GraphicsPath())
            {
                gp.StartFigure(); gp.AddLine(lo, lo + R + E, lo, lo + R); gp.AddArc(lo, lo, d, d, 180, 90); gp.AddLine(lo + R, lo, lo + R + E, lo);
                gp.StartFigure(); gp.AddLine(hi - R - E, lo, hi - R, lo); gp.AddArc(hi - d, lo, d, d, 270, 90); gp.AddLine(hi, lo + R, hi, lo + R + E);
                gp.StartFigure(); gp.AddLine(hi, hi - R - E, hi, hi - R); gp.AddArc(hi - d, hi - d, d, d, 0, 90); gp.AddLine(hi - R, hi, hi - R - E, hi);
                gp.StartFigure(); gp.AddLine(lo + R + E, hi, lo + R, hi); gp.AddArc(lo, hi - d, d, d, 90, 90); gp.AddLine(lo, hi - R, lo, hi - R - E);
                g.DrawPath(p, gp);
            }
        }

        // estilo GRÁFICO: valor grande + curva do histórico (~48 s) de ponta a ponta em baixo
        static void DrawGraph(Graphics g, Reading r, List<double> h, Color accent, Color txt, Color dim, Color bg)
        {
            Value(g, r.Text, r.Unit, new RectangleF(4, 36, 136, 56), 64, txt, accent);
            if (!r.Value.HasValue && !string.IsNullOrEmpty(r.Sub))
            {
                Line(g, r.Sub, LabelFont, FontStyle.Regular, 22, 13, new RectangleF(4, 104, 136, 28), dim);
                return;
            }
            RectangleF gr = new RectangleF(0, 98, 144, 46);
            if (h.Count < 2)
            {
                using (Pen p = new Pen(Color.FromArgb(110, accent), 3f)) g.DrawLine(p, 0, 141, 144, 141);
                return;
            }
            double lo, hi; Range(r, h, out lo, out hi);
            int n = HIST;
            float step = (gr.Width + 4) / (n - 1);
            int start = n - h.Count;
            PointF[] pts = new PointF[h.Count];
            for (int i = 0; i < h.Count; i++)
            {
                double t = Math.Max(0, Math.Min(1, (h[i] - lo) / (hi - lo)));
                pts[i] = new PointF(-2 + (start + i) * step * (140f / 148f), (float)(gr.Bottom - 3 - t * (gr.Height - 8)));
            }
            using (GraphicsPath curve = new GraphicsPath())
            {
                curve.AddCurve(pts, 0.4f);
                using (GraphicsPath area = (GraphicsPath)curve.Clone())
                {
                    area.AddLine(pts[pts.Length - 1].X, pts[pts.Length - 1].Y, pts[pts.Length - 1].X, 146);
                    area.AddLine(pts[pts.Length - 1].X, 146, pts[0].X, 146);
                    area.CloseFigure();
                    using (LinearGradientBrush lb = new LinearGradientBrush(new RectangleF(0, gr.Y - 2, 144, gr.Height + 4),
                           Color.FromArgb(120, accent), Color.FromArgb(0, accent), LinearGradientMode.Vertical))
                        g.FillPath(lb, area);
                }
                using (Pen glow = new Pen(Color.FromArgb(45, accent), 10f) { LineJoin = LineJoin.Round }) g.DrawPath(glow, curve);
                using (Pen glow = new Pen(Color.FromArgb(90, accent), 6f) { LineJoin = LineJoin.Round }) g.DrawPath(glow, curve);
                using (Pen line = new Pen(Mix(accent, Color.White, 0.25), 2.5f) { LineJoin = LineJoin.Round, StartCap = LineCap.Round, EndCap = LineCap.Round })
                    g.DrawPath(line, curve);
                PointF last = pts[pts.Length - 1];
                using (SolidBrush gl = new SolidBrush(Color.FromArgb(80, accent))) g.FillEllipse(gl, last.X - 7, last.Y - 7, 14, 14);
                using (SolidBrush dot = new SolidBrush(Color.White)) g.FillEllipse(dot, last.X - 3, last.Y - 3, 6, 6);
            }
        }

        // estilo ANEL: anel fino e arredondado com o valor no centro
        static void DrawRing(Graphics g, Reading r, List<double> h, Color accent, Color txt, Color dim, Color bg)
        {
            RectangleF rc = new RectangleF(72 - 39, 92 - 39, 78, 78);
            using (Pen track = new Pen(Color.FromArgb(34, txt), 9f)) g.DrawEllipse(track, rc);
            // marcas à volta, como um mostrador
            using (Pen tk = new Pen(Color.FromArgb(90, accent), 1.5f))
                for (int i = 0; i < 36; i++)
                {
                    double a = i * Math.PI / 18 - Math.PI / 2;
                    float r1 = 47, r2 = i % 3 == 0 ? 51 : 49;
                    float cx = rc.X + rc.Width / 2, cy = rc.Y + rc.Height / 2;
                    g.DrawLine(tk, cx + (float)Math.Cos(a) * r1, cy + (float)Math.Sin(a) * r1, cx + (float)Math.Cos(a) * r2, cy + (float)Math.Sin(a) * r2);
                }
            double frac = 0;
            if (r.Value.HasValue)
            {
                double lo, hi; Range(r, h, out lo, out hi);
                frac = Math.Max(0, Math.Min(1, (r.Value.Value - lo) / (hi - lo)));
            }
            float sweep = (float)(frac * 360);
            if (sweep > 1f)
            {
                using (Pen glow = new Pen(Color.FromArgb(60, accent), 15f) { StartCap = LineCap.Round, EndCap = LineCap.Round }) g.DrawArc(glow, rc, -90, Math.Min(sweep, 359.5f));
                using (Pen arc = new Pen(accent, 9f) { StartCap = LineCap.Round, EndCap = LineCap.Round }) g.DrawArc(arc, rc, -90, Math.Min(sweep, 359.5f));
            }
            bool hasUnit = r.Unit != "";
            Line(g, r.Text, NumFont, FontStyle.Bold, 44, 18, new RectangleF(rc.X + 10, hasUnit ? 64 : 71, rc.Width - 20, 38), txt, accent);
            if (hasUnit) Line(g, r.Unit, LabelFont, FontStyle.Bold, 18, 11, new RectangleF(rc.X + 16, 101, rc.Width - 32, 20), accent);
        }

        // estilo NÚMERO: só o valor, o maior possível
        // ---------- música: o que está a tocar no Windows (Spotify, browser…), com a capa; pedido ao NEXUS só se houver tecla de música
        static Dictionary<string, object> media;
        static DateTime mediaT = DateTime.MinValue;
        static Bitmap cover; static string coverId;
        static Dictionary<string, object> Media()
        {
            if ((DateTime.Now - mediaT).TotalSeconds < 1.5) return media;
            mediaT = DateTime.Now;
            try
            {
                HttpWebRequest req = (HttpWebRequest)WebRequest.Create("http://127.0.0.1:8765/api/x/media"); req.Timeout = 2500; req.Proxy = null;
                using (WebResponse resp = req.GetResponse())
                using (StreamReader sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8)) media = js.Deserialize<Dictionary<string, object>>(sr.ReadToEnd());
                string cid = Get(media, "now", "cover") as string ?? "";
                if (cid == "") { coverId = null; if (cover != null) { lock (drawLock) { cover.Dispose(); cover = null; } } }
                else if (cid != coverId)
                {
                    HttpWebRequest ri = (HttpWebRequest)WebRequest.Create("http://127.0.0.1:8765/api/x/media/cover?n=" + cid); ri.Timeout = 2500; ri.Proxy = null;
                    using (WebResponse resp = ri.GetResponse())
                    using (Stream st = resp.GetResponseStream())
                    using (MemoryStream ms = new MemoryStream())
                    {
                        st.CopyTo(ms); ms.Position = 0;
                        Bitmap nb;
                        using (Image im = Image.FromStream(ms)) nb = new Bitmap(im, 144, 144);
                        lock (drawLock) { if (cover != null) cover.Dispose(); cover = nb; }
                        coverId = cid;
                    }
                }
            }
            catch { }
            return media;
        }
        static void DrawMedia(Graphics g, Reading r, Color accent, Color txt, Color dim, Color bg)
        {
            if (cover != null)
            {
                g.DrawImage(cover, 0, 0, 144, 144);
                using (LinearGradientBrush b = new LinearGradientBrush(new Rectangle(0, 40, 144, 104), Color.FromArgb(0, bg), Color.FromArgb(235, bg), 90f)) g.FillRectangle(b, 0, 40, 144, 104);
                using (SolidBrush b = new SolidBrush(Color.FromArgb(150, bg))) g.FillRectangle(b, 0, 0, 144, 40);
                Line(g, r.Label, LabelFont, FontStyle.Bold, 24, 14, new RectangleF(10, 8, 124, 26), accent);
            }
            Line(g, r.Text, LabelFont, FontStyle.Bold, 30, 14, new RectangleF(6, cover != null ? 82 : 46, 132, 32), txt);
            if (!string.IsNullOrEmpty(r.Sub)) Line(g, r.Sub, LabelFont, FontStyle.Regular, 22, 12, new RectangleF(6, cover != null ? 112 : 88, 132, 26), dim);
        }

        static void DrawNumber(Graphics g, Reading r, Color accent, Color txt, Color dim)
        {
            bool hasSub = !string.IsNullOrEmpty(r.Sub);
            Value(g, r.Text, r.Unit, new RectangleF(2, 38, 140, hasSub ? 70 : 100), 88, txt, accent);
            if (hasSub) Line(g, r.Sub, LabelFont, FontStyle.Regular, 22, 13, new RectangleF(4, 110, 136, 28), dim);
        }

        // ------------------------------------------------------------ teste: NexusDeck.exe --render <pasta>
        static void RenderTest(string dir)
        {
            Directory.CreateDirectory(dir);
            Dictionary<string, object> d = null;
            List<string> ids = null;
            for (int i = 0; i < 24; i++)
            {
                d = Fetch();
                if (d != null && ids == null) ids = Sensors(d).Select(s => s.Id).ToList();
                if (ids != null) Sample(d, ids);
                Thread.Sleep(500);
            }
            if (ids == null) ids = Fixed.Select(f => f[0]).ToList();
            foreach (string style in new[] { "graph", "ring", "number" })
            {
                int cols = 8, rows = (ids.Count + cols - 1) / cols, cell = 152;
                using (Bitmap sheet = new Bitmap(cols * cell + 8, rows * cell + 8))
                using (Graphics g = Graphics.FromImage(sheet))
                {
                    g.Clear(Color.FromArgb(30, 30, 30));
                    for (int i = 0; i < ids.Count; i++)
                        using (MemoryStream ms = new MemoryStream(Png(ids[i], style, d)))
                        using (Image im = Image.FromStream(ms))
                            g.DrawImage(im, 8 + (i % cols) * cell, 8 + (i / cols) * cell, 144, 144);
                    sheet.Save(Path.Combine(dir, "teclas_" + style + ".png"), ImageFormat.Png);
                }
            }
            // tamanho real aproximado de uma Stream Deck MK.2 (72 px por tecla)
            string[] demo = { "cpu", "cputemp", "gpu", "gputemp", "ram", "fps", "netdown", "vram", "power", "clock", "latency", "cpuclock", "procs", "diskwrite", "uptime" };
            using (Bitmap sheet = new Bitmap(5 * 84 + 12, 3 * 84 + 12))
            using (Graphics g = Graphics.FromImage(sheet))
            {
                g.Clear(Color.Black);
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                for (int i = 0; i < demo.Length; i++)
                    using (MemoryStream ms = new MemoryStream(Png(demo[i], i % 3 == 1 ? "ring" : i % 5 == 4 ? "number" : "graph", d)))
                    using (Image im = Image.FromStream(ms))
                        g.DrawImage(im, 12 + (i % 5) * 84, 12 + (i / 5) * 84, 72, 72);
                sheet.Save(Path.Combine(dir, "teclas_tamanho_real.png"), ImageFormat.Png);
            }
            File.WriteAllText(Path.Combine(dir, "fonte.txt"), LabelFont);
            File.WriteAllLines(Path.Combine(dir, "sensores.txt"), Sensors(d).Select(s => s.Id + "\t" + s.Group + "\t" + s.Name).ToArray(), Encoding.UTF8);
        }
    }
}
