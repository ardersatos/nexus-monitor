// NEXUS // Stream Deck plugin - mostra estatísticas do NEXUS Monitor nas teclas (C# 5, .NET Framework 4.x)
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.WebSockets;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;

[assembly: AssemblyTitle("NEXUS Deck")]
[assembly: AssemblyProduct("NEXUS Monitor")]
[assembly: AssemblyVersion("1.7.0.0")]
[assembly: AssemblyFileVersion("1.7.0.0")]

namespace NexusDeck
{
    // uma leitura pronta a desenhar
    class Reading
    {
        public string Label = "";        // o que é (ex.: "CPU TEMP")
        public string Sub;               // detalhe por baixo (ex.: nome do jogo, "de 32 GB")
        public double? Value;            // valor numérico (para o gráfico)
        public string Text = "--";       // valor como texto
        public string Unit = "";
        public double? Min = 0, Max;     // escala do gráfico/anel (Max null = automático)
        public string Tone = "c1";       // c1, c2, ok, warn, crit
        public bool NoGraph;             // relógio, tempo ligado...
    }

    class Sensor
    {
        public string Id, Name, Group;
        public Sensor(string id, string name, string group) { Id = id; Name = name; Group = group; }
    }

    static class Program
    {
        const string STATS = "http://127.0.0.1:8765/api/stats";
        static string lastThemeKey = "";
        const string PAGE = "http://localhost:8765/";
        const string ACTION = "com.nexus.monitor.stat";
        const int HIST = 48;

        static ClientWebSocket ws;
        static readonly object sendLock = new object();
        static readonly Dictionary<string, string[]> keys = new Dictionary<string, string[]>();   // context -> {métrica, estilo}
        static readonly Dictionary<string, string> keyDev = new Dictionary<string, string>();       // context -> dispositivo
        static readonly ManualResetEvent wake = new ManualResetEvent(false);                          // acorda quando aparece uma tecla
        static readonly Dictionary<string, string> lastImg = new Dictionary<string, string>();
        static readonly Dictionary<string, List<double>> hist = new Dictionary<string, List<double>>();
        static readonly JavaScriptSerializer js = new JavaScriptSerializer { MaxJsonLength = 8 * 1024 * 1024 };
        static Dictionary<string, object> lastData;
        static string nexusExe;
        static readonly CultureInfo IC = CultureInfo.InvariantCulture;

        static void Main(string[] args)
        {
            if (args.Length >= 2 && args[0] == "--render") { RenderTest(args[1]); return; }

            string port = null, uuid = null, reg = null;
            for (int i = 0; i < args.Length - 1; i++)
            {
                if (args[i] == "-port") port = args[i + 1];
                else if (args[i] == "-pluginUUID") uuid = args[i + 1];
                else if (args[i] == "-registerEvent") reg = args[i + 1];
            }
            if (port == null || uuid == null || reg == null) return;

            try
            {
                string pf = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "nexus_path.txt");
                if (File.Exists(pf)) nexusExe = File.ReadAllText(pf).Trim();
            }
            catch { }

            ws = new ClientWebSocket();
            ws.ConnectAsync(new Uri("ws://127.0.0.1:" + port), CancellationToken.None).Wait();
            Send(new Dictionary<string, object> { { "event", reg }, { "uuid", uuid } });

            Thread t = new Thread(RenderLoop);
            t.IsBackground = true;
            t.Start();

            ReceiveLoop();
        }

        // ------------------------------------------------------------ comunicação com a app Stream Deck
        static void Send(object o)
        {
            byte[] b = Encoding.UTF8.GetBytes(js.Serialize(o));
            lock (sendLock)
            {
                if (ws == null || ws.State != WebSocketState.Open) return;
                ws.SendAsync(new ArraySegment<byte>(b), WebSocketMessageType.Text, true, CancellationToken.None).Wait();
            }
        }

        static void ReceiveLoop()
        {
            byte[] buf = new byte[65536];
            MemoryStream msg = new MemoryStream();
            while (ws.State == WebSocketState.Open)
            {
                WebSocketReceiveResult r;
                try { r = ws.ReceiveAsync(new ArraySegment<byte>(buf), CancellationToken.None).Result; }
                catch { break; }
                if (r.MessageType == WebSocketMessageType.Close) break;
                msg.Write(buf, 0, r.Count);
                if (!r.EndOfMessage) continue;
                string text = Encoding.UTF8.GetString(msg.ToArray());
                msg.SetLength(0);
                try { Handle(js.Deserialize<Dictionary<string, object>>(text)); } catch { }
            }
        }

        static object Get(object o, params string[] path)
        {
            foreach (string p in path)
            {
                Dictionary<string, object> d = o as Dictionary<string, object>;
                if (d == null || !d.TryGetValue(p, out o)) return null;
            }
            return o;
        }

        static void Handle(Dictionary<string, object> m)
        {
            string ev = Get(m, "event") as string;
            string ctx = Get(m, "context") as string;
            if (ev == null) return;
            switch (ev)
            {
                case "willAppear":
                case "didReceiveSettings":
                    {
                        string metric = Get(m, "payload", "settings", "metric") as string ?? "cpu";
                        string style = Get(m, "payload", "settings", "style") as string ?? "graph";
                        string dev = Get(m, "device") as string;
                        lock (keys) { keys[ctx] = new[] { metric, style }; if (dev != null) keyDev[ctx] = dev; lastImg.Remove(ctx); lastSig.Remove(ctx); }
                        wake.Set();
                        Render(ctx, metric, style, lastData);
                        break;
                    }
                case "willDisappear":
                    lock (keys) { keys.Remove(ctx); keyDev.Remove(ctx); lastImg.Remove(ctx); lastSig.Remove(ctx); }
                    break;
                case "deviceDidDisconnect":   // Stream Deck desligada: esquece as teclas dela
                    {
                        string dev = Get(m, "device") as string;
                        lock (keys)
                            foreach (string c in keyDev.Where(kv => kv.Value == dev).Select(kv => kv.Key).ToList())
                            { keys.Remove(c); keyDev.Remove(c); lastImg.Remove(c); lastSig.Remove(c); }
                        break;
                    }
                case "propertyInspectorDidAppear":
                    SendSensorList(ctx);
                    break;
                case "sendToPlugin":
                    if (Get(m, "payload", "request") as string == "sensors") SendSensorList(ctx);
                    break;
                case "keyDown":
                    if (lastData != null)
                        Send(new Dictionary<string, object> { { "event", "openUrl" }, { "payload", new Dictionary<string, object> { { "url", PAGE } } } });
                    else if (!string.IsNullOrEmpty(nexusExe) && File.Exists(nexusExe))
                    {
                        try { Process.Start(new ProcessStartInfo(nexusExe) { UseShellExecute = true, WorkingDirectory = Path.GetDirectoryName(nexusExe) }); } catch { }
                    }
                    else
                        Send(new Dictionary<string, object> { { "event", "showAlert" }, { "context", ctx } });
                    break;
            }
        }

        static void SendSensorList(string ctx)
        {
            Dictionary<string, object> d = lastData ?? Fetch();
            List<object> list = new List<object>();
            foreach (Sensor s in Sensors(d))
                list.Add(new Dictionary<string, object> { { "id", s.Id }, { "name", s.Name }, { "group", s.Group } });
            Send(new Dictionary<string, object> {
                { "action", ACTION }, { "event", "sendToPropertyInspector" }, { "context", ctx },
                { "payload", new Dictionary<string, object> { { "sensors", list }, { "online", d != null }, { "lang", lang } } } });
        }

        static void RenderLoop()
        {
            while (true)
            {
                List<KeyValuePair<string, string[]>> list;
                lock (keys) list = keys.ToList();
                if (list.Count == 0)   // nenhuma tecla do NEXUS no ecrã: dorme sem gastar nada até aparecer uma
                {
                    wake.Reset();
                    lock (keys) if (keys.Count > 0) continue;
                    lastData = null;
                    wake.WaitOne();
                    continue;
                }
                lastData = Fetch(list.Any(kv => kv.Value[0].IndexOf("gpu", StringComparison.OrdinalIgnoreCase) >= 0 || kv.Value[0] == "vram" || kv.Value[0] == "power"));
                Sample(lastData, list.Select(kv => kv.Value[0]).Distinct());
                foreach (KeyValuePair<string, string[]> kv in list)
                {
                    try { Render(kv.Key, kv.Value[0], kv.Value[1], lastData); } catch { }
                }
                // cores do tema a mudar (SignalRGB): atualiza 3 vezes por segundo; o resto do tempo, 1 vez
                string tk = Convert.ToString(Get(lastData, "theme", "c1")) + Convert.ToString(Get(lastData, "theme", "c2"));
                bool themeMoving = tk != lastThemeKey; lastThemeKey = tk;
                Thread.Sleep(themeMoving ? 330 : 1000);
            }
        }

        static void Sample(Dictionary<string, object> d, IEnumerable<string> metrics)
        {
            if (d == null) return;
            foreach (string mt in metrics)
            {
                Reading r = Read(mt, d);
                if (!r.Value.HasValue || r.NoGraph) continue;
                List<double> h;
                lock (hist)
                {
                    if (!hist.TryGetValue(mt, out h)) hist[mt] = h = new List<double>();
                    h.Add(r.Value.Value);
                    if (h.Count > HIST) h.RemoveAt(0);
                }
            }
        }

        static Dictionary<string, object> Fetch() { return Fetch(true); }
        // gpu=false: nenhuma tecla visível mostra a GPU, por isso o NEXUS não precisa de a ler
        static Dictionary<string, object> Fetch(bool gpu)
        {
            try
            {
                HttpWebRequest req = (HttpWebRequest)WebRequest.Create(gpu ? STATS + "?deck=1" : STATS + "?nogpu=1&deck=1");
                req.Timeout = 2500;
                req.Proxy = null;
                using (WebResponse resp = req.GetResponse())
                using (StreamReader sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8))
                    return js.Deserialize<Dictionary<string, object>>(sr.ReadToEnd());
            }
            catch { return null; }
        }

        // "assinatura" do que a tecla mostra: se não mudou, não volta a desenhar nem a enviar

        // ---------- alertas (quando estão ligados no NEXUS): sinal discreto nas teclas
        // 0 = nada; 1 = há um alerta noutro sensor (só um ⚠ pequeno a piscar); 2 = esta tecla é o sensor em alerta (contorno a pulsar)
        static int AlertState(string metric, Dictionary<string, object> d)
        {
            if (d == null || !(Get(d, "settings", "alerts") is bool) || !(bool)Get(d, "settings", "alerts")) return 0;
            double lc = Num(Get(d, "settings", "alert_cpu")) ?? 999, lg = Num(Get(d, "settings", "alert_gpu")) ?? 999, lr = Num(Get(d, "settings", "alert_ram")) ?? 999;
            double? ct = Num(Get(d, "cpu_temps", "package")) ?? Num(Get(d, "cpu_temp")), gt = Num(Get(d, "gpu", "temp")), rp = Num(Get(d, "memory", "percent"));
            bool cpu = ct.HasValue && ct.Value >= lc, gpu = gt.HasValue && gt.Value >= lg, ram = rp.HasValue && rp.Value >= lr;
            if (!cpu && !gpu && !ram) return 0;
            if (cpu && (metric == "cputemp" || metric == "cpumax" || metric.StartsWith("core:"))) return 2;
            if (gpu && (metric == "gputemp" || metric == "gpu")) return 2;
            if (ram && (metric == "ram" || metric == "ramgb")) return 2;
            return 1;
        }
        static bool BlinkOn { get { return (DateTime.Now.Second & 1) == 0; } }

        static void DrawAlert(Graphics g, int state, Color crit)
        {
            if (state == 0) return;
            bool on = BlinkOn;
            if (state == 2)
                using (Pen p = new Pen(Color.FromArgb(on ? 230 : 90, crit), on ? 4f : 2.5f))
                using (GraphicsPath gp = new GraphicsPath())
                {
                    int r = 18; Rectangle b = new Rectangle(3, 3, 137, 137);
                    gp.AddArc(b.X, b.Y, r, r, 180, 90); gp.AddArc(b.Right - r, b.Y, r, r, 270, 90);
                    gp.AddArc(b.Right - r, b.Bottom - r, r, r, 0, 90); gp.AddArc(b.X, b.Bottom - r, r, r, 90, 90); gp.CloseFigure();
                    g.DrawPath(p, gp);
                }
            if (state == 2 || on)
            {
                // triângulo ⚠ pequeno no canto de cima à direita
                PointF[] tri = { new PointF(124, 10), new PointF(135, 29), new PointF(113, 29) };
                using (SolidBrush b = new SolidBrush(Color.FromArgb(state == 2 ? 255 : 200, crit))) g.FillPolygon(b, tri);
                using (SolidBrush b = new SolidBrush(Color.FromArgb(20, 10, 14))) { g.FillRectangle(b, 123, 15.5f, 2.2f, 7); g.FillRectangle(b, 123, 24, 2.2f, 2.2f); }
            }
        }

        static string Signature(string metric, string style, Dictionary<string, object> d)
        {
            if (d == null) return "off|" + style;
            Reading r = Read(metric, d);
            StringBuilder sb = new StringBuilder();
            sb.Append(style).Append('|').Append(r.Label).Append('|').Append(r.Text).Append('|').Append(r.Unit).Append('|').Append(r.Sub).Append('|').Append(r.Tone);
            foreach (string k in new[] { "bg", "panel", "txt", "dim", "c1", "c2", "warn", "ok", "crit" }) sb.Append('|').Append(Get(d, "theme", k));
            int al = AlertState(metric, d);
            if (al > 0) sb.Append("|alert").Append(al).Append(BlinkOn ? "+" : "-");   // muda a cada segundo: pisca devagar
            if (!r.NoGraph && style != "number")
                lock (hist)
                {
                    List<double> h;
                    if (hist.TryGetValue(metric, out h)) foreach (double v in h) sb.Append(',').Append(v.ToString("0.#", IC));
                }
            return sb.ToString();
        }

        static readonly Dictionary<string, string> lastSig = new Dictionary<string, string>();
        static readonly object drawLock = new object();

        static void Render(string ctx, string metric, string style, Dictionary<string, object> d)
        {
            string sig = Signature(metric, style, d), prevSig;
            lock (keys) { if (lastSig.TryGetValue(ctx, out prevSig) && prevSig == sig && lastImg.ContainsKey(ctx)) return; }
            string img;
            lock (drawLock) img = "data:image/png;base64," + Convert.ToBase64String(Png(metric, style, d));   // GDI+ não gosta de 2 threads no mesmo bitmap
            lock (keys)
            {
                lastSig[ctx] = sig;
                string prev;
                if (lastImg.TryGetValue(ctx, out prev) && prev == img) return;
                lastImg[ctx] = img;
            }
            Send(new Dictionary<string, object> {
                { "event", "setImage" }, { "context", ctx },
                { "payload", new Dictionary<string, object> { { "image", img }, { "target", 0 } } } });
        }

        // ------------------------------------------------------------ sensores disponíveis
        static double? Num(object o)
        {
            if (o == null) return null;
            try { return Convert.ToDouble(o, IC); } catch { return null; }
        }

        static System.Collections.IList Arr(object o) { return o as System.Collections.IList; }

        static readonly string[][] Fixed = {
            new[] { "cpu", "Uso do CPU", "Processador" },
            new[] { "cputemp", "Temperatura do CPU", "Processador" },
            new[] { "cpuhot", "Núcleo mais quente", "Processador" },
            new[] { "cpuclock", "Frequência do CPU", "Processador" },
            new[] { "cpupower", "Consumo do CPU", "Processador" },
            new[] { "gpu", "Uso da GPU", "Placa gráfica" },
            new[] { "gputemp", "Temperatura da GPU", "Placa gráfica" },
            new[] { "vram", "Memória da GPU (VRAM)", "Placa gráfica" },
            new[] { "gpupower", "Consumo da GPU", "Placa gráfica" },
            new[] { "power", "Consumo CPU + GPU", "Placa gráfica" },
            new[] { "ram", "Uso da RAM (%)", "Memória" },
            new[] { "ramused", "RAM em uso (GB)", "Memória" },
            new[] { "swap", "Memória virtual", "Memória" },
            new[] { "fps", "FPS", "Jogo" },
            new[] { "frametime", "Frametime", "Jogo" },
            new[] { "latency", "Latência (PresentMon)", "Jogo" },
            new[] { "netdown", "Download", "Rede" },
            new[] { "netup", "Upload", "Rede" },
            new[] { "diskread", "Leitura dos discos", "Discos" },
            new[] { "diskwrite", "Escrita dos discos", "Discos" },
            new[] { "procs", "Processos abertos", "Sistema" },
            new[] { "uptime", "Tempo ligado", "Sistema" },
            new[] { "clock", "Relógio", "Sistema" },
            new[] { "battery", "Bateria", "Sistema" },
        };

        static List<Sensor> Sensors(Dictionary<string, object> d)
        {
            string lg = Get(d, "lang") as string;
            if (!string.IsNullOrEmpty(lg)) lang = lg;
            List<Sensor> l = Fixed.Select(f => new Sensor(f[0], L(f[1]), L(f[2]))).ToList();
            if (d == null) return l;
            System.Collections.IList disks = Arr(Get(d, "disks"));
            if (disks != null) foreach (object o in disks)
            {
                string mnt = Get(o, "mount") as string;
                if (mnt != null) l.Add(new Sensor("disk:" + mnt, L("Disco " + mnt.TrimEnd('\\') + " (espaço usado)"), L("Discos")));
            }
            Dictionary<string, object> temps = Get(d, "temps") as Dictionary<string, object>;
            if (temps != null) foreach (string k in temps.Keys) l.Add(new Sensor("temp:" + k, k, L("Temperaturas")));
            System.Collections.IList cores = Arr(Get(d, "cpu_temps", "cores"));
            if (cores != null) for (int i = 0; i < cores.Count; i++) l.Add(new Sensor("core:" + i, L("Núcleo " + (i + 1) + " (temperatura)"), L("Temperaturas")));
            System.Collections.IList fans = Arr(Get(d, "fans"));
            if (fans != null) foreach (object o in fans)
            {
                string n = Get(o, "name") as string;
                if (n != null) l.Add(new Sensor("fan:" + n, n, L("Ventoinhas")));
            }
            System.Collections.IList per = Arr(Get(d, "cpu", "per_core"));
            if (per != null) for (int i = 0; i < per.Count; i++) l.Add(new Sensor("thread:" + i, L("Thread " + (i + 1) + " (uso)"), L("Uso por thread")));
            return l;
        }

        static string Rate(double b, out string unit)
        {
            if (b >= 1073741824) { unit = "GB/s"; return (b / 1073741824).ToString("0.0", IC); }
            if (b >= 1048576) { unit = "MB/s"; return (b / 1048576).ToString(b >= 104857600 ? "0" : "0.0", IC); }
            if (b >= 1024) { unit = "KB/s"; return (b / 1024).ToString("0", IC); }
            unit = "B/s"; return b.ToString("0", IC);
        }

        static string F(double v, int dec) { return v.ToString(dec == 0 ? "0" : dec == 1 ? "0.0" : "0.00", IC); }

        static string ShortName(string n)
        {
            int i = n.IndexOf(" · ");
            if (i >= 0) n = n.Substring(i + 3);
            n = n.Replace("Temperature", "").Replace("Temperatura", "").Replace("GeForce ", "").Trim();
            return n.ToUpperInvariant();
        }

        static string Group(string n)
        {
            int i = n.IndexOf(" · ");
            return i >= 0 ? n.Substring(0, i) : null;
        }

        static void Temp(Reading r, double? v)
        {
            r.Unit = "°C"; r.Tone = "ok"; r.Min = null; r.Max = null;
            if (v.HasValue) { r.Value = v; r.Text = F(v.Value, 0); r.Tone = v < 60 ? "ok" : v < 80 ? "warn" : "crit"; }
        }

        static void Pct(Reading r, double? v, string tone)
        {
            r.Unit = "%"; r.Max = 100; r.Tone = tone;
            if (v.HasValue) { r.Value = v; r.Text = F(v.Value, 0); if (v > 85) r.Tone = "crit"; else if (v > 60 && tone == "c1") r.Tone = "warn"; }
        }


        // ------------------------------------------------------------ idioma: segue a língua escolhida no NEXUS (browser)
        static volatile string lang = "pt";
        static readonly Dictionary<string, string[]> TR = new Dictionary<string, string[]> {
            // { pt, { en, es, fr, de } }
            { "CPU USO", new[] { "CPU USE", "USO CPU", "CPU UTIL.", "CPU LAST" } },
            { "CPU MÁX", new[] { "CPU MAX", "CPU MÁX", "CPU MAX", "CPU MAX" } },
            { "GPU USO", new[] { "GPU USE", "USO GPU", "GPU UTIL.", "GPU LAST" } },
            { "RAM USO", new[] { "RAM USE", "USO RAM", "RAM UTIL.", "RAM LAST" } },
            { "VIRTUAL", new[] { "VIRTUAL", "VIRTUAL", "VIRTUELLE", "VIRTUELL" } },
            { "LATÊNCIA", new[] { "LATENCY", "LATENCIA", "LATENCE", "LATENZ" } },
            { "LEITURA", new[] { "READ", "LECTURA", "LECTURE", "LESEN" } },
            { "ESCRITA", new[] { "WRITE", "ESCRITURA", "ÉCRITURE", "SCHREIBEN" } },
            { "PROCESSOS", new[] { "PROCESSES", "PROCESOS", "PROCESSUS", "PROZESSE" } },
            { "LIGADO HÁ", new[] { "UPTIME", "ENCENDIDO", "ALLUMÉ", "LAUFZEIT" } },
            { "HORA", new[] { "TIME", "HORA", "HEURE", "UHRZEIT" } },
            { "BATERIA", new[] { "BATTERY", "BATERÍA", "BATTERIE", "AKKU" } },
            { "NÚCLEO #", new[] { "CORE #", "NÚCLEO #", "CŒUR #", "KERN #" } },
            { "DISCO #", new[] { "DISK #", "DISCO #", "DISQUE #", "DISK #" } },
            { "TOTAL WATTS", new[] { "TOTAL WATTS", "WATTS TOTAL", "WATTS TOTAL", "WATT GESAMT" } },
            { "sem sensor", new[] { "no sensor", "sin sensor", "pas de capteur", "kein Sensor" } },
            { "de # GB", new[] { "of # GB", "de # GB", "sur # Go", "von # GB" } },
            { "sem jogo", new[] { "no game", "sin juego", "aucun jeu", "kein Spiel" } },
            { "sem dados", new[] { "no data", "sin datos", "aucune donnée", "keine Daten" } },
            { "sem bateria", new[] { "no battery", "sin batería", "pas de batterie", "kein Akku" } },
            { "a carregar", new[] { "charging", "cargando", "en charge", "lädt" } },
            { "sem leitura", new[] { "no reading", "sin lectura", "aucune lecture", "kein Wert" } },
            { "temperatura", new[] { "temperature", "temperatura", "température", "Temperatur" } },
            { "ventoinha", new[] { "fan", "ventilador", "ventilateur", "Lüfter" } },
            { "toca p/ abrir", new[] { "tap to open", "toca p/ abrir", "appuie : ouvrir", "tippen: öffnen" } },
            // lista de sensores (Stream Deck → definições da tecla)
            { "Uso do CPU", new[] { "CPU usage", "Uso del CPU", "Utilisation CPU", "CPU-Auslastung" } },
            { "Temperatura do CPU", new[] { "CPU temperature", "Temperatura del CPU", "Température CPU", "CPU-Temperatur" } },
            { "Núcleo mais quente", new[] { "Hottest core", "Núcleo más caliente", "Cœur le plus chaud", "Heißester Kern" } },
            { "Frequência do CPU", new[] { "CPU frequency", "Frecuencia del CPU", "Fréquence CPU", "CPU-Takt" } },
            { "Consumo do CPU", new[] { "CPU power", "Consumo del CPU", "Consommation CPU", "CPU-Verbrauch" } },
            { "Uso da GPU", new[] { "GPU usage", "Uso de la GPU", "Utilisation GPU", "GPU-Auslastung" } },
            { "Temperatura da GPU", new[] { "GPU temperature", "Temperatura de la GPU", "Température GPU", "GPU-Temperatur" } },
            { "Memória da GPU (VRAM)", new[] { "GPU memory (VRAM)", "Memoria de la GPU (VRAM)", "Mémoire GPU (VRAM)", "GPU-Speicher (VRAM)" } },
            { "Consumo da GPU", new[] { "GPU power", "Consumo de la GPU", "Consommation GPU", "GPU-Verbrauch" } },
            { "Consumo CPU + GPU", new[] { "CPU + GPU power", "Consumo CPU + GPU", "Consommation CPU + GPU", "Verbrauch CPU + GPU" } },
            { "Uso da RAM (%)", new[] { "RAM usage (%)", "Uso de la RAM (%)", "Utilisation RAM (%)", "RAM-Auslastung (%)" } },
            { "RAM em uso (GB)", new[] { "RAM in use (GB)", "RAM en uso (GB)", "RAM utilisée (Go)", "Belegter RAM (GB)" } },
            { "Memória virtual", new[] { "Virtual memory", "Memoria virtual", "Mémoire virtuelle", "Virtueller Speicher" } },
            { "Latência (PresentMon)", new[] { "Latency (PresentMon)", "Latencia (PresentMon)", "Latence (PresentMon)", "Latenz (PresentMon)" } },
            { "Leitura dos discos", new[] { "Disk read", "Lectura de discos", "Lecture disques", "Festplatten lesen" } },
            { "Escrita dos discos", new[] { "Disk write", "Escritura de discos", "Écriture disques", "Festplatten schreiben" } },
            { "Processos abertos", new[] { "Open processes", "Procesos abiertos", "Processus ouverts", "Offene Prozesse" } },
            { "Tempo ligado", new[] { "Uptime", "Tiempo encendido", "Temps allumé", "Laufzeit" } },
            { "Relógio", new[] { "Clock", "Reloj", "Horloge", "Uhr" } },
            { "Bateria", new[] { "Battery", "Batería", "Batterie", "Akku" } },
            { "Processador", new[] { "Processor", "Procesador", "Processeur", "Prozessor" } },
            { "Placa gráfica", new[] { "Graphics card", "Tarjeta gráfica", "Carte graphique", "Grafikkarte" } },
            { "Memória", new[] { "Memory", "Memoria", "Mémoire", "Speicher" } },
            { "Jogo", new[] { "Game", "Juego", "Jeu", "Spiel" } },
            { "Rede", new[] { "Network", "Red", "Réseau", "Netzwerk" } },
            { "Discos", new[] { "Disks", "Discos", "Disques", "Festplatten" } },
            { "Sistema", new[] { "System", "Sistema", "Système", "System" } },
            { "Temperaturas", new[] { "Temperatures", "Temperaturas", "Températures", "Temperaturen" } },
            { "Ventoinhas", new[] { "Fans", "Ventiladores", "Ventilateurs", "Lüfter" } },
            { "Uso por thread", new[] { "Usage per thread", "Uso por hilo", "Utilisation par thread", "Auslastung pro Thread" } },
            { "Disco # (espaço usado)", new[] { "Disk # (space used)", "Disco # (espacio usado)", "Disque # (espace utilisé)", "Festplatte # (belegt)" } },
            { "Núcleo # (temperatura)", new[] { "Core # (temperature)", "Núcleo # (temperatura)", "Cœur # (température)", "Kern # (Temperatur)" } },
            { "Thread # (uso)", new[] { "Thread # (usage)", "Hilo # (uso)", "Thread # (utilisation)", "Thread # (Auslastung)" } },
        };
        static readonly System.Text.RegularExpressions.Regex TNum = new System.Text.RegularExpressions.Regex(@"\d+(?:[.,]\d+)?|[A-Z]:");
        static string L(string pt)
        {
            if (string.IsNullOrEmpty(pt) || lang == "pt") return pt;
            int li = Array.IndexOf(new[] { "en", "es", "fr", "de" }, lang);
            if (li < 0) return pt;
            string[] t;
            if (TR.TryGetValue(pt, out t)) return t[li];
            System.Text.RegularExpressions.MatchCollection ms = TNum.Matches(pt);
            if (ms.Count == 0 || !TR.TryGetValue(TNum.Replace(pt, "#"), out t)) return pt;
            int k = 0;
            return System.Text.RegularExpressions.Regex.Replace(t[li], "#", delegate { return k < ms.Count ? ms[k++].Value : "#"; });
        }
        static CultureInfo LangCulture { get { switch (lang) { case "en": return new CultureInfo("en-GB"); case "es": return new CultureInfo("es-ES"); case "fr": return new CultureInfo("fr-FR"); case "de": return new CultureInfo("de-DE"); default: return new CultureInfo("pt-PT"); } } }

        static Reading Read(string metric, Dictionary<string, object> d)
        {
            string lg = Get(d, "lang") as string;
            if (!string.IsNullOrEmpty(lg)) lang = lg;
            Reading r = new Reading();
            string game = Get(d, "game", "name") as string;
            switch (metric)
            {
                case "cpu": r.Label = "CPU USO"; Pct(r, Num(Get(d, "cpu", "total")), "c1"); break;
                case "cputemp": r.Label = "CPU TEMP"; Temp(r, Num(Get(d, "cpu_temps", "package")) ?? Num(Get(d, "cpu_temp"))); if (!r.Value.HasValue) r.Sub = "sem sensor"; break;
                case "cpuhot": r.Label = "CPU MÁX"; Temp(r, Num(Get(d, "cpu_temps", "max"))); if (!r.Value.HasValue) r.Sub = "sem sensor"; break;
                case "cpuclock":
                    {
                        r.Label = "CPU CLOCK"; r.Unit = "GHz"; r.Tone = "c1"; r.Min = null;
                        double? v = Num(Get(d, "cpu", "freq"));
                        if (v.HasValue) { r.Value = v / 1000; r.Text = F(v.Value / 1000, 2); }
                        break;
                    }
                case "cpupower":
                    { r.Label = "CPU WATTS"; r.Unit = "W"; r.Tone = "warn"; double? v = Num(Get(d, "cpu_power")); if (v.HasValue) { r.Value = v; r.Text = F(v.Value, 0); } else r.Sub = "sem sensor"; break; }
                case "gpu": r.Label = "GPU USO"; Pct(r, Num(Get(d, "gpu", "util")), "ok"); break;
                case "gputemp": r.Label = "GPU TEMP"; Temp(r, Num(Get(d, "gpu", "temp"))); break;
                case "vram":
                    {
                        r.Label = "VRAM"; r.Unit = "GB"; r.Tone = "c2";
                        double? u = Num(Get(d, "gpu", "mem_used")), t = Num(Get(d, "gpu", "mem_total"));
                        if (u.HasValue) { r.Value = u / 1024; r.Text = F(u.Value / 1024, 1); }
                        if (t.HasValue && t > 0) { r.Max = t / 1024; r.Sub = "de " + F(t.Value / 1024, 0) + " GB"; if (u > t * 0.9) r.Tone = "crit"; }
                        break;
                    }
                case "gpupower":
                    { r.Label = "GPU WATTS"; r.Unit = "W"; r.Tone = "warn"; double? v = Num(Get(d, "gpu", "power")); if (v.HasValue) { r.Value = v; r.Text = F(v.Value, 0); } break; }
                case "power":
                    {
                        r.Label = "TOTAL WATTS"; r.Unit = "W"; r.Tone = "warn";
                        double? a = Num(Get(d, "cpu_power")), b = Num(Get(d, "gpu", "power"));
                        if (a.HasValue || b.HasValue) { r.Value = (a ?? 0) + (b ?? 0); r.Text = F(r.Value.Value, 0); r.Sub = "CPU + GPU"; }
                        break;
                    }
                case "ram": r.Label = "RAM USO"; Pct(r, Num(Get(d, "memory", "percent")), "c2"); break;
                case "ramused":
                    {
                        r.Label = "RAM"; r.Unit = "GB"; r.Tone = "c2";
                        double? u = Num(Get(d, "memory", "used")), t = Num(Get(d, "memory", "total"));
                        if (u.HasValue) { r.Value = u / 1073741824; r.Text = F(u.Value / 1073741824, 1); }
                        if (t.HasValue) { r.Max = t / 1073741824; r.Sub = "de " + F(t.Value / 1073741824, 0) + " GB"; }
                        break;
                    }
                case "swap": r.Label = "VIRTUAL"; Pct(r, Num(Get(d, "swap", "percent")), "c2"); break;
                case "fps":
                    {
                        r.Label = "FPS"; r.Tone = "ok"; r.Min = 0;
                        double? v = Num(Get(d, "game", "fps"));
                        if (v.HasValue) { r.Value = v; r.Text = F(v.Value, 0); r.Sub = game; } else r.Sub = "sem jogo";
                        break;
                    }
                case "frametime":
                    {
                        r.Label = "FRAMETIME"; r.Unit = "ms"; r.Tone = "c1";
                        double? v = Num(Get(d, "game", "frametime"));
                        if (v.HasValue) { r.Value = v; r.Text = F(v.Value, v.Value < 10 ? 1 : 0); r.Sub = game; } else r.Sub = "sem jogo";
                        break;
                    }
                case "latency":
                    {
                        r.Label = "LATÊNCIA"; r.Unit = "ms"; r.Tone = "c2";
                        double? v = Num(Get(d, "game", "latency"));
                        if (v.HasValue) { r.Value = v; r.Text = F(v.Value, v.Value < 10 ? 1 : 0); r.Sub = game; }
                        else r.Sub = Get(d, "game") != null ? "sem dados" : "sem jogo";
                        break;
                    }
                case "netdown":
                    { r.Label = "DOWNLOAD"; r.Tone = "c1"; double? v = Num(Get(d, "net", "down")); if (v.HasValue) { r.Value = v; r.Text = Rate(v.Value, out r.Unit); } break; }
                case "netup":
                    { r.Label = "UPLOAD"; r.Tone = "c2"; double? v = Num(Get(d, "net", "up")); if (v.HasValue) { r.Value = v; r.Text = Rate(v.Value, out r.Unit); } break; }
                case "diskread":
                    { r.Label = "LEITURA"; r.Tone = "c1"; double? v = Num(Get(d, "disk_io", "read")); if (v.HasValue) { r.Value = v; r.Text = Rate(v.Value, out r.Unit); } break; }
                case "diskwrite":
                    { r.Label = "ESCRITA"; r.Tone = "c2"; double? v = Num(Get(d, "disk_io", "write")); if (v.HasValue) { r.Value = v; r.Text = Rate(v.Value, out r.Unit); } break; }
                case "procs":
                    { r.Label = "PROCESSOS"; r.Tone = "c1"; r.Min = null; double? v = Num(Get(d, "processes", "count")); if (v.HasValue) { r.Value = v; r.Text = F(v.Value, 0); } break; }
                case "uptime":
                    {
                        r.Label = "LIGADO HÁ"; r.Tone = "c1"; r.NoGraph = true;
                        double? boot = Num(Get(d, "system", "boot")), now = Num(Get(d, "time"));
                        if (boot.HasValue && now.HasValue)
                        {
                            TimeSpan ts = TimeSpan.FromSeconds(Math.Max(0, now.Value - boot.Value));
                            r.Value = ts.TotalHours;
                            if (ts.TotalDays >= 1) { r.Text = ((int)ts.TotalDays) + "d"; r.Unit = ts.Hours + "h"; }
                            else { r.Text = ts.Hours + "h"; r.Unit = ts.Minutes.ToString("00") + "m"; }
                        }
                        break;
                    }
                case "clock":
                    {
                        DateTime n = DateTime.Now;
                        r.Label = "HORA"; r.Tone = "c1"; r.NoGraph = true; r.Value = 0;
                        r.Text = n.ToString("HH:mm"); r.Sub = n.ToString("ddd dd/MM", LangCulture).ToUpperInvariant();
                        break;
                    }
                case "battery":
                    {
                        r.Label = "BATERIA"; Pct(r, Num(Get(d, "battery", "percent")), "ok");
                        if (!r.Value.HasValue) r.Sub = "sem bateria";
                        else if (Get(d, "battery", "plugged") is bool && (bool)Get(d, "battery", "plugged")) r.Sub = "a carregar";
                        if (r.Value < 20) r.Tone = "crit"; else r.Tone = "ok";
                        break;
                    }
                default:
                    if (metric.StartsWith("temp:"))
                    {
                        string n = metric.Substring(5);
                        r.Label = ShortName(n); Temp(r, Num(Get(d, "temps", n)));
                        r.Sub = Group(n);
                        if (!r.Value.HasValue) r.Sub = "sem leitura";
                    }
                    else if (metric.StartsWith("core:"))
                    {
                        int i; int.TryParse(metric.Substring(5), out i);
                        r.Label = "NÚCLEO " + (i + 1); r.Sub = "temperatura";
                        System.Collections.IList c = Arr(Get(d, "cpu_temps", "cores"));
                        Temp(r, c != null && i < c.Count ? Num(c[i]) : null);
                    }
                    else if (metric.StartsWith("thread:"))
                    {
                        int i; int.TryParse(metric.Substring(7), out i);
                        r.Label = "THREAD " + (i + 1);
                        System.Collections.IList c = Arr(Get(d, "cpu", "per_core"));
                        Pct(r, c != null && i < c.Count ? Num(c[i]) : null, "c1");
                    }
                    else if (metric.StartsWith("fan:"))
                    {
                        string n = metric.Substring(4);
                        r.Label = n.ToUpperInvariant().Replace("SYSTEM FAN", "FAN").Replace("CPU FAN", "CPU FAN"); r.Unit = "RPM"; r.Tone = "c1"; r.Min = null;
                        System.Collections.IList fans = Arr(Get(d, "fans"));
                        if (fans != null) foreach (object o in fans)
                            if (Get(o, "name") as string == n) { double? v = Num(Get(o, "rpm")); if (v.HasValue) { r.Value = v; r.Text = F(v.Value, 0); } }
                        r.Sub = "ventoinha";
                    }
                    else if (metric.StartsWith("disk:"))
                    {
                        string mnt = metric.Substring(5);
                        r.Label = "DISCO " + mnt.TrimEnd('\\');
                        System.Collections.IList disks = Arr(Get(d, "disks"));
                        if (disks != null) foreach (object o in disks)
                            if (Get(o, "mount") as string == mnt)
                            {
                                Pct(r, Num(Get(o, "percent")), "c1");
                                double? u = Num(Get(o, "used")), t = Num(Get(o, "total"));
                                if (u.HasValue && t.HasValue) r.Sub = Size(u.Value) + " / " + Size(t.Value);
                            }
                    }
                    else r.Label = metric.ToUpperInvariant();
                    break;
            }
            r.Label = L(r.Label);
            if (r.Sub != null && r.Sub != game) r.Sub = L(r.Sub);
            return r;
        }

        static string Size(double b)
        {
            if (b >= 1e12) return F(b / 1e12, 1) + "T";
            return F(b / 1e9, 0) + "G";
        }

        // ------------------------------------------------------------ desenho das teclas (144x144)
        static Color Col(Dictionary<string, object> d, string k, string def)
        {
            string h = Get(d, "theme", k) as string ?? def;
            try { return ColorTranslator.FromHtml(h); } catch { return ColorTranslator.FromHtml(def); }
        }

        static Color Mix(Color a, Color b, double t)
        {
            return Color.FromArgb((int)(a.R * (1 - t) + b.R * t), (int)(a.G * (1 - t) + b.G * t), (int)(a.B * (1 - t) + b.B * t));
        }

        static readonly StringFormat TF = MakeTF();
        static readonly string LabelFont = PickFont("Bahnschrift SemiCondensed", "Bahnschrift", "Segoe UI");
        static string PickFont(params string[] names)
        {
            try
            {
                using (InstalledFontCollection fc = new InstalledFontCollection())
                    foreach (string n in names)
                        if (fc.Families.Any(f => string.Equals(f.Name, n, StringComparison.OrdinalIgnoreCase))) return n;
            }
            catch { }
            return "Segoe UI";
        }
        static StringFormat MakeTF()
        {
            StringFormat f = (StringFormat)StringFormat.GenericTypographic.Clone();
            f.FormatFlags |= StringFormatFlags.NoWrap | StringFormatFlags.MeasureTrailingSpaces;
            return f;
        }

        static float W(Graphics g, string s, Font f) { return s == "" ? 0 : g.MeasureString(s, f, PointF.Empty, TF).Width; }

        static float Ascent(Font f)
        {
            FontFamily ff = f.FontFamily;
            return f.Size * ff.GetCellAscent(f.Style) / ff.GetEmHeight(f.Style);
        }

        // texto numa linha, centrado, a encolher até caber
        static void Line(Graphics g, string s, string family, FontStyle st, float maxPx, float minPx, RectangleF area, Color c)
        {
            Line(g, s, family, st, maxPx, minPx, area, c, Color.Empty);
        }

        // texto com "neon": cópias desfocadas à volta, depois o texto por cima
        static void Glow(Graphics g, string s, Font f, float x, float y, Color glow)
        {
            if (glow.IsEmpty) return;
            using (SolidBrush gb = new SolidBrush(Color.FromArgb(16, glow)))
                for (int i = 0; i < 8; i++)
                {
                    double a = i * Math.PI / 4;
                    float rr = i % 2 == 0 ? 2.2f : 1.2f;
                    g.DrawString(s, f, gb, x + (float)Math.Cos(a) * rr, y + (float)Math.Sin(a) * rr, TF);
                }
        }

        static void Line(Graphics g, string s, string family, FontStyle st, float maxPx, float minPx, RectangleF area, Color c, Color glow)
        {
            if (string.IsNullOrEmpty(s)) return;
            float sz = maxPx;
            Font f = new Font(family, sz, st, GraphicsUnit.Pixel);
            while (sz > minPx && W(g, s, f) > area.Width) { f.Dispose(); sz -= 0.5f; f = new Font(family, sz, st, GraphicsUnit.Pixel); }
            string t = s;
            while (t.Length > 2 && W(g, t, f) > area.Width) t = t.Substring(0, t.Length - 1);
            if (t != s) t = t.Substring(0, t.Length - 1) + "…";
            float w = W(g, t, f), capH = sz * 0.70f;
            float baseline = area.Y + area.Height / 2 + capH / 2;
            Glow(g, t, f, area.X + (area.Width - w) / 2, baseline - Ascent(f), glow);
            using (SolidBrush b = new SolidBrush(c)) g.DrawString(t, f, b, area.X + (area.Width - w) / 2, baseline - Ascent(f), TF);
            f.Dispose();
        }

        // valor grande + unidade pequena alinhados pela base
        static void Value(Graphics g, string val, string unit, RectangleF area, float maxPx, Color vc, Color uc)
        {
            float sz = maxPx;
            Font vf = null, uf = null;
            float w = 0, gap = 0;
            while (true)
            {
                if (vf != null) { vf.Dispose(); uf.Dispose(); }
                vf = new Font(NumFont, sz, FontStyle.Bold, GraphicsUnit.Pixel);
                uf = new Font(LabelFont, Math.Max(18f, sz * 0.42f), FontStyle.Bold, GraphicsUnit.Pixel);
                gap = unit == "" ? 0 : Math.Max(2f, sz * 0.06f);
                w = W(g, val, vf) + gap + W(g, unit, uf);
                if (w <= area.Width || sz <= 16) break;
                sz -= 1f;
            }
            float capH = sz * 0.70f;
            float baseline = area.Y + area.Height / 2 + capH / 2;
            float x = area.X + (area.Width - w) / 2;
            Glow(g, val, vf, x, baseline - Ascent(vf), uc);
            using (SolidBrush b = new SolidBrush(vc)) g.DrawString(val, vf, b, x, baseline - Ascent(vf), TF);
            if (unit != "")
                using (SolidBrush b = new SolidBrush(uc)) g.DrawString(unit, uf, b, x + W(g, val, vf) + gap, baseline - Ascent(uf), TF);
            vf.Dispose(); uf.Dispose();
        }

        static void Range(Reading r, List<double> h, out double lo, out double hi)
        {
            double cur = r.Value ?? 0;
            double mn = h.Count > 0 ? h.Min() : cur, mx = h.Count > 0 ? h.Max() : cur;
            lo = r.Min.HasValue ? r.Min.Value : mn;
            hi = r.Max.HasValue ? r.Max.Value : mx;
            if (!r.Max.HasValue)
            {
                double span = Math.Max(hi - lo, Math.Max(Math.Abs(hi) * 0.15, r.Unit == "°C" ? 8 : 1));
                if (!r.Min.HasValue) lo = Math.Max(0, mn - span * 0.25);
                hi = lo + span * 1.25 + (mx - lo > span ? mx - lo - span : 0);
                if (hi < mx) hi = mx * 1.1;
            }
            if (hi <= lo) hi = lo + 1;
        }

        static readonly string NumFont = PickFont("Bahnschrift", "Segoe UI");

        static byte[] Png(string metric, string style, Dictionary<string, object> d)
        {
            Color bg = Col(d, "bg", "#05070d"), panel = Col(d, "panel", "#0c1322"), txt = Col(d, "txt", "#d4e8ff"), dim = Col(d, "dim", "#5f7896");
            Color crit = Col(d, "crit", "#ff4e6a");
            Reading r = d != null ? Read(metric, d) : null;
            Color accent = r == null ? crit : Col(d, r.Tone, "#3ee8ff");
            List<double> h;
            lock (hist) h = hist.ContainsKey(metric) ? hist[metric].ToList() : new List<double>();

            using (Bitmap bmp = new Bitmap(144, 144, PixelFormat.Format32bppArgb))
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.TextRenderingHint = TextRenderingHint.AntiAlias;
                g.PixelOffsetMode = PixelOffsetMode.HighQuality;

                g.DrawImageUnscaled(Background(bg, panel, accent), 0, 0);

                if (r == null)
                {
                    Line(g, "NEXUS", LabelFont, FontStyle.Bold, 26, 14, new RectangleF(4, 14, 136, 30), dim);
                    Line(g, "OFF", NumFont, FontStyle.Bold, 70, 30, new RectangleF(4, 46, 136, 56), crit);
                    Line(g, L("toca p/ abrir"), LabelFont, FontStyle.Regular, 22, 12, new RectangleF(4, 108, 136, 26), dim);
                }
                else
                {
                    // nome do sensor, na cor do tema
                    Line(g, r.Label, LabelFont, FontStyle.Bold, 28, 16, new RectangleF(15, 8, 114, 29), accent);
                    // traço HUD por baixo do nome
                    using (Pen hp = new Pen(Color.FromArgb(150, accent), 1.5f)) g.DrawLine(hp, 46, 37, 98, 37);
                    using (SolidBrush hb = new SolidBrush(accent)) { g.FillRectangle(hb, 66, 35.5f, 12, 3); }
                    if (style == "ring" && !r.NoGraph) DrawRing(g, r, h, accent, txt, dim, bg);
                    else if (style == "number" || r.NoGraph) DrawNumber(g, r, accent, txt, dim);
                    else DrawGraph(g, r, h, accent, txt, dim, bg);
                    DrawAlert(g, AlertState(metric, d), crit);
                }

                using (MemoryStream ms = new MemoryStream())
                {
                    bmp.Save(ms, ImageFormat.Png);
                    return ms.ToArray();
                }
            }
        }

        // fundo da tecla: igual enquanto o tema e a cor não mudam, por isso desenha-se uma vez só
        static readonly Dictionary<string, Bitmap> bgCache = new Dictionary<string, Bitmap>();
        static Bitmap Background(Color bg, Color panel, Color accent)
        {
            string key = bg.ToArgb() + "|" + panel.ToArgb() + "|" + accent.ToArgb();
            lock (bgCache)
            {
                Bitmap b;
                if (bgCache.TryGetValue(key, out b)) return b;
                if (bgCache.Count > 40) { foreach (Bitmap old in bgCache.Values) old.Dispose(); bgCache.Clear(); }
                b = new Bitmap(144, 144, PixelFormat.Format32bppArgb);
                using (Graphics g = Graphics.FromImage(b))
                {
                    g.SmoothingMode = SmoothingMode.AntiAlias;
                    g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                    using (LinearGradientBrush lb = new LinearGradientBrush(new Rectangle(0, 0, 144, 145), Mix(panel, bg, 0.15), bg, LinearGradientMode.Vertical))
                        g.FillRectangle(lb, 0, 0, 144, 144);
                    using (GraphicsPath gp = new GraphicsPath())
                    {
                        gp.AddEllipse(-40, 70, 224, 150);
                        using (PathGradientBrush pgb = new PathGradientBrush(gp))
                        {
                            pgb.CenterColor = Color.FromArgb(42, accent);
                            pgb.SurroundColors = new[] { Color.FromArgb(0, accent) };
                            g.FillPath(pgb, gp);
                        }
                    }
                    using (SolidBrush sl = new SolidBrush(Color.FromArgb(55, 0, 0, 0)))
                        for (int y = 1; y < 144; y += 3) g.FillRectangle(sl, 0, y, 144, 1);
                    Corners(g, accent);
                }
                bgCache[key] = b;
                return b;
            }
        }

        // cantos tipo HUD, arredondados para acompanhar a forma da tecla
        static void Corners(Graphics g, Color accent)
        {
            const float M = 7, R = 17, E = 8;
            float lo = M, hi = 144 - M, d = R * 2;
            using (Pen p = new Pen(Color.FromArgb(230, accent), 3f) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            using (GraphicsPath gp = new GraphicsPath())
            {
                gp.StartFigure(); gp.AddLine(lo, lo + R + E, lo, lo + R); gp.AddArc(lo, lo, d, d, 180, 90); gp.AddLine(lo + R, lo, lo + R + E, lo);
                gp.StartFigure(); gp.AddLine(hi - R - E, lo, hi - R, lo); gp.AddArc(hi - d, lo, d, d, 270, 90); gp.AddLine(hi, lo + R, hi, lo + R + E);
                gp.StartFigure(); gp.AddLine(hi, hi - R - E, hi, hi - R); gp.AddArc(hi - d, hi - d, d, d, 0, 90); gp.AddLine(hi - R, hi, hi - R - E, hi);
                gp.StartFigure(); gp.AddLine(lo + R + E, hi, lo + R, hi); gp.AddArc(lo, hi - d, d, d, 90, 90); gp.AddLine(lo, hi - R, lo, hi - R - E);
                g.DrawPath(p, gp);
            }
        }

        // estilo GRÁFICO: valor grande + curva do histórico (~48 s) de ponta a ponta em baixo
        static void DrawGraph(Graphics g, Reading r, List<double> h, Color accent, Color txt, Color dim, Color bg)
        {
            Value(g, r.Text, r.Unit, new RectangleF(4, 36, 136, 56), 64, txt, accent);
            if (!r.Value.HasValue && !string.IsNullOrEmpty(r.Sub))
            {
                Line(g, r.Sub, LabelFont, FontStyle.Regular, 22, 13, new RectangleF(4, 104, 136, 28), dim);
                return;
            }
            RectangleF gr = new RectangleF(0, 98, 144, 46);
            if (h.Count < 2)
            {
                using (Pen p = new Pen(Color.FromArgb(110, accent), 3f)) g.DrawLine(p, 0, 141, 144, 141);
                return;
            }
            double lo, hi; Range(r, h, out lo, out hi);
            int n = HIST;
            float step = (gr.Width + 4) / (n - 1);
            int start = n - h.Count;
            PointF[] pts = new PointF[h.Count];
            for (int i = 0; i < h.Count; i++)
            {
                double t = Math.Max(0, Math.Min(1, (h[i] - lo) / (hi - lo)));
                pts[i] = new PointF(-2 + (start + i) * step * (140f / 148f), (float)(gr.Bottom - 3 - t * (gr.Height - 8)));
            }
            using (GraphicsPath curve = new GraphicsPath())
            {
                curve.AddCurve(pts, 0.4f);
                using (GraphicsPath area = (GraphicsPath)curve.Clone())
                {
                    area.AddLine(pts[pts.Length - 1].X, pts[pts.Length - 1].Y, pts[pts.Length - 1].X, 146);
                    area.AddLine(pts[pts.Length - 1].X, 146, pts[0].X, 146);
                    area.CloseFigure();
                    using (LinearGradientBrush lb = new LinearGradientBrush(new RectangleF(0, gr.Y - 2, 144, gr.Height + 4),
                           Color.FromArgb(120, accent), Color.FromArgb(0, accent), LinearGradientMode.Vertical))
                        g.FillPath(lb, area);
                }
                using (Pen glow = new Pen(Color.FromArgb(45, accent), 10f) { LineJoin = LineJoin.Round }) g.DrawPath(glow, curve);
                using (Pen glow = new Pen(Color.FromArgb(90, accent), 6f) { LineJoin = LineJoin.Round }) g.DrawPath(glow, curve);
                using (Pen line = new Pen(Mix(accent, Color.White, 0.25), 2.5f) { LineJoin = LineJoin.Round, StartCap = LineCap.Round, EndCap = LineCap.Round })
                    g.DrawPath(line, curve);
                PointF last = pts[pts.Length - 1];
                using (SolidBrush gl = new SolidBrush(Color.FromArgb(80, accent))) g.FillEllipse(gl, last.X - 7, last.Y - 7, 14, 14);
                using (SolidBrush dot = new SolidBrush(Color.White)) g.FillEllipse(dot, last.X - 3, last.Y - 3, 6, 6);
            }
        }

        // estilo ANEL: anel fino e arredondado com o valor no centro
        static void DrawRing(Graphics g, Reading r, List<double> h, Color accent, Color txt, Color dim, Color bg)
        {
            RectangleF rc = new RectangleF(72 - 39, 92 - 39, 78, 78);
            using (Pen track = new Pen(Color.FromArgb(34, txt), 9f)) g.DrawEllipse(track, rc);
            // marcas à volta, como um mostrador
            using (Pen tk = new Pen(Color.FromArgb(90, accent), 1.5f))
                for (int i = 0; i < 36; i++)
                {
                    double a = i * Math.PI / 18 - Math.PI / 2;
                    float r1 = 47, r2 = i % 3 == 0 ? 51 : 49;
                    float cx = rc.X + rc.Width / 2, cy = rc.Y + rc.Height / 2;
                    g.DrawLine(tk, cx + (float)Math.Cos(a) * r1, cy + (float)Math.Sin(a) * r1, cx + (float)Math.Cos(a) * r2, cy + (float)Math.Sin(a) * r2);
                }
            double frac = 0;
            if (r.Value.HasValue)
            {
                double lo, hi; Range(r, h, out lo, out hi);
                frac = Math.Max(0, Math.Min(1, (r.Value.Value - lo) / (hi - lo)));
            }
            float sweep = (float)(frac * 360);
            if (sweep > 1f)
            {
                using (Pen glow = new Pen(Color.FromArgb(60, accent), 15f) { StartCap = LineCap.Round, EndCap = LineCap.Round }) g.DrawArc(glow, rc, -90, Math.Min(sweep, 359.5f));
                using (Pen arc = new Pen(accent, 9f) { StartCap = LineCap.Round, EndCap = LineCap.Round }) g.DrawArc(arc, rc, -90, Math.Min(sweep, 359.5f));
            }
            bool hasUnit = r.Unit != "";
            Line(g, r.Text, NumFont, FontStyle.Bold, 44, 18, new RectangleF(rc.X + 10, hasUnit ? 64 : 71, rc.Width - 20, 38), txt, accent);
            if (hasUnit) Line(g, r.Unit, LabelFont, FontStyle.Bold, 18, 11, new RectangleF(rc.X + 16, 101, rc.Width - 32, 20), accent);
        }

        // estilo NÚMERO: só o valor, o maior possível
        static void DrawNumber(Graphics g, Reading r, Color accent, Color txt, Color dim)
        {
            bool hasSub = !string.IsNullOrEmpty(r.Sub);
            Value(g, r.Text, r.Unit, new RectangleF(2, 38, 140, hasSub ? 70 : 100), 88, txt, accent);
            if (hasSub) Line(g, r.Sub, LabelFont, FontStyle.Regular, 22, 13, new RectangleF(4, 110, 136, 28), dim);
        }

        // ------------------------------------------------------------ teste: NexusDeck.exe --render <pasta>
        static void RenderTest(string dir)
        {
            Directory.CreateDirectory(dir);
            Dictionary<string, object> d = null;
            List<string> ids = null;
            for (int i = 0; i < 24; i++)
            {
                d = Fetch();
                if (d != null && ids == null) ids = Sensors(d).Select(s => s.Id).ToList();
                if (ids != null) Sample(d, ids);
                Thread.Sleep(500);
            }
            if (ids == null) ids = Fixed.Select(f => f[0]).ToList();
            foreach (string style in new[] { "graph", "ring", "number" })
            {
                int cols = 8, rows = (ids.Count + cols - 1) / cols, cell = 152;
                using (Bitmap sheet = new Bitmap(cols * cell + 8, rows * cell + 8))
                using (Graphics g = Graphics.FromImage(sheet))
                {
                    g.Clear(Color.FromArgb(30, 30, 30));
                    for (int i = 0; i < ids.Count; i++)
                        using (MemoryStream ms = new MemoryStream(Png(ids[i], style, d)))
                        using (Image im = Image.FromStream(ms))
                            g.DrawImage(im, 8 + (i % cols) * cell, 8 + (i / cols) * cell, 144, 144);
                    sheet.Save(Path.Combine(dir, "teclas_" + style + ".png"), ImageFormat.Png);
                }
            }
            // tamanho real aproximado de uma Stream Deck MK.2 (72 px por tecla)
            string[] demo = { "cpu", "cputemp", "gpu", "gputemp", "ram", "fps", "netdown", "vram", "power", "clock", "latency", "cpuclock", "procs", "diskwrite", "uptime" };
            using (Bitmap sheet = new Bitmap(5 * 84 + 12, 3 * 84 + 12))
            using (Graphics g = Graphics.FromImage(sheet))
            {
                g.Clear(Color.Black);
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                for (int i = 0; i < demo.Length; i++)
                    using (MemoryStream ms = new MemoryStream(Png(demo[i], i % 3 == 1 ? "ring" : i % 5 == 4 ? "number" : "graph", d)))
                    using (Image im = Image.FromStream(ms))
                        g.DrawImage(im, 12 + (i % 5) * 84, 12 + (i / 5) * 84, 72, 72);
                sheet.Save(Path.Combine(dir, "teclas_tamanho_real.png"), ImageFormat.Png);
            }
            File.WriteAllText(Path.Combine(dir, "fonte.txt"), LabelFont);
            File.WriteAllLines(Path.Combine(dir, "sensores.txt"), Sensors(d).Select(s => s.Id + "\t" + s.Group + "\t" + s.Name).ToArray(), Encoding.UTF8);
        }
    }
}
