@echo off
chcp 65001 >NUL
setlocal EnableExtensions
set "VER=2.0"
title NEXUS Monitor %VER% · Instalador
cd /d "%~dp0"
set "HERE=%~dp0"
if "%HERE:~-1%"=="\" set "HERE=%HERE:~0,-1%"
set "DEST=%LOCALAPPDATA%\Programs\NEXUS Monitor"
for /F %%a in ('echo prompt $E ^| cmd') do set "ESC=%%a"
set "C=%ESC%[96m" & set "M=%ESC%[95m" & set "G=%ESC%[92m" & set "Y=%ESC%[93m" & set "R=%ESC%[91m" & set "D=%ESC%[90m" & set "B=%ESC%[1m" & set "N=%ESC%[0m"
set "HR=%D%  ────────────────────────────────────────────────────────────%N%"
set "PS=powershell -NoProfile -ExecutionPolicy Bypass -File "%HERE%\nexus_ficheiros.ps1""

for %%f in (NexusMonitor.cs codigo\Otimizacao.cs index.html disk.html pad.html perf.html i18n.js nexus.ico nexus_ficheiros.txt nexus_ficheiros.ps1) do if not exist "%%f" goto naoextraido

rem argumentos (ao reabrir como administrador): 2 stream-deck presentmon gdu apagar-antiga atalho-menu atalho-ambiente
set "DECK=%~2" & set "PM=%~3" & set "GDU=%~4" & set "RMOLD=%~5" & set "SM=%~6" & set "SD=%~7"
set "ARGS=%~1"
set "DESTF=%TEMP%\nexus_destino.txt"
if defined ARGS if exist "%DESTF%" (set /p DEST=<"%DESTF%" & del "%DESTF%" >NUL 2>NUL)
if defined ARGS goto detetar

rem ---- onde instalar: se já houver um NEXUS instalado, a sugestão é a pasta dele
set "ACHADO="
for /f "usebackq delims=" %%i in (`%PS% -Modo Procurar`) do set "ACHADO=%%i"
if defined ACHADO set "DEST=%ACHADO%"
:pasta
cls
call :logo
echo   %B%Onde queres instalar o NEXUS Monitor?%N%
echo.
echo      %C%%DEST%%N%
if defined ACHADO if /i "%DEST%"=="%ACHADO%" echo      %D%^(é onde o NEXUS já está instalado^)%N%
echo.
echo      %B%S%N% - instalar aqui
echo      %B%E%N% - escolher outra pasta ^(abre uma janela^)
echo      %B%C%N% - escrever o caminho
echo.
choice /c SEC /n /m "  %C%»%N% Escolhe (S/E/C): "
if errorlevel 3 goto escreverPasta
if errorlevel 2 goto escolherPasta
goto detetar
:escolherPasta
echo.
echo   %D%A abrir a janela para escolher a pasta...%N%
set "NOVA="
for /f "usebackq delims=" %%i in (`%PS% -Modo Escolher -Destino "%DEST%"`) do set "NOVA=%%i"
if "%NOVA%"=="?" goto escreverPasta
goto validarPasta
:escreverPasta
echo.
echo   Escreve a pasta onde instalar ^(ex.: D:\Programas^) e carrega Enter.
echo   %D%Enter vazio = voltar. É criada uma pasta "NEXUS Monitor" lá dentro.%N%
set "ESCRITA="
set /p "ESCRITA=  %C%»%N% "
if not defined ESCRITA goto pasta
set "NOVA="
for /f "usebackq delims=" %%i in (`%PS% -Modo Validar -Destino "%ESCRITA%"`) do set "NOVA=%%i"
:validarPasta
if "%NOVA%"=="!" (
  echo.
  echo   %R%✗%N% Essa pasta não pode ser usada ^(pasta do Windows, raiz do sistema ou disco que não existe^).
  timeout /t 3 >NUL
  goto pasta
)
if defined NOVA set "DEST=%NOVA%"
goto pasta

rem ---- o que já existe neste PC (na pasta escolhida)
:detetar
set "SDEXE="
if exist "streamdeck\procurar_streamdeck.ps1" for /f "usebackq delims=" %%p in (`powershell -NoProfile -ExecutionPolicy Bypass -File "streamdeck\procurar_streamdeck.ps1"`) do set "SDEXE=%%p"
set "HASDECK="
if defined SDEXE if exist "streamdeck\NexusDeck.cs" set "HASDECK=1"
set "HASPM=" & set "HASGDU="
rem outras cópias do NEXUS neste PC (noutras pastas): o que descarregaram é aproveitado e no fim são apagadas
set "COPIAS=%TEMP%\nexus_copias.txt"
%PS% -Modo Antiga -Destino "%DEST%" -Origem "%HERE%" > "%COPIAS%" 2>NUL
set "OLD=" & set /a NOLD=0
for /f "usebackq delims=" %%o in ("%COPIAS%") do (
  if not defined OLD set "OLD=%%o"
  set /a NOLD+=1
  if exist "%%o\presentmon\PresentMon.exe" set "HASPM=1"
  if exist "%%o\gdu\gdu.exe" set "HASGDU=1"
)
if exist "%DEST%\presentmon\PresentMon.exe" set "HASPM=1"
if exist "%DEST%\gdu\gdu.exe" set "HASGDU=1"
set "JA="
if exist "%DEST%\NEXUS Monitor.exe" set "JA=1"
set "ADMIN="
net session >NUL 2>NUL && set "ADMIN=1"

rem plugin Stream Deck: assinatura dos ficheiros + pasta do NEXUS; igual à instalada = já está atualizado
set "PLUGSRC=%DEST%\streamdeck\com.nexus.monitor.sdPlugin"
set "PLUGDST=%APPDATA%\Elgato\StreamDeck\Plugins\com.nexus.monitor.sdPlugin"
set "PLUGSTATE=nenhum"
if defined HASDECK call :plugEstado "%HERE%"

if defined ARGS goto instalar

rem ================================================================ PERGUNTAS
cls
call :logo
if defined JA (
  echo   %B%Vai ser reinstalado o NEXUS Monitor %VER%%N%  %D%· as definições ficam%N%
) else (
  echo   %B%Vai ser instalado o NEXUS Monitor %VER%%N%
)
echo.
echo      Lê sozinho todas as temperaturas, ventoinhas e consumos.
echo      %D%Usa o driver PawnIO ^(assinado, open-source^) e pede administrador.%N%
echo      %Y%Alguns antivírus e anti-cheats de jogos podem dar aviso.%N%
echo      %D%Fica em: %DEST%%N%
echo      %D%Definições em: Documentos\NEXUS Monitor%N%
echo.
echo   %B%Atalhos%N%
echo.
choice /c SN /n /m "     Atalho no menu Iniciar? (S/N): "
if errorlevel 2 (set "SM=N") else (set "SM=S")
choice /c SN /n /m "     Atalho no ambiente de trabalho? (S/N): "
if errorlevel 2 (set "SD=N") else (set "SD=S")
echo.
echo   %B%Extras%N%  %D%(opcionais)%N%
echo.
if defined HASPM (
  echo      %G%✓%N% Intel PresentMon já está instalado  %D%· FPS e latência dos jogos%N%
  set "PM=S"
) else (
  echo      %C%Intel PresentMon%N%  %D%· FPS, frametime e latência dos jogos ^(~1 MB^)%N%
  choice /c SN /n /m "     Instalar? (S/N): "
)
if not defined HASPM if errorlevel 2 (set "PM=N") else (set "PM=S")
echo.
if defined HASGDU (
  echo      %G%✓%N% gdu já está instalado  %D%· motor do Deep Scan%N%
  set "GDU=S"
) else (
  echo      %C%gdu%N%  %D%· motor do Deep Scan, open-source ^(~6 MB^) - só corre quando pedes%N%
  choice /c SN /n /m "     Instalar? (S/N): "
)
if not defined HASGDU if errorlevel 2 (set "GDU=N") else (set "GDU=S")
echo.
set "DECK=N"
if "%PLUGSTATE%"=="ok" echo      %G%✓%N% Plugin Stream Deck já instalado e atualizado
if "%PLUGSTATE%"=="velho" (
  echo      %C%Plugin Stream Deck%N%  %D%· há uma versão nova ^(a Stream Deck reinicia^)%N%
  choice /c SN /n /m "     Atualizar? (S/N): "
)
if "%PLUGSTATE%"=="velho" if not errorlevel 2 set "DECK=S"
if defined HASDECK if "%PLUGSTATE%"=="nenhum" (
  echo      %C%Plugin Stream Deck%N%  %D%· estatísticas do PC nas teclas%N%
  choice /c SN /n /m "     Instalar? (S/N): "
)
if defined HASDECK if "%PLUGSTATE%"=="nenhum" if not errorlevel 2 set "DECK=S"
if not defined OLD goto resumo
echo.
echo      %Y%Outras cópias do NEXUS neste PC%N% %D%- vão ser apagadas no fim ^(fica só a da pasta escolhida^):%N%
for /f "usebackq delims=" %%o in ("%COPIAS%") do echo        %D%·%N% %%o
echo      %D%O que já tinham descarregado passa para a pasta nova. As definições ficam.%N%

:resumo
echo.
echo %HR%
if /i "%PM%"=="S" (set "TXT_PM=sim") else (set "TXT_PM=não")
if /i "%GDU%"=="S" (set "TXT_GDU=sim") else (set "TXT_GDU=não")
if /i "%DECK%"=="S" (set "TXT_DECK=sim") else (set "TXT_DECK=não")
if "%PLUGSTATE%"=="ok" set "TXT_DECK=já atualizado"
if /i "%SM%"=="S" (set "TXT_SM=sim") else (set "TXT_SM=não")
if /i "%SD%"=="S" (set "TXT_SD=sim") else (set "TXT_SD=não")
echo      Pasta: %C%%DEST%%N%
echo      Atalhos: menu Iniciar %B%%TXT_SM%%N%   ·   ambiente de trabalho %B%%TXT_SD%%N%
if defined HASDECK echo      PresentMon %B%%TXT_PM%%N%   ·   gdu %B%%TXT_GDU%%N%   ·   Stream Deck %B%%TXT_DECK%%N%
if not defined HASDECK echo      PresentMon %B%%TXT_PM%%N%   ·   gdu %B%%TXT_GDU%%N%
echo      %D%No fim, o instalador e os ficheiros extraídos são apagados ^(já não fazem falta^).%N%
echo %HR%
echo.
choice /c SN /n /m "  %C%»%N% Instalar agora? (S/N): "
if errorlevel 2 goto cancelado

rem ================================================================ INSTALAR
:instalar
if not defined DECK set "DECK=N"
if not defined PM set "PM=N"
if not defined GDU set "GDU=N"
if not defined RMOLD set "RMOLD=N"
if not defined SM set "SM=S"
if not defined SD set "SD=N"
if not defined HASDECK set "DECK=N"
if not defined ADMIN (
  echo.
  echo   %Y%!%N% No aviso do Windows carrega em %B%Sim%N%.
  > "%DESTF%" echo %DEST%
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -ArgumentList '2','%DECK%','%PM%','%GDU%','%RMOLD%','%SM%','%SD%' -Verb RunAs"
  exit /b 0
)
set /a TOTAL=6, I=0
if /i "%PM%"=="S" set /a TOTAL+=1
if /i "%GDU%"=="S" set /a TOTAL+=1
if /i "%DECK%"=="S" set /a TOTAL+=1

cls
call :logo
echo   %B%A instalar%N%
echo.

set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%CSC%" (
  echo   %R%✗%N% Não encontrei o .NET Framework 4 neste PC.
  goto erroFim
)

call :fecharNexus

rem ---- driver PawnIO
call :passo "Driver PawnIO"
call :temPawn && (call :ok "já instalado" & goto ficheiros)
where winget >NUL 2>NUL && winget install --id namazso.PawnIO -e --silent --accept-package-agreements --accept-source-agreements >NUL 2>NUL
call :temPawn && (call :ok "instalado" & goto ficheiros)
curl -L -s -o "%TEMP%\PawnIO_setup.exe" "https://github.com/namazso/PawnIO.Setup/releases/latest/download/PawnIO_setup.exe"
if exist "%TEMP%\PawnIO_setup.exe" "%TEMP%\PawnIO_setup.exe" -install -silent
del "%TEMP%\PawnIO_setup.exe" >NUL 2>NUL
call :temPawn && (call :ok "instalado") || call :falha "não consegui - o CPU pode ficar sem temperatura"

rem ---- ficheiros para a pasta do NEXUS (só o que mudou; o que está a mais sai)
:ficheiros
call :passo "Ficheiros"
mkdir "%DEST%" >NUL 2>NUL
rem o que a versão antiga já tinha descarregado passa para aqui (não volta a descarregar)
for /f "usebackq delims=" %%o in ("%COPIAS%") do for %%d in (lhm presentmon gdu) do if exist "%%o\%%d" if not exist "%DEST%\%%d" xcopy "%%o\%%d" "%DEST%\%%d\" /e /i /y /q >NUL
set "CP=0 0"
for /f "usebackq delims=" %%r in (`%PS% -Modo Copiar -Origem "%HERE%" -Destino "%DEST%"`) do set "CP=%%r"
call :tirarModulos
for /f "tokens=1,2" %%a in ("%CP%") do (set "NCOP=%%a" & set "NDEL=%%b")
if exist "%DEST%\NexusMonitor.cs" (call :ok "%NCOP% novos/atualizados, %NDEL% antigos removidos") else (call :falha "não consegui copiar para %DEST%" & goto erroFim)
cd /d "%DEST%"

rem ---- LibreHardwareMonitor
call :passo "LibreHardwareMonitor"
if exist "lhm\LibreHardwareMonitorLib.dll" (call :ok "já existe" & goto compilar)
set "LHMZIP=%TEMP%\nexus_lhm.zip"
del "%LHMZIP%" >NUL 2>NUL
curl -L -s -o "%LHMZIP%" "https://github.com/LibreHardwareMonitor/LibreHardwareMonitor/releases/download/v0.9.6/LibreHardwareMonitor.zip"
rmdir /s /q "%TEMP%\nexus_lhm" >NUL 2>NUL
if exist "%LHMZIP%" powershell -NoProfile -Command "Expand-Archive -LiteralPath '%LHMZIP%' -DestinationPath '%TEMP%\nexus_lhm' -Force" >NUL 2>NUL
del "%LHMZIP%" >NUL 2>NUL
set "LIBDIR="
for /f "delims=" %%F in ('dir /s /b "%TEMP%\nexus_lhm\LibreHardwareMonitorLib.dll" 2^>NUL') do if not defined LIBDIR set "LIBDIR=%%~dpF"
if defined LIBDIR (
  mkdir "lhm" >NUL 2>NUL
  copy /y "%LIBDIR%*.dll" "lhm\" >NUL
)
rmdir /s /q "%TEMP%\nexus_lhm" >NUL 2>NUL
if exist "lhm\LibreHardwareMonitorLib.dll" (call :ok "descarregado") else (call :falha "falhou o download - sem internet? volta a correr o instalador")

rem ---- NEXUS Monitor.exe
:compilar
call :passo "NEXUS Monitor"
call :compilarNexus || goto erroFim
call :ok "criado"

rem ---- Intel PresentMon
if /i not "%PM%"=="S" goto gdu
call :passo "Intel PresentMon"
if exist "presentmon\PresentMon.exe" (call :ok "já existe" & goto gdu)
mkdir "presentmon" >NUL 2>NUL
powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol='Tls12'; $h=@{'User-Agent'='NEXUS-Monitor'}; $rs=Invoke-RestMethod -UseBasicParsing -Headers $h 'https://api.github.com/repos/GameTechDev/PresentMon/releases?per_page=30'; $a=$null; foreach($r in $rs){ if($r.prerelease){continue}; $a=$r.assets | Where-Object { $_.name -match '^PresentMon-[0-9.]+-x64\.exe$' } | Select-Object -First 1; if($a){break} }; if(-not $a){ exit 2 }; Invoke-WebRequest -UseBasicParsing -Headers $h $a.browser_download_url -OutFile '%DEST%\presentmon\PresentMon.exe'" >NUL 2>NUL
if exist "presentmon\PresentMon.exe" (call :ok "descarregado") else (call :falha "não consegui descarregar")

rem ---- gdu (motor do Deep Scan, open-source MIT)
:gdu
if /i not "%GDU%"=="S" goto deck
call :passo "gdu"
if exist "gdu\gdu.exe" (call :ok "já existe" & goto deck)
mkdir "gdu" >NUL 2>NUL
del "%TEMP%\nexus_gdu.zip" >NUL 2>NUL
curl -L -s -o "%TEMP%\nexus_gdu.zip" "https://github.com/dundee/gdu/releases/latest/download/gdu_windows_amd64.exe.zip"
if exist "%TEMP%\nexus_gdu.zip" powershell -NoProfile -Command "Expand-Archive -LiteralPath '%TEMP%\nexus_gdu.zip' -DestinationPath '%DEST%\gdu' -Force; Get-ChildItem -LiteralPath '%DEST%\gdu' -Filter 'gdu*.exe' | Where-Object { $_.Name -ne 'gdu.exe' } | Select-Object -First 1 | Move-Item -Destination '%DEST%\gdu\gdu.exe' -Force" >NUL 2>NUL
del "%TEMP%\nexus_gdu.zip" >NUL 2>NUL
if exist "gdu\gdu.exe" (call :ok "descarregado") else (call :falha "não consegui descarregar - dá para descarregar depois no Deep Scan")

rem ---- plugin Stream Deck (só se for novo ou mudou - senão não mexe na Stream Deck)
:deck
if /i not "%DECK%"=="S" goto atalhos
call :passo "Plugin Stream Deck"
call :instalarPlugin
if "%PLUGRES%"=="ok" call :ok "já atualizado"
if "%PLUGRES%"=="novo" call :ok "instalado"
if "%PLUGRES%"=="erro" call :falha "erro ao criar - vê o erro_deck.txt"

rem ---- menu Iniciar e lista de aplicações do Windows
:atalhos
call :passo "Atalhos"
call :registar
set "TXT_AT=Aplicações do Windows"
if /i "%SM%"=="S" set "TXT_AT=%TXT_AT%, menu Iniciar"
if /i "%SD%"=="S" set "TXT_AT=%TXT_AT%, ambiente de trabalho"
call :ok "%TXT_AT%"

rem ---- versão antiga e ficheiros do instalador
call :passo "Limpeza"
set "TXTL=ficheiros do instalador apagados ao fechar"
if defined OLD (
  set "RES=0 0"
  for /f "usebackq delims=" %%r in (`%PS% -Modo ApagarOutras -Destino "%DEST%" -Origem "%HERE%"`) do set "RES=%%r"
)
if defined OLD for /f "tokens=1,2" %%a in ("%RES%") do (
  if "%%b"=="0" (set "TXTL=%%a outra^(s^) cópia^(s^) do NEXUS e ficheiros do instalador apagados") else (set "TXTL=%%a cópia^(s^) apagada^(s^), %%b não deu ^(ficheiro em uso?^)")
)
del "%COPIAS%" >NUL 2>NUL
call :ok "%TXTL%"

rem ================================================================ FIM
echo.
echo %HR%
echo   %G%%B%✓ Pronto!%N%  NEXUS Monitor %VER% instalado.
echo.
echo   %D%·%N% Fica junto ao relógio %D%(ícones ocultos ^^)%N% e no menu Iniciar.
echo   %D%·%N% Opções, temas, línguas, Deep Scan e telemóvel no topo da página.
if /i "%DECK%"=="S" if "%PLUGRES%"=="novo" echo   %D%·%N% Stream Deck: procura a categoria %C%NEXUS Monitor%N%.
echo   %D%·%N% Para atualizar no futuro usa o %C%ATUALIZAR NEXUS.bat%N% das versões novas.
echo %HR%
echo.
start "" "%DEST%\NEXUS Monitor.exe"
echo   %D%A abrir o NEXUS... esta janela fecha-se e apaga os ficheiros do instalador.%N%
timeout /t 8 >NUL
goto autoApagar

:erroFim
echo.
pause
exit /b 1

:cancelado
echo.
echo   %D%Cancelado - nada foi alterado.%N%
timeout /t 3 >NUL
exit /b 0

:naoextraido
cls
echo.
echo   [!] Faltam ficheiros nesta pasta.
echo.
echo   Abriste este ficheiro de dentro do zip?
echo     1. Fecha esta janela.
echo     2. Botão direito no zip ^> "Extrair tudo..." ^> Extrair.
echo     3. Abre a pasta extraída e corre o INSTALAR NEXUS.bat de lá.
echo.
echo   Se já extraíste: o antivírus pode ter apagado o NexusMonitor.cs.
echo.
pause
exit /b 1

rem ================================================================ FUNÇÕES
:logo
echo.
echo   %C%███╗   ██╗███████╗██╗  ██╗██╗   ██╗███████╗%N%
echo   %C%████╗  ██║██╔════╝╚██╗██╔╝██║   ██║██╔════╝%N%
echo   %C%██╔██╗ ██║█████╗   ╚███╔╝ ██║   ██║███████╗%N%
echo   %M%██║╚██╗██║██╔══╝   ██╔██╗ ██║   ██║╚════██║%N%
echo   %M%██║ ╚████║███████╗██╔╝ ██╗╚██████╔╝███████║%N%
echo   %M%╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝%N%  %D%MONITOR %VER%%N%
echo.
exit /b 0

rem escreve "[n/total] Nome  " sem mudar de linha; :ok / :falha acabam a linha
:passo
set /a I+=1
set "PNOME=%~1                         "
<NUL set /p "=%N%   %D%[%I%/%TOTAL%]%N%  %PNOME:~0,24%"
exit /b 0

:ok
echo %G%✓%N% %D%%~1%N%
exit /b 0

:falha
echo %R%✗%N% %~1
exit /b 0

rem ---- módulos que este PC não tem (Stream Deck / SignalRGB): os ficheiros deles saem da pasta do NEXUS
:tirarModulos
set "TEMSD="
if defined SDEXE set "TEMSD=1"
if exist "%APPDATA%\Elgato\StreamDeck" set "TEMSD=1"
if not defined TEMSD rmdir /s /q "%DEST%\streamdeck" >NUL 2>NUL
if not defined TEMSD del "%DEST%\INSTALAR ADDON STREAM DECK.bat" >NUL 2>NUL
set "TEMSR="
if exist "%LOCALAPPDATA%\VortxEngine" set "TEMSR=1"
if exist "%LOCALAPPDATA%\WhirlwindFX\SignalRgb" set "TEMSR=1"
if not defined TEMSR for /f "usebackq delims=" %%d in (`powershell -NoProfile -Command "[Environment]::GetFolderPath('MyDocuments')"`) do del "%%d\WhirlwindFX\Plugins\NEXUS_Monitor.js" >NUL 2>NUL
exit /b 0

rem cria o NEXUS Monitor.exe na pasta do NEXUS
:compilarNexus
pushd "%DEST%"
del "NEXUS Monitor.exe" >NUL 2>NUL
"%CSC%" /nologo /codepage:65001 /target:winexe /optimize+ /out:"NEXUS Monitor.exe" /win32icon:nexus.ico /resource:index.html,index.html /resource:disk.html,disk.html /resource:pad.html,pad.html /resource:perf.html,perf.html /resource:i18n.js,i18n.js /r:System.Management.dll /r:System.Windows.Forms.dll /r:System.Drawing.dll /r:System.Core.dll /r:System.ServiceProcess.dll /r:Microsoft.VisualBasic.dll NexusMonitor.cs codigo\*.cs > erro.txt 2>&1
if not exist "NEXUS Monitor.exe" (
  call :falha "erro ao criar o programa"
  echo.
  type erro.txt
  echo.
  echo   %D%Envia o ficheiro erro.txt ^(%DEST%^) a quem te deu o NEXUS.%N%
  popd
  exit /b 1
)
del erro.txt >NUL 2>NUL
> "versao.txt" echo %VER%
popd
exit /b 0

rem PLUGSTATE = nenhum / velho / ok, comparando a assinatura com a do plugin instalado
rem %1 = pasta de onde vêm os ficheiros do plugin (a extraída, antes de copiar; ou a do NEXUS)
:plugEstado
set "PLUGHASH="
for /f "usebackq delims=" %%h in (`powershell -NoProfile -Command "((Get-FileHash -Algorithm SHA256 -LiteralPath '%~1\streamdeck\NexusDeck.cs','%~1\streamdeck\com.nexus.monitor.sdPlugin\pi.html','%~1\streamdeck\com.nexus.monitor.sdPlugin\manifest.json' | ForEach-Object Hash) -join '').Substring(0,40)"`) do set "PLUGHASH=%%h"
set "PLUGHASH=%PLUGHASH%@%DEST%\"
set "PLUGSTATE=nenhum"
if not exist "%PLUGDST%\NexusDeck.exe" exit /b 0
set "PLUGSTATE=velho"
set "OLDHASH="
if exist "%PLUGDST%\nexus_build.txt" set /p OLDHASH=<"%PLUGDST%\nexus_build.txt"
if "%OLDHASH%"=="%PLUGHASH%" set "PLUGSTATE=ok"
exit /b 0

rem PLUGRES = ok (já estava) / novo / erro
:instalarPlugin
call :plugEstado "%DEST%"
set "PLUGRES=ok"
if "%PLUGSTATE%"=="ok" exit /b 0
"%CSC%" /nologo /codepage:65001 /target:winexe /optimize+ /out:"%PLUGSRC%\NexusDeck.exe" /r:System.Drawing.dll /r:System.Web.Extensions.dll /r:System.Core.dll "%DEST%\streamdeck\NexusDeck.cs" > "%DEST%\erro_deck.txt" 2>&1
if not exist "%PLUGSRC%\NexusDeck.exe" (set "PLUGRES=erro" & exit /b 0)
del "%DEST%\erro_deck.txt" >NUL 2>NUL
> "%PLUGSRC%\nexus_path.txt" echo %DEST%\NEXUS Monitor.exe
> "%PLUGSRC%\nexus_build.txt" echo %PLUGHASH%
taskkill /im "StreamDeck.exe" /f >NUL 2>NUL
taskkill /im "NexusDeck.exe" /f >NUL 2>NUL
timeout /t 2 /nobreak >NUL
if exist "%PLUGDST%" rmdir /s /q "%PLUGDST%" >NUL 2>NUL
xcopy "%PLUGSRC%" "%PLUGDST%\" /e /i /y /q >NUL
rem reabre a Stream Deck sem administrador
if defined SDEXE explorer.exe "%SDEXE%"
if exist "%PLUGDST%\NexusDeck.exe" (set "PLUGRES=novo") else (set "PLUGRES=erro")
exit /b 0

rem atalho no menu Iniciar + entrada em Definições > Aplicações (com o desinstalador)
:registar
set "UK=HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\NEXUS Monitor"
reg add "%UK%" /v DisplayName /d "NEXUS Monitor" /f >NUL
reg add "%UK%" /v DisplayVersion /d "%VER%" /f >NUL
reg add "%UK%" /v Publisher /d "NEXUS" /f >NUL
reg add "%UK%" /v DisplayIcon /d "%DEST%\NEXUS Monitor.exe" /f >NUL
reg add "%UK%" /v InstallLocation /d "%DEST%" /f >NUL
reg add "%UK%" /v UninstallString /d "cmd.exe /c \"\"%DEST%\DESINSTALAR NEXUS.bat\"\"" /f >NUL
reg add "%UK%" /v NoModify /t REG_DWORD /d 1 /f >NUL
reg add "%UK%" /v NoRepair /t REG_DWORD /d 1 /f >NUL
if /i "%SM%"=="S" (
  powershell -NoProfile -Command "$p=[Environment]::GetFolderPath('Programs')+'\NEXUS Monitor.lnk'; $s=(New-Object -ComObject WScript.Shell).CreateShortcut($p); $s.TargetPath='%DEST%\NEXUS Monitor.exe'; $s.WorkingDirectory='%DEST%'; $s.IconLocation='%DEST%\NEXUS Monitor.exe,0'; $s.Description='NEXUS Monitor'; $s.Save()" >NUL 2>NUL
) else (
  powershell -NoProfile -Command "Remove-Item -LiteralPath ([Environment]::GetFolderPath('Programs')+'\NEXUS Monitor.lnk') -Force -ErrorAction SilentlyContinue" >NUL 2>NUL
)
if /i "%SD%"=="S" (
  powershell -NoProfile -Command "$p=[Environment]::GetFolderPath('Desktop')+'\NEXUS Monitor.lnk'; $s=(New-Object -ComObject WScript.Shell).CreateShortcut($p); $s.TargetPath='%DEST%\NEXUS Monitor.exe'; $s.WorkingDirectory='%DEST%'; $s.IconLocation='%DEST%\NEXUS Monitor.exe,0'; $s.Description='NEXUS Monitor'; $s.Save()" >NUL 2>NUL
) else (
  powershell -NoProfile -Command "Remove-Item -LiteralPath ([Environment]::GetFolderPath('Desktop')+'\NEXUS Monitor.lnk') -Force -ErrorAction SilentlyContinue" >NUL 2>NUL
)
exit /b 0

rem fecha o NEXUS com calma (retoma apps em pausa) e só depois à força
:fecharNexus
tasklist /fi "imagename eq NEXUS Monitor.exe" 2>NUL | find /i "NEXUS Monitor.exe" >NUL || exit /b 0
curl -s -m 3 -X POST http://127.0.0.1:8765/api/shutdown >NUL 2>NUL
timeout /t 2 /nobreak >NUL
taskkill /im "NEXUS Monitor.exe" /f >NUL 2>NUL
taskkill /im "PresentMon.exe" /f >NUL 2>NUL
timeout /t 1 /nobreak >NUL
exit /b 0

:temPawn
powershell -NoProfile -Command "if (Get-ItemProperty 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*','HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*' -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -like 'PawnIO*' }) { exit 0 } else { exit 1 }" >NUL 2>NUL
exit /b %errorlevel%

rem apaga os ficheiros extraídos do zip (e este .bat) depois de a janela fechar
:autoApagar
set "RM=%TEMP%\nexus_limpar.bat"
> "%RM%" echo @echo off
>>"%RM%" echo timeout /t 2 /nobreak ^>NUL
>>"%RM%" echo powershell -NoProfile -ExecutionPolicy Bypass -File "%TEMP%\nexus_limpar.ps1" -Modo Limpar -Origem "%HERE%" ^>NUL 2^>NUL
>>"%RM%" echo del "%TEMP%\nexus_limpar.ps1" ^>NUL 2^>NUL
>>"%RM%" echo (goto) 2^>NUL ^& del "%%~f0"
copy /y "%HERE%\nexus_ficheiros.ps1" "%TEMP%\nexus_limpar.ps1" >NUL
cd /d "%TEMP%"
start "" /min cmd /c ""%RM%""
exit
