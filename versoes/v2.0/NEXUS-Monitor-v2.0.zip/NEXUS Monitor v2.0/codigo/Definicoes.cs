﻿// NEXUS // MONITOR - definições guardadas, traduções, módulos opcionais (SignalRGB / Stream Deck) e abrir o Explorador à frente
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Linq;
using System.Management;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Reflection;
using System.Security.Principal;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Win32;

namespace Nexus
{

    // ---------------------------------------------------------------- opções de arranque
    static class AppSettings
    {
        public static bool AutoStart, Minimized, NoPrompt;
        public static bool Alerts = true;
        public static bool Remote;
        public static string Token = "";

        public static bool TokenMatches(string t)
        {
            if (string.IsNullOrEmpty(Token) || t == null || t.Length != Token.Length) return false;
            int diff = 0;
            for (int i = 0; i < t.Length; i++) diff |= t[i] ^ Token[i];
            return diff == 0;
        }

        static string NewToken()
        {
            const string A = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
            byte[] r = new byte[16];
            using (System.Security.Cryptography.RNGCryptoServiceProvider rng = new System.Security.Cryptography.RNGCryptoServiceProvider()) rng.GetBytes(r);
            return new string(r.Select(x => A[x % A.Length]).ToArray());
        }

        public static string LanIp()
        {
            try
            {
                foreach (NetworkInterface ni in NetworkInterface.GetAllNetworkInterfaces())
                {
                    if (ni.OperationalStatus != OperationalStatus.Up || ni.NetworkInterfaceType == NetworkInterfaceType.Loopback) continue;
                    IPInterfaceProperties ipp = ni.GetIPProperties();
                    if (!ipp.GatewayAddresses.Any(g => g.Address.AddressFamily == AddressFamily.InterNetwork && !g.Address.Equals(IPAddress.Any))) continue;
                    foreach (UnicastIPAddressInformation ua in ipp.UnicastAddresses)
                        if (ua.Address.AddressFamily == AddressFamily.InterNetwork && !IPAddress.IsLoopback(ua.Address)) return ua.Address.ToString();
                }
            }
            catch { }
            return null;
        }

        public static string RemoteUrl()
        {
            string ip = LanIp();
            return ip == null ? null : "http://" + ip + ":" + Program.PortNumber + "/?k=" + Token;
        }

        // regra da firewall do Windows para a porta do NEXUS (redes privadas)
        static string SetFirewall(bool on)
        {
            string del = "advfirewall firewall delete rule name=\"NEXUS Monitor\"";
            string add = "advfirewall firewall add rule name=\"NEXUS Monitor\" dir=in action=allow protocol=TCP localport=" + Program.PortNumber + " profile=private,domain";
            if (Program.IsAdmin())
            {
                RunHidden("netsh.exe", del);
                if (on && RunHidden("netsh.exe", add) != 0) return "Não consegui criar a regra da firewall.";
                return null;
            }
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo("cmd.exe", "/c netsh " + del + (on ? " & netsh " + add : ""));
                psi.Verb = "runas"; psi.UseShellExecute = true; psi.WindowStyle = ProcessWindowStyle.Hidden;
                using (Process p = Process.Start(psi)) p.WaitForExit(15000);
                return null;
            }
            catch { return on ? "Sem permissão para abrir a firewall - aceita o aviso do Windows." : null; }
        }
        static readonly string[] ThemeKeys = { "bg", "panel", "txt", "dim", "c1", "c2", "warn", "ok", "crit" };
        static Dictionary<string, string> theme = new Dictionary<string, string> {
            {"bg","05070d"},{"panel","0c1322"},{"txt","d4e8ff"},{"dim","5f7896"},{"c1","3ee8ff"},
            {"c2","ff3ec8"},{"warn","ffb23e"},{"ok","9dff5c"},{"crit","ff4e6a"} };

        // cor do tema; com o SignalRGB ligado e a enviar, c1/c2 seguem as cores dele
        public static Color ThemeColor(string k)
        {
            if (RgbSync && (k == "c1" || k == "c2")) { string o = global::Nexus.RgbSync.Override(k); if (o != null) return ColorTranslator.FromHtml("#" + o); }
            return BaseColor(k);
        }
        public static Color BaseColor(string k)
        {
            string h;
            lock (theme) { if (!theme.TryGetValue(k, out h)) h = "3ee8ff"; }
            return ColorTranslator.FromHtml("#" + h);
        }

        public static string ThemeJson()
        {
            string o1 = RgbSync ? global::Nexus.RgbSync.Override("c1") : null, o2 = o1 == null ? null : global::Nexus.RgbSync.Override("c2");
            lock (theme)
                return "{" + string.Join(",", ThemeKeys.Select(k => "\"" + k + "\":\"#" + (k == "c1" && o1 != null ? o1 : k == "c2" && o2 != null ? o2 : theme[k]) + "\"").ToArray()) + "}";
        }

        static bool IsHex(string v) { return v != null && v.Length == 6 && v.All(ch => Uri.IsHexDigit(ch)); }

        public static void SetTheme(string path)
        {
            int qi = path.IndexOf('?');
            if (qi < 0) return;
            bool changed = false;
            lock (theme)
            {
                foreach (string part in path.Substring(qi + 1).Split('&'))
                {
                    string[] kv = part.Split('=');
                    if (kv.Length == 2 && ThemeKeys.Contains(kv[0]))
                    {
                        string v = kv[1].TrimStart('#').Replace("%23", "").ToLowerInvariant();
                        if (IsHex(v) && theme[kv[0]] != v) { theme[kv[0]] = v; changed = true; }
                    }
                }
            }
            if (changed) { try { Save(); } catch { } }
        }
        // definições da página (tema, privacidade, velocidade...) partilhadas entre o PC e o telemóvel
        static string ui = null;
        static int uiVer = 1;
        public static int UiVersion { get { return uiVer; } }
        public static string UiJson()
        {
            string d = ui;
            return "{\"ver\":" + uiVer + ",\"data\":" + (d ?? "null") + "}";
        }
        public static void SetUi(string d)
        {
            if (d == null) return;
            d = d.Trim();
            if (d.Length < 2 || d.Length > 6000 || d[0] != '{' || d[d.Length - 1] != '}') return;
            if (d.IndexOf('<') >= 0 || d.Any(ch => ch < ' ')) return;
            if (d == ui) return;
            ui = d;
            System.Threading.Interlocked.Increment(ref uiVer);
            try { Save(); } catch { }
        }

        // os mesmos temas da página (chave, nome, bg, panel, txt, dim, c1, c2, warn, ok, crit)
        public static readonly string[][] Themes = {
            new[] { "nexus", "Nexus", "05070d", "0c1322", "d4e8ff", "5f7896", "3ee8ff", "ff3ec8", "ffb23e", "9dff5c", "ff4e6a" },
            new[] { "synth", "Synthwave", "0d0518", "1a0c2c", "f3dcff", "8a6aa8", "ff4fd8", "7b5cff", "ffcc33", "4dffd2", "ff3b5c" },
            new[] { "matrix", "Matrix", "020804", "07160c", "c8ffd4", "4f8a5e", "39ff6a", "b6ff3b", "e6ff3b", "39ff6a", "ff5a4e" },
            new[] { "inferno", "Inferno", "0c0505", "1a0b0a", "ffe3d6", "9a6a5e", "ff5a2e", "ffb02e", "ffd23e", "ffe08a", "ff2e4d" },
            new[] { "ice", "Glaciar", "060b12", "0e1824", "e6f4ff", "6d8aa6", "8fd8ff", "c4b5ff", "ffd27a", "7dffcf", "ff6b8a" },
            new[] { "amber", "Retro Âmbar", "0a0700", "161004", "ffdca3", "8f7344", "ffb000", "ff7a00", "ffd166", "ffc94d", "ff5530" },
            new[] { "mono", "Grafite", "0b0b0c", "161618", "ececec", "7a7a80", "ffffff", "9a9aa2", "e8c26a", "b8e0b0", "ff6b6b" },
            new[] { "light", "Claro", "eef2f7", "ffffff", "13202e", "6a7b8e", "0077ff", "d6338a", "d98200", "139a52", "d92644" } };

        public static string UiTheme()
        {
            string d = ui;
            if (d == null) return "nexus";
            System.Text.RegularExpressions.Match m = System.Text.RegularExpressions.Regex.Match(d, "\"theme\":\"([a-z]+)\"");
            return m.Success ? m.Groups[1].Value : "nexus";
        }

        // escolher um tema no menu do ícone: muda as cores aqui e avisa as páginas abertas (sincronização)
        public static void ApplyNamedTheme(string key)
        {
            string[] t = Themes.FirstOrDefault(x => x[0] == key);
            if (t == null) return;
            lock (theme) for (int i = 0; i < ThemeKeys.Length; i++) theme[ThemeKeys[i]] = t[i + 2];
            string d = ui ?? "{}";
            if (System.Text.RegularExpressions.Regex.IsMatch(d, "\"theme\":\"[a-z]*\""))
                d = System.Text.RegularExpressions.Regex.Replace(d, "\"theme\":\"[a-z]*\"", "\"theme\":\"" + key + "\"");
            else d = d.Length > 2 ? "{\"theme\":\"" + key + "\"," + d.Substring(1) : "{\"theme\":\"" + key + "\"}";
            ui = d;
            System.Threading.Interlocked.Increment(ref uiVer);
            try { Save(); } catch { }
        }

        public static int AlertCpu = 90, AlertGpu = 85, AlertRam = 90, AlertSecs = 20, AlertSecsGame = 12;   // tempo do alerta no ecrã: fora de jogo / em jogo
        public static bool RgbSync = false;
        public static int RgbDelay = 150;          // atraso/suavidade das cores do SignalRGB (ms)
        // overlay em jogo (tipo Alt+R da NVIDIA)
        public static bool OverlayOn, OverlayGameOnly = true;
        public static string OverlayItems = "fps,ft,cpu,cput,gpu,gput,ram", OverlayStyle = "col", OverlayKey = "alt+shift+o";
        public static int OverlayX = 0, OverlayY = 0, OverlayScale = 100, OverlayOp = 85;
        public static string UiMode = "";          // "" = ainda não escolheu (pergunta no primeiro arranque), "simple" ou "full"
        public static bool TurboPrio, TurboPower, TurboRam;   // turbo ao jogar (página Performance)
        public static bool TutorialDone;           // o tutorial já foi visto (volta a false quando se pede para o ver outra vez)
        public static string NewsSeen = "";        // última versão cujas novidades já foram abertas
        public static int AlertOp = 97, AlertOpGame = 55;                     // opacidade do alerta (%): fora de jogo / em jogo
        public static bool RamClean, GameMode, ShowHidden;
        public static string Lang = "";   // "" = automático (idioma do Windows)
        public static int RamCleanPct = 85, RamCleanMin = 5;
        public static string[] GameApps = new string[0], GameSkip = new string[0];

        static string[] CleanApps(string v)
        {
            return (v ?? "").Split(',').Select(x => x.Trim()).Select(x => x.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) ? x.Substring(0, x.Length - 4) : x)
                .Where(x => x.Length > 0 && x.Length <= 80 && x.All(ch => char.IsLetterOrDigit(ch) || " ._-+()&".IndexOf(ch) >= 0))
                .Distinct(StringComparer.OrdinalIgnoreCase).Take(80).ToArray();
        }
        const string TASK = "NEXUS Monitor";
        const string RUNKEY = @"Software\Microsoft\Windows\CurrentVersion\Run";
        // Definições (incluindo a chave do telemóvel) nos Documentos: sobrevivem a reinstalar e atualizar.
        // O que é só do momento (open.flag, processos em pausa) fica no AppData.
        public static readonly string Dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "NEXUS Monitor");
        static readonly string OldDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "NEXUS");
        static string FilePath { get { return Path.Combine(Dir, "settings.ini"); } }
        static string FlagPath { get { return Path.Combine(OldDir, "open.flag"); } }

        // versões antigas guardavam em AppData\Local\NEXUS: traz as definições (e a chave) para os Documentos
        static void Migrate()
        {
            try
            {
                string old = Path.Combine(OldDir, "settings.ini");
                if (File.Exists(FilePath) || !File.Exists(old)) return;
                Directory.CreateDirectory(Dir);
                File.Copy(old, FilePath);
                File.Delete(old);
            }
            catch { }
        }

        public static void Load()
        {
            Migrate();
            try
            {
                if (!File.Exists(FilePath)) return;
                foreach (string line in File.ReadAllLines(FilePath))
                {
                    string[] kv = line.Split(new[] { '=' }, 2);
                    if (kv.Length != 2) continue;
                    bool v = kv[1].Trim() == "1";
                    int iv; int.TryParse(kv[1].Trim(), out iv);
                    switch (kv[0].Trim())
                    {
                        case "autostart": AutoStart = v; break;
                        case "minimized": Minimized = v; break;
                        case "noprompt": NoPrompt = v; break;
                        case "alerts": Alerts = v; break;
                        case "rgbsync": RgbSync = v; break;
                        case "rgbdelay": if (iv >= 0 && iv <= 1000) RgbDelay = iv; break;
                        case "alert_cpu": if (iv > 0) AlertCpu = iv; break;
                        case "alert_gpu": if (iv > 0) AlertGpu = iv; break;
                        case "alert_ram": if (iv > 0) AlertRam = iv; break;
                        case "alert_secs": if (iv >= 3 && iv <= 300) AlertSecs = iv; break;
                        case "alert_secs_game": if (iv >= 3 && iv <= 300) AlertSecsGame = iv; break;
                        case "alert_op": if (iv >= 15 && iv <= 100) AlertOp = iv; break;
                        case "alert_op_game": if (iv >= 15 && iv <= 100) AlertOpGame = iv; break;
                        case "remote": Remote = v; break;
                        case "token": Token = kv[1].Trim(); break;
                        case "ramclean": RamClean = v; break;
                        case "ramclean_pct": if (iv >= 30 && iv <= 98) RamCleanPct = iv; break;
                        case "ramclean_min": if (iv >= 1 && iv <= 120) RamCleanMin = iv; break;
                        case "gamemode": GameMode = v; break;
                        case "showhidden": ShowHidden = v; break;
                        case "lang": Lang = global::Nexus.Lang.Pick(kv[1].Trim()); break;
                        case "tutorial": TutorialDone = v; break;
                        case "overlay": OverlayOn = v; break;
                        case "ov_gameonly": OverlayGameOnly = v; break;
                        case "ov_items": OverlayItems = kv[1].Trim(); break;
                        case "ov_style": OverlayStyle = kv[1].Trim() == "row" ? "row" : "col"; break;
                        case "ov_key": OverlayKey = kv[1].Trim().ToLowerInvariant(); break;
                        case "ov_x": OverlayX = Math.Max(0, Math.Min(1000, iv)); break;
                        case "ov_y": OverlayY = Math.Max(0, Math.Min(1000, iv)); break;
                        case "ov_scale": if (iv >= 60) OverlayScale = Math.Min(220, iv); break;
                        case "ov_op": if (iv >= 15) OverlayOp = Math.Min(100, iv); break;
                        case "uimode": UiMode = kv[1] == "simple" || kv[1] == "full" ? kv[1] : ""; break;
                        case "turbo_prio": TurboPrio = v; break;
                        case "turbo_power": TurboPower = v; break;
                        case "turbo_ram": TurboRam = v; break;
                        case "newsseen": NewsSeen = CleanVer(kv[1]); break;
                        case "gameapps": GameApps = CleanApps(kv[1]); break;
                        case "gameskip": GameSkip = CleanApps(kv[1]); break;
                        case "ui":
                            try { ui = Encoding.UTF8.GetString(Convert.FromBase64String(kv[1].Trim())); } catch { ui = null; }
                            if (string.IsNullOrEmpty(ui) || ui[0] != '{') ui = null;
                            break;
                        case "theme":
                            string[] cols = kv[1].Trim().Split(',');
                            if (cols.Length == ThemeKeys.Length && cols.All(IsHex))
                                lock (theme) for (int ti = 0; ti < cols.Length; ti++) theme[ThemeKeys[ti]] = cols[ti];
                            break;
                    }
                }
            }
            catch { }
        }

        public static void Save()
        {
            Directory.CreateDirectory(Dir);
            File.WriteAllLines(FilePath, new[] {
                "autostart=" + (AutoStart ? "1" : "0"),
                "minimized=" + (Minimized ? "1" : "0"),
                "noprompt=" + (NoPrompt ? "1" : "0"),
                "alerts=" + (Alerts ? "1" : "0"), "rgbsync=" + (RgbSync ? "1" : "0"), "rgbdelay=" + RgbDelay,
                "alert_cpu=" + AlertCpu, "alert_gpu=" + AlertGpu, "alert_ram=" + AlertRam, "alert_secs=" + AlertSecs, "alert_secs_game=" + AlertSecsGame, "alert_op=" + AlertOp, "alert_op_game=" + AlertOpGame,
                "theme=" + ThemeLine(),
                "remote=" + (Remote ? "1" : "0"), "token=" + Token,
                "ramclean=" + (RamClean ? "1" : "0"), "ramclean_pct=" + RamCleanPct, "ramclean_min=" + RamCleanMin,
                "gamemode=" + (GameMode ? "1" : "0"), "showhidden=" + (ShowHidden ? "1" : "0"), "lang=" + Lang, "tutorial=" + (TutorialDone ? "1" : "0"), "uimode=" + UiMode, "overlay=" + (OverlayOn ? "1" : "0"), "ov_gameonly=" + (OverlayGameOnly ? "1" : "0"), "ov_items=" + OverlayItems, "ov_style=" + OverlayStyle, "ov_key=" + OverlayKey,
                "ov_x=" + OverlayX, "ov_y=" + OverlayY, "ov_scale=" + OverlayScale, "ov_op=" + OverlayOp, "turbo_prio=" + (TurboPrio ? "1" : "0"), "turbo_power=" + (TurboPower ? "1" : "0"), "turbo_ram=" + (TurboRam ? "1" : "0"), "newsseen=" + NewsSeen, "gameapps=" + string.Join(",", GameApps), "gameskip=" + string.Join(",", GameSkip),
                "ui=" + (ui == null ? "" : Convert.ToBase64String(Encoding.UTF8.GetBytes(ui))) });
        }

        static string ThemeLine() { lock (theme) return string.Join(",", ThemeKeys.Select(k => theme[k]).ToArray()); }

        public static void RequestBrowser()
        {
            try { Directory.CreateDirectory(OldDir); File.WriteAllText(FlagPath, "1"); } catch { }
        }

        public static bool ConsumeBrowserRequest()
        {
            try { if (File.Exists(FlagPath)) { File.Delete(FlagPath); return true; } } catch { }
            return false;
        }

        static int RunHidden(string exe, string args)
        {
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo(exe, args);
                psi.UseShellExecute = false;
                psi.CreateNoWindow = true;
                psi.RedirectStandardOutput = true;
                psi.RedirectStandardError = true;
                using (Process p = Process.Start(psi))
                {
                    p.StandardOutput.ReadToEnd();
                    p.StandardError.ReadToEnd();
                    p.WaitForExit(15000);
                    return p.ExitCode;
                }
            }
            catch { return -1; }
        }

        public static bool TaskExists() { return RunHidden("schtasks.exe", "/query /tn \"" + TASK + "\"") == 0; }
        public static bool RunTask() { return RunHidden("schtasks.exe", "/run /tn \"" + TASK + "\"") == 0; }

        static string X(string s) { return System.Security.SecurityElement.Escape(s); }

        static bool CreateTask(bool atLogon)
        {
            string user = WindowsIdentity.GetCurrent().Name;
            string exe = Application.ExecutablePath;
            string xml =
                "<?xml version=\"1.0\" encoding=\"UTF-16\"?>\r\n" +
                "<Task version=\"1.2\" xmlns=\"http://schemas.microsoft.com/windows/2004/02/mit/task\">\r\n" +
                "  <RegistrationInfo><Description>NEXUS Monitor - abre como administrador sem aviso</Description></RegistrationInfo>\r\n" +
                (atLogon ? "  <Triggers><LogonTrigger><Enabled>true</Enabled><UserId>" + X(user) + "</UserId><Delay>PT8S</Delay></LogonTrigger></Triggers>\r\n" : "") +
                "  <Principals><Principal id=\"Author\"><UserId>" + X(user) + "</UserId><LogonType>InteractiveToken</LogonType><RunLevel>HighestAvailable</RunLevel></Principal></Principals>\r\n" +
                "  <Settings><MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy><DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>" +
                "<StopIfGoingOnBatteries>false</StopIfGoingOnBatteries><AllowHardTerminate>true</AllowHardTerminate><StartWhenAvailable>false</StartWhenAvailable>" +
                "<AllowStartOnDemand>true</AllowStartOnDemand><Enabled>true</Enabled><Hidden>false</Hidden><ExecutionTimeLimit>PT0S</ExecutionTimeLimit><Priority>7</Priority></Settings>\r\n" +
                "  <Actions Context=\"Author\"><Exec><Command>" + X(exe) + "</Command><Arguments>--task</Arguments><WorkingDirectory>" + X(Path.GetDirectoryName(exe)) + "</WorkingDirectory></Exec></Actions>\r\n" +
                "</Task>\r\n";
            string tmp = Path.Combine(Path.GetTempPath(), "nexus_task.xml");
            File.WriteAllText(tmp, xml, Encoding.Unicode);
            int rc = RunHidden("schtasks.exe", "/create /tn \"" + TASK + "\" /xml \"" + tmp + "\" /f");
            try { File.Delete(tmp); } catch { }
            return rc == 0;
        }

        static void SetRunKey(bool on)
        {
            using (RegistryKey k = Registry.CurrentUser.OpenSubKey(RUNKEY, true) ?? Registry.CurrentUser.CreateSubKey(RUNKEY))
            {
                if (on) k.SetValue("NEXUS Monitor", "\"" + Application.ExecutablePath + "\" --autostart");
                else if (k.GetValue("NEXUS Monitor") != null) k.DeleteValue("NEXUS Monitor", false);
            }
        }

        // Ao arrancar: se o NEXUS mudou de pasta (instalação nova/atualização), o arranque automático e a tarefa
        // passam a apontar para este .exe; e fica escrito nos Documentos onde está instalado (o ATUALIZAR usa isto).
        public static void RepairPaths()
        {
            try
            {
                Directory.CreateDirectory(Dir);
                File.WriteAllText(Path.Combine(Dir, "pasta.txt"), AppDomain.CurrentDomain.BaseDirectory.TrimEnd('\\'));
            }
            catch { }
        }

        // a tarefa "sem aviso" aponta para ESTE .exe? (depois de mudar de pasta ainda pode apontar para a antiga)
        public static bool TaskPointsHere()
        {
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo("schtasks.exe", "/query /tn \"" + TASK + "\" /xml");
                psi.UseShellExecute = false; psi.CreateNoWindow = true; psi.RedirectStandardOutput = true;
                using (Process p = Process.Start(psi))
                {
                    string xml = p.StandardOutput.ReadToEnd();
                    p.WaitForExit(5000);
                    int a = xml.IndexOf("<Command>"), b = xml.IndexOf("</Command>");
                    if (a < 0 || b < a) return false;
                    string cmd = System.Net.WebUtility.HtmlDecode(xml.Substring(a + 9, b - a - 9)).Trim('"', ' ');
                    return string.Equals(Path.GetFullPath(cmd), Path.GetFullPath(Application.ExecutablePath), StringComparison.OrdinalIgnoreCase);
                }
            }
            catch { return false; }
        }

        // aplica as opções ao sistema; devolve uma mensagem para a página
        public static string Apply()
        {
            bool wantTask = NoPrompt && Program.FullMode;
            if (wantTask)
            {
                if (!Program.IsAdmin()) return "Precisa de administrador para criar a tarefa.";
                if (!CreateTask(AutoStart)) return "Não consegui criar a tarefa agendada.";
                SetRunKey(false);
                return AutoStart ? "Arranca com o Windows como administrador, sem aviso." : "Abre como administrador sem aviso.";
            }
            if (TaskExists())
            {
                if (Program.IsAdmin()) RunHidden("schtasks.exe", "/delete /tn \"" + TASK + "\" /f");
            }
            SetRunKey(AutoStart);
            if (AutoStart && Program.FullMode) return "Arranca com o Windows (vai pedir permissão de administrador).";
            return AutoStart ? "Arranca com o Windows." : "Não arranca com o Windows.";
        }

        static bool? Q(string path, string key)
        {
            int qi = path.IndexOf('?');
            if (qi < 0) return null;
            foreach (string part in path.Substring(qi + 1).Split('&'))
            {
                string[] kv = part.Split('=');
                if (kv.Length == 2 && kv[0] == key) return kv[1] == "1" || kv[1] == "true";
            }
            return null;
        }

        static int? QI(string path, string key)
        {
            int qi = path.IndexOf('?');
            if (qi < 0) return null;
            foreach (string part in path.Substring(qi + 1).Split('&'))
            {
                string[] kv = part.Split('=');
                int v;
                if (kv.Length == 2 && kv[0] == key && int.TryParse(kv[1], out v)) return v;
            }
            return null;
        }

        static string CleanVer(string v) { return new string((v ?? "").Trim().Where(c => char.IsDigit(c) || c == '.').Take(16).ToArray()); }
        static string QS(string path, string key)
        {
            int qi = path.IndexOf('?');
            if (qi < 0) return null;
            foreach (string part in path.Substring(qi + 1).Split('&'))
            {
                int e = part.IndexOf('=');
                if (e > 0 && part.Substring(0, e) == key) { try { return Uri.UnescapeDataString(part.Substring(e + 1)); } catch { return null; } }
            }
            return null;
        }

        public static string Update(string path)
        {
            bool? tu = Q(path, "tutorial");
            string nsv = QS(path, "newsseen");
            if (tu.HasValue || nsv != null)
            {
                if (tu.HasValue) TutorialDone = tu.Value;
                if (nsv != null) NewsSeen = CleanVer(nsv);
                try { Save(); } catch (Exception ex) { return "Não consegui guardar: " + ex.Message; }
                return "Guardado.";
            }
            int? rd = QI(path, "rgbdelay");
            if (rd.HasValue)
            {
                RgbDelay = Math.Max(0, Math.Min(1000, rd.Value));
                try { Save(); } catch (Exception ex) { return "Não consegui guardar: " + ex.Message; }
                return "Guardado.";
            }
            bool? rg = Q(path, "rgbsync");
            if (rg.HasValue)
            {
                if (rg.Value && !global::Nexus.RgbSync.SignalInstalled) return "O SignalRGB não está instalado neste PC.";
                RgbSync = rg.Value;
                if (RgbSync) global::Nexus.RgbSync.InstallPlugin();
                global::Nexus.RgbSync.SetActive(RgbSync);
                try { Save(); } catch (Exception ex) { return "Não consegui guardar: " + ex.Message; }
                return RgbSync ? "Cores do SignalRGB ligadas." : "Cores do SignalRGB desligadas.";
            }
            bool? sh = Q(path, "showhidden");
            if (sh.HasValue)
            {
                ShowHidden = sh.Value;
                try { Save(); } catch (Exception ex) { return "Não consegui guardar: " + ex.Message; }
                return ShowHidden ? "Ficheiros ocultos visíveis no analisador de disco." : "Ficheiros ocultos censurados no analisador de disco.";
            }
            bool? ovOn = Q(path, "overlay"), ovGo = Q(path, "ov_gameonly");
            string ovIt = QS(path, "ov_items"), ovSt = QS(path, "ov_style"), ovK = QS(path, "ov_key");
            int? ovX = QI(path, "ov_x"), ovY = QI(path, "ov_y"), ovS = QI(path, "ov_scale"), ovO = QI(path, "ov_op");
            if (ovOn.HasValue || ovGo.HasValue || ovIt != null || ovSt != null || ovK != null || ovX.HasValue || ovY.HasValue || ovS.HasValue || ovO.HasValue)
            {
                if (ovOn.HasValue) OverlayOn = ovOn.Value;
                if (ovGo.HasValue) OverlayGameOnly = ovGo.Value;
                if (ovIt != null) OverlayItems = string.Join(",", ovIt.Split(',').Select(oz => oz.Trim().ToLowerInvariant()).Where(oz => System.Text.RegularExpressions.Regex.IsMatch(oz, "^[a-z]{1,8}$")).Distinct().ToArray());
                if (ovSt != null) OverlayStyle = ovSt == "row" ? "row" : "col";
                if (ovK != null) { string okey = ovK.Trim().ToLowerInvariant(); if (okey == "" || GameOverlay.ParseKey(okey) != null) OverlayKey = okey; }
                if (ovX.HasValue) OverlayX = Math.Max(0, Math.Min(1000, ovX.Value));
                if (ovY.HasValue) OverlayY = Math.Max(0, Math.Min(1000, ovY.Value));
                if (ovS.HasValue) OverlayScale = Math.Max(60, Math.Min(220, ovS.Value));
                if (ovO.HasValue) OverlayOp = Math.Max(15, Math.Min(100, ovO.Value));
                try { Save(); } catch (Exception ex) { return "Não consegui guardar: " + ex.Message; }
                Program.Ui(GameOverlay.Apply);
                if (ovOn.HasValue) return OverlayOn ? "Overlay ligado." : "Overlay desligado.";
                return "Guardado.";
            }
            string um = QS(path, "uimode");
            if (um == "simple" || um == "full")
            {
                UiMode = um;
                try { Save(); } catch (Exception ex) { return "Não consegui guardar: " + ex.Message; }
                return UiMode == "simple" ? "Modo simples ligado." : "Modo completo ligado.";
            }
            bool? tp = Q(path, "turbo_prio"), tw = Q(path, "turbo_power"), tr = Q(path, "turbo_ram");
            if (tp.HasValue || tw.HasValue || tr.HasValue)
            {
                if (tp.HasValue) TurboPrio = tp.Value;
                if (tw.HasValue) TurboPower = tw.Value;
                if (tr.HasValue) TurboRam = tr.Value;
                try { Save(); } catch (Exception ex) { return "Não consegui guardar: " + ex.Message; }
                return "Guardado.";
            }
            bool? rc = Q(path, "ramclean"), gm = Q(path, "gamemode");
            int? rp = QI(path, "ramclean_pct"), rm2 = QI(path, "ramclean_min");
            string ga = QS(path, "gameapps"), gs = QS(path, "gameskip");
            if (rc.HasValue || gm.HasValue || rp.HasValue || rm2.HasValue || ga != null || gs != null)
            {
                if (rc.HasValue) RamClean = rc.Value;
                if (rp.HasValue) RamCleanPct = Math.Max(30, Math.Min(98, rp.Value));
                if (rm2.HasValue) RamCleanMin = Math.Max(1, Math.Min(120, rm2.Value));
                if (gm.HasValue) GameMode = gm.Value;
                if (ga != null) GameApps = CleanApps(ga);
                if (gs != null) GameSkip = CleanApps(gs);
                try { Save(); } catch (Exception ex) { return "Não consegui guardar: " + ex.Message; }
                if (gm.HasValue) return GameMode ? "Deteção de jogo ligada." : "Deteção de jogo desligada.";
                if (rc.HasValue) return RamClean ? "Limpeza automática da RAM ligada." : "Limpeza automática da RAM desligada.";
                return "Guardado.";
            }
            bool? al = Q(path, "alerts");
            int? ac = QI(path, "alert_cpu"), ag = QI(path, "alert_gpu"), ar = QI(path, "alert_ram"), asec = QI(path, "alert_secs"), asg = QI(path, "alert_secs_game"), aop = QI(path, "alert_op"), aopg = QI(path, "alert_op_game");
            bool onlyAlerts = al.HasValue || ac.HasValue || ag.HasValue || ar.HasValue || asec.HasValue || asg.HasValue || aop.HasValue || aopg.HasValue;
            if (asec.HasValue) AlertSecs = Math.Max(3, Math.Min(300, asec.Value));
            if (asg.HasValue) AlertSecsGame = Math.Max(3, Math.Min(300, asg.Value));
            if (aop.HasValue) AlertOp = Math.Max(15, Math.Min(100, aop.Value));
            if (aopg.HasValue) AlertOpGame = Math.Max(15, Math.Min(100, aopg.Value));
            if (al.HasValue) Alerts = al.Value;
            if (ac.HasValue) AlertCpu = Math.Max(40, Math.Min(110, ac.Value));
            if (ag.HasValue) AlertGpu = Math.Max(40, Math.Min(110, ag.Value));
            if (ar.HasValue) AlertRam = Math.Max(10, Math.Min(100, ar.Value));
            bool? rm = Q(path, "remote"), nt = Q(path, "newtoken");
            if (rm.HasValue || (nt.HasValue && nt.Value))
            {
                string rmsg = null;
                if (string.IsNullOrEmpty(Token) || (nt.HasValue && nt.Value)) Token = NewToken();
                if (rm.HasValue && rm.Value != Remote)
                {
                    Remote = rm.Value;
                    rmsg = SetFirewall(Remote);
                    Program.RestartListener();
                }
                try { Save(); } catch { }
                return rmsg ?? (Remote ? (nt.HasValue && nt.Value ? "Novo código criado - o telemóvel tem de ler o QR outra vez." :
                                          "Acesso pelo telemóvel ligado. Lê o QR code com o telemóvel (mesma rede Wi-Fi).")
                                       : "Acesso pelo telemóvel desligado.");
            }
            if (onlyAlerts && Q(path, "autostart") == null)
            {
                try { Save(); return "Alertas guardados."; } catch (Exception ex) { return "Não consegui guardar: " + ex.Message; }
            }
            bool? a = Q(path, "autostart"), m = Q(path, "minimized"), n = Q(path, "noprompt");
            if (a.HasValue) AutoStart = a.Value;
            if (m.HasValue) Minimized = m.Value;
            if (n.HasValue) NoPrompt = n.Value && Program.FullMode;
            string msg;
            try { msg = Apply(); } catch (Exception ex) { msg = "Erro: " + ex.Message; }
            try { Save(); } catch (Exception ex) { msg = "Não consegui guardar: " + ex.Message; }
            return msg;
        }

        public static string Json() { return Json(null, false); }
        public static string Json(string msg) { return Json(msg, true); }
        public static string Json(string msg, bool includeSecret)
        {
            Func<bool, string> b = x => x ? "true" : "false";
            string url = Remote && includeSecret ? RemoteUrl() : null;
            return "{\"autostart\":" + b(AutoStart) + ",\"minimized\":" + b(Minimized) + ",\"noprompt\":" + b(NoPrompt) +
                   ",\"remote\":" + b(Remote) + ",\"remote_url\":" + (url == null ? "null" : "\"" + url + "\"") +
                   ",\"lan_ip\":" + (includeSecret ? "\"" + (LanIp() ?? "") + "\"" : "null") +
                   ",\"fps_source\":\"" + PresentMonReader.Status.Replace("\"", "'") + "\"" +
                   ",\"alerts\":" + b(Alerts) + ",\"alert_cpu\":" + AlertCpu + ",\"alert_gpu\":" + AlertGpu + ",\"alert_ram\":" + AlertRam + ",\"alert_secs\":" + AlertSecs + ",\"alert_secs_game\":" + AlertSecsGame + ",\"alert_op\":" + AlertOp + ",\"alert_op_game\":" + AlertOpGame +
                   ",\"full\":" + b(Program.FullMode) + ",\"admin\":" + b(Program.IsAdmin()) + ",\"ui_ver\":" + uiVer +
                   ",\"ramclean\":" + b(RamClean) + ",\"ramclean_pct\":" + RamCleanPct + ",\"ramclean_min\":" + RamCleanMin + ",\"gamemode\":" + b(GameMode) + ",\"showhidden\":" + b(ShowHidden) + ",\"rgbsync\":" + b(RgbSync) + ",\"has_srgb\":" + b(Modules.SignalRgb) + ",\"has_sdeck\":" + b(Modules.StreamDeck) + ",\"tutorial\":" + b(TutorialDone) + ",\"uimode\":\"" + UiMode + "\",\"overlay\":" + b(OverlayOn) + ",\"ov_gameonly\":" + b(OverlayGameOnly) +
                   ",\"ov_items\":\"" + OverlayItems + "\",\"ov_style\":\"" + OverlayStyle + "\",\"ov_key\":\"" + OverlayKey + "\",\"ov_keyok\":" + b(GameOverlay.KeyOk) +
                   ",\"ov_x\":" + OverlayX + ",\"ov_y\":" + OverlayY + ",\"ov_scale\":" + OverlayScale + ",\"ov_op\":" + OverlayOp + ",\"turbo_prio\":" + b(TurboPrio) + ",\"turbo_power\":" + b(TurboPower) + ",\"turbo_ram\":" + b(TurboRam) + ",\"newsseen\":\"" + NewsSeen + "\",\"ver\":\"" + Assembly.GetExecutingAssembly().GetName().Version.ToString(3) + "\"" + ",\"rgbdelay\":" + RgbDelay +
                   ",\"gameapps\":[" + string.Join(",", GameApps.Select(x => "\"" + x.Replace("\\", "\\\\").Replace("\"", "\\\"") + "\"").ToArray()) + "]" +
                   ",\"gameskip\":[" + string.Join(",", GameSkip.Select(x => "\"" + x.Replace("\\", "\\\\").Replace("\"", "\\\"") + "\"").ToArray()) + "]" +
                   ",\"opt\":" + Optimizer.Json() +
                   ",\"message\":" + (msg == null ? "null" : "\"" + msg.Replace("\\", "\\\\").Replace("\"", "\\\"") + "\"") + "}";
        }
    }

    // ---------------------------------------------------------------- analisador de disco (gdu, open-source MIT)
    // só corre quando o utilizador carrega em "Analisar"; o gdu fecha no fim e a análise é apagada da memória
    // quando já não é usada (15 min) ou quando o utilizador a fecha

    // ------------------------------------------------------------ idiomas (o mesmo dicionário da página: i18n.js)
    static class Lang
    {
        static readonly string[] Codes = { "pt", "en", "es", "fr", "de" };
        static readonly Dictionary<string, Dictionary<string, string>> dicts = new Dictionary<string, Dictionary<string, string>>();
        static readonly System.Text.RegularExpressions.Regex Num = new System.Text.RegularExpressions.Regex(@"\d+(?:[.,  ]\d+)*");

        public static string Pick(string l)
        {
            l = (l ?? "").Trim().ToLowerInvariant();
            if (l == "" || l == "auto") return "";
            if (l.Length > 2) l = l.Substring(0, 2);
            return Codes.Contains(l) ? l : "en";
        }
        public static string Current
        {
            get
            {
                string l = AppSettings.Lang;
                if (string.IsNullOrEmpty(l)) { l = Pick(CultureInfo.CurrentUICulture.TwoLetterISOLanguageName); if (l == "") l = "en"; }
                return l;
            }
        }

        // lê {"en":{"pt":"en",...},...} do i18n.js
        public static void Load(string js)
        {
            if (string.IsNullOrEmpty(js)) return;
            int i = js.IndexOf('{');
            if (i < 0) return;
            try
            {
                i++;
                while (true)
                {
                    Ws(js, ref i);
                    if (js[i] == '}') break;
                    if (js[i] == ',') { i++; continue; }
                    string code = Str(js, ref i); Ws(js, ref i); i++; Ws(js, ref i); i++;   // :{
                    Dictionary<string, string> d = new Dictionary<string, string>();
                    while (true)
                    {
                        Ws(js, ref i);
                        if (js[i] == '}') { i++; break; }
                        if (js[i] == ',') { i++; continue; }
                        string k = Str(js, ref i); Ws(js, ref i); i++; Ws(js, ref i);
                        d[k] = Str(js, ref i);
                    }
                    dicts[code] = d;
                }
            }
            catch { }
        }
        static void Ws(string s, ref int i) { while (i < s.Length && char.IsWhiteSpace(s[i])) i++; }
        static string Str(string s, ref int i)
        {
            StringBuilder sb = new StringBuilder();
            i++;   // "
            while (s[i] != '"')
            {
                if (s[i] == '\\')
                {
                    i++;
                    char c = s[i];
                    if (c == 'n') sb.Append('\n'); else if (c == 't') sb.Append('\t');
                    else if (c == 'u') { sb.Append((char)Convert.ToInt32(s.Substring(i + 1, 4), 16)); i += 4; }
                    else sb.Append(c);
                }
                else sb.Append(s[i]);
                i++;
            }
            i++;
            return sb.ToString();
        }

        // traduz um texto escrito em PT-PT (números trocados por # para procurar)
        public static string L(string pt)
        {
            if (string.IsNullOrEmpty(pt)) return pt;
            Dictionary<string, string> d;
            if (!dicts.TryGetValue(Current, out d)) return pt;
            string core = pt.Trim();
            if (core.Length == 0) return pt;
            string lead = pt.Substring(0, pt.Length - pt.TrimStart().Length), trail = pt.Substring(pt.TrimEnd().Length);
            string r = Find(d, core);
            if (r == null)
            {
                System.Text.RegularExpressions.Match m = System.Text.RegularExpressions.Regex.Match(core, @"^([^\p{L}\p{N}]+)(.*)$");
                if (m.Success) { string r2 = Find(d, m.Groups[2].Value); if (r2 != null) r = m.Groups[1].Value + r2; }
            }
            return r == null ? pt : lead + r + trail;
        }
        static string Find(Dictionary<string, string> d, string core)
        {
            string r;
            if (d.TryGetValue(core, out r)) return r;
            System.Text.RegularExpressions.MatchCollection ms = Num.Matches(core);
            if (ms.Count == 0) return null;
            if (!d.TryGetValue(Num.Replace(core, "#"), out r)) return null;
            int k = 0;
            return System.Text.RegularExpressions.Regex.Replace(r, "#", delegate { return k < ms.Count ? ms[k++].Value : "#"; });
        }
    }

    // ---------------------------------------------------------------- desinstalador de programas (Deep Scan)
    // Lista o que o Windows tem instalado (registo + apps da Loja), corre o desinstalador oficial e depois procura
    // os restos à mão: pastas, atalhos, registo, serviços, tarefas, arranque e firewall. Tudo local, sem add-ons.
    // Segurança: ficheiros vão para a Reciclagem, o registo é exportado para .reg antes de apagar, e nunca toca
    // no Windows, em pastas de sistema nem em coisas de outros programas instalados.

    // Abrir o Explorador sempre em primeiro plano. O Windows não deixa um programa em segundo plano (o NEXUS)
    // trazer janelas para a frente, por isso: espera pela janela do Explorador e força-a para a frente
    // (a tecla Alt "desbloqueia" o SetForegroundWindow e o AttachThreadInput liga-nos à janela da frente).
    // módulos opcionais instalados neste PC: o que fala deles (opções, tutorial, novidades) só aparece se existirem
    static class Modules
    {
        static DateTime t = DateTime.MinValue;
        static bool srgb, sdeck;
        static void Check()
        {
            if ((DateTime.UtcNow - t).TotalSeconds < 30) return;
            t = DateTime.UtcNow;
            try { srgb = global::Nexus.RgbSync.SignalInstalled; } catch { srgb = false; }
            try
            {
                string ad = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                string pf = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
                sdeck = Directory.Exists(Path.Combine(ad, "Elgato", "StreamDeck")) || File.Exists(Path.Combine(pf, "Elgato", "StreamDeck", "StreamDeck.exe"))
                        || Process.GetProcessesByName("StreamDeck").Length > 0;
            }
            catch { sdeck = false; }
        }
        public static bool SignalRgb { get { Check(); return srgb; } }
        public static bool StreamDeck { get { Check(); return sdeck; } }
    }

    static class Front
    {
        [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc cb, IntPtr lp);
        delegate bool EnumProc(IntPtr h, IntPtr lp);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(IntPtr h, StringBuilder sb, int max);
        [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
        [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
        [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr h, int cmd);
        [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr h);
        [DllImport("user32.dll")] static extern bool BringWindowToTop(IntPtr h);
        [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, IntPtr pid);
        [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();
        [DllImport("user32.dll")] static extern bool AttachThreadInput(uint a, uint b, bool attach);
        [DllImport("user32.dll")] static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);
        [DllImport("user32.dll")] static extern bool AllowSetForegroundWindow(int pid);

        static List<IntPtr> ExplorerWindows()
        {
            List<IntPtr> l = new List<IntPtr>();
            EnumWindows((h, lp) =>
            {
                if (!IsWindowVisible(h)) return true;
                StringBuilder sb = new StringBuilder(64); GetClassName(h, sb, 64);
                string c = sb.ToString();
                if (c == "CabinetWClass" || c == "ExploreWClass") l.Add(h);
                return true;
            }, IntPtr.Zero);
            return l;
        }

        public static void Explorer(string args)
        {
            List<IntPtr> before = ExplorerWindows();
            IntPtr topBefore = before.Count > 0 ? before[0] : IntPtr.Zero;   // EnumWindows vai da frente para trás
            try { AllowSetForegroundWindow(-1); } catch { }
            Process.Start("explorer.exe", args);
            new Thread(() =>
            {
                // janela nova ou (se a pasta já estava aberta) a janela do Explorador que o Windows reutilizou
                for (int i = 0; i < 40; i++)
                {
                    Thread.Sleep(100);
                    List<IntPtr> now = ExplorerWindows();
                    IntPtr w = now.FirstOrDefault(h => !before.Contains(h));
                    if (w == IntPtr.Zero && i >= 12 && now.Count > 0) w = now[0];
                    if (w == IntPtr.Zero) continue;
                    Raise(w);
                    return;
                }
            }) { IsBackground = true }.Start();
        }

        public static void Raise(IntPtr w)
        {
            try
            {
                if (IsIconic(w)) ShowWindow(w, 9);           // SW_RESTORE
                IntPtr fg = GetForegroundWindow();
                uint me = GetCurrentThreadId(), them = fg == IntPtr.Zero ? 0 : GetWindowThreadProcessId(fg, IntPtr.Zero);
                bool att = them != 0 && them != me && AttachThreadInput(me, them, true);
                keybd_event(0x12, 0, 0, UIntPtr.Zero);         // Alt carregado...
                keybd_event(0x12, 0, 2, UIntPtr.Zero);         // ...e largado
                BringWindowToTop(w);
                SetForegroundWindow(w);
                ShowWindow(w, 5);                              // SW_SHOW
                if (att) AttachThreadInput(me, them, false);
            }
            catch { }
        }
    }
}
